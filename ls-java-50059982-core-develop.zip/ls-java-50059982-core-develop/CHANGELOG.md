## Release 8.0.0
* [ESPC360-11896](https://sanes.atlassian.net/browse/ESPC360-11896)
  * [Migrar Darwin 4.x] ls-java-50059982-core

## Release 3.178.0 (6.1.2)
* [ESPC360-8570](https://sanes.atlassian.net/browse/ESPC360-8570)
  * [Global PG] - Incluir el resto de tipologías en el filtro de contratos carterizados
## Release 6.1.1
* [CACHE] Se incluye Serializable a clase IntervenerInfo.
## Release 3.176.0 (6.1.0)
* [ESPC360-5203](https://sanes.atlassian.net/browse/ESPC360-5203)
  * [CACHE] - Optimizar caché librería product-commons

## Release 6.0.6
* [ESPC360-7600](https://sanes.atlassian.net/browse/ESPC360-7600)
  * Se incluye un nuevo filtro por tipo de cartera
## Release 6.0.5
* [ESPC360-5798](https://sanes.atlassian.net/browse/ESPC360-5798)
  * Add connectTimeout and readTimeout params
## Release 6.0.2
* [ESPC360-5523](https://sanes.atlassian.net/browse/ESPC360-5523)
  * Implementación reactiva completa
## Release 6.0.1
* Hotfix RestTemplate original Darwin client restablished
## Release 6.0.0
* [ESPC360-4280](https://sanes.atlassian.net/browse/ESPC360-4280)
  * Implementación reactiva parcial

## Release 5.0.2
* Hotfix RestTemplate original Darwin client restablished

## Release 3.165.0
* [PORTALADN-38898](https://sanes.atlassian.net/browse/PORTALADN-38898)
  * Integrar migraciones Darwin 3.2 (1/2)
  
## Release 4.1.0
* Se desacopla de la dependencia adn360-mongodb-starter
  * Ahora el conector de mongo es provided, el micro que tenga conexión con mongo debe declarar su propio conector.
  
## Release 3.129.0
* [PORTALADN-31414](https://sanes.atlassian.net/browse/PORTALADN-31414)
  Actualización a Darwin 3.0.4

## Release 3.0.17
* Se agregan métodos de utilidad para canales.
## Release 3.0.16
* [#29325] Se cambia la respuesta de X-santander-channel requerida de html a json
## Release 3.0.13
* [#26588] Incluida configuración en conector mongo para que se publiquen el número de conexiones abiertas en el pool.
