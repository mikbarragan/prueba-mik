package es.santander.adn360.core;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
class ApplicationTestMock {

	public static void main(String[] args) {
		SpringApplication.run(ApplicationTestMock.class, args);
	}
}
