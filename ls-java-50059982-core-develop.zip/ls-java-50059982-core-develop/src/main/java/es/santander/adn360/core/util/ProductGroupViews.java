package es.santander.adn360.core.util;

/**
 * The product basic class
 */
public class ProductGroupViews {

    /**
     * The basic class
     */
    public interface Basic {
    }

    /**
     * The full class
     */
    public static class Full implements Basic {
    }

}
