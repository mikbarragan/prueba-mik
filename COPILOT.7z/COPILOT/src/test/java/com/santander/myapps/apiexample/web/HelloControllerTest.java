package com.santander.myapps.apiexample.web;

import org.junit.jupiter.api.Test;
import org.springframework.test.web.reactive.server.WebTestClient;

class HelloControllerTest {

    @Test
    void callHelloEndpoint() {

        WebTestClient.bindToController(HelloController.class).build().get().uri("/api-example/hello")
                .exchange()
                .expectStatus().isOk()
                .expectBody(String.class).isEqualTo("Hello world!");
    }
}