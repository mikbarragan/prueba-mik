package com.santander.myapps.apiexample.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.Operation;
import io.swagger.v3.oas.models.PathItem;
import io.swagger.v3.oas.models.Paths;
import io.swagger.v3.oas.models.parameters.Parameter;
import org.junit.jupiter.api.Test;
import org.springdoc.core.models.GroupedOpenApi;
import org.springframework.boot.autoconfigure.AutoConfigurations;
import org.springframework.boot.test.context.runner.WebApplicationContextRunner;

import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertTrue;

class SwaggerConfigTest {

    
        private WebApplicationContextRunner applicationContextRunner = new WebApplicationContextRunner()
            .withConfiguration(AutoConfigurations.of(SwaggerConfig.class));
    
    @Test
    void isSwaggerConfigPresent() {
        this.applicationContextRunner.run((context) -> {
            assertThat(context).hasBean("swaggerConfig");
            assertThat(context).hasBean("apiInfo");
            assertThat(context).hasBean("api");

            // OpenAPI assert
            OpenAPI openAPI = (OpenAPI) context.getBean("apiInfo");
            assertTrue(openAPI.getInfo().getTitle().contains("api-example"));
            assertTrue(openAPI.getInfo().getVersion().contains("1.0.0-SNAPSHOT"));
            assertTrue(openAPI.getComponents().getSecuritySchemes().containsKey("BearerAuth"));

            // GroupedOpenApi assert
            GroupedOpenApi groupedOpenApi = (GroupedOpenApi) context.getBean("api");
            assertThat(groupedOpenApi).isNotNull();
            assertTrue(groupedOpenApi.getGroup().equalsIgnoreCase("api-web"));
            assertTrue(groupedOpenApi.getPackagesToScan().contains("com.santander.myapps.apiexample.web"));

            // OpenApiCustomiser assert
            PathItem pathItem = new PathItem();
            pathItem.operation(PathItem.HttpMethod.GET, new Operation());
            openAPI.setPaths(new Paths().addPathItem("test", pathItem));
            groupedOpenApi.getOpenApiCustomizers().forEach(openApiCustomizer ->
                    assertDoesNotThrow(() ->
                            openApiCustomizer.customise(openAPI)));

            //openAPI headers assert
            Map<String, Parameter> oc = openAPI.getComponents().getParameters();
            assertTrue(oc.containsKey("Contact-Point"));
            assertTrue(oc.containsKey("Session-Id"));
            assertTrue(oc.containsKey("User-Agent"));
            assertTrue(oc.containsKey("app-init"));
            assertTrue(oc.containsKey("X-B3-TraceId"));
            assertTrue(oc.containsKey("X-B3-SpanId"));
            assertTrue(oc.containsKey("X-ClientId"));
            assertTrue(oc.containsKey("X-Santander-Channel"));
            assertTrue(oc.containsKey("organization"));

        });
    }

}
