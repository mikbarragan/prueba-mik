package com.santander.myapps.apiexample.model;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "personas")
public class Persona {
    @JsonProperty("tipoPersona")
    private String tipoPersona;
    @JsonProperty("codigoPersona")
    private String codigoPersona;
    @JsonProperty("nombrePersona")
    private String nombrePersona;
    @JsonProperty("tipoDocumento")
    private String tipoDocumento;
    @JsonProperty("codDocumento")
    private String codDocumento;

    // Getters y setters
}