package com.santander.myapps.apiexample.repository;
import com.santander.myapps.apiexample.model.Persona;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

public interface PersonaRepository extends MongoRepository<Persona, String> {
    Persona findByTipoPersonaAndCodigoPersona(String tipoPersona, String codigoPersona);
}