## Release 3.173.2
* [ESPC360-6766](https://sanes.atlassian.net/browse/ESPC360-6766)
  * Se elimina obligatoriedad de la cookie en el swagger
## Release 3.173.0
* [ESPC360-5746](https://sanes.atlassian.net/browse/ESPC360-5746)
  * Kerberización de microservicios Parte (1/5) - Crear Release
## Release 3.171.0
* [ESPC360-5746](https://sanes.atlassian.net/browse/ESPC360-5746)
  * Kerberización de microservicios Parte (1/5)

## Release 3.167.0
* [ESPC360-3743](https://sanes.atlassian.net/browse/ESPC360-3743)
  * Integrar migraciones Darwin 3.2 (1/3)
## Release 3.166.0
* [PORTALADN-38898](https://sanes.atlassian.net/browse/PORTALADN-38898)
  * Integrar migraciones Darwin 3.2 (1/2)
## Release 3.164.0
* [PORTALADN-38278](https://sanes.atlassian.net/browse/PORTALADN-38278)
* Eliminar el @CrossOrigin Parte (4/5)
## Release 3.157.0
* [PORTALADN-36835](https://sanes.atlassian.net/browse/PORTALADN-36835)
  * Migración darwin 3.2
## Release 3.155.0
* [PORTALADN-37172](https://sanes.atlassian.net/browse/PORTALADN-37172)
    * Migración nombre del micro y cambios para vadeca