package es.santander.adn360.alias.config;

import org.springdoc.core.GroupedOpenApi;
import org.springdoc.core.customizers.OpenApiCustomiser;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import io.swagger.v3.oas.models.media.IntegerSchema;
import io.swagger.v3.oas.models.media.ObjectSchema;
import io.swagger.v3.oas.models.media.StringSchema;
import io.swagger.v3.oas.models.parameters.HeaderParameter;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import lombok.val;
import org.springframework.core.annotation.Order;

/**
 * The configuration of Swagger API and Swagger UI
 */
/*
 * This class may need manual changes.
 *  Only if you have multiple Docket beans replace them with GroupedOpenApi beans.
 *  review: https://springdoc.org/#migrating-from-springfox
 */
@Configuration
@Order(105)
public class SwaggerConfig {

	// TITLE
	private static final String TITLE = "ADN360 Alias service";
	// DESCRIPTION
	private static final String DESCRIPTION = "Alias service";
	// VERSION
	private static final String VERSION = "/v1";
	// TERMS
	private static final String TERMS = "";
	// CONTACT
	private static final String ADN360_NAME = "ADN360";
    private static final String ADN360_URL = "https://sanes.atlassian.net/wiki/spaces/ADN360PORTAL/overview?homepageId=8556159988";
    private static final String ADN360_EMAIL = "stadn360@gruposantander.es";
	// LICENSE
	private static final String LICENSE = "";
	// LICENSE_URL
	private static final String LICENSE_URL = "";

	/**
	 * Get Docket Bean
	 * 
	 * @return Docket
	 */
	@Bean
    public OpenAPI customOpenAPI() {

        val info = new Info()
                .title(TITLE)
                .description(DESCRIPTION)
                .version(VERSION)
                .termsOfService(TERMS)
                .contact(new Contact().name(ADN360_NAME).url(ADN360_URL).email(ADN360_EMAIL))
                .license(new License().name(LICENSE).url(LICENSE_URL));

        return new OpenAPI()
                .info(info)
                .components(new Components()
                        .addSecuritySchemes("BearerAuth", new SecurityScheme().type(SecurityScheme.Type.HTTP)
                                .scheme("bearer")
                                .bearerFormat("JWT")
                                .description("Token that contains the credentials of a user.\nIt originates from the " +
                                        "client that calls an API, either a presentation component or a microservice," +
                                        "it must be propagated through all communications.")
                        )
                        .addSchemas("ErrorModelGateway", new ObjectSchema()
                                .description("Generic Darwin Gateway error")
                                .addProperties("httpCode", new IntegerSchema()
                                        .description("Http error code").example("404")
                                )
                                .addProperties("httpMessage", new StringSchema()
                                        .description("Short description of the error").example("Not Found")
                                )
                                .addProperties("moreInformation", new StringSchema()
                                        .description("Long description of the error")
                                        .example("Not Found in /v1/applications//gateways//subscriptors")
                                )
                        )
                ).addSecurityItem(new SecurityRequirement().addList("BearerAuth"));


    }
    /**
     * Add all default arquitecture headears
     * @return OpenApiCustomiser
     */
    @Bean
    public OpenApiCustomiser customerGlobalHeaderOpenApiCustomiser() {

        return (OpenAPI openApi) -> {
            openApi.components(openApi.getComponents()
                    .addParameters("Authorization", new HeaderParameter()
                            .required(Boolean.FALSE)
                            .name("Authorization")
                            .description("String containing the authorization OAuth2 token with the\n" +
                                    "following structure: token type + space character + access token. [Ex .:\n" +
                                    "\"Bearer AbCDeFg1hiJkLmN2opQrsTuvWxyZ\" (omit quotes)]")
                            .schema(new StringSchema())
                    )
                    .addParameters("X-ClientId", new HeaderParameter()
                            .required(Boolean.FALSE)
                            .name("X-ClientId")
                            .description("\t\n" +
                                    "Identify the calling application.\n" +
                                    "\n" +
                                    "It originates from the client that calls an API, either a presentation component or a microservice.")
                            .schema(new StringSchema())
                            .example("regapi")
                    )
                    .addParameters("Cookie", new HeaderParameter()
                            .required(Boolean.FALSE)
                            .name("Cookie")
                            .description("Character string containing the authorization cookie.")
                            .schema(new StringSchema())
                    )
                    .addParameters("X-Santander-Channel", new HeaderParameter()
                            .required(Boolean.FALSE)
                            .name("X-Santander-Channel")
                            .description("\t\n" +
                                    "Identify the channel through which the user interacts.\n" +
                                    "\n" +
                                    "It originates from the web gateway that creates it from the user's credential, it must be propagated in all communications.")
                            .schema(new StringSchema())
                            .example("INT")
                    )
            );

            openApi.getPaths().values().stream().flatMap(pathItem -> pathItem.readOperations().stream())
                    .forEach(operation -> {
                        operation.addParametersItem(new HeaderParameter().$ref("#/components/parameters/Authorization"));
                        operation.addParametersItem(new HeaderParameter().$ref("#/components/parameters/X-ClientId"));
                        operation.addParametersItem(new HeaderParameter().$ref("#/components/parameters/X-Santander-Channel"));
                        operation.addParametersItem(new HeaderParameter().$ref("#/components/parameters/Cookie"));
                    });
        };
    }

    /**
     * Creates Springdoc object
     * where the API Documentation is grouped
     * by package and path pattern
     *
     * @return GroupedOpenApi
     */
    @Bean
    public GroupedOpenApi api() {
        return GroupedOpenApi.builder()
                .group("api-web")
                .packagesToScan("es.santander.adn360.alias.web")
                .addOpenApiCustomiser(customerGlobalHeaderOpenApiCustomiser())
                .build();
    }

}