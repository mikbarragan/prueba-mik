package es.santander.adn360.alias.web;

import java.util.List;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Data;

/**
 * 
 * class Aliasparams
 *
 */
@Data
@Builder
public class Aliasparams {
	// internal_user
	@NotEmpty
	@Pattern(regexp = "^[a-zA-Z0-9]{1,15}$")
	@Schema(description = "Variable for the internal user")
	private String internal_user;

	// id_list
	@NotNull
	@Size(min = 1)
	@Schema(description = "Variable for the id's list")
	private List<String> id_list;

	// global_position
	@Pattern(regexp = "^[0-9]{1,2}$")
	@Schema(description = "Variable for the global position")
	private String global_position;

	// alias
	/* filter for alias */
	@Schema(description = "Variable for the alias")
	private String alias;
}
