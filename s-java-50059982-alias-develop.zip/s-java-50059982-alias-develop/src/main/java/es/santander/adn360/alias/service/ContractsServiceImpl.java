package es.santander.adn360.alias.service;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import es.santander.adn360.alias.domain.ContractAlias;
import es.santander.adn360.alias.repository.ContractsRepository;
import es.santander.adn360.alias.web.Aliasparams;
import es.santander.adn360.core.web.WebUtils;

/**
 * Implementation of the interface of ContractsService dedicated to managing and
 * obtaining data from a list of contract aliases
 **/
@Service
public class ContractsServiceImpl implements ContractsService {
	// contractsRepository
	@Autowired
	private ContractsRepository contractsRepository;

	/**
	 * See Inherit doc
	 */
	@Override
	public Map<String, ContractAlias> findContractsAlias(Aliasparams aliasparams) {
		if (WebUtils.SANTANDER_CHANNEL_EMP.equalsIgnoreCase(WebUtils.getSantanderChannel())) {
			return contractsRepository.findContractsAliasEmp(aliasparams);
		}

		return contractsRepository.findContractsAlias(aliasparams);
	}
}