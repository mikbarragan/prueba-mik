package es.santander.adn360.alias.domain;

import java.util.Optional;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 *
 * Model to Card alias data
 *
 */
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
@EqualsAndHashCode()
public class CardAlias {

	/**
	 * pan field in mongoDb
	 */
	@JsonProperty("pan")
	@Schema(description = "Variable for the pan")
	private String pan;

	/**
	 * alias field in mongoDb
	 */
	@JsonIgnore
	private String alias;

	// aliasTarjetaEmpresa
	@JsonIgnore
	private String aliasTarjetaEmpresa;

	/**
	 * 
	 * getAlias
	 * 
	 * @return alias
	 */
	@JsonProperty("alias")
	@Schema(description = "Variable for the alias")
	public String getAlias() {
		return Optional.ofNullable(alias).orElse(aliasTarjetaEmpresa);
	}

	/**
	 * visibility_indicator field in mongoDb
	 */
	@JsonProperty("visibility_indicator")
	@Schema(description = "Variable for the visibility indicator")
	private String indicadorVisibilidad;

	/**
	 * internalUser field in mongoDb. It is not necesary to api response
	 */
	@JsonIgnore
	private String usuarioInterno;

	/**
	 * posicionGlobal field in mongoDb. It is not necesary to api response
	 */
	@JsonIgnore
	private String posicionGlobal;

}
