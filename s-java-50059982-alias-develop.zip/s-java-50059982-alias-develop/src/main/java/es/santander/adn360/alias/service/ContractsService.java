package es.santander.adn360.alias.service;

import es.santander.adn360.alias.domain.ContractAlias;
import es.santander.adn360.alias.web.Aliasparams;

import java.util.Map;

/**
 * Interface interface for the implementation of Service dedicated to managing
 * and obtaining data from a list of contract aliases
 **/
public interface ContractsService {

    /**
     * Function that searches for a list of aliases for its
     * corresponding contract and internal user
     *
     * @param aliasparams aliasparams
     * @return List of ContractsAlias entities
     */
    Map<String, ContractAlias> findContractsAlias(Aliasparams aliasparams);

}
