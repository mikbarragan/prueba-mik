package es.santander.adn360.alias.web;

import java.util.List;
import java.util.Map;

import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import es.santander.adn360.alias.domain.CardAlias;
import es.santander.adn360.alias.domain.ContractAlias;
import es.santander.adn360.alias.service.CardsService;
import es.santander.adn360.alias.service.ContractsService;
import es.santander.adn360.core.model.exception.FunctionalException;
import es.santander.adn360.core.util.ExceptionEnum;
import io.swagger.v3.oas.annotations.Operation;
import lombok.RequiredArgsConstructor;

/**
 * Controller to managing request to api alias
 */
@RestController
@RequestMapping("/alias")
@RequiredArgsConstructor
public class AliasController {

	private static final String PAN_REGEX = "^[0-9]+$";
	private static final String CONTRACT_ID_REGEX = "^[0-9]{18}$";

	private static final java.util.regex.Pattern PAN_PATTERN = java.util.regex.Pattern.compile(PAN_REGEX);
	private static final java.util.regex.Pattern CONTRACT_PATTERN = java.util.regex.Pattern.compile(CONTRACT_ID_REGEX);

	private final CardsService cardsService;
	private final ContractsService contractsService;

	/**
	 * Api querying the aliases of a list of pan numbers filtering by user and
	 * global position
	 * 
	 * @param aliasparams
	 *            list of pans, internal user and global position params
	 * @return CardsAliasResponse objects with cards list aliases
	 */
	@Operation(summary="Query the aliases of a list of pan numbers filtering by user and global position")
	@PostMapping(path = "/cards")
	public Map<String, CardAlias> findAliasCards(@Validated @RequestBody Aliasparams aliasparams) {

		listValidation(aliasparams.getId_list(), PAN_PATTERN);

		return cardsService.findCardsAlias(aliasparams);
	}

	/**
	 * Api querying the aliases of a list of contract id numbers filtering by user
	 * and global position
	 * 
	 * @param aliasparams
	 *            list of contract ids, internal user and global position params
	 * @return ContractsAliasResponse objects with contract list aliases
	 */
	@Operation(summary="Query the aliases of a list of contract id numbers filtering by user and global position.")
	@PostMapping(path = "/contracts")
	public Map<String, ContractAlias> findAliasContracts(@Validated @RequestBody Aliasparams aliasparams) {

		listValidation(aliasparams.getId_list(), CONTRACT_PATTERN);

		return contractsService.findContractsAlias(aliasparams);
	}

	/**
	 * Funcion para validar que cada elemento de un parametro lista esta formado
	 * correctamente. Hay que pasarle el Regex para comprobar si está formado con el
	 * formato que es requerido
	 *
	 * TODO: De momento se tiene que hacer de esta forma por no estar actualizada la
	 * versión de Spring boot cuando se actualice la versión se actualizará la
	 * versión del Bean Validation a las 2.0 y la comprobacion se podrá hacer de la
	 * siguiente forma: List<@Pattern(regexp=PAN_REGEX) String> cardList;
	 *
	 * Mas información: https://beanvalidation.org/2.0/spec/
	 */
	private static void listValidation(final List<String> dataList, final java.util.regex.Pattern ptn) {
		dataList.stream().filter(data -> !ptn.matcher(data).find()).findAny().ifPresent(data -> {
			throw new FunctionalException(ExceptionEnum.INVALID_INPUT_PARAMETERS,
					"Element '" + data + "' is not formatted correctly");
		});
	}

}
