package es.santander.adn360.alias.web.response;

import java.util.Map;

import es.santander.adn360.alias.domain.ContractAlias;
import lombok.Builder;
import lombok.Data;

/**
 * Response to contracts api
 */
@Data
@Builder
public class ContractsAliasResponse {

	/**
	 * List of contracts response
	 */
	// contracts
	private Map<String, ContractAlias> contracts;

}
