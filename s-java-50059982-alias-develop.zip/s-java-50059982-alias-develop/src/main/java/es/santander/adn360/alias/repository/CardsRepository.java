package es.santander.adn360.alias.repository;

import es.santander.adn360.alias.domain.CardAlias;
import es.santander.adn360.alias.web.Aliasparams;

import java.util.Map;


/**
 * interface for the implementation of a repository dedicated to the collection
 * of data from collections to MongoDb
 * */
public interface CardsRepository {

    /**
     * Method that searches for a list of aliases for its corresponding card and user.
     *
     * Check if the fechaBaja is gt than now because the RT has been able to update the record and unsubscribe
     *
     * @param aliasparams aliasparams
     * @return CardAlias list
     */
    Map<String, CardAlias> findCardsAlias(Aliasparams aliasparams);

    /**
     * Method for NWE that searches for a list of aliases for its corresponding card and user.
     *
     * @param aliasparams aliasparams
     * @return CardAlias list
     */
    Map<String, CardAlias> findCardsAliasEmp(Aliasparams aliasparams);
}
