package es.santander.adn360.alias.domain;

import java.util.Optional;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 *
 * Model to Contract alias data
 *
 */
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
@EqualsAndHashCode()
public class ContractAlias {

	/**
	 * contractId field in mongoDb
	 */
	@JsonProperty("contractId")
	@Schema(description = "Variable for the contract id")
	private String idContrato;

	/**
	 * alias field in mongoDb
	 */
	@JsonIgnore
	private String alias;

	/**
	 * aliasContratoEmpresa
	 */
	@JsonIgnore
	private String aliasContratoEmpresa;

	/**
	 * getAlias
	 * 
	 * @return alias
	 */
	@JsonProperty("alias")
	@Schema(description = "Variable for the alias")
	public String getAlias() {
		return Optional.ofNullable(alias).orElse(aliasContratoEmpresa);
	}

	/**
	 * visibility_indicator field in mongoDb
	 */
	@JsonProperty("visibility_indicator")
	@Schema(description = "Variable for the visibility indicator")
	private String indicadorVisibilidad;

	/**
	 * internalUser field in mongoDb. It is not necesary to api response
	 */
	@JsonIgnore
	private String usuarioInterno;

	/**
	 * posicionGlobal field in mongoDb. It is not necesary to api response
	 */
	@JsonIgnore
	private String posicionGlobal;
}
