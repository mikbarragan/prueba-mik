package es.santander.adn360.alias.service;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import es.santander.adn360.alias.domain.CardAlias;
import es.santander.adn360.alias.repository.CardsRepository;
import es.santander.adn360.alias.web.Aliasparams;
import es.santander.adn360.core.web.WebUtils;

/**
 * Implementation of the interface of CardsService dedicated to managing and
 * obtaining data from a list of card aliases
 **/
@Service
public class CardsServiceImpl implements CardsService {
	// cardsRepository
	@Autowired
	private CardsRepository cardsRepository;

	/**
	 * See Inherit doc
	 */
	@Override
	public Map<String, CardAlias> findCardsAlias(Aliasparams aliasparams) {

		if (WebUtils.SANTANDER_CHANNEL_EMP.equalsIgnoreCase(WebUtils.getSantanderChannel())) {
			return cardsRepository.findCardsAliasEmp(aliasparams);
		}
		// Return
		return cardsRepository.findCardsAlias(aliasparams);
	}

}
