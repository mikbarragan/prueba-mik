package es.santander.adn360.alias.repository;

import es.santander.adn360.alias.domain.ContractAlias;
import es.santander.adn360.alias.web.Aliasparams;

import java.util.Map;

/**
 * interface for the implementation of a repository dedicated to the collection of data from the alias_contracts collection to MongoDb
 * */
public interface ContractsRepository {

    /**
     * Method that searches for a list of aliases for its corresponding contract and user.
     *
     * Check if the fechaBaja is gt than now because the RT has been able to update the record and unsubscribe
     *
     * @param aliasparams aliasparams
     * @return ContractsAlias list
     */
    Map<String, ContractAlias> findContractsAlias(Aliasparams aliasparams);


    /**
     * Method for NWE that searches for a list of aliases for its corresponding contract and user.
     *
     * Check if the fechaBaja is gt than now because the RT has been able to update the record and unsubscribe
     *
     * @param aliasparams aliasparams
     * @return ContractsAlias list
     */
    Map<String, ContractAlias> findContractsAliasEmp(Aliasparams aliasparams);

}
