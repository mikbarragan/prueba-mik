package es.santander.adn360.alias;

import org.springframework.boot.WebApplicationType;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;

/**
 * Class to application
 * */
@SpringBootApplication
public class Application {

    /**
     * Method where SpringApplication run
     *
     * @param args args to config springboot class run
     */
	public static void main(String[] args) {
		new SpringApplicationBuilder(Application.class)
				.web(WebApplicationType.SERVLET)
				.run(args);
	}
}
