package es.santander.adn360.alias.repository;

import static org.springframework.data.mongodb.core.aggregation.Aggregation.match;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.MatchOperation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Repository;

import es.santander.adn360.alias.config.MongoCollectionsProperties;
import es.santander.adn360.alias.domain.AliasQueryParams;
import es.santander.adn360.alias.domain.ContractAlias;
import es.santander.adn360.alias.web.Aliasparams;
import lombok.RequiredArgsConstructor;

/**
 * Implementation of the interface of ContractRepository dedicated to the
 * collection of data from collections to MongoDb
 */
@Repository
@RequiredArgsConstructor
public class ContractsRepositoryImpl implements ContractsRepository {
	// usuarioInterno
	private static final String INTERNAL_USER = "usuarioInterno";
	// posicionGlobal
	private static final String GLOBAL_POSITION = "posicionGlobal";
	// fechaBaja
	private static final String FECHA_BAJA = "fechaBaja";
	// idContrato
	private static final String CONTRACT_ID = "idContrato";
	// aliasContratoEmpresa
	private static final String ALIAS_EMP = "aliasContratoEmpresa";
	// INSENSITIVE_CASE_OPTION
	private static final String INSENSITIVE_CASE_OPTION = "i";

	// mongoTemplate
	@Autowired
	private MongoTemplate mongoTemplate;
	// mongoCollectionsProperties
	@Autowired
	private MongoCollectionsProperties mongoCollectionsProperties;

	/**
	 * See Inherit doc
	 */
	@Override
	public Map<String, ContractAlias> findContractsAlias(Aliasparams aliasparams) {
		AliasQueryParams aliasQueryParams = AliasQueryParams.builder().internalUser(aliasparams.getInternal_user())
				.contractList(aliasparams.getId_list()).globalPosition(aliasparams.getGlobal_position()).build();
		List<ContractAlias> content = mongoTemplate.aggregate(this.buildAggregation(aliasQueryParams, false),
				mongoCollectionsProperties.getAliasContracts(), ContractAlias.class).getMappedResults();

		return content.stream().collect(Collectors.toMap(ContractAlias::getIdContrato, Function.identity()));
	}

	private Aggregation buildAggregation(AliasQueryParams aliasQueryParams, boolean isEMPChannel) {
		MatchOperation match = match(buildCriteria(aliasQueryParams));

		if (isEMPChannel) {
			match = match(buildEMPCriteria(aliasQueryParams));
		}

		return Aggregation.newAggregation(match);
	}

	/**
	 * See Inherit doc
	 */
	@Override
	public Map<String, ContractAlias> findContractsAliasEmp(Aliasparams aliasparams) {

		AliasQueryParams aliasQueryParams = AliasQueryParams.builder().internalUser(aliasparams.getInternal_user())
				.contractList(aliasparams.getId_list()).aliasText(aliasparams.getAlias()).build();
		List<ContractAlias> content = mongoTemplate.aggregate(this.buildAggregation(aliasQueryParams, true),
				mongoCollectionsProperties.getAliasContractsEmp(), ContractAlias.class).getMappedResults();

		return content.stream().collect(Collectors.toMap(ContractAlias::getIdContrato, Function.identity()));
	}

	/**
	 * Gets criteria for getting proper contract. Criteria by internal user, list of
	 * contract id and global Position
	 *
	 * Check if the fechaBaja is gt than now because the RT has been able to update
	 * the record and unsubscribe
	 *
	 * @param aliasQueryParams
	 *            aliasQueryParams
	 * @return The Criteria Query
	 */
	private static Criteria buildCriteria(AliasQueryParams aliasQueryParams) {
		return Criteria.where(INTERNAL_USER).is(aliasQueryParams.getInternalUser()).and(CONTRACT_ID)
				.in(aliasQueryParams.getContractList()).and(GLOBAL_POSITION).is(aliasQueryParams.getGlobalPosition())
				.and(FECHA_BAJA).gt(new Date());
	}

	/**
	 * Gets criteria for NWE getting proper cards. Criteria by internal user and
	 * list of pan card
	 *
	 * @param aliasQueryParams
	 *            aliasQueryParams
	 * @return The Criteria Query
	 */
	private static Criteria buildEMPCriteria(AliasQueryParams aliasQueryParams) {
		Criteria criteria = Criteria.where(INTERNAL_USER).is(aliasQueryParams.getInternalUser()).and(CONTRACT_ID)
				.in(aliasQueryParams.getContractList()).orOperator(Criteria.where(FECHA_BAJA).exists(Boolean.FALSE),
						Criteria.where(FECHA_BAJA).gt(new Date()));

		Optional.ofNullable(aliasQueryParams.getAliasText()).ifPresent(
				aliasText -> criteria.and(ALIAS_EMP).regex("^.*" + aliasText + ".*$", INSENSITIVE_CASE_OPTION));

		return criteria;
	}
}