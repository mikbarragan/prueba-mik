package es.santander.adn360.alias.domain;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * AliasQueryParams class
 *
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class AliasQueryParams {

	// internalUser
	private String internalUser;
	// cardList
	private List<String> cardList;
	// contractList
	private List<String> contractList;
	// globalPosition
	private String globalPosition;
	// used to filter for alias
	private String aliasText;

}
