package es.santander.adn360.alias.web.response;

import java.util.Map;

import es.santander.adn360.alias.domain.CardAlias;
import lombok.Builder;
import lombok.Data;

/**
 * Response to cards api
 */
@Data
@Builder
public class CardsAliasResponse {

	/**
	 * List of cards response
	 */
	// cards
	private Map<String, CardAlias> cards;

}
