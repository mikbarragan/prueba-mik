package es.santander.adn360.alias.repository;

import static org.springframework.data.mongodb.core.aggregation.Aggregation.match;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.MatchOperation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Repository;

import es.santander.adn360.alias.config.MongoCollectionsProperties;
import es.santander.adn360.alias.domain.AliasQueryParams;
import es.santander.adn360.alias.domain.CardAlias;
import es.santander.adn360.alias.web.Aliasparams;
import lombok.RequiredArgsConstructor;

/**
 * Implementation of the interface of CardsRepository dedicated to the
 * collection of data from the alias_cards collection to MongoDb
 */
@Repository
@RequiredArgsConstructor
public class CardsRepositoryImpl implements CardsRepository {
	// usuarioInterno
	private static final String INTERNAL_USER = "usuarioInterno";
	// posicionGlobal
	private static final String GLOBAL_POSITION = "posicionGlobal";
	// fechaBaja
	private static final String FECHA_BAJA = "fechaBaja";
	// pan
	private static final String PAN = "pan";
	// aliasTarjetaEmpresa
	private static final String ALIAS_EMP = "aliasTarjetaEmpresa";
	// INSENSITIVE_CASE_OPTION
	private static final String INSENSITIVE_CASE_OPTION = "i";

	// mongoTemplate
	@Autowired
	private MongoTemplate mongoTemplate;
	// mongoCollectionsProperties
	@Autowired
	private MongoCollectionsProperties mongoCollectionsProperties;

	/**
	 * See Inherit doc
	 */
	@Override
	public Map<String, CardAlias> findCardsAlias(Aliasparams aliasparams) {

		AliasQueryParams aliasQueryParams = AliasQueryParams.builder().internalUser(aliasparams.getInternal_user())
				.cardList(aliasparams.getId_list()).globalPosition(aliasparams.getGlobal_position()).build();
		List<CardAlias> content = mongoTemplate.aggregate(this.buildAggregation(aliasQueryParams, false),
				mongoCollectionsProperties.getAliasCards(), CardAlias.class).getMappedResults();

		return content.stream().collect(Collectors.toMap(CardAlias::getPan, Function.identity()));
	}

	/**
	 * See Inherit doc
	 */
	@Override
	public Map<String, CardAlias> findCardsAliasEmp(Aliasparams aliasparams) {
		AliasQueryParams aliasQueryParams = AliasQueryParams.builder().internalUser(aliasparams.getInternal_user())
				.cardList(aliasparams.getId_list()).aliasText(aliasparams.getAlias()).build();
		List<CardAlias> content = mongoTemplate.aggregate(this.buildAggregation(aliasQueryParams, true),
				mongoCollectionsProperties.getAliasCardsEmp(), CardAlias.class).getMappedResults();

		return content.stream().collect(Collectors.toMap(CardAlias::getPan, Function.identity()));
	}

	private Aggregation buildAggregation(AliasQueryParams aliasQueryParams, boolean isEMPChannel) {
		MatchOperation match = match(buildCriteria(aliasQueryParams));

		if (isEMPChannel) {
			match = match(buildEMPCriteria(aliasQueryParams));
		}

		return Aggregation.newAggregation(match);
	}

	/**
	 * Gets criteria for getting proper cards. Criteria by internal user, list of
	 * pan card and globalPosition
	 *
	 * Check if the fechaBaja is gt than now because the RT has been able to update
	 * the record and unsubscribe
	 *
	 * @param aliasQueryParams
	 *            aliasQueryParams
	 * @return The Criteria Query
	 */
	private static Criteria buildCriteria(AliasQueryParams aliasQueryParams) {
		return Criteria.where(INTERNAL_USER).is(aliasQueryParams.getInternalUser()).and(PAN)
				.in(aliasQueryParams.getCardList()).and(GLOBAL_POSITION).is(aliasQueryParams.getGlobalPosition())
				.and(FECHA_BAJA).gt(new Date());
	}

	/**
	 * Gets criteria for NWE getting proper cards. Criteria by internal user and
	 * list of pan card
	 *
	 * @param aliasQueryParams
	 *            aliasQueryParams
	 * @return The Criteria Query
	 */
	private static Criteria buildEMPCriteria(AliasQueryParams aliasQueryParams) {
		Criteria criteria = Criteria.where(INTERNAL_USER).is(aliasQueryParams.getInternalUser()).and(PAN)
				.in(aliasQueryParams.getCardList()).orOperator(Criteria.where(FECHA_BAJA).exists(Boolean.FALSE),
						Criteria.where(FECHA_BAJA).gt(new Date()));

		Optional.ofNullable(aliasQueryParams.getAliasText()).ifPresent(
				aliasText -> criteria.and(ALIAS_EMP).regex("^.*" + aliasText + ".*$", INSENSITIVE_CASE_OPTION));

		return criteria;
	}
}