package es.santander.adn360.alias.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import javax.validation.constraints.NotNull;


/**
 * Class that getting the conexion MongoDb properties
 *
 * */
@Data
@Configuration
@ConfigurationProperties(prefix = "spring.data.mongodb.collections")
public class MongoCollectionsProperties {
    /**
     * AliasCard collection name in mongoDb
     * */
    @NotNull
    private String aliasCards;

    /**
     * AliasContract collection name in mongoDb
     * */
    @NotNull
    private String aliasContracts;

    /**
     * AliasCardEmp collection name in mongoDb
     * */
    @NotNull
    private String aliasCardsEmp;

    /**
     * AliasContractEmp collection name in mongoDb
     * */
    @NotNull
    private String aliasContractsEmp;


}


