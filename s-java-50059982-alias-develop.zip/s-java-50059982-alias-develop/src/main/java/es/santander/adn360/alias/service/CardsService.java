package es.santander.adn360.alias.service;


import es.santander.adn360.alias.domain.CardAlias;
import es.santander.adn360.alias.web.Aliasparams;

import java.util.Map;

/**
 * Interface interface for the implementation of Service dedicated to managing
 * and obtaining data from a list of card aliases
 **/
public interface CardsService {

   /**
    * Function that searches for a list of aliases for its
    * corresponding card and internal user
    *
    * @param aliasparams aliasparams
    * @return List of CardAlias entities
    */
   Map<String, CardAlias> findCardsAlias(Aliasparams aliasparams);

}
