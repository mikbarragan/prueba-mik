package es.santander.adn360.alias.repository;

import com.mongodb.BasicDBList;
import com.mongodb.DBObject;
import es.santander.adn360.alias.config.MongoCollectionsProperties;
import es.santander.adn360.alias.domain.CardAlias;
import es.santander.adn360.alias.web.Aliasparams;
import org.apache.commons.io.FileUtils;
import org.bson.BsonArray;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.mongodb.core.MongoOperations;

import java.nio.charset.Charset;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;


@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class CardsRepositoryTest {

    @Autowired
    private MongoOperations mongoOperations;

    @Autowired
    private MongoCollectionsProperties collections;

    @Autowired
    private CardsRepositoryImpl cardsRepository;

    @BeforeEach
    public void setUp() throws Exception {
        String doc = FileUtils.readFileToString(
                new ClassPathResource("json/adn360.alias-cards.json").getFile(),
                Charset.defaultCharset()
        );
    
        final BsonArray parse = BsonArray.parse(doc);
        BasicDBList dbList = new BasicDBList();
        dbList.addAll(parse);
        DBObject dbObject = dbList;
        ((BasicDBList) dbObject).forEach(dbo -> mongoOperations.save(dbo, collections.getAliasCards()));

        String docEmp = FileUtils.readFileToString(
                new ClassPathResource("json/adn360.alias-cards-emp.json").getFile(),
                Charset.defaultCharset()
        );

        final BsonArray parseEmp = BsonArray.parse(docEmp);
        BasicDBList dbListEmp = new BasicDBList();
        dbListEmp.addAll(parseEmp);
        DBObject dbObjectEmp = dbListEmp;
        ((BasicDBList) dbObjectEmp).forEach(dbo -> mongoOperations.save(dbo, collections.getAliasCardsEmp()));
    }


    /**
     * The repository should return only the documents that:
     * usuarioInterno = 12345678
     * pan = 1234567890123456 || 1234567890123000 || 1234567890123011
     * posicionGlobal = 1
     */
    @Test
    public void findCardsAliasFilteringCorrectly_1() {
        String user = "12345678";
        List<String> cardList = Arrays.asList("1234567890123456", "1234567890123000", "1234567890123011");
        String globalPosition = "1";

        Aliasparams aliasParam = Aliasparams.builder()
                .internal_user(user)
                .id_list(cardList)
                .global_position(globalPosition)
                .build();
        Map<String, CardAlias> response = cardsRepository.findCardsAlias(aliasParam);

        assertThat(response).isNotNull();
        assertThat(response.size()).isEqualTo(2);
        assertThat(response.get("1234567890123456").getPan()).isEqualTo("1234567890123456");
        assertThat(response.get("1234567890123456").getAlias()).isEqualTo("Alias de tarjeta 1");
        assertThat(response.get("1234567890123456").getIndicadorVisibilidad()).isEqualTo("S");

        assertThat(response.get("1234567890123000").getPan()).isEqualTo("1234567890123000");
        assertThat(response.get("1234567890123000").getAlias()).isEqualTo("Alias de tarjeta N");
        assertThat(response.get("1234567890123000").getIndicadorVisibilidad()).isEqualTo("N");

    }

    /**
     * The repository should return only the documents that:
     * usuarioInterno = 12345678
     * pan = 1234567890123456 || 1234567890123000 || 1234567890123011
     * posicionGlobal = 1
     */
    @Test
    public void findCardsAliasEmpFilteringCorrectly_1() {
        String user = "UEEBXB1Y";
        List<String> cardList = Arrays.asList("4425990000916404", "5464090000012095", "4425990000916701");

        Aliasparams aliasParam = Aliasparams.builder()
                .internal_user(user)
                .id_list(cardList)
                .build();
        Map<String, CardAlias> response = cardsRepository.findCardsAliasEmp(aliasParam);

        assertThat(response).isNotNull();
        assertThat(response.size()).isEqualTo(cardList.size());

        assertThat(response.get("4425990000916404").getPan()).isEqualTo("4425990000916404");
        assertThat(response.get("4425990000916404").getAlias()).isEqualTo("Alias Pan Tarjeta        ");

        assertThat(response.get("5464090000012095").getPan()).isEqualTo("5464090000012095");
        assertThat(response.get("5464090000012095").getAlias()).isEqualTo("Alias Pan Tarjeta m4     ");

        assertThat(response.get("4425990000916701").getPan()).isEqualTo("4425990000916701");
        assertThat(response.get("4425990000916701").getAlias()).isEqualTo("Alias Pan Tarjeta pcas1  ");

    }

    /**
     * The repository should return only the documents that:
     * usuarioInterno = 12345678
     * pan = 1234567890123456 || 1234567890123000 || 1234567890123011 || 1234567890123025
     * posicionGlobal = 1
     */
    @Test
    public void findCardsAliasFilteringCorrectly_2() {
        String user = "12345688";
        List<String> cardList = Arrays.asList("1234567890123456", "1234567890123000", "1234567890123011", "1234567890123025");
        String globalPosition = "1";

        Aliasparams aliasParam = Aliasparams.builder()
                .internal_user(user)
                .id_list(cardList)
                .global_position(globalPosition)
                .build();
        Map<String, CardAlias> response = cardsRepository.findCardsAlias(aliasParam);

        assertThat(response).isNotNull();
        assertThat(response.size()).isEqualTo(1);
        assertThat(response.get("1234567890123025").getPan()).isEqualTo("1234567890123025");
        assertThat(response.get("1234567890123025").getAlias()).isEqualTo("Alias de tarjeta 5");
        assertThat(response.get("1234567890123025").getIndicadorVisibilidad()).isEqualTo("S");

    }

    /**
     * The repository should return only the documents that:
     * usuarioInterno = 12345678
     * pan = 1234567890123456 || 1234567890123000 || 1234567890123011
     * posicionGlobal = 2
     */
    @Test
    public void findCardsAliasFilteringCorrectly_3() {
        String user = "12345678";
        List<String> cardList = Arrays.asList("1234567890123456", "1234567890123000", "1234567890123011");
        String globalPosition = "2";

        Aliasparams aliasParam = Aliasparams.builder()
                .internal_user(user)
                .id_list(cardList)
                .global_position(globalPosition)
                .build();
        Map<String, CardAlias> response = cardsRepository.findCardsAlias(aliasParam);

        assertThat(response).isNotNull();
        assertThat(response.size()).isEqualTo(1);
        assertThat(response.get("1234567890123456").getPan()).isEqualTo("1234567890123456");
        assertThat(response.get("1234567890123456").getAlias()).isEqualTo("Alias de tarjeta 2");
        assertThat(response.get("1234567890123456").getIndicadorVisibilidad()).isEqualTo("N");
    }

    /**
     * The repository should return only the documents that with correct fechaBaja:
     * usuarioInterno = 12345678
     * pan = 1234567890123456 || 1234567890123333
     * posicionGlobal = 2
     */
    @Test
    public void findCardsAliasFilteringCorrectly_fechaBaja() {
        String user = "12345678";
        List<String> cardList = Arrays.asList("1234567890123456", "1234567890123333");
        String globalPosition = "2";

        Aliasparams aliasParam = Aliasparams.builder()
                .internal_user(user)
                .id_list(cardList)
                .global_position(globalPosition)
                .build();
        Map<String, CardAlias>  response = cardsRepository.findCardsAlias(aliasParam);

        assertThat(response).isNotNull();
        assertThat(response.size()).isEqualTo(1);
        assertThat(response.get("1234567890123456").getPan()).isEqualTo("1234567890123456");
        assertThat(response.get("1234567890123456").getAlias()).isEqualTo("Alias de tarjeta 2");
        assertThat(response.get("1234567890123456").getIndicadorVisibilidad()).isEqualTo("N");
    }

    @Test
    public void findCardsAliasEMPFilteringCorrectly_fechaBaja() {
        String user = "UEEBXB84";
        List<String> cardList = Arrays.asList("4425990000917907", "4425990000917402");

        Aliasparams aliasParam = Aliasparams.builder()
                .internal_user(user)
                .id_list(cardList)
                .build();
        Map<String, CardAlias>  response = cardsRepository.findCardsAliasEmp(aliasParam);

        assertThat(response).isNotNull();
        assertThat(response.size()).isEqualTo(1);
        assertThat(response.get("4425990000917907").getPan()).isEqualTo("4425990000917907");
        assertThat(response.get("4425990000917907").getAlias()).isEqualTo("Alias tarjetita 4 pcas   ");
    }

    @Test
    public void findCardsAliasEMPFilteringCorrectly_AliasTexto() {
        String user = "UEEBXB1Y";
        List<String> cardList = Arrays.asList("4425990000916404", "5464090000012095", "4425990000916701"
                ,"4425990000916705");

        Aliasparams aliasParam = Aliasparams.builder()
                .internal_user(user)
                .id_list(cardList)
                .alias("pcas")
                .build();
        Map<String, CardAlias> response = cardsRepository.findCardsAliasEmp(aliasParam);

        assertThat(response).isNotNull();
        assertThat(response.size()).isEqualTo(2);

        assertThat(response.get("4425990000916701").getPan()).isEqualTo("4425990000916701");
        assertThat(response.get("4425990000916701").getAlias()).isEqualTo("Alias Pan Tarjeta pcas1  ");

        assertThat(response.get("4425990000916705").getPan()).isEqualTo("4425990000916705");
        assertThat(response.get("4425990000916705").getAlias()).isEqualTo("Alias Pan Tarjeta pcas2  ");

    }

    @Test
    public void findCardsAliasEMPFilteringCorrectly_AliasTexto_SinResultado() {
        String user = "UEEBXB1Y";
        List<String> cardList = Arrays.asList("4425990000916404", "5464090000012095", "4425990000916701"
                ,"4425990000916705");

        Aliasparams aliasParam = Aliasparams.builder()
                .internal_user(user)
                .id_list(cardList)
                .alias("sin resultado")
                .build();
        Map<String, CardAlias> response = cardsRepository.findCardsAliasEmp(aliasParam);

        assertThat(response).isEmpty();

    }
}
