package es.santander.adn360.alias.services;

import es.santander.adn360.alias.domain.CardAlias;
import es.santander.adn360.alias.repository.CardsRepository;
import es.santander.adn360.alias.service.CardsServiceImpl;
import es.santander.adn360.alias.web.Aliasparams;
import es.santander.adn360.core.model.exception.FunctionalException;
import es.santander.adn360.core.util.ExceptionEnum;
import es.santander.adn360.core.web.CoreSecurityContextImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

public class CardsServiceTest {

    @Mock
    private CardsRepository cardsRepository;

    @InjectMocks
    private CardsServiceImpl cardsService;

    private static final CoreSecurityContextImpl CORE_SECURITY_CONTEXT = (CoreSecurityContextImpl) Mockito.mock(CoreSecurityContextImpl.class);

    @BeforeEach
    public void setup() {
        //Initialize security context
        SecurityContextHolder.setContext(CORE_SECURITY_CONTEXT);
        mockSantanderChannel("OFI");
        initMocks(this);
    }

    private void mockSantanderChannel(String santanderChannel) {
        Mockito.when(CORE_SECURITY_CONTEXT.getSantanderChannel()).thenReturn(santanderChannel);
    }


    /** When call to findCardAlias and repository return data, the service should return data */
    @Test
    public void findCardsAliasShouldReturnListOfCardsList(){

        String user = "00666845";
        List<String> cards = Arrays.asList( "pan1", "pan2", "pan3" );
        String globalPosition = "1";

        when(cardsRepository.findCardsAlias(any() ))
                .thenReturn(new HashMap<String, CardAlias>(){{
                    put("pan1",  CardAlias.builder().pan("pan1").indicadorVisibilidad("S").usuarioInterno("00666845").alias("aliasCards 1").posicionGlobal("1").build());
                    put("pan2", CardAlias.builder().pan("pan2").indicadorVisibilidad("N").usuarioInterno("00666845").alias("aliasCards 2").posicionGlobal("1").build());
                    put("pan3",CardAlias.builder().pan("pan3").indicadorVisibilidad("S").usuarioInterno("00666845").alias("aliasCards 3").posicionGlobal("1").build());
                }} );


        Aliasparams aliasParam = Aliasparams.builder()
                .internal_user(user)
                .id_list(cards)
                .global_position(globalPosition)
                .build();
        Map<String, CardAlias> response = cardsService.findCardsAlias( aliasParam );

        assertThat( response ).isNotNull();
        assertThat( response.size() ).isEqualTo( 3 );

        assertThat( response.get("pan1").getPan()).isEqualTo("pan1");
        assertThat( response.get("pan1").getIndicadorVisibilidad()).isEqualTo("S");
        assertThat( response.get("pan1").getAlias()).isEqualTo("aliasCards 1");
        assertThat( response.get("pan1").getUsuarioInterno()).isEqualTo("00666845");

        assertThat( response.get("pan2").getPan()).isEqualTo("pan2");
        assertThat( response.get("pan2").getIndicadorVisibilidad()).isEqualTo("N");
        assertThat( response.get("pan2").getAlias()).isEqualTo("aliasCards 2");
        assertThat( response.get("pan2").getUsuarioInterno()).isEqualTo("00666845");

        assertThat( response.get("pan3").getPan()).isEqualTo("pan3");
        assertThat( response.get("pan3").getIndicadorVisibilidad()).isEqualTo("S");
        assertThat( response.get("pan3").getAlias()).isEqualTo("aliasCards 3");
        assertThat( response.get("pan3").getUsuarioInterno()).isEqualTo("00666845");

    }

    /** When call to findCardAlias and repository return data, the service should return data */
    @Test
    public void findCardsAliasEMPShouldReturnListOfCardsList(){

        mockSantanderChannel("EMP");
        String user = "00666845";
        List<String> cards = Arrays.asList( "pan1", "pan2", "pan3" );
        String globalPosition = "1";

        when(cardsRepository.findCardsAliasEmp(any()))
                .thenReturn(new HashMap<String, CardAlias>(){{
                    put("pan1",  CardAlias.builder().pan("pan1").usuarioInterno("00666845").alias("aliasCards 1").build());
                    put("pan2", CardAlias.builder().pan("pan2").usuarioInterno("00666845").alias("aliasCards 2").build());
                    put("pan3",CardAlias.builder().pan("pan3").usuarioInterno("00666845").alias("aliasCards 3").build());
                }} );

        Aliasparams aliasParam = Aliasparams.builder()
                .internal_user(user)
                .id_list(cards)
                .global_position(globalPosition)
                .build();
        Map<String, CardAlias> response = cardsService.findCardsAlias( aliasParam );

        assertThat( response ).isNotNull();
        assertThat( response.size() ).isEqualTo( 3 );

        assertThat( response.get("pan1").getPan()).isEqualTo("pan1");
        assertThat( response.get("pan1").getAlias()).isEqualTo("aliasCards 1");
        assertThat( response.get("pan1").getUsuarioInterno()).isEqualTo("00666845");

        assertThat( response.get("pan2").getPan()).isEqualTo("pan2");
        assertThat( response.get("pan2").getAlias()).isEqualTo("aliasCards 2");
        assertThat( response.get("pan2").getUsuarioInterno()).isEqualTo("00666845");

        assertThat( response.get("pan3").getPan()).isEqualTo("pan3");
        assertThat( response.get("pan3").getAlias()).isEqualTo("aliasCards 3");
        assertThat( response.get("pan3").getUsuarioInterno()).isEqualTo("00666845");

    }

    /** When call to findCardAlias and repository return an empty List, the service should return empty List */
    @Test
    public void findCardsAliasShouldReturnEmptyList(){

        mockSantanderChannel("EMP");
        String user = "00666845";
        List<String> cards = Arrays.asList( "pan1", "pan2", "pan3" );
        String globalPosition = "1";

        when(cardsRepository.findCardsAliasEmp(any() ))
                .thenReturn( Collections.EMPTY_MAP );

        Aliasparams aliasParam = Aliasparams.builder()
                .internal_user(user)
                .id_list(cards)
                .global_position(globalPosition)
                .build();
        Map<String, CardAlias> response = cardsService.findCardsAlias( aliasParam );

        assertThat( response ).isNotNull();
        assertThat( response.size() ).isEqualTo( 0 );
    }

    /** When call to findCardAlias and repository return an empty List, the service should return empty List */
    @Test
    public void findCardsAliasEMPShouldReturnEmptyList(){

        String user = "00666845";
        List<String> cards = Arrays.asList( "pan1", "pan2", "pan3" );
        String globalPosition = "1";

        when(cardsRepository.findCardsAlias(any() ))
                .thenReturn( Collections.EMPTY_MAP );

        Aliasparams aliasParam = Aliasparams.builder()
                .internal_user(user)
                .id_list(cards)
                .global_position(globalPosition)
                .build();
        Map<String, CardAlias> response = cardsService.findCardsAlias( aliasParam );

        assertThat( response ).isNotNull();
        assertThat( response.size() ).isEqualTo( 0 );
    }


    /** When call to findCardAlias and repository thrown Exception, the service should thrown the same exception */
    @Test
    public void findCardsAliasShouldReturnError(){

        String user = "00666845";
        List<String> cards = Arrays.asList( "pan1", "pan2", "pan3" );
        String globalPosition = "1";

        when(cardsRepository.findCardsAlias(any() ))
                .thenThrow( new FunctionalException(ExceptionEnum.INTERNAL_SERVER_ERROR, "Error de prueba"));

        Aliasparams aliasParam = Aliasparams.builder()
                .internal_user(user)
                .id_list(cards)
                .global_position(globalPosition)
                .build();
        assertThrows(FunctionalException.class, () -> cardsService.findCardsAlias( aliasParam ));
    }

    @Test
    public void findCardsAliasEMP_withAliasText_ShouldReturnListOfCardsList(){

        mockSantanderChannel("EMP");
        String user = "00666845";
        List<String> cards = Arrays.asList( "pan1", "pan2", "pan3" );
        String globalPosition = "1";

        when(cardsRepository.findCardsAliasEmp(any()))
                .thenReturn(new HashMap<String, CardAlias>(){{
                    put("pan1",  CardAlias.builder().pan("pan1").usuarioInterno("00666845").alias("tarjeta habitual compras").build());
                    put("pan2", CardAlias.builder().pan("pan2").usuarioInterno("00666845").alias("tarjeta habitual comidas").build());
                    put("pan3",CardAlias.builder().pan("pan3").usuarioInterno("00666845").alias("tarjeta habitual combustible").build());
                }} );

        Aliasparams aliasParam = Aliasparams.builder()
                .internal_user(user)
                .id_list(cards)
                .global_position(globalPosition)
                .alias("habitual")
                .build();
        Map<String, CardAlias> response = cardsService.findCardsAlias( aliasParam );

        assertThat( response ).isNotNull();
        assertThat( response.size() ).isEqualTo( 3 );

        assertThat( response.get("pan1").getPan()).isEqualTo("pan1");
        assertThat( response.get("pan1").getAlias()).isEqualTo("tarjeta habitual compras");
        assertThat( response.get("pan1").getUsuarioInterno()).isEqualTo("00666845");

        assertThat( response.get("pan2").getPan()).isEqualTo("pan2");
        assertThat( response.get("pan2").getAlias()).isEqualTo("tarjeta habitual comidas");
        assertThat( response.get("pan2").getUsuarioInterno()).isEqualTo("00666845");

        assertThat( response.get("pan3").getPan()).isEqualTo("pan3");
        assertThat( response.get("pan3").getAlias()).isEqualTo("tarjeta habitual combustible");
        assertThat( response.get("pan3").getUsuarioInterno()).isEqualTo("00666845");

    }

}
