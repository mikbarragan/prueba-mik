package es.santander.adn360.alias;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class ApplicationTest {

    @Test
    void testApplication() {
        Application.main(new String[]{
                "--spring.main.web-environment=false"
        });
        Application nuevo = new Application();
        assertThat(nuevo).isNotNull();
    }
}