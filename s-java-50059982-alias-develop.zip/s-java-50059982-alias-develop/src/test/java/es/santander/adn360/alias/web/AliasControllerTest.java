package es.santander.adn360.alias.web;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.util.UriComponentsBuilder;

import es.santander.adn360.alias.domain.CardAlias;
import es.santander.adn360.alias.domain.ContractAlias;
import es.santander.adn360.alias.service.CardsService;
import es.santander.adn360.alias.service.ContractsService;
import es.santander.adn360.alias.web.response.CardsAliasResponse;
import es.santander.adn360.alias.web.response.ContractsAliasResponse;
import es.santander.adn360.core.web.CoreSecurityContextImpl;
import com.santander.darwin.core.exceptions.InternalServerErrorDarwinException;
import lombok.val;


@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class AliasControllerTest {
    private static final String PATH_CARDS = "/alias/cards";
    private static final String PATH_CONTRACTS = "/alias/contracts";

    @Autowired
    private TestRestTemplate restTemplate;

    @MockBean
    private CardsService cardsService;

    @MockBean
    private ContractsService contractsService;

    private static final CoreSecurityContextImpl CORE_SECURITY_CONTEXT = (CoreSecurityContextImpl) Mockito.mock(CoreSecurityContextImpl.class);

    @BeforeEach
    public void setup() {
        //Initialize security context
        SecurityContextHolder.setContext(CORE_SECURITY_CONTEXT);
        mockSantanderChannel("OFI");
    }

    private void mockSantanderChannel(String santanderChannel) {
        Mockito.when(CORE_SECURITY_CONTEXT.getSantanderChannel()).thenReturn(santanderChannel);
    }

    /**
     * if the service return data then api /cards response this data
     **/
    @Test
    public void findAliasCardsResponseAliasCardList(){
        String user = "12345678";
        List<String> cards = Arrays.asList("1234567890123456", "1234567890123457", "1234567890123458");
        String globalPosition = "1";


        Map<String, CardAlias> cardAliasResponse = new HashMap<>();
        cardAliasResponse.put("1234567890123456",CardAlias.builder().pan("1234567890123456").indicadorVisibilidad("S").alias("Alias 1").build());
        cardAliasResponse.put("1234567890123457",CardAlias.builder().pan("1234567890123457").indicadorVisibilidad("N").alias("Alias 2").build());
        cardAliasResponse.put("1234567890123458",CardAlias.builder().pan("1234567890123456").indicadorVisibilidad("S").alias("Alias 1").build());

        Aliasparams aliasParam = Aliasparams.builder()
                .internal_user(user)
                .id_list(cards)
                .global_position(globalPosition)
                .build();
        when(cardsService.findCardsAlias(aliasParam)).thenReturn( cardAliasResponse );

        UriComponentsBuilder builder = UriComponentsBuilder.fromPath(PATH_CARDS);


        Aliasparams aliasParams = Aliasparams.builder()
                .global_position(globalPosition)
                .internal_user(user)
                .id_list(Arrays.asList("1234567890123456","1234567890123457","1234567890123458"))
                .build();

        HttpEntity request = new HttpEntity(aliasParams);

        val response = restTemplate.exchange(builder.build().encode().toUri(), HttpMethod.POST, request,
                new ParameterizedTypeReference<Map<String,CardAlias>>() {
                });
    
    
        assertThat(HttpStatus.OK).isEqualTo(response.getStatusCode());
        assertThat(response.getBody()).isEqualTo( cardAliasResponse );
    }

    /**
     * if the service return data then api /cards response this data
     **/
    @Test
    public void findAliasCardsEMPResponseAliasCardList(){
        mockSantanderChannel("EMP");
        String user = "12345678";
        List<String> cards = Arrays.asList("1234567890123456", "1234567890123457", "1234567890123458");
        String globalPosition = "1";


        Map<String, CardAlias> cardAliasResponse = new HashMap<>();
        cardAliasResponse.put("1234567890123456",CardAlias.builder().pan("1234567890123456").alias("Alias 1").build());
        cardAliasResponse.put("1234567890123457",CardAlias.builder().pan("1234567890123457").alias("Alias 2").build());
        cardAliasResponse.put("1234567890123458",CardAlias.builder().pan("1234567890123456").alias("Alias 1").build());

        Aliasparams aliasParam = Aliasparams.builder()
                .internal_user(user)
                .id_list(cards)
                .global_position(globalPosition)
                .build();
        when(cardsService.findCardsAlias(aliasParam)).thenReturn( cardAliasResponse );

        UriComponentsBuilder builder = UriComponentsBuilder.fromPath(PATH_CARDS);

        Aliasparams aliasParams = Aliasparams.builder()
                .global_position(globalPosition)
                .internal_user(user)
                .id_list(Arrays.asList("1234567890123456","1234567890123457","1234567890123458"))
                .build();

        HttpEntity request = new HttpEntity(aliasParams);

        val response = restTemplate.exchange(builder.build().encode().toUri(), HttpMethod.POST, request,
                new ParameterizedTypeReference<Map<String,CardAlias>>() {
                });


        assertThat(HttpStatus.OK).isEqualTo(response.getStatusCode());
        assertThat(response.getBody()).isEqualTo( cardAliasResponse );
    }


    /**
     * if the service thron error then api /cards response this error
     **/
    @Test
    public void findAliasCards_service_error(){
        String user = "12345678";
        List<String> cards = Arrays.asList("1234567890123456", "1234567890123457", "1234567890123458");
        String globalPosition = "1";


        List<CardAlias> cardAliasResponse =  Arrays.asList(
                CardAlias.builder().pan("1234567890123456").indicadorVisibilidad("S").alias("Alias 1").build(),
                CardAlias.builder().pan("1234567890123457").indicadorVisibilidad("N").alias("Alias 2").build(),
                CardAlias.builder().pan("1234567890123458").indicadorVisibilidad("S").alias("Alias 3").build()
        );

        Aliasparams aliasParam = Aliasparams.builder()
                .internal_user(user)
                .id_list(cards)
                .global_position(globalPosition)
                .build();
        when(cardsService.findCardsAlias(aliasParam)).thenThrow(new NullPointerException());

        UriComponentsBuilder builder = UriComponentsBuilder.fromPath(PATH_CARDS);

        Aliasparams aliasParams = Aliasparams.builder()
                .global_position(globalPosition)
                .internal_user(user)
                .id_list(Arrays.asList("1234567890123456","1234567890123457","1234567890123458"))
                .build();

        HttpEntity request = new HttpEntity(aliasParams);

        ResponseEntity<CardsAliasResponse> response = restTemplate.exchange(builder.build().encode().toUri(), HttpMethod.POST, request,
                new ParameterizedTypeReference<CardsAliasResponse>() {
                });


        assertThat(HttpStatus.INTERNAL_SERVER_ERROR).isEqualTo( response.getStatusCode());
    }

    /**
     * if the service return emptyList then api /cards response emptyList
     **/
    @Test
    public void findAliasCardsResponseAliasCardEmptyMap(){
        String user = "12345678";
        List<String> cards = Arrays.asList("1234567890123456", "1234567890123457");
        String globalPosition = "1";

        Aliasparams aliasParam = Aliasparams.builder()
                .internal_user(user)
                .id_list(cards)
                .global_position(globalPosition)
                .build();
        when(cardsService.findCardsAlias(aliasParam)).thenReturn( Collections.EMPTY_MAP );

        UriComponentsBuilder builder = UriComponentsBuilder.fromPath(PATH_CARDS);

        Aliasparams aliasParams = Aliasparams.builder()
                .global_position(globalPosition)
                .internal_user(user)
                .id_list(Arrays.asList("1234567890123456","1234567890123457"))
                .build();

        HttpEntity request = new HttpEntity(aliasParams);
        final ResponseEntity<Map<String, CardAlias>> response = restTemplate
                .exchange(builder.build().toUri(),
                        HttpMethod.POST, request,
                        new ParameterizedTypeReference<Map<String, CardAlias>>() {
                        });

        assertThat(response).isNotNull();
        assertThat(HttpStatus.OK).isEqualTo( response.getStatusCode());
        assertThat(response.getBody()).isEqualTo( Collections.EMPTY_MAP );
    }

    /**
     *  if request whith bad internal User should return Bad Request status
     * */
    @Test
    public void findAliasCards_internal_user_Bad_request() {
        UriComponentsBuilder builder = UriComponentsBuilder.fromPath(PATH_CARDS);

        Aliasparams aliasParams = Aliasparams.builder()
                .global_position("1")
                .internal_user("1234567890123456")
                .id_list(Arrays.asList("1234567890123456","1234567890123457","1234567890123458"))
                .build();

        HttpEntity request = new HttpEntity(aliasParams);

        ResponseEntity<CardsAliasResponse> response = restTemplate.exchange(builder.build().encode().toUri(), HttpMethod.POST, request,
                new ParameterizedTypeReference<CardsAliasResponse>() {
                });
        assertThat(HttpStatus.BAD_REQUEST).isEqualTo( response.getStatusCode());
    }

    /**
     *  if request whith bad card List element should return Bad Request status
     * */
    @Test
    public void findAliasCards_card_list_element_Bad_request() {
        UriComponentsBuilder builder = UriComponentsBuilder.fromPath(PATH_CARDS);

        Aliasparams aliasParams = Aliasparams.builder()
                .global_position("1")
                .internal_user("12345678")
                .id_list(Arrays.asList("F12345678901234567"))
                .build();

        HttpEntity request = new HttpEntity(aliasParams);
        ResponseEntity<CardsAliasResponse> response = restTemplate.exchange(builder.build().encode().toUri(), HttpMethod.POST, request,
                new ParameterizedTypeReference<CardsAliasResponse>() {
                });
        assertThat(HttpStatus.BAD_REQUEST).isEqualTo( response.getStatusCode());
    }


    /**
     *  if request whith bad card List element should return Bad Request status
     * */
    @Test
    public void findAliasCards_card_list_element_OK_request() {
        UriComponentsBuilder builder = UriComponentsBuilder.fromPath(PATH_CARDS);

        Aliasparams aliasParams = Aliasparams.builder()
                .global_position("1")
                .internal_user("12345678")
                .id_list(Arrays.asList("12345678901234567666666666666666666666666666666666666666666666"))
                .build();

        HttpEntity request = new HttpEntity(aliasParams);
        ResponseEntity<CardsAliasResponse> response = restTemplate.exchange(builder.build().encode().toUri(), HttpMethod.POST, request,
                new ParameterizedTypeReference<CardsAliasResponse>() {
                });
        assertThat(HttpStatus.OK).isEqualTo( response.getStatusCode());
    }

    /**
     *  if request whith bad global Position should return Bad Request status
     * */
    @Test
    public void findAliasCards_global_position_Bad_request() {
        UriComponentsBuilder builder = UriComponentsBuilder.fromPath(PATH_CARDS);

        Aliasparams aliasParams = Aliasparams.builder()
                .global_position("aaa")
                .internal_user("12345678")
                .id_list(Arrays.asList("123456789012345"))
                .build();

        HttpEntity request = new HttpEntity(aliasParams);
        ResponseEntity<CardsAliasResponse> response = restTemplate.exchange(builder.build().encode().toUri(), HttpMethod.POST, request,
                new ParameterizedTypeReference<CardsAliasResponse>() {
                });
        assertThat(HttpStatus.BAD_REQUEST).isEqualTo( response.getStatusCode());
    }

    /**
     *  if request whithouth internal User should return Bad Request status
     * */
    @Test
    public void findAliasCards_internal_user_null() {
        UriComponentsBuilder builder = UriComponentsBuilder.fromPath(PATH_CARDS);

        Aliasparams aliasParams = Aliasparams.builder()
                .global_position("1")
                .id_list(Arrays.asList("1234567890123456","1234567890123457","1234567890123458"))
                .build();

        HttpEntity request = new HttpEntity(aliasParams);
        ResponseEntity<CardsAliasResponse> response = restTemplate.exchange(builder.build().encode().toUri(), HttpMethod.POST, request,
                new ParameterizedTypeReference<CardsAliasResponse>() {
                });
        assertThat(HttpStatus.BAD_REQUEST).isEqualTo( response.getStatusCode());
    }

    /**
     *  if request whithouth card_list should return Bad Request status
     * */
    @Test
    public void findAliasCards_card_list_null() {
        UriComponentsBuilder builder = UriComponentsBuilder.fromPath(PATH_CARDS)
                .queryParam("internal_user", "12345678")
                .queryParam("global_position", "1");
        Aliasparams aliasParams = Aliasparams.builder()
                .global_position("1")
                .internal_user("12345678")
                .build();

        HttpEntity request = new HttpEntity(aliasParams);
        ResponseEntity<CardsAliasResponse> response = restTemplate.exchange(builder.build().encode().toUri(), HttpMethod.POST, request,
                new ParameterizedTypeReference<CardsAliasResponse>() {
                });
        assertThat(HttpStatus.BAD_REQUEST).isEqualTo( response.getStatusCode());
    }

    /**
     *  if request whithouth global position should return Bad Request status
     * */
    @Test
    public void findAliasCards_global_position_null() {
        UriComponentsBuilder builder = UriComponentsBuilder.fromPath(PATH_CARDS)
                .queryParam("internal_user", "12345678")
                .queryParam("card_list", "12345678901234567");
        Aliasparams aliasParams = Aliasparams.builder()
                .internal_user("12345678")
                .id_list(Arrays.asList("F12345678901234567"))
                .build();

        HttpEntity request = new HttpEntity(aliasParams);
        ResponseEntity<CardsAliasResponse> response = restTemplate.exchange(builder.build().encode().toUri(), HttpMethod.POST, request,
                new ParameterizedTypeReference<CardsAliasResponse>() {
                });
        assertThat(HttpStatus.BAD_REQUEST).isEqualTo( response.getStatusCode());
    }


    /**
     * if the service return data then api response this data
     * */
    @Test
    public void findAliasContractsShouldReturnData() {
        String user = "12345678";
        List<String> contracts = Arrays.asList("123456789012345678","123456789012345679");
        String globalPosition = "1";

        Map<String, ContractAlias> responseExpected = new HashMap<String, ContractAlias>(){{
           put("123456789012345678", ContractAlias.builder().idContrato("123456789012345678").alias("Contrato 1").indicadorVisibilidad("S").build());
           put("123456789012345679", ContractAlias.builder().idContrato("123456789012345679").alias("Contrato 2").indicadorVisibilidad("N").build());
        }};


        Aliasparams aliasParam = Aliasparams.builder()
                .internal_user(user)
                .id_list(contracts)
                .global_position(globalPosition)
                .build();
        when(contractsService.findContractsAlias(aliasParam)).thenReturn( responseExpected );

        UriComponentsBuilder builder = UriComponentsBuilder.fromPath(PATH_CONTRACTS);

        HttpEntity request = new HttpEntity(aliasParam);

        val response = restTemplate.exchange(builder.build().encode().toUri(), HttpMethod.POST, request,
                new ParameterizedTypeReference<Map<String,ContractAlias>>() {
                });
    
        assertThat(response).isNotNull();
        assertThat(HttpStatus.OK).isEqualTo( response.getStatusCode());
        assertThat(response.getBody()).isEqualTo( responseExpected );

    }

    /**
     * if the service return data then api response this data
     * */
    @Test
    public void findAliasContractsEMPShouldReturnData() {
        mockSantanderChannel("EMP");
        String user = "12345678";
        List<String> contracts = Arrays.asList("123456789012345678","123456789012345679");
        String globalPosition = "1";

        Map<String, ContractAlias> responseExpected = new HashMap<String, ContractAlias>(){{
            put("123456789012345678", ContractAlias.builder().idContrato("123456789012345678").alias("Contrato 1").build());
            put("123456789012345679", ContractAlias.builder().idContrato("123456789012345679").alias("Contrato 2").build());
        }};


        Aliasparams aliasParam = Aliasparams.builder()
                .internal_user(user)
                .id_list(contracts)
                .global_position(globalPosition)
                .build();
        when(contractsService.findContractsAlias(aliasParam)).thenReturn( responseExpected );

        UriComponentsBuilder builder = UriComponentsBuilder.fromPath(PATH_CONTRACTS);


        HttpEntity request = new HttpEntity(aliasParam);

        val response = restTemplate.exchange(builder.build().encode().toUri(), HttpMethod.POST, request,
                new ParameterizedTypeReference<Map<String,ContractAlias>>() {
                });

        assertThat(response).isNotNull();
        assertThat(HttpStatus.OK).isEqualTo( response.getStatusCode());
        assertThat(response.getBody()).isEqualTo( responseExpected );

    }

    @Test
    public void findAliasContractsEMP_withAliasText_ShouldReturnData() {
        mockSantanderChannel("EMP");
        String user = "12345678";
        List<String> contracts = Arrays.asList("123456789012345678","123456789012345679");
        String globalPosition = "1";

        Map<String, ContractAlias> responseExpected = new HashMap<String, ContractAlias>(){{
            put("123456789012345678", ContractAlias.builder().idContrato("123456789012345678").alias("Contrato 1").build());
            put("123456789012345679", ContractAlias.builder().idContrato("123456789012345679").alias("Contrato 2").build());
        }};


        Aliasparams aliasParam = Aliasparams.builder()
                .internal_user(user)
                .id_list(contracts)
                .global_position(globalPosition)
                .alias("Contrato")
                .build();
        when(contractsService.findContractsAlias(aliasParam)).thenReturn( responseExpected );

        UriComponentsBuilder builder = UriComponentsBuilder.fromPath(PATH_CONTRACTS);


        HttpEntity request = new HttpEntity(aliasParam);

        val response = restTemplate.exchange(builder.build().encode().toUri(), HttpMethod.POST, request,
                new ParameterizedTypeReference<Map<String,ContractAlias>>() {
                });

        assertThat(response).isNotNull();
        assertThat(HttpStatus.OK).isEqualTo( response.getStatusCode());
        assertThat(response.getBody()).isEqualTo( responseExpected );

    }

    /**
     * if the service return emptyList then api /cards response emptyList
     **/
    @Test
    public void findAliasContractsShouldReturnEmptyMap() {
        String user = "12345678";
        List<String> contracts = Arrays.asList("123456789012345678");
        String globalPosition = "1";

        Aliasparams aliasParams = Aliasparams.builder()
                .global_position("1")
                .internal_user("12345678")
                .id_list(Arrays.asList("123456789012345678"))
                .build();
        when(contractsService.findContractsAlias(eq(aliasParams))).thenReturn( Collections.EMPTY_MAP );

        UriComponentsBuilder builder = UriComponentsBuilder.fromPath(PATH_CONTRACTS);

        HttpEntity request = new HttpEntity(aliasParams);

        val response = restTemplate.exchange(builder.build().encode().toUri(), HttpMethod.POST, request,
                new ParameterizedTypeReference<Map<String, ContractAlias>>() {
                });
    
        assertThat(response).isNotNull();
        assertThat(HttpStatus.OK).isEqualTo( response.getStatusCode());
        assertThat(response.getBody()).isEqualTo( Collections.EMPTY_MAP);

    }


    /**
     * the service response as bad request if body is null
     * */
    @Test
    public void findAliasContracts_internal_error() {
        mockSantanderChannel("EMP");

        String user = "12345678";
        List<String> contracts = Arrays.asList("123456789012345678","123456789012345679");
        String globalPosition = "1";

        List<ContractAlias> responseExpected = Arrays.asList(
                ContractAlias.builder().idContrato("123456789012345678").alias("Contrato 1").indicadorVisibilidad("S").build(),
                ContractAlias.builder().idContrato("123456789012345679").alias("Contrato 2").indicadorVisibilidad("N").build()
        );

        Aliasparams aliasParam = Aliasparams.builder()
                .internal_user(user)
                .id_list(contracts)
                .global_position(globalPosition)
                .build();

        UriComponentsBuilder builder = UriComponentsBuilder.fromPath(PATH_CONTRACTS)
                .queryParam("internal_user", "12345678")
                .queryParam("contract_list", "123456789012345678,123456789012345679")
                .queryParam("global_position", "1");


        HttpEntity request = new HttpEntity(aliasParam);

        ResponseEntity<ContractsAliasResponse> response = restTemplate.exchange(builder.build().encode().toUri(), HttpMethod.POST, null,
                new ParameterizedTypeReference<ContractsAliasResponse>() {
                });
    
        assertThat(response).isNotNull();
        assertThat(HttpStatus.BAD_REQUEST).isEqualTo( response.getStatusCode());
    }


    /**
     *  if request whith bad internal User should return Bad Request status
     * */
    @Test
    public void findAliasContracts_internal_user_Bad_request() {
        String user = "12345678918673126736182673";
        List<String> contracts = Arrays.asList("123456789012345678");
        String globalPosition = "1";

        Aliasparams aliasParam = Aliasparams.builder()
                .internal_user(user)
                .id_list(contracts)
                .global_position(globalPosition)
                .build();

        when(contractsService.findContractsAlias(aliasParam))
                .thenReturn(
                        new HashMap<String, ContractAlias>(){{
                            put("123456789012345678", ContractAlias.builder().idContrato("123456789012345678").alias("Contrato 1").indicadorVisibilidad("S").build());
                            put("123456789012345679", ContractAlias.builder().idContrato("123456789012345679").alias("Contrato 2").indicadorVisibilidad("N").build());
                        }}
                        );

        UriComponentsBuilder builder = UriComponentsBuilder.fromPath(PATH_CONTRACTS);

        HttpEntity request = new HttpEntity(aliasParam);
        ResponseEntity<ContractsAliasResponse> response = restTemplate.exchange(builder.build().encode().toUri(), HttpMethod.POST, request,
                new ParameterizedTypeReference<ContractsAliasResponse>() {
                });
    
        assertThat(response).isNotNull();
        assertThat(HttpStatus.BAD_REQUEST).isEqualTo( response.getStatusCode());
    }

    /**
     *  if request whith bad global position should return Bad Request status
     * */
    @Test
    public void findAliasContracts_global_position_Bad_request() {
        String user = "12345678912312312321323";
        List<String> contracts = Arrays.asList("123456789012345678");
        String globalPosition = "aaaa";

        Aliasparams aliasParam = Aliasparams.builder()
                .internal_user(user)
                .id_list(contracts)
                .global_position(globalPosition)
                .build();

        when(contractsService.findContractsAlias(aliasParam))
                .thenReturn( new HashMap<String, ContractAlias>(){{
                    put("123456789012345678", ContractAlias.builder().idContrato("123456789012345678").alias("Contrato 1").indicadorVisibilidad("S").build());
                    }}
                    );

        UriComponentsBuilder builder = UriComponentsBuilder.fromPath(PATH_CONTRACTS);

        HttpEntity request = new HttpEntity(aliasParam);
        ResponseEntity<ContractsAliasResponse> response = restTemplate.exchange(builder.build().encode().toUri(), HttpMethod.POST, request,
                new ParameterizedTypeReference<ContractsAliasResponse>() {
                });
    
        assertThat(response).isNotNull();
        assertThat(HttpStatus.BAD_REQUEST).isEqualTo( response.getStatusCode());
    }

    /**
     *  if request whith bad element in contract_list should return Bad Request status
     * */
    @Test
    public void findAliasContracts_contract_list_element_Bad_request() {
        String user = "12345678912312312321323";
        List<String> contracts = Arrays.asList("1234567890");
        String globalPosition = "1";

        Aliasparams aliasParam = Aliasparams.builder()
                .internal_user(user)
                .id_list(contracts)
                .global_position(globalPosition)
                .build();
        when(contractsService.findContractsAlias(aliasParam))
                .thenReturn(
                        new HashMap<String, ContractAlias>(){{
                            put("123456789012345678", ContractAlias.builder().idContrato("123456789012345678").alias("Contrato 1").indicadorVisibilidad("S").build());
                        }}
                );

        UriComponentsBuilder builder = UriComponentsBuilder.fromPath(PATH_CONTRACTS);


        HttpEntity request = new HttpEntity(aliasParam);

        ResponseEntity<ContractsAliasResponse> response = restTemplate.exchange(builder.build().encode().toUri(), HttpMethod.POST, request,
                new ParameterizedTypeReference<ContractsAliasResponse>() {
                });
    
        assertThat(response).isNotNull();
        assertThat(HttpStatus.BAD_REQUEST).isEqualTo( response.getStatusCode());
    }

    /**
     *  if request whithouth internal User should return Bad Request status
     * */
    @Test
    public void findAliasContracts_internal_user_null() {
        String user = null;
        List<String> contracts = Arrays.asList("123456789012345678");
        String globalPosition = "1";

        Aliasparams aliasParam = Aliasparams.builder()
                .internal_user(user)
                .id_list(contracts)
                .global_position(globalPosition)
                .build();
        when(contractsService.findContractsAlias(aliasParam))
                .thenReturn(
                        new HashMap<String, ContractAlias>(){{
                            put("123456789012345678", ContractAlias.builder().idContrato("123456789012345678").alias("Contrato 1").indicadorVisibilidad("S").build());
                            put("123456789012345679", ContractAlias.builder().idContrato("123456789012345679").alias("Contrato 2").indicadorVisibilidad("N").build());
                        }}
                );

        UriComponentsBuilder builder = UriComponentsBuilder.fromPath(PATH_CONTRACTS);

        HttpEntity request = new HttpEntity(aliasParam);

        ResponseEntity<ContractsAliasResponse> response = restTemplate.exchange(builder.build().encode().toUri(), HttpMethod.POST, request,
                new ParameterizedTypeReference<ContractsAliasResponse>() {
                });
    
        assertThat(response).isNotNull();
        assertThat(HttpStatus.BAD_REQUEST).isEqualTo( response.getStatusCode());
    }

    /**
     *  if request whithouth contract list should return Bad Request status
     * */
    @Test
    public void findAliasContracts_contract_list_element_null() {
        String user = "12345678";
        List<String> contracts = null;
        String globalPosition = "1";

        Aliasparams aliasParam = Aliasparams.builder()
                .internal_user(user)
                .id_list(contracts)
                .global_position(globalPosition)
                .build();
        when(contractsService.findContractsAlias(eq(aliasParam)))
                .thenReturn(
                        new HashMap<String, ContractAlias>(){{
                            put("123456789012345678", ContractAlias.builder().idContrato("123456789012345678").alias("Contrato 1").indicadorVisibilidad("S").build());
                        }}
                        );

        UriComponentsBuilder builder = UriComponentsBuilder.fromPath(PATH_CONTRACTS);

        HttpEntity request = new HttpEntity(aliasParam);
        ResponseEntity<ContractsAliasResponse> response = restTemplate.exchange(builder.build().encode().toUri(), HttpMethod.POST, request,
                new ParameterizedTypeReference<ContractsAliasResponse>() {
                });
    
        assertThat(response).isNotNull();
        assertThat(HttpStatus.BAD_REQUEST).isEqualTo( response.getStatusCode());
    }

    @Test
    public void testValidUserIds(){
        String VALID_USER = "12345678";

        when(cardsService.findCardsAlias(any())).thenReturn( Collections.EMPTY_MAP );

        UriComponentsBuilder builder = UriComponentsBuilder.fromPath(PATH_CARDS);


        Aliasparams aliasParams = Aliasparams.builder()
                .global_position("1")
                .internal_user(VALID_USER)
                .id_list(Arrays.asList("1234567890123456","1234567890123457"))
                .build();

        HttpEntity request = new HttpEntity(aliasParams);
        val response = restTemplate.postForEntity(builder.build().toUri(), request, CardsAliasResponse.class);
    
        assertThat(response).isNotNull();
        assertThat(HttpStatus.OK).isEqualTo( response.getStatusCode());

        val USER_WITH_CHARACTERS = "MM25868M";

        UriComponentsBuilder builder2 = UriComponentsBuilder.fromPath(PATH_CARDS);

        aliasParams.setInternal_user(USER_WITH_CHARACTERS);

        HttpEntity request2 = new HttpEntity(aliasParams);
        val response2 = restTemplate.postForEntity(builder2.build().toUri(), request2, CardsAliasResponse.class);
    
        assertThat(response2).isNotNull();
        assertThat(HttpStatus.OK).isEqualTo( response2.getStatusCode());

        val USER_TOO_LONG = "1234567890123456";

        UriComponentsBuilder builder3 = UriComponentsBuilder.fromPath(PATH_CARDS);
        aliasParams.setInternal_user(USER_TOO_LONG);
        HttpEntity request3 = new HttpEntity(aliasParams);
        val response3 = restTemplate.postForEntity(builder3.build().toUri(), request3, CardsAliasResponse.class);
    
        assertThat(response3).isNotNull();
        assertThat(HttpStatus.BAD_REQUEST).isEqualTo( response3.getStatusCode());

        val USER_TOO_SHORT = "1234M";

        UriComponentsBuilder builder4 = UriComponentsBuilder.fromPath(PATH_CARDS);
        aliasParams.setInternal_user(USER_TOO_LONG);
        HttpEntity request4 = new HttpEntity(aliasParams);

        val response4 = restTemplate.postForEntity(builder4.build().toUri(), request4, CardsAliasResponse.class);
    
        assertThat(response4).isNotNull();
        assertThat(HttpStatus.BAD_REQUEST).isEqualTo( response3.getStatusCode());

    }

}
