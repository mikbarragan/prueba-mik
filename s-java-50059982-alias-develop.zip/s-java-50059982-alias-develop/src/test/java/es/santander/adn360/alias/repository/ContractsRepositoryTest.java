package es.santander.adn360.alias.repository;

import com.mongodb.BasicDBList;
import com.mongodb.DBObject;
import es.santander.adn360.alias.config.MongoCollectionsProperties;
import es.santander.adn360.alias.domain.ContractAlias;
import es.santander.adn360.alias.web.Aliasparams;
import org.apache.commons.io.FileUtils;
import org.bson.BsonArray;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.mongodb.core.MongoOperations;

import java.nio.charset.Charset;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;


@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class ContractsRepositoryTest {

    @Autowired
    private MongoOperations mongoOperations;

    @Autowired
    private MongoCollectionsProperties collections;

    @Autowired
    private ContractsRepositoryImpl contractsRepository;

    @BeforeEach
    public void setUp() throws Exception {
        String doc = FileUtils.readFileToString(
                new ClassPathResource("json/adn360.alias-contracts.json").getFile(),
                Charset.defaultCharset()
        );
    
        final BsonArray parse = BsonArray.parse(doc);
        BasicDBList dbList = new BasicDBList();
        dbList.addAll(parse);
        DBObject dbObject = dbList;
        ((BasicDBList) dbObject).forEach(dbo -> mongoOperations.save(dbo, collections.getAliasContracts()));

        String docEmp = FileUtils.readFileToString(
                new ClassPathResource("json/adn360.alias-contracts-emp.json").getFile(),
                Charset.defaultCharset()
        );

        final BsonArray parseEmp = BsonArray.parse(docEmp);
        BasicDBList dbListEmp = new BasicDBList();
        dbListEmp.addAll(parseEmp);
        DBObject dbObjectEmp = dbListEmp;
        ((BasicDBList) dbObjectEmp).forEach(dbo -> mongoOperations.save(dbo, collections.getAliasContractsEmp()));
    }


    /**
     * The repository should return only the documents that:
     * usuarioInterno = 00237078
     * pan = 003011272710001832 || 003011272710001844 || 003011272710001872 || 003011272710001836 || 003015392710022553
     * posicionGlobal = 1
     */
    @Test
    public void findContractsAliasFilteringCorrectly_1() {
        String user = "00237078";
        List<String> contractList = Arrays.asList("003011272710001832", "00301127271000144","00301127271000172", "003011272710001836", "003015392710022553");
        String globalPosition = "1";

        Aliasparams aliasParam = Aliasparams.builder()
                .internal_user(user)
                .id_list(contractList)
                .global_position(globalPosition)
                .build();
        Map<String, ContractAlias> response = contractsRepository.findContractsAlias(aliasParam);

        assertThat(response).isNotNull();
        assertThat(response.size()).isEqualTo(2);
        assertThat(response.get("003011272710001832").getIdContrato()).isEqualTo("003011272710001832");
        assertThat(response.get("003011272710001832").getAlias()).isEqualTo("cuenta1");
        assertThat(response.get("003011272710001832").getIndicadorVisibilidad()).isEqualTo("N");

        assertThat(response.get("003011272710001836").getIdContrato()).isEqualTo("003011272710001836");
        assertThat(response.get("003011272710001836").getAlias()).isEqualTo("home");
        assertThat(response.get("003011272710001836").getIndicadorVisibilidad()).isEqualTo("S");



    }

    /**
     * The repository should return only the documents that:
     * usuarioInterno = UEEBXB1Y
     * posicionGlobal = 1
     */
    @Test
    public void findContractsAliasEmpFilteringCorrectly_1() {
        String user = "UEEBXB1Y";
        List<String> contractList = Arrays.asList("004900755021898765", "004900015013435195","004900015013435196",
                "004900015013435197", "004900015013435198");
        String globalPosition = "1";

        Aliasparams aliasParam = Aliasparams.builder()
                .internal_user(user)
                .id_list(contractList)
                .global_position(globalPosition)
                .build();
        Map<String, ContractAlias> response = contractsRepository.findContractsAliasEmp(aliasParam);

        assertThat(response).isNotNull();
        assertThat(response.size()).isEqualTo(contractList.size());
        assertThat(response.get("004900755021898765").getIdContrato()).isEqualTo("004900755021898765");
        assertThat(response.get("004900755021898765").getAlias()).isEqualTo("Alias Contrato Tarjeta m4");

        assertThat(response.get("004900015013435195").getIdContrato()).isEqualTo("004900015013435195");
        assertThat(response.get("004900015013435195").getAlias()).isEqualTo("Alias Contrato Tarjeta   ");

    }

    /**
     * The repository should return only the documents that:
     * usuarioInterno = 00237065
     * pan = 003011272710001832 || 003011272710001844 || 003011272710001836 || 003015392710022553
     * posicionGlobal = 1
     */
    @Test
    public void findContractsAliasFilteringCorrectly_2() {
        String user = "00237065";
        List<String> contractList = Arrays.asList("003011272710001832", "00301127271000144", "003011272710001836", "003015392710022553");
        String globalPosition = "1";

        Aliasparams aliasParam = Aliasparams.builder()
                .internal_user(user)
                .id_list(contractList)
                .global_position(globalPosition)
                .build();
        Map<String, ContractAlias> response = contractsRepository.findContractsAlias(aliasParam);

        assertThat(response).isNotNull();
        assertThat(response.size()).isEqualTo(1);
        assertThat(response.get("003011272710001832").getIdContrato()).isEqualTo("003011272710001832");
        assertThat(response.get("003011272710001832").getAlias()).isEqualTo("cuenta3");
        assertThat(response.get("003011272710001832").getIndicadorVisibilidad()).isEqualTo("N");

    }

    /**
     * The repository should return only the documents that:
     * usuarioInterno = 00237078
     * pan = 003011272710001832 || 003011272710001844 || 003011272710001872 || 003011272710001836 || 003015392710022553
     * posicionGlobal = 2
     */
    @Test
    public void findContractsAliasFilteringCorrectly_3() {
        String user = "00237078";
        List<String> contractList = Arrays.asList("003011272710001832", "00301127271000144","00301127271000172", "003011272710001836", "003015392710022553");
        String globalPosition = "2";

        Aliasparams aliasParam = Aliasparams.builder()
                .internal_user(user)
                .id_list(contractList)
                .global_position(globalPosition)
                .build();
        Map<String, ContractAlias> response = contractsRepository.findContractsAlias(aliasParam);

        assertThat(response).isNotNull();
        assertThat(response.size()).isEqualTo(2);
        assertThat(response.get("003011272710001832").getIdContrato()).isEqualTo("003011272710001832");
        assertThat(response.get("003011272710001832").getAlias()).isEqualTo("cuenta2");
        assertThat(response.get("003011272710001832").getIndicadorVisibilidad()).isEqualTo("S");

        assertThat(response.get("003015392710022553").getIdContrato()).isEqualTo("003015392710022553");
        assertThat(response.get("003015392710022553").getAlias()).isEqualTo("CUENTA CORRIENTE");
        assertThat(response.get("003015392710022553").getIndicadorVisibilidad()).isEqualTo("S");


    }


    /**
     * The repository should return only the documents that:
     * usuarioInterno = 00237078
     * pan = 003011272710001832 || 003015392710022577
     * posicionGlobal = 2
     */
    @Test
    public void findContractsAliasFilteringCorrectly_Fecha_baja() {
        String user = "00237078";
        List<String> contractList = Arrays.asList("003011272710001832", "003015392710022577");
        String globalPosition = "2";

        Aliasparams aliasParam = Aliasparams.builder()
                .internal_user(user)
                .id_list(contractList)
                .global_position(globalPosition)
                .build();
        Map<String, ContractAlias> response = contractsRepository.findContractsAlias(aliasParam);

        assertThat(response).isNotNull();
        assertThat(response.size()).isEqualTo(1);
        assertThat(response.get("003011272710001832").getIdContrato()).isEqualTo("003011272710001832");
        assertThat(response.get("003011272710001832").getAlias()).isEqualTo("cuenta2");
        assertThat(response.get("003011272710001832").getIndicadorVisibilidad()).isEqualTo("S");

    }

    @Test
    public void findContractsAliasEMPFilteringCorrectly_Fecha_baja() {
        String user = "UEEBXB84";
        List<String> contractList = Arrays.asList("004900015065594276", "004900015065594273");

        Aliasparams aliasParam = Aliasparams.builder()
                .internal_user(user)
                .id_list(contractList)
                .build();
        Map<String, ContractAlias> response = contractsRepository.findContractsAliasEmp(aliasParam);

        assertThat(response).isNotNull();
        assertThat(response.size()).isEqualTo(1);
        assertThat(response.get("004900015065594276").getIdContrato()).isEqualTo("004900015065594276");
        assertThat(response.get("004900015065594276").getAlias()).isEqualTo("CTO Tarjetadebito gira   ");

    }

    @Test
    public void findContractsAliasEMPFilteringCorrectly_AliasTexto() {
        String user = "UEEBXB1Y";
        List<String> contractList = Arrays.asList("004900755021898765", "004900015013435195","004900015013435196",
                "004900015013435197", "004900015013435198");

        Aliasparams aliasParam = Aliasparams.builder()
                .internal_user(user)
                .id_list(contractList)
                .alias("m4")
                .build();
        Map<String, ContractAlias> response = contractsRepository.findContractsAliasEmp(aliasParam);

        assertThat(response).isNotNull();
        assertThat(response.size()).isEqualTo(1);

        assertThat(response.get("004900755021898765").getIdContrato()).isEqualTo("004900755021898765");
        assertThat(response.get("004900755021898765").getAlias()).isEqualTo("Alias Contrato Tarjeta m4");

    }

    @Test
    public void findContractsAliasEMPFilteringCorrectly_AliasTexto_SinResultado() {
        String user = "UEEBXB1Y";
        List<String> contractList = Arrays.asList("004900755021898765", "004900015013435195","004900015013435196",
                "004900015013435197", "004900015013435198");

        Aliasparams aliasParam = Aliasparams.builder()
                .internal_user(user)
                .id_list(contractList)
                .alias("sin resultado")
                .build();
        Map<String, ContractAlias> response = contractsRepository.findContractsAliasEmp(aliasParam);

        assertThat(response).isEmpty();

    }

}
