package es.santander.adn360.alias.services;

import es.santander.adn360.alias.domain.ContractAlias;
import es.santander.adn360.alias.repository.ContractsRepository;
import es.santander.adn360.alias.service.ContractsServiceImpl;
import es.santander.adn360.alias.web.Aliasparams;
import es.santander.adn360.core.model.exception.FunctionalException;
import es.santander.adn360.core.util.ExceptionEnum;
import es.santander.adn360.core.web.CoreSecurityContextImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

public class ContractServiceTest {

    @Mock
    private ContractsRepository contractsRepository;

    @InjectMocks
    private ContractsServiceImpl contractsService;

    private static final CoreSecurityContextImpl CORE_SECURITY_CONTEXT = (CoreSecurityContextImpl) Mockito.mock(CoreSecurityContextImpl.class);

    @BeforeEach
    public void setup() {
        //Initialize security context
        SecurityContextHolder.setContext(CORE_SECURITY_CONTEXT);
        mockSantanderChannel("OFI");
        initMocks(this);
    }

    private void mockSantanderChannel(String santanderChannel) {
        Mockito.when(CORE_SECURITY_CONTEXT.getSantanderChannel()).thenReturn(santanderChannel);
    }

    /** When call to findContractAlias and repository return data, the service should return data */
    @Test
    public void findContractAliasShouldReturnListOfContractsList(){

        String user = "00666845";
        List<String> contracts = Arrays.asList( "003011272710001832", "003011272710001833", "003011272710001834" );
        String globalPosition = "1";

        when(contractsRepository.findContractsAlias(any() ))
                .thenReturn(
                        new HashMap<String, ContractAlias>(){{
                            put("003011272710001832", ContractAlias.builder().idContrato("003011272710001832").indicadorVisibilidad("S").usuarioInterno("00666845").alias("ContractAlias 1").posicionGlobal("1").build());
                            put("003011272710001833", ContractAlias.builder().idContrato("003011272710001833").indicadorVisibilidad("N").usuarioInterno("00666845").alias("ContractAlias 2").posicionGlobal("1").build());
                            put("003011272710001834", ContractAlias.builder().idContrato("003011272710001834").indicadorVisibilidad("S").usuarioInterno("00666845").alias("ContractAlias 3").posicionGlobal("1").build());
                        }}
                 );

        Aliasparams aliasParam = Aliasparams.builder()
                .internal_user(user)
                .id_list(contracts)
                .global_position(globalPosition)
                .build();
        Map<String, ContractAlias> response = contractsService.findContractsAlias( aliasParam );

        assertThat( response ).isNotNull();
        assertThat( response.size() ).isEqualTo( 3 );

        assertThat( response.get("003011272710001832").getIdContrato()).isEqualTo("003011272710001832");
        assertThat( response.get("003011272710001832").getIndicadorVisibilidad()).isEqualTo("S");
        assertThat( response.get("003011272710001832").getAlias()).isEqualTo("ContractAlias 1");
        assertThat( response.get("003011272710001832").getUsuarioInterno()).isEqualTo("00666845");

        assertThat( response.get("003011272710001833").getIdContrato()).isEqualTo("003011272710001833");
        assertThat( response.get("003011272710001833").getIndicadorVisibilidad()).isEqualTo("N");
        assertThat( response.get("003011272710001833").getAlias()).isEqualTo("ContractAlias 2");
        assertThat( response.get("003011272710001833").getUsuarioInterno()).isEqualTo("00666845");

        assertThat( response.get("003011272710001834").getIdContrato()).isEqualTo("003011272710001834");
        assertThat( response.get("003011272710001834").getIndicadorVisibilidad()).isEqualTo("S");
        assertThat( response.get("003011272710001834").getAlias()).isEqualTo("ContractAlias 3");
        assertThat( response.get("003011272710001834").getUsuarioInterno()).isEqualTo("00666845");

    }

    /** When call to findContractAlias and repository return data, the service should return data */
    @Test
    public void findContractAliasEMPShouldReturnListOfContractsList(){
        mockSantanderChannel("EMP");
        String user = "UEEBXB1Y";
        List<String> contracts = Arrays.asList( "003011272710001832", "003011272710001833", "003011272710001834" );
        String globalPosition = "1";

        when(contractsRepository.findContractsAliasEmp(any()))
                .thenReturn(
                        new HashMap<String, ContractAlias>(){{
                            put("003011272710001832", ContractAlias.builder().idContrato("003011272710001832").usuarioInterno("UEEBXB1Y").alias("ContractAlias 1").build());
                            put("003011272710001833", ContractAlias.builder().idContrato("003011272710001833").usuarioInterno("UEEBXB1Y").alias("ContractAlias 2").build());
                            put("003011272710001834", ContractAlias.builder().idContrato("003011272710001834").usuarioInterno("UEEBXB1Y").alias("ContractAlias 3").build());
                        }}
                );

        Aliasparams aliasParam = Aliasparams.builder()
                .internal_user(user)
                .id_list(contracts)
                .global_position(globalPosition)
                .build();
        Map<String, ContractAlias> response = contractsService.findContractsAlias( aliasParam );

        assertThat( response ).isNotNull();
        assertThat( response.size() ).isEqualTo( contracts.size() );

        assertThat( response.get("003011272710001832").getIdContrato()).isEqualTo("003011272710001832");
        assertThat( response.get("003011272710001832").getAlias()).isEqualTo("ContractAlias 1");
        assertThat( response.get("003011272710001832").getUsuarioInterno()).isEqualTo("UEEBXB1Y");

        assertThat( response.get("003011272710001833").getIdContrato()).isEqualTo("003011272710001833");
        assertThat( response.get("003011272710001833").getAlias()).isEqualTo("ContractAlias 2");
        assertThat( response.get("003011272710001833").getUsuarioInterno()).isEqualTo("UEEBXB1Y");

        assertThat( response.get("003011272710001834").getIdContrato()).isEqualTo("003011272710001834");
        assertThat( response.get("003011272710001834").getAlias()).isEqualTo("ContractAlias 3");
        assertThat( response.get("003011272710001834").getUsuarioInterno()).isEqualTo("UEEBXB1Y");

    }

    /** When call to findContractsAlias and repository return an empty List, the service should return empty List */
    @Test
    public void findContractsAliasShouldReturnEmptyList(){

        String user = "00666845";
        List<String> contracts = Arrays.asList( "003011272710001832", "003011272710001833", "003011272710001834" );
        String globalPosition = "1";

        when(contractsRepository.findContractsAlias(any() ))
                .thenReturn( Collections.EMPTY_MAP );


        Aliasparams aliasParam = Aliasparams.builder()
                .internal_user(user)
                .id_list(contracts)
                .global_position(globalPosition)
                .build();
        Map<String, ContractAlias> response = contractsService.findContractsAlias( aliasParam );

        assertThat( response ).isNotNull();
        assertThat( response.size() ).isEqualTo( 0 );
    }


    /** When call to findContractsAlias and repository thrown Exception, the service should thrown the same exception */
    @Test
    public void findContractsAliasShouldReturnError(){
    
        
        
        String user = "00666845";
        List<String> contracts = Arrays.asList( "003011272710001832", "003011272710001833", "003011272710001834" );
        String globalPosition = "1";

        when(contractsRepository.findContractsAlias(any() ))
                .thenThrow( new FunctionalException(ExceptionEnum.INTERNAL_SERVER_ERROR, "Error de prueba"));

        Aliasparams aliasParam = Aliasparams.builder()
                .internal_user(user)
                .id_list(contracts)
                .global_position(globalPosition)
                .build();
        assertThrows(FunctionalException.class, () -> contractsService.findContractsAlias( aliasParam ));

    }

    @Test
    public void findContractAliasEMP_withAliasText_ShouldReturnListOfContractsList(){
        mockSantanderChannel("EMP");
        String user = "UEEBXB1Y";
        List<String> contracts = Arrays.asList( "003011272710001832", "003011272710001833", "003011272710001834" );
        String globalPosition = "1";

        when(contractsRepository.findContractsAliasEmp(any()))
                .thenReturn(
                        new HashMap<String, ContractAlias>(){{
                            put("003011272710001833", ContractAlias.builder().idContrato("003011272710001833").usuarioInterno("UEEBXB1Y").alias("Ahorro comun").build());
                            put("003011272710001834", ContractAlias.builder().idContrato("003011272710001834").usuarioInterno("UEEBXB1Y").alias("Familia e hijos ahorro").build());
                        }}
                );

        Aliasparams aliasParam = Aliasparams.builder()
                .internal_user(user)
                .id_list(contracts)
                .global_position(globalPosition)
                .alias("ahorro")
                .build();
        Map<String, ContractAlias> response = contractsService.findContractsAlias( aliasParam );

        assertThat( response ).isNotNull();
        assertThat( response.size() ).isEqualTo( 2 );

        assertThat( response.get("003011272710001833").getIdContrato()).isEqualTo("003011272710001833");
        assertThat( response.get("003011272710001833").getAlias()).isEqualTo("Ahorro comun");
        assertThat( response.get("003011272710001833").getUsuarioInterno()).isEqualTo("UEEBXB1Y");

        assertThat( response.get("003011272710001834").getIdContrato()).isEqualTo("003011272710001834");
        assertThat( response.get("003011272710001834").getAlias()).isEqualTo("Familia e hijos ahorro");
        assertThat( response.get("003011272710001834").getUsuarioInterno()).isEqualTo("UEEBXB1Y");

    }

}
