package es.santander.adn360.alias.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.Paths;
import org.junit.jupiter.api.Test;
import org.springdoc.core.GroupedOpenApi;
import org.springdoc.core.customizers.OpenApiCustomiser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class SwaggerConfigTest {
    private static final String GROUP = "api-web";
    private static final String PACKAGE_TO_SCAN = "es.santander.adn360.alias.web";

    @Autowired
    private OpenAPI openApi;
    @Autowired
    private OpenApiCustomiser openApiCustomiser;

    @Test
    void testSwaggerConfig(){
        GroupedOpenApi groupedOpenApi = new SwaggerConfig().api();
        assertThat(groupedOpenApi.getGroup()).isEqualToIgnoringCase(GROUP);
        assertThat(groupedOpenApi.getPackagesToScan().get(0)).isEqualToIgnoringCase(PACKAGE_TO_SCAN);
        assertThat(groupedOpenApi.getOperationCustomizers()).isNotNull();

        openApi.setPaths(new Paths());
        openApiCustomiser.customise(openApi);
    }
}
