## Release 8.0.0
* [ESPC360-11898](https://sanes.atlassian.net/browse/ESPC360-11898)__
  * [Migrar Darwin 4.x] ls-java-50059982-security
## Release 3.177.0 (6.1.0)
* [ESPC360-5203](https://sanes.atlassian.net/browse/ESPC360-5203)__
  * [CACHE] - Optimizar caché librería product-commons
## Release 6.0.4
* [ESPC360-5935](https://sanes.atlassian.net/browse/ESPC360-5935)__
*  fix security.properties
## Release 6.0.3
* Hotfix: parallelStream is changes with stream

## Release 6.0.0
* [ESPC360-4284](https://sanes.atlassian.net/browse/ESPC360-4284)__
    * Implementación reactiva parcial
## Release 3.165.0
* [PORTALADN-38898](https://sanes.atlassian.net/browse/PORTALADN-38898)__
    * Integrar migraciones Darwin 3.2 (1/2)
## Release 4.0.3
* [#] Fix Renombrado Electronic-Banking
## Release 3.1.4
* [#26512] Se aplica getUserInfo solo en peticiones autenticadas
## Release 3.1.3
* [#25895] Sobrecarga método filterContracts para pasar el productId como parámetro
## Release 3.1.2
* [#24953] Quitar actuator de la primera comprobacion en el filtro web
## Release 3.1.0
* [#24953] Nuevos filtros para banca electronica
## Release 3.0.0
* [#] Java 11 y Darwin
## Release 2.3.3 - 2.3.9
* [#22341] Eliminación de la codificación de respuesta
## Release 2.3.2
* [#21814] Add confidentiality header to response
## Release 2.3.0
* [#19100] New method for validate contracts included
## Release 2.2.1
* [#16429] Added electronic banking security by EMP