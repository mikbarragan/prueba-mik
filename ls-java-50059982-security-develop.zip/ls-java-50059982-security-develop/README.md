# README - Seguridad ADN360
Library that implements security methods to validate authorization of the logged user.

# Releases
## release 4.x 
* Migrated to Darwin 3.x
# Configuration
## Example
```yaml
# Security Authorization config DISABLED | CONFIDENTIALITY | BOLASEG | EBANKING
adn360.security:
  enabled: true
  channel:  
    OFI:
      personSecType: CONFIDENTIALITY
      contractSecType: CONFIDENTIALITY
    EMP:
      personSecType: EBANKING
      contractSecType: EBANKING
    EMPB:
      personSecType: DISABLED
      contractSecType: DISABLED
    RML:
      personSecType: BOLASEG
      contractSecType: BOLASEG
    INT:
      personSecType: BOLASEG
      contractSecType: BOLASEG
    CIC:
      personSecType: CONFIDENTIALITY
      contractSecType: CONFIDENTIALITY
    ATM:
      personSecType: CONFIDENTIALITY
      contractSecType: CONFIDENTIALITY
  services:
    confidentialityService:
      personSecurityUri: http://adn360-confidentiality${BG}:8080/confidentiality/validateCustomer
      contractsSecurityUri: http://adn360-confidentiality${BG}:8080/confidentiality/filterContracts
    bolasegService:
      personSecurityUri: http://adn360-bolaseg${BG}:8080/checkSeguridadOperativa
      contractsSecurityUri: http://adn360-bolaseg${BG}:8080/checkSeguridadOperativa/filterContracts
    ebankingService:
      personSecurityUri: http://s-java-50059982-electronic-banking${BG}:8080/electronicBanking/validateCustomer
      contractsSecurityUri: http://s-java-50059982-electronic-banking${BG}:8080/electronicBanking/filterContracts
    # The following configuration is for the reactive version of the services
    # Since they use WebClient, a base url is needed to be configured
    confidentialityServiceReactive:
      baseUrl: http://s-java-50059982-confidentiality${BG}:8080
      personSecurityPath: /confidentiality/validateCustomer
      contractsSecurityPath: /confidentiality/filterContracts
    bolasegServiceReactive:
      baseUrl: http://s-java-50059982-bolaseg${BG}:8080
      personSecurityPath: /checkSeguridadOperativa
      contractsSecurityPath: /checkSeguridadOperativa/filterContracts
    ebankingServiceReactive:
      baseUrl: http://s-java-50059982-electronic-banking${BG}:8080
      personSecurityPath: /electronicBanking/validateCustomer
      contractsSecurityPath: /v2/electronicBanking/filter-contracts
      principalAndSubsidiariesPath: /v2/electronicBanking/principal-and-subsidiaries
  contracDetailFilter:
    enabled: true
```

## CONFIDENTIALITY
Validates the confidentiality of the user or contracts, is oriented to validate office users.

## BOLASEG
Validates operative security, oriented to final users.

## EBANKING
Validates electronic banking filters, for business users.
