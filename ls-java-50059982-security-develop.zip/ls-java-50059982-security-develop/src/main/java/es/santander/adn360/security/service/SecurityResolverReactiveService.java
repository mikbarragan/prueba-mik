package es.santander.adn360.security.service;

import es.santander.adn360.core.model.exception.FunctionalException;
import es.santander.adn360.core.util.ExceptionEnum;
import es.santander.adn360.security.config.SecurityConfigProperties;
import lombok.val;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.Map;

import static es.santander.adn360.security.constants.SecurityConstants.CHANNEL_EMP;

/**
 * Service that selects the type of security that will be passed through configuration
 */
@Service
@ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.REACTIVE)
public class SecurityResolverReactiveService {

    private static final String PERSON_CONFIG = "person";
    private static final String CONTRACT_CONFIG = "contract";

    /**
     * Security configuration properties that are used to configure the security services.
     */
    protected SecurityConfigProperties securityConfigProperties;
    private SecurityReactiveServiceNA securityServiceNa;
    private BolasegReactiveService bolasegService;
    private ConfidentialityReactiveService confidencialityService;
    private EbankingReactiveService ebankingService;
    private ReactiveContextService reactiveContextService;

    Map<SecurityConfigProperties.SecurityMode, SecurityReactiveService> securityServicesMap;

    /**
     * Constructor
     *
     * @param securityConfigProperties securityConfigProperties
     * @param securityServiceNa        default service
     * @param bolasegService           bolasegService
     * @param confidencialityService   confidencialityService
     * @param ebankingService          ebankingService
     * @param reactiveContextService   reactiveContextService
     */
    public SecurityResolverReactiveService(
            SecurityConfigProperties securityConfigProperties,
            SecurityReactiveServiceNA securityServiceNa,
            BolasegReactiveService bolasegService,
            ConfidentialityReactiveService confidencialityService,
            EbankingReactiveService ebankingService,
            ReactiveContextService reactiveContextService
    ) {
        this.securityConfigProperties = securityConfigProperties;
        this.securityServiceNa = securityServiceNa;
        this.bolasegService = bolasegService;
        this.confidencialityService = confidencialityService;
        this.ebankingService = ebankingService;
        this.reactiveContextService = reactiveContextService;

        this.securityServicesMap = Map.of(
                SecurityConfigProperties.SecurityMode.EBANKING, this.ebankingService,
                SecurityConfigProperties.SecurityMode.CONFIDENTIALITY, this.confidencialityService,
                SecurityConfigProperties.SecurityMode.BOLASEG, this.bolasegService,
                SecurityConfigProperties.SecurityMode.DISABLED, this.securityServiceNa);
    }

    /**
     * Gets service by person
     *
     * @return security service
     */
    public Mono<SecurityReactiveService> getServiceByPerson() {
        return get(PERSON_CONFIG);
    }

    /**
     * Gets service by contract
     *
     * @return security service
     */
    public Mono<SecurityReactiveService> getServiceByContract() {
        return get(CONTRACT_CONFIG);
    }

    /**
     * Gets service for a given type of configuration
     *
     * @return security service
     */
    private Mono<SecurityReactiveService> get(String typeConfig) {
        return this.reactiveContextService.getSantanderChannel()
                .map((String channel) -> {
                    val channelConfig = validateAndGetChannel(channel);
                    val securityToApply = getSecurityToApply(typeConfig, channelConfig);
                    val securityService = this.securityServicesMap.get(securityToApply);
                    if (securityService == null) {
                        throw new FunctionalException(ExceptionEnum.FORBIDDEN, "Channel not configured.");
                    }
                    return securityService;
        });
    }

    /**
     * Validates Santander channel confidentiality configuration with channel header
     * and returns it if found
     *
     * @param channel channel
     * @return channelConfig
     */
    private SecurityConfigProperties.Channel validateAndGetChannel(String channel) {
        // If channel is invalid or issuer is not configured to apply given channel confidentiality,
        // an error is thrown.
        SecurityConfigProperties.Channel channelConfig = this.securityConfigProperties.getChannel().get(channel);
        if (this.securityConfigProperties.getEnabled() && channelConfig == null) {
            throw new FunctionalException(ExceptionEnum.FORBIDDEN, "Invalid channel");
        } else if (channelConfig == null) {
            throw new FunctionalException(
                    ExceptionEnum.FORBIDDEN, "Security for channel " + channel + " is not configured");
        }
        // Requisito: El canal empresa emplea su servicio para resolver lógica de negocio
        if (CHANNEL_EMP.equals(channel) &&
                (SecurityConfigProperties.SecurityMode.EBANKING != channelConfig.getPersonSecType() ||
                        SecurityConfigProperties.SecurityMode.EBANKING != channelConfig.getContractSecType())) {
            throw new FunctionalException(ExceptionEnum.FORBIDDEN, "Channel EMP security must be EBANKING");
        }
        return channelConfig;
    }

    /**
     * Returns the security to apply depending on the type of configuration and the channel
     *
     * @param typeConfig   typeConfig
     * @param channelConfig channelConfig
     * @return security to apply
     */
    private SecurityConfigProperties.SecurityMode getSecurityToApply(
            String typeConfig, SecurityConfigProperties.Channel channelConfig) {
        switch (typeConfig) {
            case PERSON_CONFIG:
                return channelConfig.getPersonSecType();
            case CONTRACT_CONFIG:
                return channelConfig.getContractSecType();
            default:
                throw new FunctionalException(ExceptionEnum.INVALID_INPUT_PARAMETERS, "Type config invalid");
        }
    }

}
