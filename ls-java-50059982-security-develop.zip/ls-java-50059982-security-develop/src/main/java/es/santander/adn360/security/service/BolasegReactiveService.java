package es.santander.adn360.security.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import es.santander.adn360.core.model.dto.response.GlobalExceptionResponse;
import es.santander.adn360.products.common.domain.entity.BaseContract;
import es.santander.adn360.security.config.SecurityConfigProperties;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.util.UriComponentsBuilder;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.util.function.Tuples;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static es.santander.adn360.security.constants.SecurityConstants.PARAM_CONTRACTS;
import static es.santander.adn360.security.constants.SecurityConstants.PARAM_CUSTOMER_ID;
import static es.santander.adn360.security.constants.SecurityConstants.PARAM_RESPONSE_VALID_CUSTOMER_PARAM;
import static es.santander.adn360.security.constants.SecurityConstants.PARAM_RESPONSE_VALID_CUSTOMER_VALUE;

/**
 * Service for channels that don't pass BolasegSecurity
 */
@Slf4j
@Service
@ConditionalOnClass({BaseContract.class})
@ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.REACTIVE)
@Setter
public class BolasegReactiveService implements SecurityReactiveService {

    private WebClient webClient;
    private SecurityConfigProperties securityConfigProperties;

    /**
     * Constructor
     *
     * @param webClientBuilder          webClient
     * @param securityConfigProperties  securityConfigProperties
     */
    BolasegReactiveService(WebClient.Builder webClientBuilder, SecurityConfigProperties securityConfigProperties) {
        this.securityConfigProperties = securityConfigProperties;
        this.webClient = webClientBuilder
                .baseUrl(this.securityConfigProperties.getServices().getBolasegServiceReactive().getBaseUrl())
                .build();
    }

    /**
     * Method that filters a flux of contracts
     *
     * @param contracts   contracts to filter
     * @param <T>         elements' class
     * @return filtered contracts
     */
    @Override
    public <T extends BaseContract> Flux<T> filterContracts(Flux<T> contracts) {
        return this.filterContracts(contracts, Mono.empty());
    }

    /**
     * Method that filters a flux of contracts
     *
     * @param contracts   contracts to filter
     * @param productId   identifier of the product
     * @param <T>         elements' class
     * @return filtered contracts
     */
    @Override
    public <T extends BaseContract> Flux<T> filterContracts(Flux<T> contracts, Mono<String> productId) {
        return getFilteredContracts(contracts);
    }

    /**
     * Method that indicates if a given customerId is valid
     *
     * @param monoCustomerId  customer identifier
     * @return validity indicator
     */
    @Override
    public Mono<Boolean> validateCustomer(Mono<String> monoCustomerId) {
        return monoCustomerId
                .switchIfEmpty(Mono.just(""))
                .flatMap(this::callToBolasegPersonService)
                .map(responseBody -> PARAM_RESPONSE_VALID_CUSTOMER_VALUE.equals(
                                responseBody.get(PARAM_RESPONSE_VALID_CUSTOMER_PARAM)))
                .switchIfEmpty(Mono.just(false));
    }

    /**
     * Validates if logged user can see the contract
     *
     * @param contract partenon contract
     * @return validity indicator
     */
    @Override
    public Mono<Boolean> validateContract(Mono<BaseContract> contract) {
        return filterContracts(contract.flux()).hasElements();
    }

    /**
     * Method that calls BolasegService and returns a list of filtered contracts
     *
     * @param contracts  flux of elements to check
     * @param <T>        elements' class
     * @return filtered contracts
     */
    private <T extends BaseContract> Flux<T> getFilteredContracts(Flux<T> contracts) {
        return contracts
                .map(BaseContract::getIdContrato)
                .collect(Collectors.toList())
                .flatMapMany(contractsList -> callToBolasegContractsService(contractsList))
                .collectList()
                .flatMapMany(filteredContractsList -> contracts
                        .map(contract -> Tuples.of(contract, filteredContractsList)))
                .filter(tuple -> tuple.getT2().contains(tuple.getT1().getIdContrato()) &&
                        securityConfigProperties.getCompanies().contains(tuple.getT1().getEmpresa()))
                .map(tuple -> tuple.getT1());
    }

    /**
     * Method that calls BolasegService and returns a flux of filtered contracts
     *
     * @param contractsList    list of contracts to check
     * @return flux of contractIds found
     */
    private Flux<String> callToBolasegContractsService(List<String> contractsList) {

        if (contractsList.isEmpty()) {
            return Flux.empty();
        }

        return this.webClient.post()
                .uri(uriBuilder -> uriBuilder
                        .path(this.securityConfigProperties.getServices().getBolasegServiceReactive()
                                .getContractsSecurityPath())
                        .build())
                .body(BodyInserters.fromValue(Map.of(PARAM_CONTRACTS, contractsList)))
                .retrieve()
                .toEntity(new ParameterizedTypeReference<Map<String, Object>>() {})
                .onErrorResume(Exception.class, (Exception err) -> {
                    log.error("Error calling Bolaseg service.");
                    return Mono.error(this.getForbiddenException(err.getMessage()));
                })
                .flatMapMany((ResponseEntity<Map<String, Object>> response) -> {
                    if (HttpStatus.OK != response.getStatusCode()) {
                        final GlobalExceptionResponse exceptionResponse =
                                new ObjectMapper().convertValue(response.getBody(), GlobalExceptionResponse.class);

                        return Mono.error(this.getForbiddenException(exceptionResponse.getMoreInformation()));
                    }

                    return Flux.fromIterable(
                            (List<String>) response.getBody().getOrDefault(PARAM_CONTRACTS, List.of()));
                });
    }

    /**
     * Method that calls BolasegService and returns the response
     *
     * @param customerId     customerId to check
     * @return a map of the response
     */
    private Mono<Map<String, Object>> callToBolasegPersonService(String customerId) {

        if (StringUtils.isEmpty(customerId)) {
            return Mono.empty();
        }

        return this.webClient.get()
                .uri(uriBuilder -> uriBuilder
                        .path(this.securityConfigProperties.getServices().getBolasegServiceReactive()
                                .getPersonSecurityPath())
                        .queryParam(PARAM_CUSTOMER_ID, customerId)
                        .build())
                .retrieve()
                .onStatus(httpStatus -> httpStatus.isError(), (ClientResponse response) -> {
                    log.error("Error calling BolaSeg service. Calling to endpoint {} status code: {}.",
                        UriComponentsBuilder.fromPath(this.securityConfigProperties.getServices().getBolasegService()
                            .getPersonSecurityUri()).build().encode().toUri(), response.rawStatusCode());

                    return Mono.error(this.getForbiddenException("Bolaseg"));
                })
                .bodyToMono(new ParameterizedTypeReference<>() {});
    }

}
