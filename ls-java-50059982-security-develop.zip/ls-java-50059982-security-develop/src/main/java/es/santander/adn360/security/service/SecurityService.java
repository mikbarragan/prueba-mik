package es.santander.adn360.security.service;


import es.santander.adn360.core.model.exception.FunctionalException;
import es.santander.adn360.core.util.ExceptionEnum;
import es.santander.adn360.products.common.domain.entity.BaseContract;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import static es.santander.adn360.security.constants.SecurityConstants.PARAM_CUSTOMER_ID;

/**
 * Service for handle security.
 */
public interface SecurityService {

    /**
     * Filters a list of contracts and returns filtered list with contracts customer can see.
     *
     * @param contracts contract list that it will be filter
     * @param <T>       Object
     * @return Filtered contracts
     */
    <T extends BaseContract> List<T> filterContracts(List<T> contracts);

    /**
     * Filters a list of contracts and returns filtered list with contracts customer can see.
     *
     * @param contracts contract list that it will be filter
     * @param <T>       Object
     * @param productId Product id
     * @return Filtered contracts
     */
    <T extends BaseContract> List<T> filterContracts(List<T> contracts, String productId);

    /**
     * Returns if the current logged user can see given customer contracts.
     *
     * @param customerId Customer identification
     * @return True when customer validation successes.
     */
    Boolean validateCustomer(String customerId);

    /**
     * Returns if the current logged user can see given contract.
     *
     * @param contract partenon contract
     * @return True when contract validation successes.
     */
    Boolean validateContract(BaseContract contract);

    /**
     * Returns logged in user info
     *
     * @return user info
     */
    default Object getUserInfo() {
        return null;
    }

    /**
     * Builds forbidden exception
     *
     * @param moreInformation moreInformation
     * @return exception
     */
    default FunctionalException getForbiddenException(String moreInformation) {
        return new FunctionalException(ExceptionEnum.FORBIDDEN, moreInformation);
    }

    /**
     * Builds invalid parameters exception
     *
     * @param moreInformation moreInformation
     * @return exception
     */
    default FunctionalException getInvalidParametersException(String moreInformation) {
        return new FunctionalException(ExceptionEnum.INVALID_INPUT_PARAMETERS, moreInformation);
    }

    /**
     * Returns a list with the customer_id in the request
     * if customer_id is not present throws InvalidParametersException
     *
     * @return list
     */
    default List<String> resolveCustomerIdList() {
        List<String> customerIdList = Optional.ofNullable(getCustomerId())
                .map(Collections::singletonList)
                .orElse(Collections.emptyList());
        if (customerIdList.isEmpty()) {
            throw this.getInvalidParametersException("customer_id should not be empty");
        }
        return customerIdList;
    }

    /**
     * Gets customer id form request
     *
     * @return customer id
     */
    private static String getCustomerId() {
        HttpServletRequest request =
                ((ServletRequestAttributes) Objects.requireNonNull(RequestContextHolder.getRequestAttributes()))
                        .getRequest();

        return Optional.ofNullable(request.getParameterMap().get(PARAM_CUSTOMER_ID))
                .map((String[] x) -> x[0])
                .orElse(null);
    }

}
