package es.santander.adn360.security.service;

import es.santander.adn360.products.common.domain.entity.BaseContract;
import es.santander.adn360.security.config.SecurityConfigProperties;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Service for channels with DISABLED security
 */
@Slf4j
@Service
@ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
public class SecurityServiceNA implements SecurityService {

    private SecurityConfigProperties securityConfigProperties;

    /**
     * Constructor
     *
     * @param securityConfigProperties securityConfigProperties
     */
    public SecurityServiceNA(SecurityConfigProperties securityConfigProperties) {
        this.securityConfigProperties = securityConfigProperties;
    }

    /**
     * Método para filtrar elementos
     *
     * @param contracts lista de elementos
     * @param <T>       clase de la lista de elementos
     * @return devolución de lista de elementos filtrados
     */
    @Override
    public <T extends BaseContract> List<T> filterContracts(List<T> contracts) {
        return this.filterContracts(contracts, null);
    }

    @Override
    public <T extends BaseContract> List<T> filterContracts(List<T> contracts, String productId) {
        // Return filtered only as Santander's Companies
        return contracts.stream()
                .filter(x -> securityConfigProperties.getCompanies().contains(x.getEmpresa()))
                .collect(Collectors.toList());
    }

    /**
     * Método para la validación del cliente
     *
     * @param customerId Id del cliente
     * @return True
     */
    @Override
    public Boolean validateCustomer(String customerId) {
        // Default value, always true
        return Boolean.TRUE;
    }

    /**
     * Returns if the current logged user can see given contract.
     *
     * @param contract partenon contract
     * @return True when contract validation successes.
     */
    @Override
    public Boolean validateContract(BaseContract contract) {
        // Default value, always true
        return Boolean.TRUE;
    }
}
