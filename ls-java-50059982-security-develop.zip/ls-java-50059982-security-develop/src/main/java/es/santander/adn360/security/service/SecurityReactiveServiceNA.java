package es.santander.adn360.security.service;

import es.santander.adn360.products.common.domain.entity.BaseContract;
import es.santander.adn360.security.config.SecurityConfigProperties;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * Service for channels with DISABLED security
 */
@Slf4j
@Service
@Setter
@ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.REACTIVE)
public class SecurityReactiveServiceNA implements SecurityReactiveService {

    private SecurityConfigProperties securityConfigProperties;

    /**
     * Constructor
     *
     * @param securityConfigProperties securityConfigProperties
     */
    public SecurityReactiveServiceNA(SecurityConfigProperties securityConfigProperties) {
        this.securityConfigProperties = securityConfigProperties;
    }

    /**
     * Method that filters a flux of contracts
     *
     * @param contracts   contracts to filter
     * @param <T>         elements' class
     * @return filtered contracts
     */
    @Override
    public <T extends BaseContract> Flux<T> filterContracts(Flux<T> contracts) {
        return this.filterContracts(contracts, Mono.empty());
    }

    /**
     * Method that filters a flux of contracts
     *
     * @param contracts   contracts to filter
     * @param productId   identifier of the product
     * @param <T>         elements' class
     * @return filtered contracts
     */
    @Override
    public <T extends BaseContract> Flux<T> filterContracts(Flux<T> contracts, Mono<String> productId) {
        // Return filtered only as Santander's Companies
        return contracts
                .filter(contract -> securityConfigProperties.getCompanies().contains(contract.getEmpresa()));
    }

    /**
     * Method that indicates if a given customerId is valid
     *
     * @param monoCustomerId  customer identifier
     * @return validity indicator
     */
    @Override
    public Mono<Boolean> validateCustomer(Mono<String> monoCustomerId) {
        // Default value, always true
        return Mono.just(Boolean.TRUE);
    }

    /**
     * Validates if logged user can see the contract
     *
     * @param contract partenon contract
     * @return validity indicator
     */
    @Override
    public Mono<Boolean> validateContract(Mono<BaseContract> contract) {
        // Default value, always true
        return Mono.just(Boolean.TRUE);
    }
}
