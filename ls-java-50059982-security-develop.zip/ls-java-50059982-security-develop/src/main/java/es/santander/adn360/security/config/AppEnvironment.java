package es.santander.adn360.security.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

/**
 * Gets from the environment
 * the app name
 */
@Getter
@Setter
@Configuration
public class AppEnvironment {

    private String appName;

    /**
     * Gets from the environment
     * the app name
     *
     * @param environment app environment
     * @return this object
     */
    @Bean
    public AppEnvironment getAppNameFromEnviroment(Environment environment) {
        this.setAppName(environment.getProperty("spring.application.name"));
        return this;
    }
}
