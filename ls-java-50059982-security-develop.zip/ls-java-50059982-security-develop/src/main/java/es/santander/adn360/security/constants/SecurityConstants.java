package es.santander.adn360.security.constants;

/**
 * Security constants vars
 */
public class SecurityConstants {
    /**
     * Customer id
     */
    public static final String PARAM_CUSTOMER_ID = "customer_id";
    /**
     * Excluded customer id
     */
    public static final String PARAM_EXCLUDED_CUSTOMER_ID = "excluded_customer_id";
    /**
     * Channel EMP
     */
    public static final String CHANNEL_EMP = "EMP";

    /**
     * Segment values
     */
    public enum EbankingFilter {
        /**
         * Represents the "Todos" filter.
         */
        TODOS,

        /**
         * Represents the "Propios" filter.
         */
        PROPIOS,

        /**
         * Represents the "Filiales" filter.
         */
        FILIALES,

        /**
         * Represents the "Filial" filter.
         */
        FILIAL
    }

    /**
     * Valid
     */
    public static final String PARAM_RESPONSE_VALID_CUSTOMER = "valid";
    /**
     * Contracts
     */
    public static final String PARAM_CONTRACTS = "contracts";
    /**
     * Status
     */
    public static final String PARAM_RESPONSE_VALID_CUSTOMER_PARAM = "status";
    /**
     * OK
     */
    public static final String PARAM_RESPONSE_VALID_CUSTOMER_VALUE = "OK";
    /**
     * Confidentiality header
     */
    public static final String CONFIDENTIALITY_HEADER = "Contract-Confidentiality";
    /**
     * Id used to store user info of the user in the httpServletRequest
     */
    public static final String USER_INFO = "USER_INFO";

    /**
     * Private constructor to hide the implicit public one
     */
    private SecurityConstants() {
        // Private constructor to hide the implicit public one.
    }
}
