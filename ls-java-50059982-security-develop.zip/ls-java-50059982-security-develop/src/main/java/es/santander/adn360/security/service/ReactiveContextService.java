package es.santander.adn360.security.service;

import es.santander.adn360.core.web.WebReactiveUtils;
import es.santander.adn360.security.utils.ReactiveRequestContextHolder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

/**
 * Service to deal with reactive context
 */
@Slf4j
@Service
@ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.REACTIVE)
public class ReactiveContextService {

    /**
     * Constructor
     */
    public ReactiveContextService() {
        // nonsense commentary to comply with a Sonar nonsense rule
    }

    /**
     * Method to get the context request
     *
     * @return request
     */
    public Mono<ServerHttpRequest> getRequest() {
        return ReactiveRequestContextHolder.getRequest();
    }

    /**
     * Method to get the channel
     *
     * @return channel
     */
    public Mono<String> getSantanderChannel() {
        return WebReactiveUtils.getSantanderChannel();
    }
}
