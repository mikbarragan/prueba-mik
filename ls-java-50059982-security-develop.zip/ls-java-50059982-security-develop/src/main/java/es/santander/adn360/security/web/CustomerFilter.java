package es.santander.adn360.security.web;

import com.fasterxml.jackson.databind.ObjectMapper;
import es.santander.adn360.core.model.dto.response.GlobalExceptionResponse;
import es.santander.adn360.core.model.exception.FunctionalException;
import es.santander.adn360.core.util.ExceptionEnum;
import es.santander.adn360.security.config.SecurityConfigProperties;
import es.santander.adn360.security.service.SecurityResolverService;
import es.santander.adn360.security.service.SecurityService;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.owasp.encoder.Encode;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.regex.Pattern;

import static es.santander.adn360.security.constants.SecurityConstants.PARAM_CUSTOMER_ID;
import static es.santander.adn360.security.constants.SecurityConstants.USER_INFO;

/**
 * Filter to check person security. If the person is not allowed, an unauthorized exception is thrown.
 * <p>
 * annotation @Order To order the filter as the lowest preference
 */
@Slf4j
@Component
@Order
@ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
public class CustomerFilter extends OncePerRequestFilter {

    private static final Pattern CUSTOMER_ID_REGEX_PATTERN = Pattern.compile("^(F|J)[0-9]{9}$");
    private final SecurityResolverService securityResolverService;
    private final SecurityConfigProperties securityConfigProperties;


    /**
     * Constructor
     *
     * @param securityResolverService  securityResolverService
     * @param securityConfigProperties securityConfigProperties
     */
    public CustomerFilter(
            SecurityResolverService securityResolverService,
            SecurityConfigProperties securityConfigProperties
    ) {
        this.securityResolverService = securityResolverService;
        this.securityConfigProperties = securityConfigProperties;
    }


    /**
     * Filter internal
     *
     * @param httpServletRequest  httpServletRequest
     * @param httpServletResponse httpServletResponse
     * @param filterChain         filterChain
     * @throws IOException      IOException
     * @throws ServletException ServletException
     */
    @Override
    protected void doFilterInternal(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
                                    FilterChain filterChain) throws IOException, ServletException {
        // when authenticated request get info about the user
        try {
            if (SecurityContextHolder.getContext().getAuthentication() != null) {
                httpServletRequest.setAttribute(USER_INFO, securityResolverService.getServiceByPerson().getUserInfo());
            }

        } catch (FunctionalException fe) {
            log.info("Trying to get user info: ", fe);
            setErrorInResponse(httpServletResponse, fe.getInfo().getHttpStatus(),
                    fe.getInfo(), fe.getMoreInformation());
            return;
        }

        if (securityConfigProperties.getEnabled()) {

            final String customerId = httpServletRequest.getParameter(PARAM_CUSTOMER_ID);

            // if customerId is informed checks security
            if (customerId != null) {

                // Validate customer id parameter
                if (!CUSTOMER_ID_REGEX_PATTERN.matcher(customerId).find()) {
                    setErrorInResponse(httpServletResponse, HttpStatus.BAD_REQUEST,
                            ExceptionEnum.INVALID_INPUT_PARAMETERS, "Invalid customer id.");
                    return;
                }

                // Get Method of security to use
                final SecurityService securityService = securityResolverService.getServiceByPerson();
                Boolean allowed;
                try {
                    allowed = securityService.validateCustomer(customerId);
                } catch (FunctionalException error) {
                    log.error("Request web filter error: ", error);
                    final ObjectMapper objectMapper = new ObjectMapper();

                    final GlobalExceptionResponse exceptionResponse =
                            new GlobalExceptionResponse(
                                    error.getInfo().getHttpStatus().value(),
                                    error.getInfo().getMsg(),
                                    error.getMoreInformation());

                    httpServletResponse.setStatus(exceptionResponse.getHttpCode());
                    httpServletResponse.setContentType(MediaType.APPLICATION_JSON.toString());
                    httpServletResponse.getWriter()
                            .write(Encode.forJava(objectMapper.writeValueAsString(exceptionResponse))
                                    .replace("\\", ""));
                    return;
                }

                // Return exception when user is not authorized
                if (!allowed) {
                    final String msg = String.format("The person consulted %s is not allowed.", customerId);
                    log.info(msg);
                    httpServletResponse.setStatus(HttpStatus.FORBIDDEN.value());
                    httpServletResponse.setContentType(MediaType.APPLICATION_JSON.toString());
                    httpServletResponse.getWriter()
                            .write(Encode.forJava(new ObjectMapper().writeValueAsString(
                                            ExceptionEnum.FORBIDDEN.toResponse(msg)))
                                    .replace("\\", ""));
                    return;
                }
                log.info(
                        String.format("The validation of customer security service passed for person %s.", customerId)
                );
            }
        }
        filterChain.doFilter(httpServletRequest, httpServletResponse);
    }

    /**
     * Set error in httpServletResponse when confidentiality fails
     *
     * @param httpServletResponse HttpServletResponse
     * @param httpStatus          HttpStatus
     * @param exceptionEnum       ExceptionEnum
     * @param message             Response message
     * @throws IOException IO exception
     */
    private static void setErrorInResponse(HttpServletResponse httpServletResponse, HttpStatus httpStatus,
                                           ExceptionEnum exceptionEnum, String message) throws IOException {
        httpServletResponse.setStatus(httpStatus.value());
        httpServletResponse.setContentType(MediaType.APPLICATION_JSON.toString());
        httpServletResponse.getWriter()
                .write(Encode.forJava(new ObjectMapper().writeValueAsString(exceptionEnum.toResponse(message)))
                        .replace("\\", ""));
    }

}
