package es.santander.adn360.security.utils;

import org.springframework.http.server.reactive.ServerHttpRequest;
import reactor.core.publisher.Mono;

/**
 * Utility class for handling reactive request context.
 */
public class ReactiveRequestContextHolder {

    /**
     * Key used to retrieve the ServerHttpRequest from the reactive context.
     */
    public static final Class<ServerHttpRequest> CONTEXT_KEY = ServerHttpRequest.class;

    /**
     * Retrieves the ServerHttpRequest from the reactive context.
     *
     * @return Mono of ServerHttpRequest from the reactive context.
     */
    public static Mono<ServerHttpRequest> getRequest() {
        return Mono.deferContextual(ctx -> Mono.just(ctx.get(CONTEXT_KEY)));
    }

}
