package es.santander.adn360.security.service;

import es.santander.adn360.core.model.exception.FunctionalException;
import es.santander.adn360.core.util.ExceptionEnum;
import es.santander.adn360.core.web.WebUtils;
import es.santander.adn360.security.config.SecurityConfigProperties;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.stereotype.Service;

import static es.santander.adn360.security.constants.SecurityConstants.CHANNEL_EMP;

/**
 * Service that selects the type of security that will be passed through configuration
 */
@Service
@ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
public class SecurityResolverService {

    private static final String PERSON_CONFIG = "person";
    private static final String CONTRACT_CONFIG = "contract";

    /**
     * Security configuration properties that are used to configure the security services.
     */
    protected SecurityConfigProperties securityConfigProperties;
    private SecurityServiceNA securityServiceNa;
    private BolasegService bolasegService;
    private ConfidentialityService confidencialityService;
    private EbankingService ebankingService;

    /**
     * Constructor
     *
     * @param securityConfigProperties securityConfigProperties
     * @param securityServiceNa        default service
     * @param bolasegService           bolasegService
     * @param confidencialityService   confidencialityService
     * @param ebankingService          ebankingService
     */
    public SecurityResolverService(
            SecurityConfigProperties securityConfigProperties,
            SecurityServiceNA securityServiceNa,
            BolasegService bolasegService,
            ConfidentialityService confidencialityService,
            EbankingService ebankingService
    ) {
        this.securityConfigProperties = securityConfigProperties;
        this.securityServiceNa = securityServiceNa;
        this.bolasegService = bolasegService;
        this.confidencialityService = confidencialityService;
        this.ebankingService = ebankingService;
    }

    /**
     * Servicio por persona
     *
     * @return servicio de seguridad
     */
    public SecurityService getServiceByPerson() {
        return get(PERSON_CONFIG);
    }

    /**
     * Servicio por contrato
     *
     * @return servicio de seguridad
     */
    public SecurityService getServiceByContract() {
        return get(CONTRACT_CONFIG);
    }

    private SecurityService get(String typeConfig) {
        validateChannel();
        switch (getChannelConfig(typeConfig)) {
            case EBANKING:
                return ebankingService;
            case CONFIDENTIALITY:
                return confidencialityService;
            case BOLASEG:
                return bolasegService;
            case DISABLED:
                return securityServiceNa;
            default:
                throw new FunctionalException(ExceptionEnum.FORBIDDEN, "Channel not configured.");
        }
    }

    /**
     * Validates Santander channel confidentiality configuration with channel header
     */
    private void validateChannel() {
        // If channel is invalid or issuer is not configured to apply given channel confidentiality,
        // and error is thrown.
        if (securityConfigProperties.getEnabled() && this.securityConfigProperties.getChannel()
                .get(WebUtils.getSantanderChannel()) == null) {
            throw new FunctionalException(ExceptionEnum.FORBIDDEN, "Invalid channel");
        }
        // Requisito: El canal empresa emplea su servicio para resolver lógica de negocio
        validateChannelEmpEnabled();
    }

    private SecurityConfigProperties.SecurityMode getChannelConfig(String typeConfig) {
        switch (typeConfig) {
            case PERSON_CONFIG:
                return this.securityConfigProperties.getChannel().get(WebUtils.getSantanderChannel())
                        .getPersonSecType();
            case CONTRACT_CONFIG:
                return this.securityConfigProperties.getChannel().get(WebUtils.getSantanderChannel())
                        .getContractSecType();
            default:
                throw new FunctionalException(ExceptionEnum.INVALID_INPUT_PARAMETERS, "Type config invalid");
        }
    }

    /**
     * Valida que el canal empresa este configurado
     */
    private void validateChannelEmpEnabled() {
        if (CHANNEL_EMP.equals(WebUtils.getSantanderChannel()) &&
                (SecurityConfigProperties.SecurityMode.EBANKING != getChannelConfig(PERSON_CONFIG) ||
                        SecurityConfigProperties.SecurityMode.EBANKING != getChannelConfig(CONTRACT_CONFIG))
        ) {
            throw new FunctionalException(ExceptionEnum.FORBIDDEN, "Channel EMP not configured.");
        }
    }

}
