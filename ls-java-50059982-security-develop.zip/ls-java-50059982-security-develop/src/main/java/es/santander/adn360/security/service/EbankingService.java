package es.santander.adn360.security.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import es.santander.adn360.core.model.dto.response.GlobalExceptionResponse;
import es.santander.adn360.products.common.domain.entity.BaseContract;
import es.santander.adn360.security.config.AppEnvironment;
import es.santander.adn360.security.config.SecurityConfigProperties;
import es.santander.adn360.security.domain.EbankingRequest;
import es.santander.adn360.security.domain.PrincipalAndSubsidiaries;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import static es.santander.adn360.security.constants.SecurityConstants.PARAM_CONTRACTS;
import static es.santander.adn360.security.constants.SecurityConstants.PARAM_CUSTOMER_ID;
import static es.santander.adn360.security.constants.SecurityConstants.PARAM_EXCLUDED_CUSTOMER_ID;
import static es.santander.adn360.security.constants.SecurityConstants.USER_INFO;

/**
 * Service for channels that don't pass Electronic Banking Security
 */
@Slf4j
@Service
@ConditionalOnClass({BaseContract.class})
@ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
public class EbankingService implements SecurityService {

    /**
     * Indicator for excluding a user. The value "E" stands for exclusion.
     */
    public static final String EXCLUDE_USER_INDICATOR = "E";

    /**
     * Indicator for including a user. The value "I" stands for inclusion.
     */
    public static final String INCUDE_USER_INDICATOR = "I";

    private RestTemplate restTemplate;
    private SecurityConfigProperties securityConfigProperties;
    private AppEnvironment appEnvironment;

    /**
     * Constructor
     *
     * @param restTemplate             restTemplate
     * @param securityConfigProperties securityConfigProperties
     * @param appEnvironment           appEnvironment
     */
    EbankingService(
            RestTemplate restTemplate,
            SecurityConfigProperties securityConfigProperties,
            AppEnvironment appEnvironment) {
        this.restTemplate = restTemplate;
        this.securityConfigProperties = securityConfigProperties;
        this.appEnvironment = appEnvironment;
    }

    /**
     * Method to filter contracts
     *
     * @param contracts elementos con los que tratar
     * @param <T>       clase de los elementos
     * @return devolución de la lista de elementos filtrados
     */
    @Override
    public <T extends BaseContract> List<T> filterContracts(List<T> contracts) {
        return this.filterContracts(contracts, null);
    }

    /**
     * Method that filters a list of contracts
     *
     * @param contracts   contracts to filter
     * @param productId   identifier of the product
     * @param <T>         elements' class
     * @return filtered contracts
     */
    @Override
    public <T extends BaseContract> List<T> filterContracts(List<T> contracts, String productId) {
        Assert.notNull(contracts, "Contracts should not be null");

        // If contract list is empty return emptyList. if not, the ebanking service will be called.
        return !CollectionUtils.isEmpty(contracts) ? callToEBankingService(contracts, productId) : contracts;
    }

    /**
     * Method to validate the current customer
     *
     * @param customerId Customer identification
     * @return True if validation success
     */
    @Override
    public Boolean validateCustomer(String customerId) {
        Assert.notNull(customerId, "Customer should not be null");
        PrincipalAndSubsidiaries userInfo = (PrincipalAndSubsidiaries) this.getUserInfo();

        // Check if customerId is principal or a subsidiary
        if (userInfo == null || !userInfo.toList().contains(customerId)) {
            throw this.getForbiddenException("Electronic Banking");
        }

        return Boolean.TRUE;
    }

    /**
     * Returns if the current logged user can see given contract.
     *
     * @param contract partenon contract
     * @return True when contract validation successes.
     */
    @Override
    public Boolean validateContract(BaseContract contract) {
        Assert.notNull(contract, "Contract should not be null");
        return !CollectionUtils.isEmpty(this.filterContracts(Collections.singletonList(contract)));
    }

    /**
     * Returns logged in user info
     *
     * @return User info
     */
    @Override
    public Object getUserInfo() {
        HttpServletRequest httpServletRequest =
                ((ServletRequestAttributes) Objects.requireNonNull(RequestContextHolder.getRequestAttributes()))
                        .getRequest();

        if (httpServletRequest.getAttribute(USER_INFO) != null) {
            return httpServletRequest.getAttribute(USER_INFO);
        }

        final UriComponentsBuilder builder = UriComponentsBuilder
                .fromHttpUrl(this.securityConfigProperties.getServices().getEbankingService()
                        .getPrincipalAndSubsidiariesUri());

        ResponseEntity<PrincipalAndSubsidiaries> response = restTemplate.exchange(builder.build().encode().toUri(),
                HttpMethod.GET, null, PrincipalAndSubsidiaries.class);

        if (HttpStatus.OK != response.getStatusCode()) {
            throw this.getForbiddenException("Electronic Banking");
        }

        return response.getBody();

    }

    /**
     * Method that call to confidentialityService and return a contracts list filtered
     *
     * @param contracts lista de elementos para comprobar
     * @param <T>       La clase de elementos
     * @param productId Producto por el que filtrar
     * @return devolución de los elementos válidos
     */
    private <T extends BaseContract> List<T> callToEBankingService(List<T> contracts, String productId) {
        // The version 2.2.1 only filter by customers,
        // in this case using filter contract by default - idem NA
        final UriComponentsBuilder builder = UriComponentsBuilder
                .fromHttpUrl(this.securityConfigProperties.getServices().getEbankingService()
                        .getContractsSecurityUri());

        ResponseEntity<Map<String, Object>> response;
        // Get the list of contract ids.
        response = this.restTemplate.exchange(
                builder.build().encode().toUri(),
                HttpMethod.POST,
                this.getRequest(contracts, productId),
                new ParameterizedTypeReference<Map<String, Object>>() {
                }
        );

        // Return forbidden
        if (HttpStatus.OK != response.getStatusCode()) {
            final GlobalExceptionResponse exceptionResponse =
                    new ObjectMapper().convertValue(response.getBody(), GlobalExceptionResponse.class);
            throw this.getForbiddenException(exceptionResponse.getMoreInformation());
        }

        final List<String> filteredContractsId = (List<String>) response.getBody().get(PARAM_CONTRACTS);

        // Return filtered contracts
        // +filter only Santander's Companies
        return contracts.stream()
                .filter(x -> filteredContractsId.contains(x.getIdContrato()))
                .filter(x -> securityConfigProperties.getCompanies().contains(x.getEmpresa()))
                .collect(Collectors.toList());
    }

    /**
     * Prepare the request
     *
     * @param contracts contracs
     * @param <T>       base contract
     * @param productId Product Id
     * @return httpEntity request
     */
    private <T extends BaseContract> HttpEntity<EbankingRequest> getRequest(List<T> contracts, String productId) {

        HttpServletRequest request =
                ((ServletRequestAttributes) Objects.requireNonNull(RequestContextHolder.getRequestAttributes()))
                        .getRequest();

        return new HttpEntity<>(
                EbankingRequest.builder()
                        .customerId(getCustomerId(request))
                        .excludedCustomerId(getExcludedCustomerId(request))
                        .productId(productId == null ? this.appEnvironment.getAppName() : productId)
                        .contracts(
                                contracts.stream().map(BaseContract::getIdContrato).collect(Collectors.toList())
                        )
                        .build()
        );
    }

    /**
     * Gets customer id form request
     *
     * @param httpServletRequest request
     * @return customer id
     */
    private static String getCustomerId(HttpServletRequest httpServletRequest) {
        return Optional.ofNullable(httpServletRequest.getParameterMap().get(PARAM_CUSTOMER_ID))
                .map((String[] x) -> x[0])
                .orElse(null);
    }

    /**
     * Gets excluded customer id form request
     *
     * @param httpServletRequest request
     * @return excluded customer id
     */
    private static String getExcludedCustomerId(HttpServletRequest httpServletRequest) {
        return Optional.ofNullable(httpServletRequest.getParameterMap().get(PARAM_EXCLUDED_CUSTOMER_ID))
                .map((String[] x) -> x[0])
                .orElse(null);
    }

    /**
     * Logica de resolución de clientes para banca electronica
     *
     * @return lista de Js
     */
    @Override
    public List<String> resolveCustomerIdList() {
        HttpServletRequest request =
                ((ServletRequestAttributes) Objects.requireNonNull(RequestContextHolder.getRequestAttributes()))
                        .getRequest();
        PrincipalAndSubsidiaries info = (PrincipalAndSubsidiaries) this.getUserInfo();
        Optional<String> customerId = Optional.ofNullable(getCustomerId(request));
        Optional<String> excludedCustomerId = Optional.ofNullable(getExcludedCustomerId(request));

        // Si customer_id y excluded_customer_id vienen vacios
        // devolvemos todos los clientes del usuario (TODOS)
        if (excludedCustomerId.isEmpty() && customerId.isEmpty()) {
            return info.toList();
        }
        // Si excluded_customer_id esta informado
        // devolvemos todos los clientes del usuario menos ese [FILIALES]
        // Aunque puede no coincidir con el usuario principal y no serian FILIALES
        if (excludedCustomerId.isPresent()) {
            return info.toList().stream().filter(x -> !x.equals(excludedCustomerId.get())).collect(Collectors.toList());
        }
        // Pasadas las dos primeras condiciones validamos que el cliente
        // es visualizable por el usuario [PROPIOS|FILIAL]
        if (this.validateCustomer(customerId.get())) {
            return Collections.singletonList(customerId.get());
        }

        throw this.getForbiddenException("Customer is not allowed");
    }

}
