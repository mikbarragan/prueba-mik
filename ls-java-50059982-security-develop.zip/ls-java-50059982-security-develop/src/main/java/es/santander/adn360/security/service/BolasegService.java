package es.santander.adn360.security.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import es.santander.adn360.core.model.dto.response.GlobalExceptionResponse;
import es.santander.adn360.products.common.domain.entity.BaseContract;
import es.santander.adn360.security.config.SecurityConfigProperties;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static es.santander.adn360.security.constants.SecurityConstants.PARAM_CONTRACTS;
import static es.santander.adn360.security.constants.SecurityConstants.PARAM_CUSTOMER_ID;
import static es.santander.adn360.security.constants.SecurityConstants.PARAM_RESPONSE_VALID_CUSTOMER_PARAM;
import static es.santander.adn360.security.constants.SecurityConstants.PARAM_RESPONSE_VALID_CUSTOMER_VALUE;

/**
 * Service for channels that don't pass BolasegSecurity
 */
@Slf4j
@Service
@ConditionalOnClass({BaseContract.class})
@ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
public class BolasegService implements SecurityService {

    private RestTemplate restTemplate;
    private SecurityConfigProperties securityConfigProperties;

    /**
     * Constructor
     *
     * @param restTemplate             restTemplate
     * @param securityConfigProperties securityConfigProperties
     */
    public BolasegService(RestTemplate restTemplate, SecurityConfigProperties securityConfigProperties) {
        this.restTemplate = restTemplate;
        this.securityConfigProperties = securityConfigProperties;
    }

    /**
     * filtrado contratos
     *
     * @param contracts elementos a filtrar
     * @param <T>       clase de los elementos a filtrar
     * @return devolución de la lista de elementos
     */
    @Override
    public <T extends BaseContract> List<T> filterContracts(List<T> contracts) {
        return this.filterContracts(contracts, null);
    }

    /**
     * Method that filters a list of contracts
     *
     * @param contracts   contracts to filter
     * @param productId   identifier of the product
     * @param <T>         elements' class
     * @return filtered contracts
     */
    @Override
    public <T extends BaseContract> List<T> filterContracts(List<T> contracts, String productId) {
        Assert.notNull(contracts, "Contracts should not be null");

        // If contract list is empty return emptyList. if not, the confidentiality service will be called.
        return !CollectionUtils.isEmpty(contracts) ? filterContractsBolaseg(contracts) : contracts;
    }

    /**
     * Validación de cliente
     *
     * @param customerId Customer identification
     * @return True o False
     */
    @Override
    public Boolean validateCustomer(String customerId) {

        // Call Bolaseg microservice to check if customer is allowed.
        final UriComponentsBuilder builder = UriComponentsBuilder
                .fromHttpUrl(this.securityConfigProperties.getServices().getBolasegService()
                        .getPersonSecurityUri())
                .queryParam(PARAM_CUSTOMER_ID, customerId);

        // Get if the customer is valid.
        ResponseEntity<Map<String, Object>> response = this.restTemplate
                .exchange(
                        builder.build().encode().toUri(),
                        HttpMethod.GET,
                        new HttpEntity<>(new HashMap<>()),
                        new ParameterizedTypeReference<Map<String, Object>>() {
                        });

        // Return internal server error with specific code.
        if (HttpStatus.OK != response.getStatusCode()) {
            log.error("Error calling to BolaSeg service. Calling to endpoint {} status code: {}.",
                    builder.build().encode().toUriString(), response.getStatusCodeValue());
            throw this.getForbiddenException("Bolaseg");
        }

        return PARAM_RESPONSE_VALID_CUSTOMER_VALUE.equals(
                response.getBody().get(PARAM_RESPONSE_VALID_CUSTOMER_PARAM));

    }

    /**
     * Validates if logged user can see the contract
     *
     * @param contract partenon contract
     * @return true if validation success
     */
    @Override
    public Boolean validateContract(BaseContract contract) {
        Assert.notNull(contract, "Contract should not be null");
        return !CollectionUtils.isEmpty(this.filterContracts(Collections.singletonList(contract)));
    }

    /**
     * Method that call to bolasegService and return a contracts list filtered
     *
     * @param contracts lista de elementos para comprobar
     * @param <T>       La clase de elementos
     * @return devolución de los elementos válidos
     */
    private <T extends BaseContract> List<T> filterContractsBolaseg(List<T> contracts) {
        List<String> contractsList = contracts.stream().map(BaseContract::getIdContrato)
                .collect(Collectors.toList());

        List<String> filteredConstractsList = callToBolasegService(contractsList);

        // Return filtered contracts
        // +filtered only as Santander's Companies
        return contracts.stream()
                .filter(x -> filteredConstractsList.contains(x.getIdContrato()))
                .filter(x -> securityConfigProperties.getCompanies().contains(x.getEmpresa()))
                .collect(Collectors.toList());
    }

    /**
     * Method that calls BolasegService and returns a list of filtered contracts
     *
     * @param contractsList   list of contracts to check
     * @return List of contractIds found
     */
    private List<String> callToBolasegService(List<String> contractsList) {
        final UriComponentsBuilder builder = UriComponentsBuilder
                .fromHttpUrl(this.securityConfigProperties.getServices().getBolasegService()
                        .getContractsSecurityUri());

        Map<String, List<String>> hasMapRequest = new HashMap<>();
        hasMapRequest.put(PARAM_CONTRACTS, contractsList);

        final HttpEntity<Map<String, List<String>>> request = new HttpEntity<>(hasMapRequest);
        ResponseEntity<Map<String, Object>> response = null;
        try {
            // Get the list of contract ids.
            response = this.restTemplate
                    .exchange(builder.build().encode().toUri(), HttpMethod.POST, request
                            , new ParameterizedTypeReference<Map<String, Object>>() {
                            });
        } catch (Exception ex) {
            log.error("Error calling bolasegService:", ex);
            throw this.getForbiddenException(ex.getMessage());
        }

        // Return internal server error with specific code.
        if (HttpStatus.OK != response.getStatusCode()) {
            final GlobalExceptionResponse exceptionResponse =
                    new ObjectMapper().convertValue(response.getBody(), GlobalExceptionResponse.class);
            this.getForbiddenException(exceptionResponse.getMoreInformation());
        }

        return (List<String>) response.getBody().get(PARAM_CONTRACTS);
    }

}
