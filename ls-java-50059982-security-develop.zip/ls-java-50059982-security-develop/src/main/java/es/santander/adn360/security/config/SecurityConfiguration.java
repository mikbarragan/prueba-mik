package es.santander.adn360.security.config;

import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;

/**
 * Security Configuration
 *
 * @author Santander Tecnologia
 */
@Configuration
@EnableConfigurationProperties(SecurityConfigProperties.class)
@ComponentScan("es.santander.adn360.security")
public class SecurityConfiguration {

    /**
     * Bean creation method for WebClient.
     *
     * @return a new instance of WebClient.
     */
    @Bean
    public WebClient webClient() {
        return WebClient.create();
    }

}
