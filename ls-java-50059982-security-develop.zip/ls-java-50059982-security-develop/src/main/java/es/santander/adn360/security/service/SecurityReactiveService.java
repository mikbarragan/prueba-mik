package es.santander.adn360.security.service;


import es.santander.adn360.core.model.exception.FunctionalException;
import es.santander.adn360.core.util.ExceptionEnum;
import es.santander.adn360.products.common.domain.entity.BaseContract;
import es.santander.adn360.security.domain.PrincipalAndSubsidiaries;
import es.santander.adn360.security.utils.ReactiveRequestContextHolder;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import static es.santander.adn360.security.constants.SecurityConstants.PARAM_CUSTOMER_ID;

/**
 * Service for handle security.
 */
public interface SecurityReactiveService {

    /**
     * Method that filters a flux of contracts
     *
     * @param contracts   contracts to filter
     * @param <T>         elements' class
     * @return filtered contracts
     */
    <T extends BaseContract> Flux<T> filterContracts(Flux<T> contracts);

    /**
     * Method that filters a flux of contracts
     *
     * @param contracts   contracts to filter
     * @param productId   identifier of the product
     * @param <T>         elements' class
     * @return filtered contracts
     */
    <T extends BaseContract> Flux<T> filterContracts(Flux<T> contracts, Mono<String> productId);

    /**
     * Method that indicates if a given customerId is valid
     *
     * @param monoCustomerId  customer identifier
     * @return validity indicator
     */
    Mono<Boolean> validateCustomer(Mono<String> monoCustomerId);

    /**
     * Validates if logged user can see the contract
     *
     * @param contract partenon contract
     * @return validity indicator
     */
    Mono<Boolean> validateContract(Mono<BaseContract> contract);

    /**
     * Returns logged in user info
     *
     * @return user info
     */
    default Mono<PrincipalAndSubsidiaries> getUserInfo() {
        return Mono.empty();
    }

    /**
     * Returns logged in user info
     * @param exchange  server web exchange object
     * @return user info
     */
    default Mono<PrincipalAndSubsidiaries> getUserInfo(ServerWebExchange exchange) {
        return Mono.empty();
    }

    /**
     * Builds forbidden exception
     *
     * @param moreInformation moreInformation
     * @return exception
     */
    default FunctionalException getForbiddenException(String moreInformation) {
        return new FunctionalException(ExceptionEnum.FORBIDDEN, moreInformation);
    }

    /**
     * Builds invalid parameters exception
     *
     * @param moreInformation moreInformation
     * @return exception
     */
    default FunctionalException getInvalidParametersException(String moreInformation) {
        return new FunctionalException(ExceptionEnum.INVALID_INPUT_PARAMETERS, moreInformation);
    }

    /**
     * Returns a flux with the customer_id in the request
     * if customer_id is not present throws InvalidParametersException
     *
     * @return flux of customer Id
     */
    default Flux<String> resolveCustomerIdList() {
        return getCustomerId().flatMapMany(Mono::just)
                .switchIfEmpty(Flux.error(this.getInvalidParametersException("customer_id should not be empty")));

    }

    /**
     * Gets customer id form request
     *
     * @return customer id
     */
    private static Mono<String> getCustomerId() {
        return ReactiveRequestContextHolder.getRequest().map(ServerHttpRequest::getQueryParams)
                .map(queryParams -> queryParams.getFirst(PARAM_CUSTOMER_ID));
    }

}
