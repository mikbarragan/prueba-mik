package es.santander.adn360.security.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import es.santander.adn360.core.model.dto.response.GlobalExceptionResponse;
import es.santander.adn360.products.common.domain.entity.BaseContract;
import es.santander.adn360.security.config.SecurityConfigProperties;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static es.santander.adn360.security.constants.SecurityConstants.CONFIDENTIALITY_HEADER;
import static es.santander.adn360.security.constants.SecurityConstants.PARAM_CONTRACTS;
import static es.santander.adn360.security.constants.SecurityConstants.PARAM_CUSTOMER_ID;
import static es.santander.adn360.security.constants.SecurityConstants.PARAM_RESPONSE_VALID_CUSTOMER;

/**
 * Service for channels that don't pass Confidentiality
 */
@Slf4j
@Service
@ConditionalOnClass({BaseContract.class})
@ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
public class ConfidentialityService implements SecurityService {

    private RestTemplate restTemplate;
    private SecurityConfigProperties securityConfigProperties;
    private HttpServletResponse httpServletResponse;

    /**
     * Constructor
     *
     * @param restTemplate             restTemplate
     * @param securityConfigProperties securityConfigProperties
     * @param httpServletResponse      httpServletResponse
     */
    public ConfidentialityService(
            RestTemplate restTemplate,
            SecurityConfigProperties securityConfigProperties,
            HttpServletResponse httpServletResponse
    ) {
        this.restTemplate = restTemplate;
        this.securityConfigProperties = securityConfigProperties;
        this.httpServletResponse = httpServletResponse;
    }

    /**
     * Method to filter contracts
     *
     * @param contracts elementos con los que tratar
     * @param <T>       clase de los elementos
     * @return devolución de la lista de elementos filtrados
     */
    @Override
    public <T extends BaseContract> List<T> filterContracts(List<T> contracts) {

        return this.filterContracts(contracts, null);
    }

    /**
     * Method to filter contracts
     *
     * @param contracts     list of contracts to filter
     * @param productId     identifier of the product
     * @param <T>         elements' class
     * @return List of contracts filtered
     */
    @Override
    public <T extends BaseContract> List<T> filterContracts(List<T> contracts, String productId) {
        Assert.notNull(contracts, "Contracts should not be null");

        // If contract list is empty return emptyList. if not, the confidentiality service will be called.
        return !CollectionUtils.isEmpty(contracts) ? callToConfidentialityService(contracts) : contracts;
    }

    /**
     * Method to validate the current customer
     *
     * @param customerId Customer identification
     * @return Boolean true or false
     */
    @Override
    public Boolean validateCustomer(String customerId) {

        // Call confidentiality microservice to getServiceByPerson if customer is allowed.
        final UriComponentsBuilder builder = UriComponentsBuilder
                .fromHttpUrl(this.securityConfigProperties.getServices().getConfidentialityService()
                        .getPersonSecurityUri());

        HashMap<String, String> hashMapRequest = new HashMap<>();
        hashMapRequest.put(PARAM_CUSTOMER_ID, customerId);

        final HttpEntity<Map<String, String>> request = new HttpEntity<>(hashMapRequest);
        ResponseEntity<Map<String, Object>> response;
        // Get if the customer is valid.
        response = this.restTemplate
                .exchange(builder.build().encode().toUri(), HttpMethod.POST, request
                        , new ParameterizedTypeReference<Map<String, Object>>() {
                        });

        // Return internal server error with specific code.
        if (HttpStatus.OK != response.getStatusCode()) {
            log.error("Error calling to confidentiality service. Calling to endpoint {} status code: {}.",
                    builder.build().encode().toUriString(), response.getStatusCodeValue());
            throw this.getForbiddenException("Confidentiality");
        }

        return (Boolean) response.getBody().get(PARAM_RESPONSE_VALID_CUSTOMER);

    }

    /**
     * Returns if the current logged user can see given contract.
     *
     * @param contract partenon contract
     * @return True when contract validation successes.
     */
    @Override
    public Boolean validateContract(BaseContract contract) {
        Assert.notNull(contract, "Contract should not be null");
        return !CollectionUtils.isEmpty(this.filterContracts(Collections.singletonList(contract)));
    }

    /**
     * Method that call to confidentialityService and return a contracts list filtered
     *
     * @param contracts lista de elementos para comprobar
     * @param <T>       La clase de elementos
     * @return devolución de los elementos válidos
     */
    private <T extends BaseContract> List<T> callToConfidentialityService(List<T> contracts) {
        List<String> contracsList = contracts.stream()
                .map(BaseContract::getIdContrato)
                .collect(Collectors.toList());

        final List<String> filteredContractsId = callConfidentialityService(contracsList);

        // Return filtered contracts
        // +filtered only as Santander's Companies
        return contracts.stream()
                .filter(x -> filteredContractsId.contains(x.getIdContrato()))
                .filter(x -> securityConfigProperties.getCompanies().contains(x.getEmpresa()))
                .collect(Collectors.toList());
    }

    /**
     * Method that call to confidentialityService and return a contracts list filtered
     *
     * @param contracsList lista de elementos para comprobar
     * @return devolución de los elementos válidos
     */
    private List<String> callConfidentialityService(List<String> contracsList) {
        final UriComponentsBuilder builder = UriComponentsBuilder
                .fromHttpUrl(this.securityConfigProperties.getServices().getConfidentialityService()
                        .getContractsSecurityUri());

        Map<String, List<String>> hashMapRequest = new HashMap<>();
        hashMapRequest.put(PARAM_CONTRACTS, contracsList);

        final HttpEntity<Map<String, List<String>>> request = new HttpEntity<>(hashMapRequest);
        ResponseEntity<Map<String, Object>> response;
        try {
            // Get the list of contract ids.
            response = this.restTemplate
                    .exchange(builder.build().encode().toUri(), HttpMethod.POST, request
                            , new ParameterizedTypeReference<Map<String, Object>>() {
                            });
        } catch (Exception ex) {
            log.error("Call to confidentiality service:", ex);
            throw this.getForbiddenException(ex.getLocalizedMessage());
        }

        // Return internal server error with specific code.
        if (HttpStatus.OK != response.getStatusCode()) {
            final GlobalExceptionResponse exceptionResponse =
                    new ObjectMapper().convertValue(response.getBody(), GlobalExceptionResponse.class);
            throw this.getForbiddenException(exceptionResponse.getMoreInformation());
        }

        final List<String> filteredContractsId = (List<String>) response.getBody().get(PARAM_CONTRACTS);
        if (response.getHeaders().get(CONFIDENTIALITY_HEADER) != null) {
            httpServletResponse.addHeader(CONFIDENTIALITY_HEADER, "true");
        }
        return filteredContractsId;
    }

}
