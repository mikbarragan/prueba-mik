package es.santander.adn360.security.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.Builder;
import lombok.Data;

import java.util.List;

/**
 * Ebanking
 * Request
 */
@Data
@Builder
public class EbankingRequest {
    /**
     * Customer
     * id
     */
    @JsonProperty("customer_id")
    @Pattern(regexp = "^(F|J)[0-9]{9}$")
    public String customerId;
    /**
     * Excluded
     * customer id
     */
    @JsonProperty("excluded_customer_id")
    @Pattern(regexp = "^(F|J)[0-9]{9}$")
    public String excludedCustomerId;
    /**
     * Product
     * id
     */
    @JsonProperty("product")
    @Pattern(regexp = "^[a-zA-Z\\-0-9]+$")
    @NotNull
    public String productId;
    /**
     * List
     * of contracts
     */
    @NotNull
    public List<@Pattern(regexp = "^[0-9]{18}$") String> contracts;
}
