package es.santander.adn360.security.web;

import es.santander.adn360.core.model.exception.FunctionalException;
import es.santander.adn360.core.util.ExceptionEnum;
import es.santander.adn360.security.config.SecurityConfigProperties;
import es.santander.adn360.security.service.SecurityReactiveService;
import es.santander.adn360.security.service.SecurityResolverReactiveService;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.core.annotation.Order;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.security.core.context.ReactiveSecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilter;
import org.springframework.web.server.WebFilterChain;
import reactor.core.publisher.Mono;
import reactor.util.function.Tuple2;

import java.util.Optional;
import java.util.regex.Pattern;

import static es.santander.adn360.security.constants.SecurityConstants.PARAM_CUSTOMER_ID;
import static es.santander.adn360.security.constants.SecurityConstants.USER_INFO;

/**
 * Filter to check person security. If the person is not allowed, an unauthorized exception is thrown.
 * <p>
 * annotation @Order To order the filter as the lowest preference
 */
@Slf4j
@Component
@Order
@ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.REACTIVE)
@Setter
public class CustomerReactiveFilter implements WebFilter {

    private static final Pattern CUSTOMER_ID_REGEX_PATTERN = Pattern.compile("^(F|J)[0-9]{9}$");
    private SecurityResolverReactiveService securityResolverService;
    private SecurityConfigProperties securityConfigProperties;

    /**
     * Constructor
     *
     * @param securityResolverService  securityResolverService
     * @param securityConfigProperties securityConfigProperties
     */
    public CustomerReactiveFilter(
            SecurityResolverReactiveService securityResolverService,
            SecurityConfigProperties securityConfigProperties
    ) {
        this.securityResolverService = securityResolverService;
        this.securityConfigProperties = securityConfigProperties;
    }

    /**
     * Filter internal
     *
     * @param exchange      serverWebExchange
     * @param filterChain   webFilterChain
     * @return Mono void
     */
    @Override
    public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain filterChain) {

        var customerIdOptional = Optional.of(exchange.getRequest())
                .map(ServerHttpRequest::getQueryParams)
                .map(queryParams -> queryParams.getFirst(PARAM_CUSTOMER_ID));

        // Se devuelve un Mono del servicio de seguridad tras guardar en el exchange la información de usuario
        // o Mono.empty si no hay autenticación
        Mono<SecurityReactiveService> securityService = ReactiveSecurityContextHolder.getContext()
                .filter(context -> context.getAuthentication() != null)
                .flatMap(context -> securityResolverService.getServiceByPerson())
                .flatMap(service -> Mono.zip(
                        Mono.just(service),
                        service.getUserInfo(exchange)))
                .doOnNext(tuple -> exchange.getAttributes().put(USER_INFO, tuple.getT2()))
                .doOnError(FunctionalException.class, e -> log.info("Trying to get user info: ", e))
                .map(Tuple2::getT1);

        return securityService
                .switchIfEmpty((securityConfigProperties.getEnabled() && customerIdOptional.isPresent()) ?
                        securityResolverService.getServiceByPerson() : Mono.empty())
                .filter(service -> securityConfigProperties.getEnabled() && customerIdOptional.isPresent())
                .flatMap(service -> validateCustomer(service, customerIdOptional.orElse(null)))
                .map(tuple -> exchange)
                .switchIfEmpty(Mono.just(exchange))
                .flatMap(filterChain::filter);

    }

    /**
     * Validates if customerId is valid
     *
     * @param securityService securityService to call
     * @param customerId      customerId
     * @return Mono<Void>
     */
    private Mono<Void> validateCustomer(SecurityReactiveService securityService, String customerId) {
        if (customerId == null) {
            return Mono.empty();
        }
        if (!CUSTOMER_ID_REGEX_PATTERN.matcher(customerId).find()) {
            return Mono.error(new FunctionalException(
                    ExceptionEnum.INVALID_INPUT_PARAMETERS, "Invalid customer id."));
        }
        return securityService
                .validateCustomer(Mono.just(customerId))
                .doOnError(FunctionalException.class, e -> log.error("Request web filter error: ", e))
                .flatMap((Boolean isCustomerAllowed) -> {
                    if (isCustomerAllowed) {
                        log.info(String.format("The validation of customer security service passed for person %s.",
                                        customerId));
                        return Mono.empty();
                    } else {
                        final String msg = String.format("The person consulted %s is not allowed.", customerId);
                        log.info(msg);
                        throw new FunctionalException(ExceptionEnum.FORBIDDEN, msg);
                    }
                });

    }

}
