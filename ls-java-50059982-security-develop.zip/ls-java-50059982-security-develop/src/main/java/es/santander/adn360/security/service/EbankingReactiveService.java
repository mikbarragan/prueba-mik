package es.santander.adn360.security.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import es.santander.adn360.core.model.dto.response.GlobalExceptionResponse;
import es.santander.adn360.products.common.domain.entity.BaseContract;
import es.santander.adn360.security.config.AppEnvironment;
import es.santander.adn360.security.config.SecurityConfigProperties;
import es.santander.adn360.security.domain.EbankingRequest;
import es.santander.adn360.security.domain.PrincipalAndSubsidiaries;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Service;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.util.function.Tuple2;
import reactor.util.function.Tuple3;
import reactor.util.function.Tuples;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import static es.santander.adn360.security.constants.SecurityConstants.PARAM_CONTRACTS;
import static es.santander.adn360.security.constants.SecurityConstants.PARAM_CUSTOMER_ID;
import static es.santander.adn360.security.constants.SecurityConstants.PARAM_EXCLUDED_CUSTOMER_ID;
import static es.santander.adn360.security.constants.SecurityConstants.USER_INFO;

/**
 * Service for channels that don't pass Electronic Banking Security
 */
@Slf4j
@Service
@ConditionalOnClass({BaseContract.class})
@ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.REACTIVE)
@Setter
public class EbankingReactiveService implements SecurityReactiveService {

    /**
     * Indicator for excluding a user. The value "E" stands for exclusion.
     */
    public static final String EXCLUDE_USER_INDICATOR = "E";

    /**
     * Indicator for including a user. The value "I" stands for inclusion.
     */
    public static final String INCUDE_USER_INDICATOR = "I";

    private WebClient webClient;
    private SecurityConfigProperties securityConfigProperties;
    private AppEnvironment appEnvironment;
    private ReactiveContextService contextService;

    /**
     * Constructor
     *
     * @param webClientBuilder                webClient
     * @param securityConfigProperties securityConfigProperties
     * @param appEnvironment           appEnvironment
     * @param contextService           contextService
     */
    EbankingReactiveService(
            WebClient.Builder webClientBuilder,
            SecurityConfigProperties securityConfigProperties,
            AppEnvironment appEnvironment,
            ReactiveContextService contextService) {
        this.securityConfigProperties = securityConfigProperties;
        this.appEnvironment = appEnvironment;
        this.contextService = contextService;
        this.webClient = webClientBuilder
                .baseUrl(this.securityConfigProperties.getServices().getEbankingServiceReactive().getBaseUrl())
                .build();
    }

    /**
     * Method that filters a flux of contracts
     *
     * @param contracts   contracts to filter
     * @param <T>         elements' class
     * @return filtered contracts
     */
    @Override
    public <T extends BaseContract> Flux<T> filterContracts(Flux<T> contracts) {
        return this.filterContracts(contracts, Mono.empty());
    }

    /**
     * Method that filters a flux of contracts
     *
     * @param contracts   contracts to filter
     * @param productId   identifier of the product
     * @param <T>         elements' class
     * @return filtered contracts
     */
    @Override
    public <T extends BaseContract> Flux<T> filterContracts(Flux<T> contracts, Mono<String> productId) {
        return getFilteredContracts(contracts, productId);
    }

    /**
     * Method that indicates if a given customerId is valid
     *
     * @param monoCustomerId  customer identifier
     * @return validity indicator
     */
    @Override
    public Mono<Boolean> validateCustomer(Mono<String> monoCustomerId) {
        return monoCustomerId
                .zipWith(this.getUserInfo())
                .map((Tuple2<String, PrincipalAndSubsidiaries> tuple) ->
                    this.validateCustomer(tuple.getT1(), tuple.getT2()))
                .switchIfEmpty(Mono.just(false));
    }

    /**
     * Method that indicates if a given customerId is valid
     *
     * @param customerId  customer identifier
     * @param userInfo    principal and subsidiaries info
     * @return validity indicator
     */
    public Boolean validateCustomer(String customerId, PrincipalAndSubsidiaries userInfo) {

        // Check if customerId is principal or a subsidiary
        if (userInfo == null || !userInfo.toList().contains(customerId)) {
            throw this.getForbiddenException("Electronic Banking");
        }
        return Boolean.TRUE;
    }

    /**
     * Validates if logged user can see the contract
     *
     * @param contract partenon contract
     * @return validity indicator
     */
    @Override
    public Mono<Boolean> validateContract(Mono<BaseContract> contract) {
        return filterContracts(contract.flux()).hasElements();
    }

    /**
     * Returns logged in user info
     *
     * @return User info
     */
    @Override
    public Mono<PrincipalAndSubsidiaries> getUserInfo() {

        return this.webClient.get()
                .uri(uriBuilder -> uriBuilder
                        .path(this.securityConfigProperties.getServices().getEbankingServiceReactive()
                                .getPrincipalAndSubsidiariesPath())
                        .build())
                .retrieve()
                .onStatus(httpStatus -> httpStatus.isError(), (ClientResponse response) -> {
                    log.error("Error calling to Electronic Banking service.");
                    throw this.getForbiddenException("Electronic Banking");
                })
                .bodyToMono(PrincipalAndSubsidiaries.class);
    }

    /**
     * Returns logged in user info
     *
     * @param exchange ServerWebExchange
     * @return User info
     */
    @Override
    public Mono<PrincipalAndSubsidiaries> getUserInfo(ServerWebExchange exchange) {

        var userInfo = exchange.getAttributes().get(USER_INFO);

        if (userInfo != null) {
            return Mono.just((PrincipalAndSubsidiaries) userInfo);
        }

        return this.getUserInfo();
    }

    /**
     * Method that calls EbankingService and returns a flux of filtered contracts
     *
     * @param bodyEntity    request body to sent
     * @return flux of contractIds found
     */
    private Flux<String> callToEBankingService(HttpEntity<EbankingRequest> bodyEntity) {
        // The version 2.2.1 only filter by customers,
        // in this case using filter contract by default - idem NA

        if (bodyEntity.getBody().contracts.isEmpty()) {
            return Flux.empty();
        }

        return this.webClient.post()
                .uri(uriBuilder -> uriBuilder
                                .path(this.securityConfigProperties.getServices().getEbankingServiceReactive()
                                        .getContractsSecurityPath())
                                .build())
                .body(BodyInserters.fromValue(bodyEntity))
                .retrieve()
                .toEntity(new ParameterizedTypeReference<Map<String, Object>>() {
                })
                .onErrorResume(Exception.class, (Exception err) -> {
                    log.error("Error calling Electronic Banking service.");
                    return Mono.error(this.getForbiddenException(err.getMessage()));
                })
                .flatMapMany((ResponseEntity<Map<String, Object>> res) -> {
                    if (HttpStatus.OK != res.getStatusCode()) {
                        final GlobalExceptionResponse exceptionResponse =
                                new ObjectMapper().convertValue(res.getBody(), GlobalExceptionResponse.class);
                        return Mono.error(this.getForbiddenException(exceptionResponse.getMoreInformation()));
                    }
                    return Flux.fromIterable(
                            (List<String>) res.getBody().getOrDefault(PARAM_CONTRACTS, List.of()));
                });
    }

    /**
     * Method that calls EbankingService and returns a list of filtered contracts
     *
     * @param contracts      flux of elements to check
     * @param monoProductId  identifier of the product
     * @param <T>            elements' class
     * @return filtered contracts
     */
    private <T extends BaseContract> Flux<T> getFilteredContracts(Flux<T> contracts, Mono<String> monoProductId) {
        return Mono.zip(
                        this.contextService.getRequest().map(ServerHttpRequest::getQueryParams),
                        contracts.map(BaseContract::getIdContrato).collect(Collectors.toList()),
                        monoProductId.switchIfEmpty(Mono.just("")))
                .map((Tuple3<MultiValueMap<String, String>, List<String>, String> tuple) ->
                        getRequestBody(tuple.getT1(), tuple.getT2(), tuple.getT3()))
                .flatMapMany(bodyEntity -> callToEBankingService(bodyEntity))
                .collectList()
                .flatMapMany(filteredContractsList -> contracts
                    .map(contract -> Tuples.of(contract, filteredContractsList)))
                .filter((Tuple2<T, List<String>> tuple) -> tuple.getT2().contains(tuple.getT1().getIdContrato()) &&
                        securityConfigProperties.getCompanies().contains(tuple.getT1().getEmpresa()))
                .map(tuple -> tuple.getT1());
    }

    /**
     * Prepares the request
     *
     * @param params    params contract
     * @param contracts contracts
     * @param productId Product Id
     * @return httpEntity request
     */
    private HttpEntity<EbankingRequest> getRequestBody(
            MultiValueMap<String, String> params, List<String> contracts, String productId) {
        return new HttpEntity<>(
            EbankingRequest.builder()
                .customerId(getQueryParamValue(params, PARAM_CUSTOMER_ID, null))
                .excludedCustomerId(getQueryParamValue(params, PARAM_EXCLUDED_CUSTOMER_ID, null))
                .productId(StringUtils.isEmpty(productId) ? this.appEnvironment.getAppName() : productId)
                .contracts(contracts)
                .build()
        );
    }

    /**
     * Gets a value from queryParams given a queryParam map and a key
     *
     * @param queryParams  request parameters
     * @param key          key to find
     * @return query param value
     */
    private static String getQueryParamValue(MultiValueMap<String, String> queryParams, String key,
                                             String defaultValue) {
        return Optional.ofNullable(queryParams)
                .map(params -> params.getFirst(key))
                .orElse(defaultValue);
    }

    /**
     * Returns a flux with the customer_id in the request
     * if customer_id is not present throws InvalidParametersException
     *
     * @return flux of customer Id
     */
    @Override
    public Flux<String> resolveCustomerIdList() {
        return this.contextService.getRequest()
                .map(ServerHttpRequest::getQueryParams)
                .map(queryParams ->
                        Tuples.of(getQueryParamValue(queryParams, PARAM_CUSTOMER_ID, ""),
                                getQueryParamValue(queryParams, PARAM_EXCLUDED_CUSTOMER_ID, "")))
                .zipWith(this.getUserInfo())
                .flatMapMany(tuple -> {
                    String customerId = tuple.getT1().getT1();
                    String excludedCustomerId = tuple.getT1().getT2();
                    PrincipalAndSubsidiaries info = tuple.getT2();

                    // Si customer_id y excluded_customer_id vienen vacios
                    // devolvemos todos los clientes del usuario (TODOS)
                    if (StringUtils.isEmpty(excludedCustomerId) && StringUtils.isEmpty(customerId)) {
                        return Flux.fromIterable(info.toList());
                    }
                    // Si excluded_customer_id esta informado
                    // devolvemos todos los clientes del usuario menos ese [FILIALES]
                    // Aunque puede no coincidir con el usuario principal y no serian FILIALES
                    if (StringUtils.isNotEmpty(excludedCustomerId)) {
                        return Flux.fromIterable(info.toList().stream().filter(x -> !x.equals(excludedCustomerId)).collect(Collectors.toList()));
                    }
                    // Pasadas las dos primeras condiciones validamos que el cliente
                    // es visualizable por el usuario [PROPIOS|FILIAL]
                    if (this.validateCustomer(customerId, info)) {
                        return Flux.just(customerId);
                    }
                    return Flux.error(this.getForbiddenException("Customer is not allowed"));
                });
    }

}
