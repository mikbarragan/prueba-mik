package es.santander.adn360.security.config;

import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import java.util.List;
import java.util.Map;


/**
 * class dedicated to obtaining security-dependent configuration properties
 *
 * @author Santander Tecnologia
 */
@Getter
@Setter
@Configuration
@ConfigurationProperties(prefix = "adn360.security")
@PropertySource("classpath:/security.properties")
@RefreshScope
public class SecurityConfigProperties {

    /**
     * List of services available to be configured
     */
    private final Services services = new Services();

    /**
     * Channels to be configured
     */
    private Map<String, Channel> channel;

    private Boolean enabled = Boolean.FALSE;

    /**
     * contract detail filter config
     */
    private ContractDetailFilter contracDetailFilter;

    /**
     * Declare Services
     */
    @Getter
    @Setter
    public static class Services {
        private final SecuritiesServices bolasegService = new SecuritiesServices();
        private final SecuritiesServices confidentialityService = new SecuritiesServices();
        private final EbankingSecuritiesServices ebankingService = new EbankingSecuritiesServices();
        private final SecuritiesServicesReactive bolasegServiceReactive = new SecuritiesServicesReactive();
        private final SecuritiesServicesReactive confidentialityServiceReactive = new SecuritiesServicesReactive();
        private final EbankingSecuritiesServicesReactive ebankingServiceReactive =
                new EbankingSecuritiesServicesReactive();
    }

    /**
     * Configuration available per channel. Person level and ContractLevel security can be enable/disable
     */
    @Getter
    @Setter
    public static class Channel {
        /**
         * DISABLED | CONFIDENTIALITY | BOLASEG | EBANKING
         */
        private SecurityMode personSecType = SecurityMode.DISABLED;
        /**
         * DISABLED | CONFIDENTIALITY | BOLASEG | EBANKING
         */
        private SecurityMode contractSecType = SecurityMode.DISABLED;
    }

    /**
     * Declare class SecurityServices
     */
    @Getter
    @Setter
    public static class SecuritiesServices {
        private String personSecurityUri;
        private String contractsSecurityUri;
    }

    /**
     * Declare class SecuritiesServicesReactive
     */
    @Getter
    @Setter
    public static class SecuritiesServicesReactive {
        private String baseUrl;
        private String personSecurityPath;
        private String contractsSecurityPath;
    }

    /**
     * Declare class EbankingSecuritiesServices
     */
    @Getter
    @Setter
    public static class EbankingSecuritiesServices {
        private String personSecurityUri;
        private String contractsSecurityUri;
        private String principalAndSubsidiariesUri;
    }

    /**
     * Declare class EbankingSecuritiesServicesReactive
     */
    @Getter
    @Setter
    public static class EbankingSecuritiesServicesReactive {
        private String baseUrl;
        private String personSecurityPath;
        private String contractsSecurityPath;
        private String principalAndSubsidiariesPath;
    }


    /**
     * Enum of security modes available
     */
    public enum SecurityMode {
        /**
         * Represents the confidentiality security mode.
         */
        CONFIDENTIALITY,

        /**
         * Represents the Bolaseg security mode.
         */
        BOLASEG,

        /**
         * Represents the disabled security mode.
         */
        DISABLED,

        /**
         * Represents the Ebanking security mode.
         */
        EBANKING
    }

    /**
     * List of authorized companies to return
     */
    @NotNull
    private List<String> companies;

    /**
     * Declare class ContractDetailFilter
     */
    @Getter
    @Setter
    public static class ContractDetailFilter {
        // TRUE for enable filter
        private Boolean enabled;
    }

}
