package es.santander.adn360.security.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * PrincipalAndSubsidiaries class
 * Object which contains principal and subsidiaries user info
 */
@Getter
@Setter
@Builder
public class PrincipalAndSubsidiaries {
    /**
     * idUsuario - user
     * Logged user
     */
    @JsonProperty("user")
    private String idUsuario;
    /**
     * idCliente - Principal
     * client ID
     */
    @JsonProperty("principal")
    private String idCliente;

    /**
     * filiales - subsidiaries
     * subsidiaries
     */
    @JsonProperty("subsidiaries")
    private List<String> filiales;

    /**
     * Transforms the object to a list of customer ids
     *
     * @return list of customer ids
     */
    public List<String> toList() {
        List<String> result = new ArrayList<>();
        if (this.idCliente != null) {
            result.add(this.idCliente);
        }
        if (!CollectionUtils.isEmpty(this.filiales)) {
            result.addAll(this.filiales);
        }
        return result;
    }
}
