package es.santander.adn360.security.domain;

import es.santander.adn360.products.common.domain.entity.BaseContract;
import es.santander.adn360.products.common.domain.entity.CompaniesUsers;
import es.santander.adn360.products.common.domain.entity.Intervener;
import es.santander.adn360.products.common.domain.entity.RiskSituation;
import es.santander.adn360.products.common.domain.entity.UserInformation;
import es.santander.adn360.products.common.domain.entity.RelatedProposal;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDate;
import java.time.Month;
import java.time.Year;
import java.util.Collections;
import java.util.List;

/**
 * Contract for testing purposes.
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Document(collection = "test")
public class TestContract extends BaseContract {

    public static final String TEST_TIPO_INTERVINIENTE = "01";

    private String zDummy;
    private String dummy;

    @Builder
    public TestContract(String id, String idContrato, String contratoCartera, String cuentaLocal, String empresa,
                        String centro, String producto, String contrato, String productoNuevo, String subproducto,
                        String contratoNuevo, String descripcion, String descripcionLarga, String divisa,
                        RiskSituation situacionGSI, List<Intervener> intervinientes, List<UserInformation> informacionUsuarios
            , List<RelatedProposal> propuestasRelacionadas, String relatedProposalId
            , String zDummy, String dummy, String estado, List<CompaniesUsers> usuariosEmpresas) {


        super(id, idContrato, contratoCartera, cuentaLocal, empresa,
                centro, producto, contrato, productoNuevo, subproducto,
                contratoNuevo, descripcion, descripcionLarga, divisa,
                situacionGSI,intervinientes, informacionUsuarios, estado, LocalDate.of(Year.MAX_VALUE, Month.JANUARY, 1),
                LocalDate.of(Year.MAX_VALUE, Month.JANUARY, 1),
                LocalDate.of(Year.MAX_VALUE, Month.JANUARY, 1), usuariosEmpresas
                ,propuestasRelacionadas, relatedProposalId);


        this.zDummy = zDummy;
        this.dummy = dummy;
    }

    @Override
    public List<String> getTipoIntervinientesTitular() {
        return Collections.singletonList(TEST_TIPO_INTERVINIENTE);
    }
}
