package es.santander.adn360.security.constants;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;


class SecurityConstantsTest {

    @Test
    void testConstants() {
        Assertions.assertThat(SecurityConstants.PARAM_CONTRACTS).isEqualToIgnoringCase("contracts");
        Assertions.assertThat(SecurityConstants.PARAM_CUSTOMER_ID).isEqualToIgnoringCase("customer_id");
        Assertions.assertThat(SecurityConstants.PARAM_RESPONSE_VALID_CUSTOMER).isEqualToIgnoringCase("valid");
        Assertions.assertThat(SecurityConstants.PARAM_RESPONSE_VALID_CUSTOMER_PARAM).isEqualToIgnoringCase("status");
        Assertions.assertThat(SecurityConstants.PARAM_RESPONSE_VALID_CUSTOMER_VALUE).isEqualToIgnoringCase("OK");
    }
}
