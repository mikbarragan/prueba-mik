package es.santander.adn360.security.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import es.santander.adn360.core.model.exception.FunctionalException;
import es.santander.adn360.core.util.ExceptionEnum;
import es.santander.adn360.products.common.domain.entity.BaseContract;
import es.santander.adn360.security.config.AppEnvironment;
import es.santander.adn360.security.config.SecurityConfigProperties;
import es.santander.adn360.security.domain.PrincipalAndSubsidiaries;
import es.santander.adn360.security.domain.TestContract;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.actuate.observability.AutoConfigureObservability;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static es.santander.adn360.security.constants.SecurityConstants.PARAM_CONTRACTS;
import static es.santander.adn360.security.constants.SecurityConstants.PARAM_CUSTOMER_ID;
import static es.santander.adn360.security.constants.SecurityConstants.PARAM_EXCLUDED_CUSTOMER_ID;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@TestPropertySource(properties = {
        "spring.main.web-application-type=reactive",
        "spring.main.allow-bean-definition-overriding=true"})
@MockitoSettings(strictness = Strictness.LENIENT)
@AutoConfigureObservability
class EbankingReactiveServiceTest {

    public static MockWebServer mockWebServer;

    @Mock
    private SecurityConfigProperties securityConfigProperties;

    private final AppEnvironment appEnvironment = Mockito.mock(AppEnvironment.class);

    @Mock
    private ReactiveContextService reactiveContextService;

    @Autowired
    WebClient.Builder webClientBuilder;

    @Mock
    private ServerHttpRequest serverHttpRequest;

    @Mock
    private ServerWebExchange serverWebExchange;

    @Mock
    private Map<String, Object> requestAttributes;

    @Mock
    private MultiValueMap<String, String> queryParams;

    private EbankingReactiveService ebankingService;

    PrincipalAndSubsidiaries principalAndSubsidiaries = PrincipalAndSubsidiaries.builder()
            .idCliente("F000000001")
            .filiales(Arrays.asList("F000000002", "F000000003"))
            .build();

    @BeforeEach
    void init() throws IOException {
        mockWebServer = new MockWebServer();
        mockWebServer.start();

        var mockServerUri = mockWebServer.url("/").toString();

        var services = new SecurityConfigProperties.Services();
        services.getEbankingServiceReactive().setBaseUrl(mockServerUri);
        services.getEbankingServiceReactive().setPrincipalAndSubsidiariesPath("");
        services.getEbankingServiceReactive().setPersonSecurityPath("");
        services.getEbankingServiceReactive().setContractsSecurityPath("");

        when(this.serverWebExchange.getAttributes()).thenReturn(this.requestAttributes);
        when(this.requestAttributes.get(anyString())).thenReturn(this.principalAndSubsidiaries);

        when(this.securityConfigProperties.getServices()).thenReturn(services);
        when(this.securityConfigProperties.getCompanies()).thenReturn(
                List.of("0030", "0049", "0086", "0075", "0233", "0238", "0229"));

        when(this.queryParams.getFirst(PARAM_CUSTOMER_ID)).thenReturn(null);
        when(this.queryParams.getFirst(PARAM_EXCLUDED_CUSTOMER_ID)).thenReturn(null);

        when(this.serverHttpRequest.getQueryParams()).thenReturn(queryParams);
        when(this.reactiveContextService.getRequest()).thenReturn(Mono.just(this.serverHttpRequest));

        ebankingService = new EbankingReactiveService(webClientBuilder, securityConfigProperties, appEnvironment,
                reactiveContextService);
    }

    @AfterEach
    void tearDownEach() throws IOException {
        mockWebServer.shutdown();
    }


    @Test
    void testFilterContractsWithoutProductId() throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        mockWebServer.enqueue(new MockResponse()
                .setBody(objectMapper.writeValueAsString(Map.of(PARAM_CONTRACTS, List.of("004900751230000001"))))
                .addHeader("Content-Type", "application/json"));

        Flux<BaseContract> contracts = Flux.just(
                TestContract.builder().idContrato("004900751230000001").empresa("0049").build(),
                TestContract.builder().idContrato("004900751230000002").empresa("0049").build(),
                TestContract.builder().idContrato("004900751230000001").empresa("0001").build()
        );

        StepVerifier
                .create(this.ebankingService.filterContracts(contracts))
                .expectNext(TestContract.builder().idContrato("004900751230000001").empresa("0049").build())
                .expectComplete()
                .verify();
    }

    @Test
    void testFilterContractsWithProductId() throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        mockWebServer.enqueue(new MockResponse()
                .setBody(objectMapper.writeValueAsString(Map.of(PARAM_CONTRACTS, List.of("004900751230000001"))))
                .addHeader("Content-Type", "application/json"));

        Flux<BaseContract> contracts = Flux.just(
                TestContract.builder().idContrato("004900751230000001").empresa("0049").build(),
                TestContract.builder().idContrato("004900751230000002").empresa("0049").build(),
                TestContract.builder().idContrato("004900751230000001").empresa("0001").build()
        );

        StepVerifier
                .create(this.ebankingService.filterContracts(contracts, Mono.just("accounts")))
                .expectNext(TestContract.builder().idContrato("004900751230000001").empresa("0049").build())
                .expectComplete()
                .verify();
    }

    @Test
    void testFilterContractsEmptyFlux() throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        mockWebServer.enqueue(new MockResponse()
                .setBody(objectMapper.writeValueAsString(Map.of(PARAM_CONTRACTS, List.of("004900751230000001"))))
                .addHeader("Content-Type", "application/json"));

        Flux<BaseContract> contracts = Flux.empty();

        StepVerifier
                .create(this.ebankingService.filterContracts(contracts, Mono.just("accounts")))
                .expectComplete()
                .verify();
    }

    @Test
    void testFilterContractsElectronicBankingError() {
        mockWebServer.enqueue(new MockResponse()
                .setResponseCode(500)
                .addHeader("Content-Type", "application/json"));

        Flux<BaseContract> contracts = Flux.just(
                TestContract.builder().idContrato("004900751230000001").empresa("0049").build(),
                TestContract.builder().idContrato("004900751230000002").empresa("0049").build(),
                TestContract.builder().idContrato("004900751230000001").empresa("0001").build()
        );

        StepVerifier
                .create(this.ebankingService.filterContracts(contracts, Mono.just("accounts")))
                .expectErrorMatches(throwable -> throwable instanceof FunctionalException
                        && ExceptionEnum.FORBIDDEN.equals(((FunctionalException) throwable).getInfo()))
                .verify();
    }

    @Test
    void testFilterContractsElectronicBankingNotFound() throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        mockWebServer.enqueue(new MockResponse()
                .setResponseCode(201)
                .setBody(objectMapper.writeValueAsString(
                        Map.of("moreInformation", "Nothing was found")))
                .addHeader("Content-Type", "application/json"));

        Flux<BaseContract> contracts = Flux.just(
                TestContract.builder().idContrato("004900751230000001").empresa("0049").build(),
                TestContract.builder().idContrato("004900751230000002").empresa("0049").build(),
                TestContract.builder().idContrato("004900751230000001").empresa("0001").build()
        );

        StepVerifier
                .create(this.ebankingService.filterContracts(contracts, Mono.just("accounts")))
                .expectErrorMatches(throwable -> throwable instanceof FunctionalException
                        && ExceptionEnum.FORBIDDEN.equals(((FunctionalException) throwable).getInfo())
                        && "Nothing was found".equals(((FunctionalException) throwable).getMoreInformation()))
                .verify();
    }

    @Test
    void testResolveCustomerIdWithNoCustomer() throws JsonProcessingException {
    	ObjectMapper objectMapper = new ObjectMapper();
    	mockWebServer.enqueue(new MockResponse()
    			.setBody(objectMapper.writeValueAsString(principalAndSubsidiaries))
    			.addHeader("Content-Type", "application/json"));

    	StepVerifier
    	.create(this.ebankingService.resolveCustomerIdList())
    	.expectNext("F000000001")
    	.expectNext("F000000002")
    	.expectNext("F000000003")
    	.expectComplete()
    	.verify();
    }

    @Test
    void testResolveCustomerIdListWithExcludedCustomerId() throws JsonProcessingException {
        when(this.queryParams.getFirst(PARAM_EXCLUDED_CUSTOMER_ID)).thenReturn("F000000001");

    	ObjectMapper objectMapper = new ObjectMapper();
    	mockWebServer.enqueue(new MockResponse()
    			.setBody(objectMapper.writeValueAsString(principalAndSubsidiaries))
    			.addHeader("Content-Type", "application/json"));

    	StepVerifier
    	.create(this.ebankingService.resolveCustomerIdList())
    	.expectNext("F000000002")
    	.expectNext("F000000003")
    	.expectComplete()
    	.verify();
    }

    @Test
    void testResolveCustomerIdListWithCustomerId() throws JsonProcessingException {
        when(this.queryParams.getFirst(PARAM_CUSTOMER_ID)).thenReturn("F000000001");

    	ObjectMapper objectMapper = new ObjectMapper();
    	mockWebServer.enqueue(new MockResponse()
    			.setBody(objectMapper.writeValueAsString(principalAndSubsidiaries))
    			.addHeader("Content-Type", "application/json"));

    	StepVerifier
    	.create(this.ebankingService.resolveCustomerIdList())
    	.expectNext("F000000001")
    	.expectComplete()
    	.verify();
    }

    @Test
    void testResolveCustomerIdListWithNotAllowedCustomerId() throws JsonProcessingException {
        when(this.queryParams.getFirst(PARAM_CUSTOMER_ID)).thenReturn("F000000005");

    	ObjectMapper objectMapper = new ObjectMapper();
    	mockWebServer.enqueue(new MockResponse()
    			.setBody(objectMapper.writeValueAsString(principalAndSubsidiaries))
    			.addHeader("Content-Type", "application/json"));

        StepVerifier
                .create(this.ebankingService.resolveCustomerIdList())
                .expectErrorMatches(throwable -> throwable instanceof FunctionalException
                            && ExceptionEnum.FORBIDDEN.equals(((FunctionalException) throwable).getInfo())
                            && "Electronic Banking".equals(((FunctionalException) throwable).getMoreInformation()))
                .verify();
    }

    @Test
    void testGetUserInfoResponseError() {
        mockWebServer.enqueue(new MockResponse()
                .setResponseCode(500)
                .addHeader("Content-Type", "application/json"));

        StepVerifier
                .create(this.ebankingService.resolveCustomerIdList())
                .expectErrorMatches(throwable -> throwable instanceof FunctionalException
                        && ExceptionEnum.FORBIDDEN.equals(((FunctionalException) throwable).getInfo())
                        && "Electronic Banking".equals(((FunctionalException) throwable).getMoreInformation()))
                .verify();
    }

    @Test
    void testGetUserInfoFoundInAttributes() {

         StepVerifier
                .create(this.ebankingService.getUserInfo(this.serverWebExchange))
                .expectNext(principalAndSubsidiaries)
                .expectComplete()
                .verify();
    }

    @Test
    void testGetUserInfoNotFoundInAttributes() throws JsonProcessingException {

        when(this.requestAttributes.get(anyString())).thenReturn(null);

        ObjectMapper objectMapper = new ObjectMapper();
        mockWebServer.enqueue(new MockResponse()
                .setBody(objectMapper.writeValueAsString(principalAndSubsidiaries))
                .addHeader("Content-Type", "application/json"));

         StepVerifier
                .create(this.ebankingService.getUserInfo(this.serverWebExchange))
                .expectNextMatches(principalAndSubsidiaries ->
                                "F000000001".equals(principalAndSubsidiaries.getIdCliente()) &&
                                List.of("F000000002", "F000000003").equals(principalAndSubsidiaries.getFiliales()))
                .expectComplete()
                .verify();
    }

    @Test
    void testValidateCustomerOK() throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        mockWebServer.enqueue(new MockResponse()
                .setBody(objectMapper.writeValueAsString(principalAndSubsidiaries))
                .addHeader("Content-Type", "application/json"));

        StepVerifier
                .create(this.ebankingService.validateCustomer(Mono.just("F000000001")))
                .expectNext(true)
                .expectComplete()
                .verify();
    }

    @Test
    void testValidateCustomerKO() throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        mockWebServer.enqueue(new MockResponse()
                .setBody(objectMapper.writeValueAsString(principalAndSubsidiaries))
                .addHeader("Content-Type", "application/json"));

        StepVerifier
                .create(this.ebankingService.validateCustomer(Mono.just("F000000005")))
                .expectErrorMatches(throwable -> throwable instanceof FunctionalException
                        && ExceptionEnum.FORBIDDEN.equals(((FunctionalException) throwable).getInfo())
                        && "Electronic Banking".equals(((FunctionalException) throwable).getMoreInformation()))
                .verify();
    }

    @Test
    void testValidateCustomerKOWhenNoCustomerId() {
        StepVerifier
                .create(this.ebankingService.validateCustomer(Mono.empty()))
                .expectNext(false)
                .expectComplete()
                .verify();
    }

    @Test
    void testValidateContractOK() throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        mockWebServer.enqueue(new MockResponse()
                .setBody(objectMapper.writeValueAsString(Map.of(PARAM_CONTRACTS, List.of("004900751230000001"))))
                .addHeader("Content-Type", "application/json"));

        StepVerifier
                .create(this.ebankingService.validateContract(
                        Mono.just(TestContract.builder().idContrato("004900751230000001").empresa("0049").build())))
                .expectNext(true)
                .expectComplete()
                .verify();
    }

    @Test
    void testValidateContractKO1() throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        mockWebServer.enqueue(new MockResponse()
                .setBody(objectMapper.writeValueAsString(Map.of(PARAM_CONTRACTS, List.of("004900751230000002"))))
                .addHeader("Content-Type", "application/json"));

        StepVerifier
                .create(this.ebankingService.validateContract(
                        Mono.just(TestContract.builder().idContrato("004900751230000001").empresa("0049").build())))
                .expectNext(false)
                .expectComplete()
                .verify();
    }

    @Test
    void testValidateContractKO2() throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        mockWebServer.enqueue(new MockResponse()
                .setBody(objectMapper.writeValueAsString(Map.of(PARAM_CONTRACTS, List.of("004900751230000001"))))
                .addHeader("Content-Type", "application/json"));

        StepVerifier
                .create(this.ebankingService.validateContract(
                        Mono.just(TestContract.builder().idContrato("004900751230000001").empresa("0001").build())))
                .expectNext(false)
                .expectComplete()
                .verify();
    }

}
