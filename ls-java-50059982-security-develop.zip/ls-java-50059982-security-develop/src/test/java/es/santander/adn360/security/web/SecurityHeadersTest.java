package es.santander.adn360.security.web;

import es.santander.adn360.products.common.domain.entity.BaseContract;
import es.santander.adn360.security.config.SecurityConfigProperties;
import es.santander.adn360.security.service.ConfidentialityService;
import es.santander.adn360.security.service.SecurityResolverService;
import jakarta.servlet.http.HttpServletResponse;
import lombok.Builder;
import lombok.Data;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.actuate.observability.AutoConfigureObservability;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static es.santander.adn360.security.constants.SecurityConstants.PARAM_CONTRACTS;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureObservability
public class SecurityHeadersTest {

    @Autowired
    private TestRestTemplate testRestTemplate;

    @Autowired
    private ConfidentialityService confidentialityService;

    @Autowired
    HttpServletResponse httpServletResponse;

    @Autowired
    private SecurityConfigProperties securityConfigProperties;

    @MockBean
    private SecurityResolverService securityResolverService;

    @MockBean(name = "restTemplate")
    private RestTemplate restTemplate;

    private TestingController testingController = new TestingController();
    private static String CONFIDENTIALITY_HEADER = "Contract-Confidentiality";

    @BeforeEach
    public void setUp() throws Exception {
        Mockito.when(securityResolverService.getServiceByPerson()).thenReturn(confidentialityService);
    }

    @Test
    void validateConfidentialityHeaderIsPresent() {
        final List<TestContract> contractList = Collections.emptyList();
        final Map<String, List<String>> mockResponse = new HashMap<String, List<String>>() {{
            put(PARAM_CONTRACTS, contractList.stream()
                    .map(BaseContract::getIdContrato)
                    .collect(Collectors.toList()));
        }};
        HttpHeaders mockHeader = new HttpHeaders();
        mockHeader.add(CONFIDENTIALITY_HEADER, "true");

        ResponseEntity<Map<String, List<String>>> mockResponseEntity = new ResponseEntity<>(
                mockResponse,
                mockHeader,
                HttpStatus.OK
        );
        Mockito.when(this.restTemplate.exchange(
                ArgumentMatchers.any(),
                ArgumentMatchers.eq(HttpMethod.POST),
                ArgumentMatchers.isNotNull(),
                ArgumentMatchers.<ParameterizedTypeReference<Map<String, List<String>>>>any())
        ).thenReturn(mockResponseEntity);

        UriComponentsBuilder builder = UriComponentsBuilder.fromPath("/controller")
                .queryParam("testContract", "004900722110000001");

        ResponseEntity<Object> response = testRestTemplate.getForEntity(builder.build().encode().toUri(), Object.class);

        assertNotNull(response.getHeaders().get(CONFIDENTIALITY_HEADER));
    }

    @Test
    void validateConfidentialityHeaderIsNotPresent() {
        final List<TestContract> contractList =
                Collections.singletonList(TestContract.builder().idContrato("004900722110000001").build());
        final Map<String, List<String>> mockResponse = new HashMap<String, List<String>>() {{
            put(PARAM_CONTRACTS, contractList.stream()
                    .map(BaseContract::getIdContrato)
                    .collect(Collectors.toList()));
        }};
        ResponseEntity<Map<String, List<String>>> mockResponseEntity = new ResponseEntity<>(
                mockResponse,
                new HttpHeaders(),
                HttpStatus.OK
        );
        Mockito.when(this.restTemplate.exchange(
                ArgumentMatchers.any(),
                ArgumentMatchers.eq(HttpMethod.POST),
                ArgumentMatchers.isNotNull(),
                ArgumentMatchers.<ParameterizedTypeReference<Map<String, List<String>>>>any())
        ).thenReturn(mockResponseEntity);

        UriComponentsBuilder builder = UriComponentsBuilder.fromPath("/controller")
                .queryParam("testContract", "004900722110000001");

        ResponseEntity<Object> response = testRestTemplate.getForEntity(builder.build().encode().toUri(), Object.class);

        assertNull(response.getHeaders().get(CONFIDENTIALITY_HEADER));
    }


    @Data
    @Builder
    public static class TestContract extends BaseContract {
        private String idContrato;
        @Override
        public List<String> getTipoIntervinientesTitular() {
            return Collections.singletonList("01");
        }
    }

}
