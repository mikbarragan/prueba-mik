package es.santander.adn360.security.service;

import es.santander.adn360.core.model.exception.FunctionalException;
import es.santander.adn360.core.web.CoreSecurityContextImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.actuate.observability.AutoConfigureObservability;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.TestPropertySource;

import static org.junit.jupiter.api.Assertions.assertThrows;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@TestPropertySource(properties = {
        "adn360.security.channel.EMP.personSecType=DISABLED",
        "adn360.security.channel.EMP.contractSecType=DISABLED"
})
@AutoConfigureObservability
class DisabledEmpChannelTest {

    @Autowired
    SecurityResolverService securityServiceResolver;

    private final CoreSecurityContextImpl coreSecurityContext = Mockito.mock(CoreSecurityContextImpl.class);

    private final SecurityServiceNA serviceNA = Mockito.mock(SecurityServiceNA.class);
    private final ConfidentialityService confidentialityService = Mockito.mock(ConfidentialityService.class);
    private final BolasegService bolasegService = Mockito.mock(BolasegService.class);
    private final EbankingService ebankingService = Mockito.mock(EbankingService.class);


    @BeforeEach
    public void setUp() throws Exception {
        Mockito.when(this.coreSecurityContext.getSantanderChannel()).thenReturn("EMP");
        SecurityContextHolder.setContext(this.coreSecurityContext);
    }

    @Test
    void resolvePersonEbankingConfig() {
        assertThrows(FunctionalException.class, () -> securityServiceResolver.getServiceByPerson());
    }

    @Test
    void resolveContractEbankingConfig() {
        assertThrows(FunctionalException.class, () -> securityServiceResolver.getServiceByContract());
    }
}
