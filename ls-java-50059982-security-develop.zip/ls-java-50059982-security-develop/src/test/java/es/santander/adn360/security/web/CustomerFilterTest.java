package es.santander.adn360.security.web;

import es.santander.adn360.core.model.exception.FunctionalException;
import es.santander.adn360.core.util.ExceptionEnum;
import es.santander.adn360.security.service.ConfidentialityService;
import es.santander.adn360.security.service.SecurityResolverService;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.Mockito;
import org.mockito.stubbing.Answer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.actuate.observability.AutoConfigureObservability;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.io.PrintWriter;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureObservability
class CustomerFilterTest {

    private final HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
    private final HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
    private final FilterChain filterChain = Mockito.mock(FilterChain.class);
    private final ConfidentialityService confidencialityService = Mockito.mock(ConfidentialityService.class);

    @Autowired
    private CustomerFilter customerFilter;

    @MockBean
    private SecurityResolverService securityResolverService;

    @MockBean(name = "restTemplate") //name included because it conflicts with nuarRestTemplate
    private RestTemplate restTemplate;

    private static Integer httpServletResponseStatus;

    @BeforeEach
    public void setUp() throws IOException {

        Mockito.doAnswer((Answer<Void>) invocationOnMock -> {
            httpServletResponseStatus = invocationOnMock.getArgument(0);
            return null;
        }).when(this.httpServletResponse).setStatus(ArgumentMatchers.anyInt());
        Mockito.when(this.httpServletResponse.getWriter()).thenReturn(Mockito.mock(PrintWriter.class));

        Mockito.when(this.httpServletResponse.getWriter()).thenReturn(Mockito.mock(PrintWriter.class));
        Mockito.when(this.securityResolverService.getServiceByPerson()).thenReturn(confidencialityService);

    }

    @Test
    void testDoFilterInternalDisabledConfidentiality() throws ServletException, IOException {
        // Disable confidentiality
        //  this.securityProperties.getServices().getConfidentialityService().setPersonConfidentialityEnabled(false);
        assertDoesNotThrow(() -> this.customerFilter.doFilterInternal(this.httpServletRequest, this.httpServletResponse, this.filterChain));
    }

    @Test
    void testDoFilterInternalNullCustomerId() throws ServletException, IOException {
        // no exception is thrown
        assertDoesNotThrow(() -> this.customerFilter.doFilterInternal(this.httpServletRequest, this.httpServletResponse, this.filterChain));
    }

    @Test
    void testDoFilterInternalAuthorizedCustomer() throws ServletException, IOException {
        Mockito.when(this.httpServletRequest.getParameter(ArgumentMatchers.any()))
                .thenReturn("F000000001");


        Mockito.when(this.confidencialityService.validateCustomer(ArgumentMatchers.any())).thenReturn(true);

        this.customerFilter.doFilterInternal(this.httpServletRequest, this.httpServletResponse, this.filterChain);
    }

    @Test
    void testDoFilterInternalServerException() throws ServletException, IOException {
        Mockito.when(this.httpServletRequest.getParameter(ArgumentMatchers.any()))
                .thenReturn("F000000001");


        Mockito.when(this.confidencialityService.validateCustomer(ArgumentMatchers.any())
        ).thenThrow(new FunctionalException(
                ExceptionEnum.INTERNAL_SERVER_ERROR,
                "Message error"));

        this.customerFilter.doFilterInternal(this.httpServletRequest, this.httpServletResponse, this.filterChain);
        Assertions.assertThat(httpServletResponseStatus).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    @Test
    void testDoFilterForbiddenException() throws ServletException, IOException {
        Mockito.when(this.httpServletRequest.getParameter(ArgumentMatchers.any()))
                .thenReturn("F000000001");


        Mockito.when(this.confidencialityService.validateCustomer(ArgumentMatchers.any())
        ).thenThrow(new FunctionalException(
                ExceptionEnum.FORBIDDEN,
                "Message error"));

        this.customerFilter.doFilterInternal(this.httpServletRequest, this.httpServletResponse, this.filterChain);
        Assertions.assertThat(httpServletResponseStatus).isEqualTo(HttpStatus.FORBIDDEN.value());
    }

    @Test
    void testDoFilterConfidentialityException() throws ServletException, IOException {
        Mockito.when(this.httpServletRequest.getParameter(ArgumentMatchers.any()))
                .thenReturn("F000000001");


        Mockito.when(this.confidencialityService.validateCustomer(ArgumentMatchers.any())
        ).thenThrow(new FunctionalException(
                ExceptionEnum.CONFIDENTIALITY_ERROR,
                "Message error"));

        this.customerFilter.doFilterInternal(this.httpServletRequest, this.httpServletResponse, this.filterChain);
        Assertions.assertThat(httpServletResponseStatus).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    @Test
    void testDoFilterConfidentialityInvalidCustomerId() throws ServletException, IOException {
        Mockito.when(this.httpServletRequest.getParameter(ArgumentMatchers.any()))
                .thenReturn("invalidCustomerId");

        this.customerFilter.doFilterInternal(this.httpServletRequest, this.httpServletResponse, this.filterChain);
        Assertions.assertThat(httpServletResponseStatus).isEqualTo(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    void testDoFilterInternalNotAuthorizedCustomer() throws ServletException, IOException {
        Mockito.when(this.httpServletRequest.getParameter(ArgumentMatchers.any()))
                .thenReturn("F000000001");

        Mockito.when(this.confidencialityService.validateCustomer(ArgumentMatchers.any())).thenReturn(false);

        this.customerFilter.doFilterInternal(this.httpServletRequest, this.httpServletResponse, this.filterChain);
        Assertions.assertThat(httpServletResponseStatus).isEqualTo(HttpStatus.FORBIDDEN.value());
    }
}
