package es.santander.adn360.security.service;

import es.santander.adn360.core.model.exception.FunctionalException;
import es.santander.adn360.security.domain.TestContract;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;


@SpringBootTest
class SecurityServiceNATest {

    @Autowired
    private SecurityServiceNA securityServiceNA;

    MockHttpServletRequest httpServletRequest;

    @BeforeEach
    void init() {
        httpServletRequest = new MockHttpServletRequest();
        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(httpServletRequest));
    }

    @Test
    void filterContracts() {

        List<TestContract> contracts = Arrays.asList(
                TestContract.builder().idContrato("004900722110000001").empresa("0233").build(),
                TestContract.builder().idContrato("004900722110000002").empresa("0238").build(),
                TestContract.builder().idContrato("004900722110000003").empresa("0030").build()
                );
        List<TestContract> filteredContracts = securityServiceNA.filterContracts(contracts);

        assertThat(filteredContracts).isEqualTo(contracts);
    }

    @Test
    void validateCustomer() {
        Boolean customerValid = securityServiceNA.validateCustomer("F000000001");

        assertThat(customerValid).isTrue();
    }

    @Test
    void filterContractsOkSantander() {

        List<TestContract> contracts = Arrays.asList(
                TestContract.builder().idContrato("004900722110000001").empresa("0233").build(),
                TestContract.builder().idContrato("004900722110000002").empresa("0238").build(),
                TestContract.builder().idContrato("004900722110000003").empresa("0030").build(),
                TestContract.builder().idContrato("004900722110000004").build(),
                TestContract.builder().idContrato("004900722110000005").empresa("1985").build()
        );
        List<TestContract> filteredContracts = securityServiceNA.filterContracts(contracts);

        assertThat(filteredContracts).hasSize(3);
    }

    @Test
    void validateContract() {
        TestContract testContract = TestContract.builder().idContrato("004900722110000001").empresa("0233").build();

        assertTrue(securityServiceNA.validateContract(testContract));

    }

    @Test
    void validateResolveCustomerId() {

        // Request has no params so resolved to invalid input parameters
        assertThrows(FunctionalException.class, () -> this.securityServiceNA.resolveCustomerIdList());

        // Resolve customer_id
        Map<String, String> parameters = new HashMap<>();
        parameters.put("customer_id", "F000000001");
        httpServletRequest.setParameters(parameters);
        List<String> customerIdList = this.securityServiceNA.resolveCustomerIdList();
        assertFalse(customerIdList.isEmpty());
        assertEquals(customerIdList, Collections.singletonList("F000000001"));
        httpServletRequest.removeAllParameters();

        assertNull(this.securityServiceNA.getUserInfo());
    }
}