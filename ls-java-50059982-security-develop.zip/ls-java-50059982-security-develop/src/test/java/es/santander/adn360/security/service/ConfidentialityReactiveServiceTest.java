package es.santander.adn360.security.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import es.santander.adn360.core.model.exception.FunctionalException;
import es.santander.adn360.core.util.ExceptionEnum;
import es.santander.adn360.products.common.domain.entity.BaseContract;
import es.santander.adn360.security.config.AppEnvironment;
import es.santander.adn360.security.config.SecurityConfigProperties;
import es.santander.adn360.security.domain.TestContract;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.actuate.observability.AutoConfigureObservability;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import static es.santander.adn360.security.constants.SecurityConstants.PARAM_CONTRACTS;
import static es.santander.adn360.security.constants.SecurityConstants.PARAM_RESPONSE_VALID_CUSTOMER;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@TestPropertySource(properties = {
        "spring.main.web-application-type=reactive",
        "spring.main.allow-bean-definition-overriding=true"})
@MockitoSettings(strictness = Strictness.LENIENT)
@AutoConfigureObservability
public class ConfidentialityReactiveServiceTest {

    public static MockWebServer mockWebServer;

    @Mock
    private SecurityConfigProperties securityConfigProperties;
    private final AppEnvironment appEnvironment = Mockito.mock(AppEnvironment.class);
    @Autowired
    WebClient.Builder webClientBuilder;
    private ConfidentialityReactiveService confidentialityService;

    @BeforeAll
    static void setUp() {
    }

    @AfterAll
    static void tearDown() throws IOException {
        mockWebServer.shutdown();
    }

    @BeforeEach
    void init() throws IOException {

        mockWebServer = new MockWebServer();
        mockWebServer.start();

        var mockServerUri = mockWebServer.url("/").toString();

        var services = new SecurityConfigProperties.Services();
        services.getConfidentialityServiceReactive().setBaseUrl(mockServerUri);
        services.getConfidentialityServiceReactive().setPersonSecurityPath("");
        services.getConfidentialityServiceReactive().setContractsSecurityPath("");

        Mockito.when(this.securityConfigProperties.getServices()).thenReturn(services);
        Mockito.when(this.securityConfigProperties.getCompanies()).thenReturn(
                List.of("0049", "0075"));

        confidentialityService = new ConfidentialityReactiveService(webClientBuilder,securityConfigProperties);

    }

    @AfterEach
    void tearDownEach() throws IOException {
        mockWebServer.shutdown();
    }

    @Test
    void testValidateCustomerOk() throws JsonProcessingException  {

        ObjectMapper objectMapper = new ObjectMapper();
        mockWebServer.enqueue(new MockResponse()
                .setBody(objectMapper.writeValueAsString(
                        Map.of(PARAM_RESPONSE_VALID_CUSTOMER, true)))
                .addHeader("Content-Type", "application/json"));

        StepVerifier
                .create(this.confidentialityService.validateCustomer(Mono.just("F00000071")))
                .expectNext(Boolean.TRUE)
                .expectComplete()
                .verify();

    }

    @Test
    void testValidateCustomerKO() throws JsonProcessingException  {

        ObjectMapper objectMapper = new ObjectMapper();
        mockWebServer.enqueue(new MockResponse()
                .setBody(objectMapper.writeValueAsString(
                        Map.of(PARAM_RESPONSE_VALID_CUSTOMER, "zzz")))
                .addHeader("Content-Type", "application/json"));

        StepVerifier
                .create(this.confidentialityService.validateCustomer(Mono.just("F00000071")))
                .expectNext(Boolean.FALSE)
                .expectComplete()
                .verify();

    }

    @Test
    void testValidateCustomerEmpty() {

        StepVerifier
                .create(this.confidentialityService.validateCustomer(Mono.empty()))
                .expectNext(Boolean.FALSE)
                .expectComplete()
                .verify();

    }

    @Test
    void testValidateCustomerErrorConfidentialityCall() throws JsonProcessingException  {

        ObjectMapper objectMapper = new ObjectMapper();
        mockWebServer.enqueue(new MockResponse()
                .setResponseCode(500)
                .setBody(objectMapper.writeValueAsString(
                        Map.of(PARAM_RESPONSE_VALID_CUSTOMER, "zzz")))
                .addHeader("Content-Type", "application/json"));

        StepVerifier
                .create(this.confidentialityService.validateCustomer(Mono.just("F00000071")))
                .expectErrorMatches(throwable -> throwable instanceof FunctionalException
                        && ExceptionEnum.FORBIDDEN.equals(((FunctionalException) throwable).getInfo())
                        && "Confidentiality".equals(((FunctionalException) throwable).getMoreInformation()))
                .verify();

    }

    @Test
    void testFilterContracts() throws JsonProcessingException {

        ObjectMapper objectMapper = new ObjectMapper();
        mockWebServer.enqueue(new MockResponse()
                .setBody(objectMapper.writeValueAsString(Map.of(PARAM_CONTRACTS, List.of("004900751230000001"))))
                .addHeader("Content-Type", "application/json"));

        Flux<BaseContract> contracts = Flux.just(
                TestContract.builder().idContrato("004900751230000001").empresa("0049").build(),
                TestContract.builder().idContrato("004900751230000002").empresa("0049").build(),
                TestContract.builder().idContrato("004900751230000001").empresa("0001").build()
        );

        StepVerifier
                .create(this.confidentialityService.filterContracts(contracts))
                .expectNext(TestContract.builder().idContrato("004900751230000001").empresa("0049").build())
                .expectComplete()
                .verify();
    }

    @Test
    void testFilterContractsEmptyFlux() throws JsonProcessingException {

        ObjectMapper objectMapper = new ObjectMapper();
        mockWebServer.enqueue(new MockResponse()
                .setBody(objectMapper.writeValueAsString(Map.of("contracts", List.of("004900751230000001"))))
                .addHeader("Content-Type", "application/json"));

        Flux<BaseContract> contracts = Flux.empty();

        StepVerifier
                .create(this.confidentialityService.filterContracts(contracts))
                .expectComplete()
                .verify();
    }

    @Test
    void testFilterContractsConfidentialityError() {

        mockWebServer.enqueue(new MockResponse()
                .setResponseCode(500)
                .addHeader("Content-Type", "application/json"));

        Flux<BaseContract> contracts = Flux.just(
                TestContract.builder().idContrato("004900751230000001").empresa("0049").build(),
                TestContract.builder().idContrato("004900751230000002").empresa("0049").build(),
                TestContract.builder().idContrato("004900751230000001").empresa("0001").build()
        );

        StepVerifier
                .create(this.confidentialityService.filterContracts(contracts, Mono.just("accounts")))
                .expectErrorMatches(throwable -> throwable instanceof FunctionalException
                        && ExceptionEnum.FORBIDDEN.equals(((FunctionalException) throwable).getInfo()))
                .verify();
    }

    @Test
    void testFilterContractsElectronicBankingNotFound() throws JsonProcessingException {

        ObjectMapper objectMapper = new ObjectMapper();
        mockWebServer.enqueue(new MockResponse()
                .setResponseCode(201)
                .setBody(objectMapper.writeValueAsString(
                        Map.of("moreInformation", "Nothing was found")))
                .addHeader("Content-Type", "application/json"));

        Flux<BaseContract> contracts = Flux.just(
                TestContract.builder().idContrato("004900751230000001").empresa("0049").build(),
                TestContract.builder().idContrato("004900751230000002").empresa("0049").build(),
                TestContract.builder().idContrato("004900751230000001").empresa("0001").build()
        );

        StepVerifier
                .create(this.confidentialityService.filterContracts(contracts, Mono.just("accounts")))
                .expectErrorMatches(throwable -> throwable instanceof FunctionalException
                        && ExceptionEnum.FORBIDDEN.equals(((FunctionalException) throwable).getInfo())
                        && "Nothing was found".equals(((FunctionalException) throwable).getMoreInformation()))
                .verify();
    }

    @Test
    void testValidateContractKO1() throws JsonProcessingException {

        ObjectMapper objectMapper = new ObjectMapper();
        mockWebServer.enqueue(new MockResponse()
                .setBody(objectMapper.writeValueAsString(Map.of(PARAM_CONTRACTS, List.of("004900751230000002"))))
                .addHeader("Content-Type", "application/json"));

        StepVerifier
                .create(this.confidentialityService.validateContract(
                        Mono.just(TestContract.builder().idContrato("004900751230000001").empresa("0049").build())))
                .expectNext(false)
                .expectComplete()
                .verify();
    }

    @Test
    void testValidateContractKO2() throws JsonProcessingException {

        ObjectMapper objectMapper = new ObjectMapper();
        mockWebServer.enqueue(new MockResponse()
                .setBody(objectMapper.writeValueAsString(Map.of(PARAM_CONTRACTS, List.of("004900751230000001"))))
                .addHeader("Content-Type", "application/json"));

        StepVerifier
                .create(this.confidentialityService.validateContract(
                        Mono.just(TestContract.builder().idContrato("004900751230000001").empresa("0001").build())))
                .expectNext(false)
                .expectComplete()
                .verify();
    }

}
