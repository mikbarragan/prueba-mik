package es.santander.adn360.security.web;

import es.santander.adn360.security.service.ConfidentialityService;
import es.santander.adn360.security.web.SecurityHeadersTest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Profile("test")
@RestController
@RequestMapping("/controller")
public class TestingController {

    @Autowired
    private ConfidentialityService confidentialityService;

    @GetMapping
    public boolean testConfidentiality(@RequestParam String testContract) {
        SecurityHeadersTest.TestContract contract = SecurityHeadersTest.TestContract.builder().idContrato(testContract).build();
        return confidentialityService.validateContract(contract);
    }

}
