package es.santander.adn360.security.service;

import es.santander.adn360.core.model.dto.response.GlobalExceptionResponse;
import es.santander.adn360.core.model.exception.FunctionalException;
import es.santander.adn360.core.util.ExceptionEnum;
import es.santander.adn360.products.common.domain.entity.BaseContract;
import es.santander.adn360.security.config.SecurityConfigProperties;
import es.santander.adn360.security.domain.EbankingRequest;
import es.santander.adn360.security.domain.PrincipalAndSubsidiaries;
import es.santander.adn360.security.domain.TestContract;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.actuate.observability.AutoConfigureObservability;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static es.santander.adn360.security.constants.SecurityConstants.PARAM_CONTRACTS;
import static es.santander.adn360.security.constants.SecurityConstants.USER_INFO;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureObservability
class EbankingServiceTest {

    @Autowired
    private EbankingService ebankingService;

    //name included because it conflicts with nuarRestTemplate
    @MockBean(name = "restTemplate")
    private RestTemplate restTemplate;

    @Autowired
    private SecurityConfigProperties securityConfigProperties;

    MockHttpServletRequest httpServletRequest;

    PrincipalAndSubsidiaries principalAndSubsidiaries = PrincipalAndSubsidiaries.builder()
            .idCliente("F000000001")
            .filiales(Arrays.asList("F000000002","F000000003"))
            .build();


    URI principalAndSubsidiariesUri;

    @BeforeEach
    void init() {
        principalAndSubsidiariesUri = UriComponentsBuilder.fromHttpUrl(this.securityConfigProperties.getServices().getEbankingService()
                .getPrincipalAndSubsidiariesUri()).build().encode().toUri();

        httpServletRequest = new MockHttpServletRequest();
        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(httpServletRequest));

        httpServletRequest.setAttribute(USER_INFO, principalAndSubsidiaries);

        when(this.restTemplate.exchange(
                ArgumentMatchers.eq(principalAndSubsidiariesUri),
                ArgumentMatchers.eq(HttpMethod.GET),
                ArgumentMatchers.isNull(),
                ArgumentMatchers.same(PrincipalAndSubsidiaries.class))
        ).thenReturn(new ResponseEntity(principalAndSubsidiaries, HttpStatus.OK));
    }

    @Test
    void testFilterContractsNullContracts() {
    	assertThrows(IllegalArgumentException.class, () ->  this.ebankingService.filterContracts(null));

    }

    @Test
    void testFilterContractsAllFiltered() {
        // Mock http call to return contract list ids
        final List<TestContract> contractList = Arrays.asList(
                TestContract.builder().idContrato("11111").dummy("test1").empresa("0030").build(),
                TestContract.builder().idContrato("22222").dummy("test2").empresa("0049").build()
        );
        final Map<String, List<String>> response = new HashMap<String, List<String>>() {{
            put(PARAM_CONTRACTS, contractList.stream()
                    .map(BaseContract::getIdContrato)
                    .collect(Collectors.toList()));
        }};
        when(this.restTemplate.exchange(
                ArgumentMatchers.any(),
                ArgumentMatchers.eq(HttpMethod.POST),
                ArgumentMatchers.isNotNull(),
                ArgumentMatchers.<ParameterizedTypeReference<Map<String, List<String>>>>any())
        ).thenReturn(new ResponseEntity(response, HttpStatus.OK));

        final List<TestContract> filteredContractList = this.ebankingService.filterContracts(Arrays.asList(
                TestContract.builder().idContrato("33333").dummy("test3").build(),
                TestContract.builder().idContrato("44444").dummy("test4").build()
        ));
        Assertions.assertThat(filteredContractList).isEmpty();
    }

    @Test
    void testFilterContractsOk() {
        // Mock http call to return contract list ids
        final List<TestContract> contractList = Arrays.asList(
                TestContract.builder().idContrato("11111").dummy("test1").empresa("0030").build(),
                TestContract.builder().idContrato("22222").dummy("test2").empresa("0049").build()
        );
        final Map<String, List<String>> response = new HashMap<String, List<String>>() {{
            put(PARAM_CONTRACTS, contractList.stream()
                    .map(BaseContract::getIdContrato)
                    .collect(Collectors.toList()));
        }};
        when(this.restTemplate.exchange(
                ArgumentMatchers.any(),
                ArgumentMatchers.eq(HttpMethod.POST),
                ArgumentMatchers.isNotNull(),
                ArgumentMatchers.<ParameterizedTypeReference<Map<String, List<String>>>>any())
        ).thenReturn(new ResponseEntity(response, HttpStatus.OK));

        final List<TestContract> filteredContractList = this.ebankingService.filterContracts(Arrays.asList(
                contractList.get(0),
                TestContract.builder().idContrato("33333").dummy("test3").build(),
                contractList.get(1),
                TestContract.builder().idContrato("44444").dummy("test4").build()
        ));
        Assertions.assertThat(filteredContractList).hasSize(contractList.size());
        Assertions.assertThat(filteredContractList.get(0).getIdContrato()).isEqualTo(contractList.get(0).getIdContrato());
        Assertions.assertThat(filteredContractList.get(0).getDummy()).isEqualTo(contractList.get(0).getDummy());
        Assertions.assertThat(filteredContractList.get(1).getIdContrato()).isEqualTo(contractList.get(1).getIdContrato());
        Assertions.assertThat(filteredContractList.get(1).getDummy()).isEqualTo(contractList.get(1).getDummy());
    }

    @Test
    void testFilterContracts_2params_Ok() {
        // Mock http call to return contract list ids
        final List<TestContract> contractList = Arrays.asList(
                TestContract.builder().idContrato("11111").dummy("test1").empresa("0030").build(),
                TestContract.builder().idContrato("22222").dummy("test2").empresa("0049").build(),
                TestContract.builder().idContrato("33333").dummy("test3").build(),
                TestContract.builder().idContrato("44444").dummy("test4").build()
        );
        final Map<String, List<String>> response = new HashMap<String, List<String>>() {{
            put(PARAM_CONTRACTS, contractList.stream()
                    .map(BaseContract::getIdContrato)
                    .collect(Collectors.toList()));
        }};
        final HttpEntity ebankingRequestHttpEntity = new HttpEntity<>(
                EbankingRequest.builder()
                        .customerId(null)
                        .excludedCustomerId(null)
                        .productId("PRODUCT_ID")
                        .contracts( contractList.stream()
                                .map(BaseContract::getIdContrato)
                                .collect(Collectors.toList()) )
                        .build());

        when(this.restTemplate.exchange(
                ArgumentMatchers.any(),
                ArgumentMatchers.eq(HttpMethod.POST),
                ArgumentMatchers.eq(ebankingRequestHttpEntity),
                ArgumentMatchers.<ParameterizedTypeReference<Map<String, List<String>>>>any())
        ).thenReturn(new ResponseEntity(response, HttpStatus.OK));

        final List<TestContract> filteredContractList = this.ebankingService.filterContracts(contractList, "PRODUCT_ID");
        Assertions.assertThat(filteredContractList).hasSize(2);
        Assertions.assertThat(filteredContractList.get(0).getIdContrato()).isEqualTo(contractList.get(0).getIdContrato());
        Assertions.assertThat(filteredContractList.get(0).getDummy()).isEqualTo(contractList.get(0).getDummy());
        Assertions.assertThat(filteredContractList.get(1).getIdContrato()).isEqualTo(contractList.get(1).getIdContrato());
        Assertions.assertThat(filteredContractList.get(1).getDummy()).isEqualTo(contractList.get(1).getDummy());
    }

    @Test
    void testFilterListContractsEmptyOk() {
        // Mock http call to return contract list ids
        final List<TestContract> contractList = Collections.emptyList();


        final List<TestContract> filteredContractList = this.ebankingService.filterContracts(contractList);
        Assertions.assertThat(filteredContractList).isEmpty();
        Assertions.assertThat(filteredContractList).isEqualTo(Collections.emptyList());

    }


    @Test
    void testFilterContractsConfidentialityException() {
        when(this.restTemplate.exchange(
                ArgumentMatchers.any(),
                ArgumentMatchers.eq(HttpMethod.POST),
                ArgumentMatchers.isNotNull(),
                ArgumentMatchers.<ParameterizedTypeReference<GlobalExceptionResponse>>any())
        ).thenReturn(new ResponseEntity<>(
                GlobalExceptionResponse.builder().httpCode(HttpStatus.INTERNAL_SERVER_ERROR.value()).build(),
                HttpStatus.INTERNAL_SERVER_ERROR));


        assertThrows(FunctionalException.class, () -> this.ebankingService.filterContracts(Arrays.asList(
                TestContract.builder().idContrato("11111").dummy("test1").build(),
                TestContract.builder().idContrato("22222").dummy("test2").build()
        )));
    }

    @Test
    void testValidateCustomerOk() {
        Boolean responseConfi = this.ebankingService.validateCustomer("F000000001");
        Assertions.assertThat(responseConfi).isTrue();
    }

    @Test
    void testValidateCustomerKO() {
        assertThrows(FunctionalException.class, () -> this.ebankingService.validateCustomer("F00000071"));
    }

    @Test
    void testValidateCustomerException() {

        when(this.restTemplate.exchange(
                ArgumentMatchers.any(),
                ArgumentMatchers.eq(HttpMethod.GET),
                ArgumentMatchers.isNotNull(),
                ArgumentMatchers.same(PrincipalAndSubsidiaries.class))
        ).thenThrow(new FunctionalException(ExceptionEnum.NO_DATA_FOUND));

        assertThrows(FunctionalException.class, () -> this.ebankingService.validateCustomer("F00000071"));
    }

    @Test
    void testFilterContractsOkSantanderCompanies() {
        // Mock http call to return contract list ids
        final List<TestContract> contractList = Arrays.asList(
                TestContract.builder().idContrato("11111").dummy("test1").empresa("0049").build(),
                TestContract.builder().idContrato("22222").dummy("test2").empresa("0030").build(),
                TestContract.builder().idContrato("33333").dummy("test3").empresa("1985").build()
        );
        final Map<String, List<String>> response = new HashMap<String, List<String>>() {{
            put(PARAM_CONTRACTS, contractList.stream()
                    .map(BaseContract::getIdContrato)
                    .collect(Collectors.toList()));
        }};
        when(this.restTemplate.exchange(
                ArgumentMatchers.any(),
                ArgumentMatchers.eq(HttpMethod.POST),
                ArgumentMatchers.isNotNull(),
                ArgumentMatchers.<ParameterizedTypeReference<Map<String, List<String>>>>any())
        ).thenReturn(new ResponseEntity(response, HttpStatus.OK));

        final List<TestContract> filteredContractList = this.ebankingService.filterContracts(Arrays.asList(
                contractList.get(0),
                TestContract.builder().idContrato("33333").dummy("test3").build(),
                contractList.get(1),
                TestContract.builder().idContrato("44444").dummy("test4").build()
        ));
        Assertions.assertThat(filteredContractList).hasSize(2);
        Assertions.assertThat(filteredContractList.get(0).getIdContrato()).isEqualTo(contractList.get(0).getIdContrato());
        Assertions.assertThat(filteredContractList.get(0).getDummy()).isEqualTo(contractList.get(0).getDummy());
        Assertions.assertThat(filteredContractList.get(1).getDummy()).isEqualTo(contractList.get(1).getDummy());
        Assertions.assertThat(filteredContractList.get(1).getDummy()).isEqualTo(contractList.get(1).getDummy());
    }

    @Test
    void validateContractOK() {
        final List<TestContract> contractList = Arrays.asList(
                TestContract.builder().idContrato("11111").dummy("test1").empresa("0049").build(),
                TestContract.builder().idContrato("22222").dummy("test2").empresa("0030").build(),
                TestContract.builder().idContrato("33333").dummy("test3").empresa("1985").build()
        );
        final Map<String, List<String>> response = new HashMap<String, List<String>>() {{
            put(PARAM_CONTRACTS, contractList.stream()
                    .map(BaseContract::getIdContrato)
                    .collect(Collectors.toList()));
        }};
        when(this.restTemplate.exchange(
                ArgumentMatchers.any(),
                ArgumentMatchers.eq(HttpMethod.POST),
                ArgumentMatchers.isNotNull(),
                ArgumentMatchers.<ParameterizedTypeReference<Map<String, List<String>>>>any())
        ).thenReturn(new ResponseEntity(response, HttpStatus.OK));

        assertFalse(
                this.ebankingService.validateContract(
                    TestContract.builder().idContrato("4444").dummy("test1").empresa("0049").build()
                )
        );
    }

    @Test
    void validateContractKO() {
        final List<TestContract> contractList = Arrays.asList(
                TestContract.builder().idContrato("11111").dummy("test1").empresa("0049").build(),
                TestContract.builder().idContrato("22222").dummy("test2").empresa("0030").build(),
                TestContract.builder().idContrato("33333").dummy("test3").empresa("1985").build()
        );
        final Map<String, List<String>> response = new HashMap<String, List<String>>() {{
            put(PARAM_CONTRACTS, contractList.stream()
                    .map(BaseContract::getIdContrato)
                    .collect(Collectors.toList()));
        }};
        when(this.restTemplate.exchange(
                ArgumentMatchers.any(),
                ArgumentMatchers.eq(HttpMethod.POST),
                ArgumentMatchers.isNotNull(),
                ArgumentMatchers.<ParameterizedTypeReference<Map<String, List<String>>>>any())
        ).thenReturn(new ResponseEntity(response, HttpStatus.OK));

        assertTrue(
                this.ebankingService.validateContract(
                        TestContract.builder().idContrato("11111").dummy("test1").empresa("0049").build()
                )
        );
    }

    @Test
    void validateGetUserInfo() {
        // From context
        PrincipalAndSubsidiaries userInfo = (PrincipalAndSubsidiaries) this.ebankingService.getUserInfo();
        assertNotNull(userInfo);

        // We delete the attribute so it will bring the info from electronic banking service
        httpServletRequest.setAttribute(USER_INFO, null);
        userInfo = (PrincipalAndSubsidiaries) this.ebankingService.getUserInfo();
        assertNotNull(userInfo);

    }

    @Test
    void validateResolveCustomerIdListLogic() {

        // Request has no params so the resolved list contains principal and subsidiaries
        List<String> customerIdList = this.ebankingService.resolveCustomerIdList();
        assertFalse(customerIdList.isEmpty());
        assertEquals(customerIdList, Arrays.asList("F000000001","F000000002","F000000003"));

        // Resolve subsidiaries
        Map<String,String> parameters = new HashMap<>();
        parameters.put("excluded_customer_id", "F000000001");
        httpServletRequest.removeAllParameters();
        httpServletRequest.setParameters(parameters);
        customerIdList = this.ebankingService.resolveCustomerIdList();
        assertFalse(customerIdList.isEmpty());
        assertEquals(customerIdList, Arrays.asList("F000000002","F000000003"));

        // Resolve own
        parameters = new HashMap<>();
        parameters.put("customer_id", "F000000001");
        httpServletRequest.removeAllParameters();
        httpServletRequest.setParameters(parameters);
        customerIdList = this.ebankingService.resolveCustomerIdList();
        assertFalse(customerIdList.isEmpty());
        assertEquals(customerIdList, Collections.singletonList("F000000001"));

        // customer_id is not informed
        // excluded_customer_id is not a customer of the user
        // so excluded_customer_id will be omitted and will resolve principal and subsidiaries
        parameters = new HashMap<>();
        parameters.put("excluded_customer_id", "F000000011");
        httpServletRequest.removeAllParameters();
        httpServletRequest.setParameters(parameters);
        customerIdList = this.ebankingService.resolveCustomerIdList();
        assertFalse(customerIdList.isEmpty());
        assertEquals(customerIdList, Arrays.asList("F000000001","F000000002","F000000003"));

        // excluded_customer_id is not informed
        // customer_id is not a customer of the user so throws a exception
        parameters = new HashMap<>();
        parameters.put("customer_id", "F000000011");
        httpServletRequest.removeAllParameters();
        httpServletRequest.setParameters(parameters);
        assertThrows(FunctionalException.class, () -> this.ebankingService.resolveCustomerIdList());

        httpServletRequest.removeAllParameters();
    }
}
