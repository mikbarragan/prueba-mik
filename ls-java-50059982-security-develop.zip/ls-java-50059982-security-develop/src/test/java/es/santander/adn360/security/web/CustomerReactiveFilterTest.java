package es.santander.adn360.security.web;

import es.santander.adn360.core.model.exception.FunctionalException;
import es.santander.adn360.core.util.ExceptionEnum;
import es.santander.adn360.security.config.SecurityConfigProperties;
import es.santander.adn360.security.domain.PrincipalAndSubsidiaries;
import es.santander.adn360.security.service.ConfidentialityReactiveService;
import es.santander.adn360.security.service.SecurityResolverReactiveService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.actuate.observability.AutoConfigureObservability;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.test.context.TestSecurityContextHolder;
import org.springframework.security.test.context.support.ReactorContextTestExecutionListener;
import org.springframework.test.context.TestExecutionListener;
import org.springframework.test.context.TestPropertySource;
import org.springframework.util.MultiValueMap;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilterChain;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.util.HashMap;
import java.util.Map;

import static es.santander.adn360.security.constants.SecurityConstants.PARAM_CUSTOMER_ID;
import static org.mockito.ArgumentMatchers.any;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@TestPropertySource(properties = {
        "spring.main.web-application-type=reactive",
        "spring.main.allow-bean-definition-overriding=true"})
@AutoConfigureObservability
class CustomerReactiveFilterTest {

    private final ServerHttpRequest httpRequest = Mockito.mock(ServerHttpRequest.class);
    private final ServerWebExchange exchange = Mockito.mock(ServerWebExchange.class);
    private final WebFilterChain filterChain = Mockito.mock(WebFilterChain.class);
    private final ConfidentialityReactiveService confidencialityService =
            Mockito.mock(ConfidentialityReactiveService.class);
    private final Map<String, Object> attributesMap = Mockito.mock(HashMap.class);
    MultiValueMap<String, String> queryParams = Mockito.mock(MultiValueMap.class);
    private final SecurityContext securityContext = Mockito.mock(SecurityContext.class);

    @Mock
    private Authentication authentication;

    @Autowired
    private CustomerReactiveFilter customerFilter;

    @MockBean
    private SecurityResolverReactiveService securityResolverService;

    @Mock
    private SecurityConfigProperties securityConfigProperties;

    private final TestExecutionListener reactorContextTestExecutionListener = new ReactorContextTestExecutionListener();

    @BeforeEach
    public void setUp() throws Exception {

        TestSecurityContextHolder.setContext(securityContext);
        reactorContextTestExecutionListener.beforeTestMethod(null);

        Mockito.when(this.securityResolverService.getServiceByPerson())
                .thenReturn(Mono.just(confidencialityService));
        Mockito.when(this.confidencialityService.validateCustomer(any())).thenReturn(Mono.just(true));
        Mockito.when(this.filterChain.filter(exchange)).thenReturn(Mono.empty());
        Mockito.when(this.confidencialityService.getUserInfo(any()))
                .thenReturn(Mono.just(PrincipalAndSubsidiaries.builder().build()));
        Mockito.when(this.exchange.getRequest()).thenReturn(this.httpRequest);
        Mockito.when(this.httpRequest.getQueryParams()).thenReturn(this.queryParams);
        Mockito.when(this.queryParams.getFirst(PARAM_CUSTOMER_ID)).thenReturn("F000000999");
        Mockito.when(this.exchange.getAttributes()).thenReturn(attributesMap);
        Mockito.when(this.securityConfigProperties.getEnabled()).thenReturn(true);
        Mockito.when(this.securityContext.getAuthentication()).thenReturn(authentication);

        customerFilter.setSecurityConfigProperties(this.securityConfigProperties);
        customerFilter.setSecurityResolverService(this.securityResolverService);

    }

    @Test
    void testFilterAuthenticationOK() {

        StepVerifier
                .create(this.customerFilter.filter(this.exchange, this.filterChain))
                .expectComplete()
                .verify();

        Mockito.verify(this.attributesMap).put(any(), any());
        Mockito.verify(this.confidencialityService).validateCustomer(any());
        Mockito.verify(this.filterChain).filter(any());
    }

    @Test
    void testFilterNoAuthentication() {

        Mockito.when(securityContext.getAuthentication()).thenReturn(null);

        StepVerifier
                .create(this.customerFilter.filter(this.exchange, this.filterChain))
                .expectComplete()
                .verify();

        Mockito.verify(this.attributesMap, Mockito.never()).put(any(), any());
        Mockito.verify(this.confidencialityService).validateCustomer(any());
        Mockito.verify(this.filterChain).filter(any());
    }

    @Test
    void testFilterErrorWhileSettingUserInfo() {

        Mockito.when(this.attributesMap.put(any(), any()))
                .thenThrow(new FunctionalException(
                        ExceptionEnum.INTERNAL_SERVER_ERROR, "Error putting attribute"));

        StepVerifier
                .create(this.customerFilter.filter(this.exchange, this.filterChain))
                .expectErrorMatches(throwable -> throwable instanceof FunctionalException
                        && ExceptionEnum.INTERNAL_SERVER_ERROR.equals(((FunctionalException) throwable).getInfo())
                        && "Error putting attribute".equals(((FunctionalException) throwable).getMoreInformation()))
                .verify();

        Mockito.verify(this.attributesMap).put(any(), any());
        Mockito.verify(this.confidencialityService, Mockito.never()).validateCustomer(any());
        Mockito.verify(this.filterChain, Mockito.never()).filter(any());
    }

    @Test
    void testFilterNoUserInfo() {

        Mockito.when(confidencialityService.getUserInfo(any())).thenReturn(Mono.empty());

        StepVerifier
                .create(this.customerFilter.filter(this.exchange, this.filterChain))
                .expectComplete()
                .verify();

        Mockito.verify(this.attributesMap, Mockito.never()).put(any(), any());
        Mockito.verify(this.confidencialityService).validateCustomer(any());
        Mockito.verify(this.filterChain).filter(any());
    }

    @Test
    void testFilterSecurityDisabled() {

        Mockito.when(this.securityConfigProperties.getEnabled()).thenReturn(false);

        StepVerifier
                .create(this.customerFilter.filter(this.exchange, this.filterChain))
                .expectComplete()
                .verify();

        Mockito.verify(this.attributesMap).put(any(), any());
        Mockito.verify(this.confidencialityService, Mockito.never()).validateCustomer(any());
        Mockito.verify(this.filterChain).filter(any());
    }

    @Test
    void testFilterNoCustomerId() {

        Mockito.when(this.queryParams.getFirst(PARAM_CUSTOMER_ID)).thenReturn(null);

        StepVerifier
                .create(this.customerFilter.filter(this.exchange, this.filterChain))
                .expectComplete()
                .verify();

        Mockito.verify(this.attributesMap).put(any(), any());
        Mockito.verify(this.confidencialityService, Mockito.never()).validateCustomer(any());
        Mockito.verify(this.filterChain).filter(any());
    }

    @Test
    void testFilterNoCustomerIdAndNoAuthentication() {

        Mockito.when(this.queryParams.getFirst(PARAM_CUSTOMER_ID)).thenReturn(null);
        Mockito.when(this.securityContext.getAuthentication()).thenReturn(null);

        StepVerifier
                .create(this.customerFilter.filter(this.exchange, this.filterChain))
                .expectComplete()
                .verify();

        Mockito.verify(this.attributesMap, Mockito.never()).put(any(), any());
        Mockito.verify(this.securityResolverService, Mockito.never()).getServiceByPerson();
        Mockito.verify(this.filterChain).filter(any());
    }

    @Test
    void testFilterInvalidCustomerIdFormat() {

        Mockito.when(this.queryParams.getFirst(PARAM_CUSTOMER_ID)).thenReturn("zzzz");

        StepVerifier
                .create(this.customerFilter.filter(this.exchange, this.filterChain))
                .expectErrorMatches(throwable -> throwable instanceof FunctionalException
                        && ExceptionEnum.INVALID_INPUT_PARAMETERS.equals(((FunctionalException) throwable).getInfo())
                        && "Invalid customer id.".equals(((FunctionalException) throwable).getMoreInformation()))
                .verify();

        Mockito.verify(this.attributesMap).put(any(), any());
        Mockito.verify(this.confidencialityService, Mockito.never()).validateCustomer(any());
        Mockito.verify(this.filterChain, Mockito.never()).filter(any());
    }

    @Test
    void testFilterErrorWhileValidatingCustomerId() {

        Mockito.when(this.confidencialityService.validateCustomer(any())).thenReturn(Mono.error(
                new FunctionalException(ExceptionEnum.INTERNAL_SERVER_ERROR, "Error validating customer")));

        StepVerifier
                .create(this.customerFilter.filter(this.exchange, this.filterChain))
                .expectErrorMatches(throwable -> throwable instanceof FunctionalException
                        && ExceptionEnum.INTERNAL_SERVER_ERROR.equals(((FunctionalException) throwable).getInfo())
                        && "Error validating customer".equals(((FunctionalException) throwable).getMoreInformation()))
                .verify();

        Mockito.verify(this.attributesMap).put(any(), any());
        Mockito.verify(this.confidencialityService).validateCustomer(any());
        Mockito.verify(this.filterChain, Mockito.never()).filter(any());
    }

    @Test
    void testFilterNotAllowedCustomerId() {

        Mockito.when(this.confidencialityService.validateCustomer(any())).thenReturn(Mono.just(false));

        StepVerifier
                .create(this.customerFilter.filter(this.exchange, this.filterChain))
                .expectErrorMatches(throwable -> throwable instanceof FunctionalException
                        && ExceptionEnum.FORBIDDEN.equals(((FunctionalException) throwable).getInfo())
                        && "The person consulted F000000999 is not allowed.".equals(((FunctionalException) throwable).getMoreInformation()))
                .verify();

        Mockito.verify(this.attributesMap).put(any(), any());
        Mockito.verify(this.confidencialityService).validateCustomer(any());
        Mockito.verify(this.filterChain, Mockito.never()).filter(any());
    }

}
