package es.santander.adn360.security.service;

import es.santander.adn360.core.model.exception.FunctionalException;
import es.santander.adn360.core.web.CoreSecurityContextImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.actuate.observability.AutoConfigureObservability;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.core.context.SecurityContextHolder;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureObservability
class SecurityResolverServiceTest {

    @Autowired
    SecurityResolverService securityServiceResolver;

    private final CoreSecurityContextImpl coreSecurityContext = Mockito.mock(CoreSecurityContextImpl.class);

    private final SecurityServiceNA serviceNA = Mockito.mock(SecurityServiceNA.class);
    private final ConfidentialityService confidentialityService = Mockito.mock(ConfidentialityService.class);
    private final BolasegService bolasegService = Mockito.mock(BolasegService.class);
    private final EbankingService ebankingService = Mockito.mock(EbankingService.class);


    @BeforeEach
    public void setUp() throws Exception {
        Mockito.when(this.coreSecurityContext.getSantanderChannel()).thenReturn("OFI");
        SecurityContextHolder.setContext(this.coreSecurityContext);
    }


    @Test
    void resolvePersonBolaSegConfig() {
        //Mock INT
        Mockito.when(this.coreSecurityContext.getSantanderChannel()).thenReturn("INT");
        SecurityService service = securityServiceResolver.getServiceByPerson();
        assertThat(service).isInstanceOf(BolasegService.class);
    }

    @Test
    void resolveContractBolaSegConfig() {
        //Mock INT
        Mockito.when(this.coreSecurityContext.getSantanderChannel()).thenReturn("INT");
        SecurityService service = securityServiceResolver.getServiceByContract();
        assertThat(service).isInstanceOf(BolasegService.class);
    }

    @Test
    void resolvePersonConfidentialityConfig() {
        //Mock OFI
        Mockito.when(this.coreSecurityContext.getSantanderChannel()).thenReturn("OFI");
        SecurityService service = securityServiceResolver.getServiceByPerson();
        assertThat(service).isInstanceOf(ConfidentialityService.class);
    }

    @Test
    void resolveContractConfidentialityConfig() {
        //Mock EMP
        Mockito.when(this.coreSecurityContext.getSantanderChannel()).thenReturn("OFI");
        SecurityService service = securityServiceResolver.getServiceByContract();
        assertThat(service).isInstanceOf(ConfidentialityService.class);
    }

    @Test
    void resolvePersonDisabled() {
        //Mock RML
        Mockito.when(this.coreSecurityContext.getSantanderChannel()).thenReturn("RML");
        SecurityService service = securityServiceResolver.getServiceByPerson();
        assertThat(service).isInstanceOf(SecurityServiceNA.class);
    }

    @Test
    void resolveContractDisabled() {
        //Mock RML
        Mockito.when(this.coreSecurityContext.getSantanderChannel()).thenReturn("RML");
        SecurityService service = securityServiceResolver.getServiceByContract();
        assertThat(service).isInstanceOf(SecurityServiceNA.class);
    }

    @Test
    void failOnUnconfiguredChanneWhenCallgetServiceByPersonFunction() {
        //Mocks WRONG channel
        Mockito.when(this.coreSecurityContext.getSantanderChannel()).thenReturn("WRONG");

        assertThrows(FunctionalException.class, () -> this.securityServiceResolver.getServiceByPerson());
    }

    @Test
    void resolvePersonEbankingConfig() {
        //Mock EMP
        Mockito.when(this.coreSecurityContext.getSantanderChannel()).thenReturn("EMP");
        SecurityService service = securityServiceResolver.getServiceByPerson();
        assertThat(service).isInstanceOf(EbankingService.class);
    }
}
