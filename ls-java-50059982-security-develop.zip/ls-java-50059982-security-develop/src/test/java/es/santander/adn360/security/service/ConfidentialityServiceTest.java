package es.santander.adn360.security.service;

import es.santander.adn360.core.model.dto.response.GlobalExceptionResponse;
import es.santander.adn360.core.model.exception.FunctionalException;
import es.santander.adn360.products.common.domain.entity.BaseContract;
import es.santander.adn360.security.domain.TestContract;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.actuate.observability.AutoConfigureObservability;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static es.santander.adn360.security.constants.SecurityConstants.PARAM_CONTRACTS;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureObservability
class ConfidentialityServiceTest {

    private static final String PARAM_RESPONSE_VALID_CUSTOMER = "valid";

    @Autowired
    private ConfidentialityService confidentialityService;

    @MockBean(name = "restTemplate") //name included because it conflicts with nuarRestTemplate
    private RestTemplate restTemplate;

    MockHttpServletRequest httpServletRequest;

    @BeforeEach
    void init() {
        httpServletRequest = new MockHttpServletRequest();
        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(httpServletRequest));
    }

    @Test
    void testFilterContractsNullContracts() {
    	assertThrows(IllegalArgumentException.class, () ->  this.confidentialityService.filterContracts(null));

    }

    @Test
    void testFilterContractsOk() {
        // Mock http call to return contract list ids
        final List<TestContract> contractList = Arrays.asList(
                TestContract.builder().idContrato("11111").dummy("test1").empresa("0030").build(),
                TestContract.builder().idContrato("22222").dummy("test2").empresa("0049").build()
        );
        final Map<String, List<String>> response = new HashMap<String, List<String>>() {{
            put(PARAM_CONTRACTS, contractList.stream()
                    .map(BaseContract::getIdContrato)
                    .collect(Collectors.toList()));
        }};
        Mockito.when(this.restTemplate.exchange(
                ArgumentMatchers.any(),
                ArgumentMatchers.eq(HttpMethod.POST),
                ArgumentMatchers.isNotNull(),
                ArgumentMatchers.<ParameterizedTypeReference<Map<String, List<String>>>>any())
        ).thenReturn(new ResponseEntity(response, HttpStatus.OK));

        final List<TestContract> filteredContractList = this.confidentialityService.filterContracts(Arrays.asList(
                contractList.get(0),
                TestContract.builder().idContrato("33333").dummy("test3").build(),
                contractList.get(1),
                TestContract.builder().idContrato("44444").dummy("test4").build()
        ));
        Assertions.assertThat(filteredContractList).hasSize(contractList.size());
        Assertions.assertThat(filteredContractList.get(0).getIdContrato()).isEqualTo(contractList.get(0).getIdContrato());
        Assertions.assertThat(filteredContractList.get(0).getDummy()).isEqualTo(contractList.get(0).getDummy());
        Assertions.assertThat(filteredContractList.get(1).getDummy()).isEqualTo(contractList.get(1).getDummy());
        Assertions.assertThat(filteredContractList.get(1).getDummy()).isEqualTo(contractList.get(1).getDummy());
    }


    @Test
    void testFilterListContractsEmptyOk() {
        // Mock http call to return contract list ids
        final List<TestContract> contractList = Collections.emptyList();


        final List<TestContract> filteredContractList = this.confidentialityService.filterContracts(contractList);
        Assertions.assertThat(filteredContractList).hasSize(0);
        Assertions.assertThat(filteredContractList).isEqualTo(Collections.emptyList());

    }


    @Test
    void testFilterContractsConfidentialityException() {
        Mockito.when(this.restTemplate.exchange(
                ArgumentMatchers.any(),
                ArgumentMatchers.eq(HttpMethod.POST),
                ArgumentMatchers.isNotNull(),
                ArgumentMatchers.<ParameterizedTypeReference<GlobalExceptionResponse>>any())
        ).thenReturn(new ResponseEntity<>(
                GlobalExceptionResponse.builder().httpCode(HttpStatus.INTERNAL_SERVER_ERROR.value()).build(),
                HttpStatus.INTERNAL_SERVER_ERROR));


        assertThrows(FunctionalException.class, () -> this.confidentialityService.filterContracts(Arrays.asList(
                TestContract.builder().idContrato("11111").dummy("test1").build(),
                TestContract.builder().idContrato("22222").dummy("test2").build()
        )));
    }

    @Test
    void testFilterContractsConfidentialityException2() {
        Mockito.when(this.restTemplate.exchange(
                ArgumentMatchers.any(),
                ArgumentMatchers.eq(HttpMethod.POST),
                ArgumentMatchers.isNotNull(),
                ArgumentMatchers.<ParameterizedTypeReference<GlobalExceptionResponse>>any())
        ).thenThrow(new RestClientException("test"));

        assertThrows(FunctionalException.class, () -> this.confidentialityService.filterContracts(Arrays.asList(
                TestContract.builder().idContrato("11111").dummy("test1").build(),
                TestContract.builder().idContrato("22222").dummy("test2").build()
        )));
    }


    @Test
    void testValidateCustomerOk() {

        final Map<String, Boolean> response = new HashMap<String, Boolean>() {{
            put(PARAM_RESPONSE_VALID_CUSTOMER, true);
        }};
        Mockito.when(this.restTemplate.exchange(
                ArgumentMatchers.any(),
                ArgumentMatchers.eq(HttpMethod.POST),
                ArgumentMatchers.isNotNull(),
                ArgumentMatchers.<ParameterizedTypeReference<Map<String, Boolean>>>any())
        ).thenReturn(new ResponseEntity<>(response, HttpStatus.OK));

        Boolean responseConfi = this.confidentialityService.validateCustomer("F00000071");
        Assertions.assertThat(responseConfi).isTrue();
    }


    @Test
    void testValidateCustomerKO() {

        final Map<String, Boolean> response = new HashMap<String, Boolean>() {{
            put(PARAM_RESPONSE_VALID_CUSTOMER, true);
        }};
        Mockito.when(this.restTemplate.exchange(
                ArgumentMatchers.any(),
                ArgumentMatchers.eq(HttpMethod.POST),
                ArgumentMatchers.isNotNull(),
                ArgumentMatchers.<ParameterizedTypeReference<Map<String, Boolean>>>any())
        ).thenReturn(new ResponseEntity<>(response, HttpStatus.NON_AUTHORITATIVE_INFORMATION));

        assertThrows(FunctionalException.class, () -> this.confidentialityService.validateCustomer("F00000071"));

    }

    @Test
    void testValidateCustomerException() {

        final Map<String, Boolean> response = new HashMap<String, Boolean>() {{
            put(PARAM_RESPONSE_VALID_CUSTOMER, true);
        }};
        Mockito.when(this.restTemplate.exchange(
                ArgumentMatchers.any(),
                ArgumentMatchers.eq(HttpMethod.POST),
                ArgumentMatchers.isNotNull(),
                ArgumentMatchers.<ParameterizedTypeReference<Map<String, Boolean>>>any())
        ).thenThrow(new RestClientException("test"));

        assertThrows(RestClientException.class, () -> this.confidentialityService.validateCustomer("F00000071"));

    }

    @Test
    void testFilterContractsOkSantanderCompanies() {
        // Mock http call to return contract list ids
        final List<TestContract> contractList = Arrays.asList(
                TestContract.builder().idContrato("11111").dummy("test1").empresa("0049").build(),
                TestContract.builder().idContrato("22222").dummy("test2").empresa("0030").build(),
                TestContract.builder().idContrato("33333").dummy("test3").empresa("1985").build()
        );
        final Map<String, List<String>> response = new HashMap<String, List<String>>() {{
            put(PARAM_CONTRACTS, contractList.stream()
                    .map(BaseContract::getIdContrato)
                    .collect(Collectors.toList()));
        }};
        Mockito.when(this.restTemplate.exchange(
                ArgumentMatchers.any(),
                ArgumentMatchers.eq(HttpMethod.POST),
                ArgumentMatchers.isNotNull(),
                ArgumentMatchers.<ParameterizedTypeReference<Map<String, List<String>>>>any())
        ).thenReturn(new ResponseEntity(response, HttpStatus.OK));

        final List<TestContract> filteredContractList = this.confidentialityService.filterContracts(Arrays.asList(
                contractList.get(0),
                TestContract.builder().idContrato("33333").dummy("test3").build(),
                contractList.get(1),
                TestContract.builder().idContrato("44444").dummy("test4").build()
        ));
        Assertions.assertThat(filteredContractList).hasSize(2);
        Assertions.assertThat(filteredContractList.get(0).getIdContrato()).isEqualTo(contractList.get(0).getIdContrato());
        Assertions.assertThat(filteredContractList.get(0).getDummy()).isEqualTo(contractList.get(0).getDummy());
        Assertions.assertThat(filteredContractList.get(1).getDummy()).isEqualTo(contractList.get(1).getDummy());
        Assertions.assertThat(filteredContractList.get(1).getDummy()).isEqualTo(contractList.get(1).getDummy());
    }

    @Test
    void validateContractOK() {
        // Mock http call to return contract list ids
        final List<TestContract> contractList = Arrays.asList(
                TestContract.builder().idContrato("004912341231234567").dummy("test1").empresa("0049").build()
        );
        final Map<String, List<String>> response = new HashMap<String, List<String>>() {{
            put(PARAM_CONTRACTS, contractList.stream()
                    .map(BaseContract::getIdContrato)
                    .collect(Collectors.toList()));
        }};
        Mockito.when(this.restTemplate.exchange(
                ArgumentMatchers.any(),
                ArgumentMatchers.eq(HttpMethod.POST),
                ArgumentMatchers.isNotNull(),
                ArgumentMatchers.<ParameterizedTypeReference<Map<String, List<String>>>>any())
        ).thenReturn(new ResponseEntity(response, HttpStatus.OK));

        TestContract testContract = TestContract.builder().idContrato("004912341231234567").empresa("0049").build();

        assertTrue(confidentialityService.validateContract(testContract));

    }

    @Test
    void validateContractKO() {
        // Mock http call to return contract list ids
        final List<TestContract> contractList = Arrays.asList(
        );
        final Map<String, List<String>> response = new HashMap<String, List<String>>() {{
            put(PARAM_CONTRACTS, contractList.stream()
                    .map(BaseContract::getIdContrato)
                    .collect(Collectors.toList()));
        }};
        Mockito.when(this.restTemplate.exchange(
                ArgumentMatchers.any(),
                ArgumentMatchers.eq(HttpMethod.POST),
                ArgumentMatchers.isNotNull(),
                ArgumentMatchers.<ParameterizedTypeReference<Map<String, List<String>>>>any())
        ).thenReturn(new ResponseEntity(response, HttpStatus.OK));

        TestContract testContract = TestContract.builder().idContrato("004900722110000001").empresa("0233").build();

        assertFalse(confidentialityService.validateContract(testContract));

    }

    @Test
    void validateResolveCustomerId() {

        // Request has no params so resolved to invalid input parameters
        assertThrows(FunctionalException.class, () -> this.confidentialityService.resolveCustomerIdList());

        // Resolve customer_id
        Map<String, String> parameters = new HashMap<>();
        parameters.put("customer_id", "F000000001");
        httpServletRequest.setParameters(parameters);
        List<String> customerIdList = this.confidentialityService.resolveCustomerIdList();
        assertFalse(customerIdList.isEmpty());
        assertEquals(customerIdList, Collections.singletonList("F000000001"));
        httpServletRequest.removeAllParameters();

        assertNull(this.confidentialityService.getUserInfo());
    }

}
