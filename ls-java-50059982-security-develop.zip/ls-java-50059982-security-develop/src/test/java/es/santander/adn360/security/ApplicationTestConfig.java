package es.santander.adn360.security;

import es.santander.adn360.products.common.config.CommonConfiguration;
import es.santander.adn360.products.common.service.CustomersServiceImpl;
import es.santander.adn360.products.common.service.IntervenerInfoServiceImpl;
import es.santander.adn360.products.common.service.IntervenerServiceImpl;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.test.mock.mockito.MockBean;

/**
 * SpringBootApplication for testing.
 */
@SpringBootApplication(exclude = {CommonConfiguration.class})
public class ApplicationTestConfig {

    @MockBean
    IntervenerServiceImpl intervenerService;
    @MockBean
    CustomersServiceImpl customersService;
    @MockBean
    IntervenerInfoServiceImpl intervenerInfoService;

}
