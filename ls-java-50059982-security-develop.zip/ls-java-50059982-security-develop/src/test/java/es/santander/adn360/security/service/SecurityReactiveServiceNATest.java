package es.santander.adn360.security.service;

import es.santander.adn360.security.config.SecurityConfigProperties;
import es.santander.adn360.security.domain.TestContract;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.util.Arrays;

import static org.mockito.Mockito.when;


@SpringBootTest
@TestPropertySource(properties = {
        "spring.main.web-application-type=reactive",
        "spring.main.allow-bean-definition-overriding=true"})
class SecurityReactiveServiceNATest {

    @Mock
    private SecurityConfigProperties securityConfigProperties;

    @Autowired
    @InjectMocks
    private SecurityReactiveServiceNA securityServiceNA;

    private TestContract contract1 = TestContract.builder().idContrato("11111").dummy("test1").empresa("0086").build();
    private TestContract contract2 = TestContract.builder().idContrato("22222").dummy("test2").empresa("0229").build();
    private TestContract contract3 = TestContract.builder().idContrato("33333").dummy("test3").empresa("1985").build();

    @BeforeEach
    void init() {

        when(this.securityConfigProperties.getCompanies()).thenReturn(Arrays.asList("0086", "0229"));
    }

    @Test
    void filterContractsWithoutProductId() {

        StepVerifier
                .create(this.securityServiceNA.filterContracts(Flux.just(contract1, contract2, contract3)))
                .expectNext(contract1)
                .expectNext(contract2)
                .expectComplete()
                .verify();
    }

    @Test
    void filterContracts() {

        StepVerifier
                .create(this.securityServiceNA.filterContracts(
                        Flux.just(contract1, contract2, contract3), Mono.just("accounts")))
                .expectNext(contract1)
                .expectNext(contract2)
                .expectComplete()
                .verify();
    }

    @Test
    void validateCustomer() {

        StepVerifier
                .create(this.securityServiceNA.validateCustomer(Mono.just("F000000001")))
                .expectNext(Boolean.TRUE)
                .expectComplete()
                .verify();
    }

    @Test
    void validateContract() {

        StepVerifier
                .create(this.securityServiceNA.validateContract(Mono.just(contract1
                )))
                .expectNext(Boolean.TRUE)
                .expectComplete()
                .verify();

    }
}