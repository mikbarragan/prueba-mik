package es.santander.adn360.security.service;

import es.santander.adn360.core.model.dto.response.GlobalExceptionResponse;
import es.santander.adn360.core.model.exception.FunctionalException;
import es.santander.adn360.security.domain.TestContract;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.actuate.observability.AutoConfigureObservability;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureObservability
public class BolasegServiceTest {

    private static final String PARAM_RESPONSE_VALID_CUSTOMER = "status";
    private static final String PARAM_CONTRACTS = "contracts";

    @Autowired
    private BolasegService bolasegService;

    @MockBean(name="restTemplate") //name included because it conflicts with nuarRestTemplate
    private RestTemplate restTemplate;

    MockHttpServletRequest httpServletRequest;

    @BeforeEach
    void init() {
        httpServletRequest = new MockHttpServletRequest();
        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(httpServletRequest));
    }

    @Test
    public void testValidateCustomerOk() {

        final Map<String, String> response = new HashMap<String, String>() {{
            put(PARAM_RESPONSE_VALID_CUSTOMER, "OK");
        }};
        Mockito.when(this.restTemplate.exchange(
                ArgumentMatchers.any(),
                ArgumentMatchers.eq(HttpMethod.GET),
                ArgumentMatchers.isNotNull(),
                ArgumentMatchers.<ParameterizedTypeReference<Map<String, String>>>any())
        ).thenReturn(new ResponseEntity<>(response, HttpStatus.OK));

        Boolean  responseConfi = this.bolasegService.validateCustomer("F00000071" );
        Assertions.assertThat(responseConfi).isTrue();
    }

    @Test
    public void testValidateCustomerKO() {

        final Map<String, String> response = new HashMap<String, String>() {{
            put(PARAM_RESPONSE_VALID_CUSTOMER, "KO");
        }};
        Mockito.when(this.restTemplate.exchange(
        		ArgumentMatchers.any(),
        		ArgumentMatchers.eq(HttpMethod.GET),
        		ArgumentMatchers.isNotNull(),
        		ArgumentMatchers.<ParameterizedTypeReference<Map<String, String>>>any())
        ).thenReturn(new ResponseEntity<>(response, HttpStatus.NON_AUTHORITATIVE_INFORMATION));

       assertThrows(FunctionalException.class, () -> this.bolasegService.validateCustomer("F00000071" ));
    }

    @Test
    public void testValidateCustomerException() {

        final Map<String, String> response = new HashMap<String, String>() {{
            put(PARAM_RESPONSE_VALID_CUSTOMER, "OK");
        }};
        Mockito.when(this.restTemplate.exchange(
        		ArgumentMatchers.any(),
        		ArgumentMatchers.eq(HttpMethod.GET),
        		ArgumentMatchers.isNotNull(),
        		ArgumentMatchers.<ParameterizedTypeReference<Map<String, String>>>any())
        ).thenThrow(new RestClientException("test"));

        assertThrows(RestClientException.class, () -> this.bolasegService.validateCustomer("F00000071" ));

    }

    @Test
    public void testFilterListContracts() {

        // Mock http call to return contract list ids
        final List<String> contracts = Arrays.asList("11111","22222");

        final Map<String, List<String>> response = new HashMap<String, List<String>>() {{
            put(PARAM_CONTRACTS, contracts);
        }};

        Mockito.when(this.restTemplate.exchange(
                ArgumentMatchers.any(),
                ArgumentMatchers.eq(HttpMethod.POST),
                ArgumentMatchers.isNotNull(),
                ArgumentMatchers.<ParameterizedTypeReference<Map<String, List<String>>>>any())
        ).thenReturn(new ResponseEntity(response, HttpStatus.OK));


        // Mock http call to return contract list ids
        final List<TestContract> contractList = Arrays.asList(
                TestContract.builder().idContrato("11111").dummy("test1").empresa("0086").build(),
                TestContract.builder().idContrato("22222").dummy("test2").empresa("0229").build(),
                TestContract.builder().idContrato("33333").dummy("test3").empresa("1985").build()
        );

        final List<TestContract> filteredContractList = this.bolasegService.filterContracts(contractList);
        Assertions.assertThat(filteredContractList).hasSize( 2 );
    }

    @Test
    public void testFilterListContractsKO() {

        final Map<String, Boolean> response = new HashMap<String, Boolean>() {{
            put(PARAM_RESPONSE_VALID_CUSTOMER, true);
        }};

        Mockito.when(this.restTemplate.exchange(
                ArgumentMatchers.any(),
                ArgumentMatchers.eq(HttpMethod.POST),
                ArgumentMatchers.isNotNull(),
                ArgumentMatchers.<ParameterizedTypeReference<GlobalExceptionResponse>>any())
        ).thenThrow(new RestClientException("test"));


        // Mock http call to return contract list ids
        final List<TestContract> contractList = Arrays.asList(
                TestContract.builder().idContrato("11111").dummy("test1").empresa("0086").build(),
                TestContract.builder().idContrato("22222").dummy("test2").empresa("0229").build(),
                TestContract.builder().idContrato("33333").dummy("test3").empresa("1985").build()
        );
        assertThrows(FunctionalException.class, () -> this.bolasegService.filterContracts(contractList));
    }

    @Test
    public void validateContractOKTest() {

        TestContract testContract = TestContract.builder()
                .idContrato("004912341231234567")
                .empresa("0049")
                .build();

        // Mock http call to return contract list ids
        final List<String> contracts = Arrays.asList("004912341231234567");

        final Map<String, List<String>> response = new HashMap<String, List<String>>() {{
            put(PARAM_CONTRACTS, contracts);
        }};

        Mockito.when(this.restTemplate.exchange(
                ArgumentMatchers.any(),
                ArgumentMatchers.eq(HttpMethod.POST),
                ArgumentMatchers.isNotNull(),
                ArgumentMatchers.<ParameterizedTypeReference<Map<String, List<String>>>>any())
        ).thenReturn(new ResponseEntity(response, HttpStatus.OK));


        assertTrue(this.bolasegService.validateContract(testContract));
    }

    @Test
    public void validateContractKOTest() {

        TestContract testContract = TestContract.builder()
                .idContrato("004912341231234567")
                .build();

        // Mock http call to return contract list ids
        final List<String> contracts = Arrays.asList();

        final Map<String, List<String>> response = new HashMap<String, List<String>>() {{
            put(PARAM_CONTRACTS, contracts);
        }};

        Mockito.when(this.restTemplate.exchange(
                ArgumentMatchers.any(),
                ArgumentMatchers.eq(HttpMethod.POST),
                ArgumentMatchers.isNotNull(),
                ArgumentMatchers.<ParameterizedTypeReference<Map<String, List<String>>>>any())
        ).thenReturn(new ResponseEntity(response, HttpStatus.OK));


        assertFalse(this.bolasegService.validateContract(testContract));
    }

    @Test
    void validateResolveCustomerId() {

        // Request has no params so resolved to invalid input parameters
        assertThrows(FunctionalException.class, () -> this.bolasegService.resolveCustomerIdList());

        // Resolve customer_id
        Map<String, String> parameters = new HashMap<>();
        parameters.put("customer_id", "F000000001");
        httpServletRequest.setParameters(parameters);
        List<String> customerIdList = this.bolasegService.resolveCustomerIdList();
        assertFalse(customerIdList.isEmpty());
        assertEquals(customerIdList, Collections.singletonList("F000000001"));
        httpServletRequest.removeAllParameters();

        assertNull(this.bolasegService.getUserInfo());
    }
}
