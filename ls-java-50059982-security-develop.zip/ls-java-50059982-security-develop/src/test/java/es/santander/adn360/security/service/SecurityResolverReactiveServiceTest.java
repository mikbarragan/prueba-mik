package es.santander.adn360.security.service;

import es.santander.adn360.core.model.exception.FunctionalException;
import es.santander.adn360.core.util.ExceptionEnum;
import es.santander.adn360.security.config.SecurityConfigProperties;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.autoconfigure.actuate.observability.AutoConfigureObservability;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.util.HashMap;
import java.util.Map;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@TestPropertySource(properties = {
        "spring.main.web-application-type=reactive",
        "spring.main.allow-bean-definition-overriding=true"})
@AutoConfigureObservability
class SecurityResolverReactiveServiceTest {

    private final SecurityConfigProperties securityConfigProperties = Mockito.mock(SecurityConfigProperties.class);

    private final SecurityReactiveServiceNA serviceNA = Mockito.mock(SecurityReactiveServiceNA.class);
    private final ConfidentialityReactiveService confidentialityService =
            Mockito.mock(ConfidentialityReactiveService.class);
    private final BolasegReactiveService bolasegService = Mockito.mock(BolasegReactiveService.class);
    private final EbankingReactiveService ebankingService = Mockito.mock(EbankingReactiveService.class);
    private final ReactiveContextService reactiveContextService = Mockito.mock(ReactiveContextService.class);


    SecurityResolverReactiveService securityServiceResolver = new SecurityResolverReactiveService(
            securityConfigProperties,
            serviceNA,
            bolasegService,
            confidentialityService,
            ebankingService,
            reactiveContextService
    );


    @BeforeEach
    public void setUp() {
        var empChannel = new SecurityConfigProperties.Channel();
        empChannel.setPersonSecType(SecurityConfigProperties.SecurityMode.EBANKING);
        empChannel.setContractSecType(SecurityConfigProperties.SecurityMode.EBANKING);
        var ofiChannel = new SecurityConfigProperties.Channel();
        ofiChannel.setPersonSecType(SecurityConfigProperties.SecurityMode.CONFIDENTIALITY);
        ofiChannel.setContractSecType(SecurityConfigProperties.SecurityMode.CONFIDENTIALITY);
        var intChannel = new SecurityConfigProperties.Channel();
        intChannel.setPersonSecType(SecurityConfigProperties.SecurityMode.BOLASEG);
        intChannel.setContractSecType(SecurityConfigProperties.SecurityMode.BOLASEG);
        var rmlChannel = new SecurityConfigProperties.Channel();
        rmlChannel.setPersonSecType(SecurityConfigProperties.SecurityMode.DISABLED);
        rmlChannel.setContractSecType(SecurityConfigProperties.SecurityMode.DISABLED);

        Map<String, SecurityConfigProperties.Channel> channelMap = Map.of(
                "EMP", empChannel,
                "OFI", ofiChannel,
                "INT", intChannel,
                "RML", rmlChannel
        );

        Mockito.when(this.securityConfigProperties.getEnabled()).thenReturn(true);
        Mockito.when(this.securityConfigProperties.getChannel()).thenReturn(channelMap);
    }

    @Test
    void resolvePersonEmpServiceOk() {

        Mockito.when(this.reactiveContextService.getSantanderChannel()).thenReturn(Mono.just("EMP"));

            StepVerifier
                    .create(this.securityServiceResolver.getServiceByPerson())
                    .expectNextMatches(service -> service instanceof EbankingReactiveService)
                    .expectComplete()
                    .verify();
    }

    @Test
    void resolvePersonOfiServiceOk() {

        Mockito.when(this.reactiveContextService.getSantanderChannel()).thenReturn(Mono.just("OFI"));

        StepVerifier
                .create(this.securityServiceResolver.getServiceByPerson())
                .expectNextMatches(service -> service instanceof ConfidentialityReactiveService)
                .expectComplete()
                .verify();

    }

    @Test
    void resolvePersonIntServiceOk() {

        Mockito.when(this.reactiveContextService.getSantanderChannel()).thenReturn(Mono.just("INT"));

        StepVerifier
                .create(this.securityServiceResolver.getServiceByPerson())
                .expectNextMatches(service -> service instanceof BolasegReactiveService)
                .expectComplete()
                .verify();

    }

    @Test
    void resolvePersonRmlServiceOk() {
        Mockito.when(this.reactiveContextService.getSantanderChannel()).thenReturn(Mono.just("RML"));

        StepVerifier
                .create(this.securityServiceResolver.getServiceByPerson())
                .expectNextMatches(service -> service instanceof SecurityReactiveServiceNA)
                .expectComplete()
                .verify();
    }

    @Test
    void resolvePersonServiceInvalidChannel() {

        Mockito.when(this.reactiveContextService.getSantanderChannel()).thenReturn(Mono.just("zzzz"));

        StepVerifier
                .create(this.securityServiceResolver.getServiceByPerson())
                .expectErrorMatches(throwable -> throwable instanceof FunctionalException
                        && ExceptionEnum.FORBIDDEN.equals(((FunctionalException) throwable).getInfo())
                        && "Invalid channel".equals(((FunctionalException) throwable).getMoreInformation()))
                .verify();
    }

    @Test
    void resolvePersonServiceSecurityNotConfigured() {

        Mockito.when(this.reactiveContextService.getSantanderChannel()).thenReturn(Mono.just("EMP"));
        Mockito.when(this.securityConfigProperties.getChannel()).thenReturn(new HashMap<>());
        Mockito.when(this.securityConfigProperties.getEnabled()).thenReturn(false);

        StepVerifier
                .create(this.securityServiceResolver.getServiceByPerson())
                .expectErrorMatches(throwable -> throwable instanceof FunctionalException
                        && ExceptionEnum.FORBIDDEN.equals(((FunctionalException) throwable).getInfo())
                        && "Security for channel EMP is not configured".equals(
                                ((FunctionalException) throwable).getMoreInformation()))
                .verify();
    }

    @Test
    void resolvePersonServiceWrongEmpService() {

        Mockito.when(this.reactiveContextService.getSantanderChannel()).thenReturn(Mono.just("EMP"));

        SecurityConfigProperties.Channel empConfig = new SecurityConfigProperties.Channel();
        empConfig.setPersonSecType(SecurityConfigProperties.SecurityMode.CONFIDENTIALITY);
        Map<String, SecurityConfigProperties.Channel> channelMap = new HashMap<>();
        channelMap.put("EMP", empConfig);

        Mockito.when(this.securityConfigProperties.getChannel()).thenReturn(channelMap);

        StepVerifier
                .create(this.securityServiceResolver.getServiceByPerson())
                .expectErrorMatches(throwable -> throwable instanceof FunctionalException
                        && ExceptionEnum.FORBIDDEN.equals(((FunctionalException) throwable).getInfo())
                        && "Channel EMP security must be EBANKING".equals(((FunctionalException) throwable).getMoreInformation()))
                .verify();
    }

    @Test
    void resolveContractEmpServiceOk() {

        Mockito.when(this.reactiveContextService.getSantanderChannel()).thenReturn(Mono.just("EMP"));

        StepVerifier
                .create(this.securityServiceResolver.getServiceByContract())
                .expectNextMatches(service -> service instanceof EbankingReactiveService)
                .expectComplete()
                .verify();
    }

    @Test
    void resolveContractOfiServiceOk() {

        Mockito.when(this.reactiveContextService.getSantanderChannel()).thenReturn(Mono.just("OFI"));

        StepVerifier
                .create(this.securityServiceResolver.getServiceByContract())
                .expectNextMatches(service -> service instanceof ConfidentialityReactiveService)
                .expectComplete()
                .verify();
    }

    @Test
    void resolveContractIntServiceOk() {

        Mockito.when(this.reactiveContextService.getSantanderChannel()).thenReturn(Mono.just("INT"));

        StepVerifier
                .create(this.securityServiceResolver.getServiceByContract())
                .expectNextMatches(service -> service instanceof BolasegReactiveService)
                .expectComplete()
                .verify();
    }

    @Test
    void resolveContractRmlServiceOk() {
        Mockito.when(this.reactiveContextService.getSantanderChannel()).thenReturn(Mono.just("RML"));

        StepVerifier
                .create(this.securityServiceResolver.getServiceByContract())
                .expectNextMatches(service -> service instanceof SecurityReactiveServiceNA)
                .expectComplete()
                .verify();
    }

    @Test
    void resolveContractServiceInvalidChannel() {

        Mockito.when(this.reactiveContextService.getSantanderChannel()).thenReturn(Mono.just("zzzz"));

        StepVerifier
                .create(this.securityServiceResolver.getServiceByContract())
                .expectErrorMatches(throwable -> throwable instanceof FunctionalException
                        && ExceptionEnum.FORBIDDEN.equals(((FunctionalException) throwable).getInfo())
                        && "Invalid channel".equals(((FunctionalException) throwable).getMoreInformation()))
                .verify();
    }

    @Test
    void resolveContractServiceSecurityNotConfigured() {

        Mockito.when(this.reactiveContextService.getSantanderChannel()).thenReturn(Mono.just("EMP"));
        Mockito.when(this.securityConfigProperties.getChannel()).thenReturn(new HashMap<>());
        Mockito.when(this.securityConfigProperties.getEnabled()).thenReturn(false);

        StepVerifier
                .create(this.securityServiceResolver.getServiceByContract())
                .expectErrorMatches(throwable -> throwable instanceof FunctionalException
                        && ExceptionEnum.FORBIDDEN.equals(((FunctionalException) throwable).getInfo())
                        && "Security for channel EMP is not configured".equals(
                                ((FunctionalException) throwable).getMoreInformation()))
                .verify();
    }

    @Test
    void resolveContractServiceWrongEmpService() {

        Mockito.when(this.reactiveContextService.getSantanderChannel()).thenReturn(Mono.just("EMP"));

        SecurityConfigProperties.Channel empConfig = new SecurityConfigProperties.Channel();
        empConfig.setContractSecType(SecurityConfigProperties.SecurityMode.CONFIDENTIALITY);
        Map<String, SecurityConfigProperties.Channel> channelMap = new HashMap<>();
        channelMap.put("EMP", empConfig);

        Mockito.when(this.securityConfigProperties.getChannel()).thenReturn(channelMap);

        StepVerifier
                .create(this.securityServiceResolver.getServiceByContract())
                .expectErrorMatches(throwable -> throwable instanceof FunctionalException
                        && ExceptionEnum.FORBIDDEN.equals(((FunctionalException) throwable).getInfo())
                        && "Channel EMP security must be EBANKING".equals(((FunctionalException) throwable).getMoreInformation()))
                .verify();
    }
}
