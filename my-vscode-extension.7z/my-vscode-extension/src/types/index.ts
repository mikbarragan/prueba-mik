export interface MyExtensionConfig {
    settingOne: string;
    settingTwo: number;
    enableFeatureX: boolean;
}

export interface Command {
    command: string;
    title: string;
    category: string;
}

export type Status = 'idle' | 'running' | 'completed' | 'error';