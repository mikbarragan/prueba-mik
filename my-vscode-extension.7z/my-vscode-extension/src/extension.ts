import * as vscode from 'vscode';

export function activate(context: vscode.ExtensionContext) {
    // Register commands here
    let disposable = vscode.commands.registerCommand('extension.helloWorld', () => {
        vscode.window.showInformationMessage('Hello World from your VS Code extension!');
    });

    context.subscriptions.push(disposable);
}

export function deactivate() {}