package es.santander.adn360.products.common.service;

import es.santander.adn360.core.config.TestConfiguration;
import es.santander.adn360.core.model.document.Exchange;
import es.santander.adn360.core.web.WebUtils;
import es.santander.adn360.products.common.domain.IntervenerInfo;
import es.santander.adn360.products.common.domain.Person;
import es.santander.adn360.products.common.domain.entity.BaseContract;
import es.santander.adn360.products.common.domain.entity.Customer;
import es.santander.adn360.products.common.domain.entity.CustomerAddress;
import es.santander.adn360.products.common.domain.entity.Intervener;
import es.santander.adn360.products.common.domain.repository.IntervenerInfoRepository;
import es.santander.adn360.products.common.domain.repository.PersonRepository;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.actuate.observability.AutoConfigureObservability;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.junit.Assert.assertNotNull;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureObservability
class CustomersServiceTest {

    @Autowired
    private CustomersService customersService;

    @MockBean(name="restTemplate") //name included because it conflicts with nuarRestTemplate
    private RestTemplate restTemplate;

    @MockBean
    private PersonRepository personRepository;

    @MockBean
    private IntervenerInfoRepository intervenerRepository;

    @BeforeEach
    public void setUp() {
        this.customersService.cleanCustomerCache();
    }

    @Test void testFoundResult() {
        Customer customer = Customer.builder().customerId("F0000001").name("Pepito grillo").build();

        Mockito.when(this.restTemplate.exchange(
        		ArgumentMatchers.<URI>any(),
        		ArgumentMatchers.eq(HttpMethod.GET),
        		ArgumentMatchers.isNull(),
        		ArgumentMatchers.<ParameterizedTypeReference<List<Exchange>>>any())
        ).thenReturn(new ResponseEntity(customer, HttpStatus.OK));

        Assertions.assertThat(this.customersService.getCustomerInfo("F", "000001"))
                .isNotNull()
                .isEqualTo(customer);
    }

    @Test void testCustomerPhoneFoundResult() {
        Customer customer = Customer.builder()
                .name("Pepito grillo")
                .documentType("F")
                .documentNumber("021494566")
                .channel("93")
                .codeClientCompany("968527")
                .phone("678786134")
                .build();

        Mockito.when(this.restTemplate.exchange(
                ArgumentMatchers.<URI>any(),
                ArgumentMatchers.eq(HttpMethod.GET),
                ArgumentMatchers.isNull(),
                ArgumentMatchers.<ParameterizedTypeReference<List<Exchange>>>any())
        ).thenReturn(new ResponseEntity(customer, HttpStatus.OK));

        Assertions.assertThat(this.customersService.getPhoneCustomerInfo("F021494566"))
                .isNotNull()
                .isEqualTo(customer);
    }

    @Test void testCustomerAdress_ok() {
        Customer customer = Customer.builder()
                .customerId("F026239524")
                .name("CONSUELO COROMINAS IZARD")
                .documentType("N")
                .documentNumber("23282658B")
                .channel("93")
                .codeClientCompany("968527")
                .phone("678786134")
                .customerAddress(CustomerAddress.builder()
                        .addressType("PL")
                        .addressName("ARQUET")
                        .number("3")
                        .city("BARCELONA")
                        .build()
                )
                .build();

        Mockito.when(this.restTemplate.exchange(
                ArgumentMatchers.<URI>any(),
                ArgumentMatchers.eq(HttpMethod.GET),
                ArgumentMatchers.isNull(),
                ArgumentMatchers.<ParameterizedTypeReference<List<Customer>>>any())
        ).thenReturn(new ResponseEntity(customer, HttpStatus.OK));

        Assertions.assertThat(this.customersService.getCustomerAddress("F026239524",1))
                .isNotNull()
                .isEqualTo(customer);
    }

    @Test void testNotFoundResult() {
        Customer customer = Customer.builder().customerId("F0000002").name("Pepito grillo").build();

        Mockito.when(this.restTemplate.exchange(
        		ArgumentMatchers.<URI>any(),
        		ArgumentMatchers.eq(HttpMethod.GET),
        		ArgumentMatchers.isNull(),
        		ArgumentMatchers.<ParameterizedTypeReference<List<Exchange>>>any())
        ).thenReturn(new ResponseEntity(customer, HttpStatus.NOT_FOUND));

        Assertions.assertThat(this.customersService.getCustomerInfo("F", "000002")).isNull();
    }

    @Test void testCustomerAdress_not_found() {
        Customer customer = Customer.builder().build();

        Mockito.when(this.restTemplate.exchange(
        		ArgumentMatchers.<URI>any(),
        		ArgumentMatchers.eq(HttpMethod.GET),
        		ArgumentMatchers.isNull(),
        		ArgumentMatchers.<ParameterizedTypeReference<List<Customer>>>any())
        ).thenReturn(new ResponseEntity(customer, HttpStatus.NOT_FOUND));

        Assertions.assertThat(this.customersService.getCustomerAddress("F026239524",1)).isNull();
    }

    @Test void testCustomerPhone_NotFoundResult() {

        Mockito.when(this.restTemplate.exchange(
                ArgumentMatchers.<URI>any(),
                ArgumentMatchers.eq(HttpMethod.GET),
                ArgumentMatchers.isNull(),
                ArgumentMatchers.<ParameterizedTypeReference<List<Exchange>>>any())
        ).thenReturn(new ResponseEntity(null, HttpStatus.NO_CONTENT));

        Assertions.assertThat(this.customersService.getPhoneCustomerInfo("F0000002")).isNull();
    }

    @Test void testFIndByClientId() {
        Customer customer = Customer.builder().customerId("F0000001").name("Pepito grillo").build();

        Mockito.when(this.restTemplate.exchange(
        		ArgumentMatchers.<URI>any(),
        		ArgumentMatchers.eq(HttpMethod.GET),
        		ArgumentMatchers.isNull(),
        		ArgumentMatchers.<ParameterizedTypeReference<List<Exchange>>>any())
        ).thenReturn(new ResponseEntity(customer, HttpStatus.OK));

        Assertions.assertThat(this.customersService.getCustomerInfo("F0000001"))
                .isNotNull()
                .isEqualTo(customer);
    }

    @Test void testCache() {

        Customer customer1 = Customer.builder().customerId("F0000003").name("Gepeto").build();
        Customer customer2 = Customer.builder().customerId("F0000004").name("Pepito grillo").build();

        //First Petition. Response Customer1 - Cache Customer1
        Mockito.when(this.restTemplate.exchange(
        		ArgumentMatchers.<URI>any(),
        		ArgumentMatchers.eq(HttpMethod.GET),
        		ArgumentMatchers.isNull(),
        		ArgumentMatchers.<ParameterizedTypeReference<List<Exchange>>>any())
        ).thenReturn(new ResponseEntity(customer1, HttpStatus.OK));
        Assertions.assertThat(this.customersService.getCustomerInfo("testCache", "testCache"))
                .isNotNull()
                .isEqualTo(customer1);

        //Second Petition. Response Customer2 - Cache Customer1
        Mockito.when(this.restTemplate.exchange(
        		ArgumentMatchers.<URI>any(),
        		ArgumentMatchers.eq(HttpMethod.GET),
        		ArgumentMatchers.isNull(),
        		ArgumentMatchers.<ParameterizedTypeReference<List<Exchange>>>any())
        ).thenReturn(new ResponseEntity(customer2, HttpStatus.OK));
        Assertions.assertThat(this.customersService.getCustomerInfo("testCache", "testCache"))
                .isNotNull()
                .isEqualTo(customer1);

        //Third Petition. Response Customer2 - Cache Customer2
        customersService.cleanCustomerCache();
        Assertions.assertThat(this.customersService.getCustomerInfo("testCache", "testCache"))
                .isNotNull()
                .isEqualTo(customer2);
    }


    @Test void testFindOneByTypeAndCode(){
        Mockito.when(this.personRepository.findOneByTypeAndCode("F", "000000001"))
                .thenReturn(Person.builder()
                        .type("F")
                        .code("000000001")
                        .name("Test Name")
                        .build());

        Assertions.assertThat(this.customersService.findOneByTypeAndCode("F", "000000001")).isNotNull();
        Assertions.assertThat(this.customersService.findOneByTypeAndCode("J", "000025698")).isNull();
    }

    @Test void testSetIntervenersName() {
        TestConfiguration.mockSantanderChannel(WebUtils.SANTANDER_CHANNEL_EMP);

        final var person4 = Person.builder().type("F").code("000000001").name("Test Name").build();

        final var iMap = Stream.of(person4).collect(Collectors.toMap(
                person -> person.getType() + person.getCode(),
                Function.identity(),
                (existing, replacement) -> existing
        ));

        Mockito.when(this.personRepository.findAsMapByInterveners(ArgumentMatchers.any())).thenReturn(iMap);

        // Put 2 interveners, one with the same idCliente as person returned by repository.
        final List<TestContract> contractList = Collections.singletonList(TestContract.builder()
                .intervinientes(Arrays.asList(
                        Intervener.builder()
                                .ordenInterv(BaseContract.ORDEN_INTERV_PRIMER_TITULAR)
                                .tipoInterv(TestContract.TEST_TIPO_INTERVINIENTE)
                                .idCliente("F000000001")
                                .build(),
                        Intervener.builder()
                                .ordenInterv(BaseContract.ORDEN_INTERV_PRIMER_TITULAR)
                                .tipoInterv(TestContract.TEST_TIPO_INTERVINIENTE)
                                .idCliente("F000000002")
                                .build())
                )
                .build());

        this.customersService.setIntervenersName(contractList);
        Assertions.assertThat(contractList.get(0).getIntervinientes().get(0).getNombreCompleto()).isEqualTo("Test Name");
        Assertions.assertThat(contractList.get(0).getIntervinientes().get(1).getNombreCompleto()).isNull();
    }

    @Test void testSetAllIntervenersName() {

        Person person1 = Person.builder().type("F").code("000000001").name("Test Name 1").build();
        Person person2 = Person.builder().type("F").code("000000002").name("Test Name 2").build();
        Person person3 = Person.builder().type("F").code("000000003").name("Test Name 3").build();
        Person person4 = Person.builder().type("F").code("000000004").name("Test Name 4").build();
        final var iMap = Stream.of(person1, person2, person3, person4).collect(Collectors.toMap(
                person -> person.getType() + person.getCode(),
                Function.identity(),
                (existing, replacement) -> existing
        ));
        Mockito.when(this.personRepository.findAsMapByInterveners(ArgumentMatchers.any()))
                .thenReturn(iMap);

        List<Intervener> interveners = Arrays.asList(
                Intervener.builder().ordenInterv(BaseContract.ORDEN_INTERV_PRIMER_TITULAR)
                        .tipoInterv(TestContract.TEST_TIPO_INTERVINIENTE).idCliente("F000000001")
                        .build(),
                Intervener.builder().ordenInterv(BaseContract.ORDEN_INTERV_PRIMER_TITULAR)
                        .tipoInterv(TestContract.TEST_TIPO_INTERVINIENTE).idCliente("F000000002").fechaBaja(LocalDate.now().minusMonths(1))
                        .build(),
                Intervener.builder().ordenInterv(BaseContract.ORDEN_INTERV_PRIMER_TITULAR)
                        .tipoInterv(TestContract.TEST_TIPO_INTERVINIENTE).idCliente("F000000003")
                        .build()
        );

        TestConfiguration.mockSantanderChannel(WebUtils.SANTANDER_CHANNEL_EMP);

        final List<TestContract> contractList = Collections.singletonList(TestContract.builder()
                                                                                        .intervinientes(interveners)
                                                                                        .build());

        this.customersService.setAllIntervenersName(contractList, true);
        Assertions.assertThat(contractList.get(0).getIntervinientes().get(0).getNombreCompleto()).isEqualTo("Test Name 1");
        Assertions.assertThat(contractList.get(0).getIntervinientes().get(1).getNombreCompleto()).isEqualTo("Test Name 2");
        Assertions.assertThat(contractList.get(0).getIntervinientes().get(2).getNombreCompleto()).isEqualTo("Test Name 3");
    }

    @Test void testSetAllIntervenersName_dontSetNameIntervenerCanceled() {

        Person person1 = Person.builder().type("F").code("000000001").name("Test Name 1").build();
        Person person2 = Person.builder().type("F").code("000000002").name("Test Name 2").build();
        Person person3 = Person.builder().type("F").code("000000003").name("Test Name 3").build();
        Person person4 = Person.builder().type("F").code("000000004").name("Test Name 4").build();
        final var iMap = Stream.of(person1, person2, person3, person4).collect(Collectors.toMap(
                person -> person.getType() + person.getCode(),
                Function.identity(),
                (existing, replacement) -> existing
        ));
        Mockito.when(this.personRepository.findAsMapByInterveners(ArgumentMatchers.any()))
                .thenReturn(iMap);

        List<Intervener> interveners = Arrays.asList(
                Intervener.builder().ordenInterv(BaseContract.ORDEN_INTERV_PRIMER_TITULAR)
                        .tipoInterv(TestContract.TEST_TIPO_INTERVINIENTE).idCliente("F000000001")
                        .build(),
                Intervener.builder().ordenInterv(BaseContract.ORDEN_INTERV_PRIMER_TITULAR)
                        .tipoInterv(TestContract.TEST_TIPO_INTERVINIENTE).idCliente("F000000002").fechaBaja(LocalDate.now().minusMonths(1))
                        .build(),
                Intervener.builder().ordenInterv(BaseContract.ORDEN_INTERV_PRIMER_TITULAR)
                        .tipoInterv(TestContract.TEST_TIPO_INTERVINIENTE).idCliente("F000000003")
                        .build()
        );

        TestConfiguration.mockSantanderChannel(WebUtils.SANTANDER_CHANNEL_EMP);

        final List<TestContract> contractList = Collections.singletonList(TestContract.builder().intervinientes(interveners).build());

        this.customersService.setIntervenersName(contractList,true);
        Assertions.assertThat(contractList.get(0).getIntervinientes().size()).isEqualTo(3);
        Assertions.assertThat(contractList.get(0).getIntervinientes().get(0).getNombreCompleto()).isEqualTo("Test Name 1");
        Assertions.assertThat(contractList.get(0).getIntervinientes().get(1).getNombreCompleto()).isNull();
        Assertions.assertThat(contractList.get(0).getIntervinientes().get(2).getNombreCompleto()).isEqualTo("Test Name 3");
    }

    @Test void testFillPersonsInfo() {

        final var person1 = Person.builder().type("F").code("000000001").name("Test Name 1").idType("N").idNumber("11111111").build();
        final var person2 = Person.builder().type("F").code("000000002").name("Test Name 2").idType("N").idNumber("22222222").build();
        final var person3 = Person.builder().type("F").code("000000003").name("Test Name 3").idType("N").idNumber("33333333").build();
        final var person4 = Person.builder().type("F").code("000000004").name("Test Name 4").idType("N").idNumber("44444444").build();
        final var iMap = Stream.of(person1, person2, person3, person4).collect(Collectors.toMap(
                person -> person.getType() + person.getCode(),
                Function.identity(),
                (existing, replacement) -> existing
        ));

        List<Intervener> interveners = List.of(
                Intervener.builder().ordenInterv(BaseContract.ORDEN_INTERV_PRIMER_TITULAR)
                        .tipoInterv(TestContract.TEST_TIPO_INTERVINIENTE).idCliente("F000000001")
                        .build(),
                Intervener.builder().ordenInterv(BaseContract.ORDEN_INTERV_PRIMER_TITULAR)
                        .tipoInterv(TestContract.TEST_TIPO_INTERVINIENTE).idCliente("F000000002").fechaBaja(LocalDate.now().minusMonths(1))
                        .build(),
                Intervener.builder().ordenInterv(BaseContract.ORDEN_INTERV_PRIMER_TITULAR)
                        .tipoInterv(TestContract.TEST_TIPO_INTERVINIENTE).idCliente("F000000003")
                        .build(),
                Intervener.builder().ordenInterv(BaseContract.ORDEN_INTERV_PRIMER_TITULAR)
                        .tipoInterv(TestContract.TEST_TIPO_INTERVINIENTE).idCliente("F000000005")
                        .build()
        );

        TestConfiguration.mockSantanderChannel(WebUtils.SANTANDER_CHANNEL_EMP);

        Mockito.when(this.personRepository.findAsMapByInterveners(ArgumentMatchers.any()))
                .thenReturn(iMap);

        final List<TestContract> contractList = Collections.singletonList(TestContract.builder()
                .intervinientes(interveners)
                .build());

        this.customersService.fillPersonsInfo(contractList);
        Assertions.assertThat(contractList.get(0).getIntervinientes().get(0).getNombreCompleto()).isEqualTo("Test Name 1");
        Assertions.assertThat(contractList.get(0).getIntervinientes().get(0).getTipoDocumento()).isEqualTo("N");
        Assertions.assertThat(contractList.get(0).getIntervinientes().get(0).getCodDocumento()).isEqualTo("11111111");

        Assertions.assertThat(contractList.get(0).getIntervinientes().get(1).getNombreCompleto()).isEqualTo("Test Name 2");
        Assertions.assertThat(contractList.get(0).getIntervinientes().get(1).getTipoDocumento()).isEqualTo("N");
        Assertions.assertThat(contractList.get(0).getIntervinientes().get(1).getCodDocumento()).isEqualTo("22222222");

        Assertions.assertThat(contractList.get(0).getIntervinientes().get(2).getNombreCompleto()).isEqualTo("Test Name 3");
        Assertions.assertThat(contractList.get(0).getIntervinientes().get(2).getTipoDocumento()).isEqualTo("N");
        Assertions.assertThat(contractList.get(0).getIntervinientes().get(2).getCodDocumento()).isEqualTo("33333333");

        Assertions.assertThat(contractList.get(0).getIntervinientes().get(3).getNombreCompleto()).isNull();
        Assertions.assertThat(contractList.get(0).getIntervinientes().get(3).getTipoDocumento()).isNull();
        Assertions.assertThat(contractList.get(0).getIntervinientes().get(3).getCodDocumento()).isNull();

    }

    @Test void testSetIntervenersDescription() {

        Mockito.when(this.intervenerRepository.findAllAsMap()).thenReturn(Map
                .of("01", IntervenerInfo.builder()
                                .tipoIntervencion("01")
                                .nombreIntervencion("TITULAR")
                                .build(),
                        "04", IntervenerInfo.builder()
                                .tipoIntervencion("04")
                                .nombreIntervencion("AUTORIZADO")
                                .build())
        );

        // Put 2 interveners, one with the same idCliente as person returned by repository.
        final List<TestContract> contractList = Collections.singletonList(TestContract.builder()
                .intervinientes(Arrays.asList(
                        Intervener.builder()
                                .ordenInterv(BaseContract.ORDEN_INTERV_PRIMER_TITULAR)
                                .tipoInterv(TestContract.TEST_TIPO_INTERVINIENTE)
                                .idCliente("F000000001")
                                .build(),
                        Intervener.builder()
                                .ordenInterv(BaseContract.ORDEN_INTERV_PRIMER_TITULAR)
                                .tipoInterv("04")
                                .idCliente("F000000002")
                                .build())
                )
                .build());

    	this.customersService.setIntervenersDescription(contractList);
    	Assertions.assertThat(contractList.get(0).getIntervinientes().get(0).getNombreIntervencion()).isEqualTo("TITULAR");
    	Assertions.assertThat(contractList.get(0).getIntervinientes().get(1).getNombreIntervencion()).isEqualTo("AUTORIZADO");
    }

    @Test void testSetIntervenersNameNullPrevent() {
        TestConfiguration.mockSantanderChannel(WebUtils.SANTANDER_CHANNEL_EMP);
        Mockito.when(this.personRepository.findByIntervenerList(ArgumentMatchers.any()))
                .thenReturn(Collections.singletonList(Person.builder()
                        .type("F")
                        .code("000000001")
                        .name("Test Name")
                        .build()));

        // Put 2 interveners, one with the same idCliente as person returned by repository.
        final List<TestContract> contractList = Collections.singletonList(TestContract.builder()
                .build());

        this.customersService.setIntervenersName(contractList);
        Assertions.assertThat(contractList.get(0).getIntervinientes()).isNullOrEmpty();
    }

    @Test void testFindOneByTypeSnfCodeAncCompary() {

        Mockito.when(this.personRepository.findOneByTypeAndCodeAndCompany(
                ArgumentMatchers.eq("J"),
                ArgumentMatchers.eq("000000583"),
                ArgumentMatchers.eq("0049"))
        ).thenReturn(
                Person.builder().type("J").code("000000583").name("Usuario Prueba").segment("CN").company("0049").build()
        );

        Person person = this.customersService.findOneByTypeAndCodeAndCompany("J", "000000583", "0049");
        assertNotNull(person);
        Assertions.assertThat(person.getName()).isEqualTo("Usuario Prueba");
        Assertions.assertThat(person.getSegment()).isEqualTo("CN");
        Assertions.assertThat(person.getCompany()).isEqualTo("0049");
    }
}
