package es.santander.adn360.products.common.domain.repository;

import com.mongodb.BasicDBList;
import es.santander.adn360.products.common.config.CommonMongoCollectionsProperties;
import es.santander.adn360.products.common.domain.ContractInfo;
import lombok.val;
import org.apache.commons.io.FileUtils;
import org.bson.BsonArray;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.actuate.observability.AutoConfigureObservability;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.mongodb.core.MongoOperations;

import java.nio.charset.Charset;
import java.util.Arrays;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;


@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureObservability
public class ContractInfoRepositoryTest {

    private final List<ContractInfo> emptyList = Arrays.asList();
    private final List<ContractInfo> noDataFound = Arrays.asList(
            ContractInfo.builder()
                    .empresa("1")
                    .producto("1")
                    .subproducto("1")
                    .build()
    );
    private final List<ContractInfo> contractList = Arrays.asList(
            ContractInfo.builder()
                    .empresa("0001")
                    .producto("823")
                    .subproducto("101")
                    .build(),
            ContractInfo.builder()
                    .empresa("0011")
                    .producto("630")
                    .subproducto("003")
                    .build()
    );

    @Autowired
    private MongoOperations mongoOperations;

    @Autowired
    private ContractInfoRepository contractInfoRepository;

    @Autowired
    private CommonMongoCollectionsProperties commonMongoCollectionsProperties;

    @BeforeEach
    public void setUp() throws Exception {
        String doc = FileUtils.readFileToString(new ClassPathResource("json/adn360.empresaSubprod.json").getFile(),
                Charset.defaultCharset());
        final BsonArray parse = BsonArray.parse(doc);
        BasicDBList dbList = new BasicDBList();
        dbList.addAll(parse);
        dbList.forEach(dbo -> mongoOperations.save(dbo, this.commonMongoCollectionsProperties.getEmpresaSubprod()));
    }

    @Test
    public void shouldThrowsAssertException() throws Exception {
    	 assertThrows(Exception.class, () ->  this.contractInfoRepository.findContractInfo(emptyList));
    }

    @Test
    public void shouldReturnEmptyList() throws Exception {
        assertThat(contractInfoRepository.findContractInfo(noDataFound)).isEmpty();
    }

    @Test
    public void shouldReturnContractInfoList() throws Exception {
        val contractInfoList = contractInfoRepository.findContractInfo(contractList);

        assertThat(contractInfoList.size()).isEqualTo(2);

        assertThat(contractInfoList.get(0)).isEqualTo(ContractInfo.builder()
                .id("5a5f56b99ccd7360d24f71e3")
                .empresa("0001")
                .producto("823")
                .subproducto("101")
                .descripcion("SANTANDER CHINA, FI    ")
                .indicadorProducto("3")
                .build());

        assertThat(contractInfoList.get(1)).isEqualTo(ContractInfo.builder()
                .id("5a5f56b99ccd7360d24f71e4")
                .empresa("0011")
                .producto("630")
                .subproducto("003")
                .descripcion("DISTRIB.FONDOS INVERS. ")
                .indicadorProducto("6")
                .build());
    }
}
