package es.santander.adn360.products.common.util;

import es.santander.adn360.products.common.domain.entity.MockContract;
import es.santander.adn360.products.common.domain.entity.RiskSituation;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class AggregationUtilsTest {

    @Test
    void testMaxRriskSituation() {
        List<MockContract> contracts = Arrays.asList(
                // Null GSI
                MockContract.builder().situacionGSI(null).build(),
                // Void GSI
                MockContract.builder().situacionGSI(RiskSituation.builder().build()).build(),
                // 0 NR GSI
                MockContract.builder().situacionGSI(RiskSituation.builder().situacion("NR").id(0).build()).build(),
                // 1 i30 GSI
                MockContract.builder().situacionGSI(RiskSituation.builder().situacion("i30").id(1).build()).build()
        );

        RiskSituation maxRiskSituation = AggregationUtils.getMaxRiskSituation(contracts);

        assertThat(maxRiskSituation.getId()).isEqualTo(1);
        assertThat(maxRiskSituation.getSituacion()).isEqualTo("i30");
    }

}
