package es.santander.adn360.products.common.switchhost;

import es.santander.adn360.products.common.switchhost.annotation.Adn360SwitchHost;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CircuitBreakerTestService {

    @Autowired
    CircuitBrakerTestRepository circuitBrakerTestRepository;

    @Adn360SwitchHost(fallback = "fallback1")
    public String testMethod(String input, List<String> input2, String input3){
        // Invokation only for mock exceptions purpose
        circuitBrakerTestRepository.testMethodOK();

        return "method OK";
    }


    private String fallback1(String input, List<String> input2, String input3){
        // Invokation only for mock exceptions purpose
        circuitBrakerTestRepository.testMethodFallback1();

        return "fallback HOST";
    }

}
