package es.santander.adn360.products.common.multichannel;

import java.time.LocalDate;
import java.util.List;

import es.santander.adn360.products.common.domain.entity.BaseContract;
import es.santander.adn360.products.common.domain.entity.CompaniesUsers;
import es.santander.adn360.products.common.domain.entity.Intervener;
import es.santander.adn360.products.common.domain.entity.RelatedProposal;
import es.santander.adn360.products.common.domain.entity.RiskSituation;
import es.santander.adn360.products.common.domain.entity.UserInformation;
import org.springframework.data.annotation.PersistenceConstructor;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Builder
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@AllArgsConstructor
@JsonPropertyOrder(value = {"contractNumber"}, alphabetic = true)
public class MultiChannelTestModel extends BaseContract {

    protected String dataExample;

    @Builder
    @PersistenceConstructor
    public MultiChannelTestModel(
            String id,
            String idContrato,
            String contratoCartera,
            String cuentaLocal,
            String empresa,
            String centro,
            String producto,
            String contrato,
            String productoNuevo,
            String subproducto,
            String contratoNuevo,
            String descripcion,
            String descripcionLarga,
            String divisa,
            RiskSituation situacionGSI,
            List<Intervener> intervinientes,
            List<UserInformation> informacionUsuarios,
            String estado,
            LocalDate fechaSituacionOperativa,
            LocalDate fechaAltaContrato,
            LocalDate fechaBajaContrato,
            String dataExample,
            List<CompaniesUsers> usuariosEmpresas,
            List<RelatedProposal> propuestasRelacionadas,
            String relatedProposalId
    ) {
        super(
                id,
                idContrato,
                contratoCartera,
                cuentaLocal,
                empresa,
                centro,
                producto,
                contrato,
                productoNuevo,
                subproducto,
                contratoNuevo,
                descripcion,
                descripcionLarga,
                divisa,
                situacionGSI,
                intervinientes,
                informacionUsuarios,
                estado,
                fechaSituacionOperativa,
                fechaAltaContrato,
                fechaBajaContrato,
                usuariosEmpresas,
                propuestasRelacionadas,
                relatedProposalId
        );

        this.dataExample = dataExample;
    }

    @Override
    public List<String> getTipoIntervinientesTitular() {
        return null;
    }
}
