package es.santander.adn360.products.common.domain.entity;


import es.santander.adn360.products.common.domain.PortfolioBaseContract;
import es.santander.adn360.products.common.domain.PortfolioContract;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class PortfolioBaseContractTest {


    @Test void hasConstat_ok() {
        var pbc = new PortfolioBaseContract();

        assertThat(pbc.hasContratosCarteras()).isFalse();
        assertThat(pbc.nonContratosCarteras()).isTrue();

        var cc = new PortfolioContract();

        cc.setFechaVencimiento("9999-12-31");

        pbc.setContratosCarteras(List.of(cc));

        assertThat(pbc.hasContratosCarteras()).isTrue();
        assertThat(pbc.nonContratosCarteras()).isFalse();
    }

}
