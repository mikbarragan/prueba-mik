package es.santander.adn360.products.common.service;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;

import es.santander.adn360.products.common.domain.entity.BaseContract;
import es.santander.adn360.products.common.domain.entity.CompaniesUsers;
import es.santander.adn360.products.common.domain.entity.Intervener;
import es.santander.adn360.products.common.domain.entity.RelatedProposal;
import es.santander.adn360.products.common.domain.entity.RiskSituation;
import es.santander.adn360.products.common.domain.entity.UserInformation;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * Contract for testing purposes.
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Document(collection = "test")
public class TestContract extends BaseContract {

    public static final String TEST_TIPO_INTERVINIENTE = "01";

    private String zDummy;
    private String dummy;

    @Builder
    public TestContract (String id, String idContrato, String contratoCartera, String cuentaLocal, String empresa,
                         String centro, String producto, String contrato, String productoNuevo, String subproducto,
                         String contratoNuevo, String descripcion, String descripcionLarga, String divisa,
                         RiskSituation situacionGSI, List<Intervener> intervinientes, List<UserInformation> informacionUsuarios
                        , String estado, String dummy, LocalDate fechaSituacionOperativa, LocalDate fechaAltaContrato,
                         LocalDate fechaBajaContrato, List<CompaniesUsers> usuariosEmpresas,
                         List<RelatedProposal> propuestasRelacionadas, String relatedProposalId) {


           super(id, idContrato, contratoCartera, cuentaLocal, empresa,
                centro, producto, contrato, productoNuevo, subproducto,
                contratoNuevo, descripcion, descripcionLarga, divisa,
                situacionGSI,intervinientes, informacionUsuarios, estado, fechaSituacionOperativa, fechaAltaContrato,
                   fechaBajaContrato, usuariosEmpresas, propuestasRelacionadas, relatedProposalId);


        this.zDummy = estado;
        this.dummy = dummy;
    }

    @Override
    public List<String> getTipoIntervinientesTitular() {
        return Collections.singletonList(TEST_TIPO_INTERVINIENTE);
    }
}
