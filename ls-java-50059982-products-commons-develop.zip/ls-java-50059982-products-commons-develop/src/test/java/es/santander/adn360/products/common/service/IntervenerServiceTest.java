package es.santander.adn360.products.common.service;

import de.flapdoodle.embed.mongo.spring.autoconfigure.EmbeddedMongoAutoConfiguration;
import es.santander.adn360.core.model.exception.FunctionalException;
import es.santander.adn360.core.util.CustomerProductQueryParams;
import es.santander.adn360.core.web.CoreSecurityContextImpl;
import es.santander.adn360.mongodb.starter.autoconfigure.MongoQueryRepositoryAutoConfiguration;
import es.santander.adn360.products.common.domain.DescriptionFormInterveners;
import es.santander.adn360.products.common.domain.IntervenerInfo;
import es.santander.adn360.products.common.domain.entity.BaseContract;
import es.santander.adn360.products.common.domain.entity.Intervener;
import es.santander.adn360.products.common.domain.repository.DescriptionFormIntervenersRepository;
import es.santander.adn360.products.common.domain.repository.IntervenerInfoRepository;
import es.santander.adn360.test.autoconfigure.Adn360EmbeddedMongoConfiguration;
import es.santander.adn360.test.autoconfigure.DataFromEmbeddedMongo;
import es.santander.adn360.test.autoconfigure.DownloadMongodb;
import es.santander.adn360.test.autoconfigure.PathUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.autoconfigure.actuate.observability.AutoConfigureObservability;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.core.context.SecurityContextHolder;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

@EnableAutoConfiguration(exclude = {
        Adn360EmbeddedMongoConfiguration.class,
        DownloadMongodb.class,
        DataFromEmbeddedMongo.class,
        PathUtils.class,
        EmbeddedMongoAutoConfiguration.class,
        MongoQueryRepositoryAutoConfiguration.class})
@SpringBootTest()
@AutoConfigureObservability
class IntervenerServiceTest {

    private static String TYPE_TITULAR = "01";
    private static String FORM_TITULAR = "01";
    private static String NAME_TITULAR = "TITULAR";
    private static String TITLE_TITULAR = "Titular";

    private static String TYPE_AUTORIZADO = "04";
    private static String FORM_AUTORIZADO = "04";

    private static String TYPE_APODERADO = "23";
    private static String TITLE_APODERADO = "Apoderado";

    private static String TYPE_AVALISTA = "08";
    private static String TITLE_AVALISTA = "Avalista";

    private static String ALL_FILTER = "ALL";
    private static String OWN_FILTER = "OWN";
    private static String DEFAULT_APPLICATION = "ADN360";

    private final CoreSecurityContextImpl coreSecurityContext = Mockito.mock(CoreSecurityContextImpl.class);

    @Autowired
    private IntervenerServiceImpl intervenerService;

    @MockBean
    private IntervenerInfoRepository intervenerRepository;

    @MockBean
    private DescriptionFormIntervenersRepository descriptionFormIntervenersRepository;

    @BeforeEach
    public void setUp() {

        Mockito.when(intervenerRepository.findAllAsMap()).thenReturn(Map.of(
                TYPE_TITULAR, IntervenerInfo.builder().tipoIntervencion(TYPE_TITULAR).nombreIntervencion("TITULAR").build(),
                "04", IntervenerInfo.builder().tipoIntervencion("04").nombreIntervencion("AUTORIZADO").build()
        ));

        Mockito.when(this.descriptionFormIntervenersRepository.findAllAsMap()).thenReturn(Map.of(
                FORM_TITULAR, DescriptionFormInterveners.builder().formaIntervencion(FORM_TITULAR).descripcion("descripcion titular").build(),
                FORM_AUTORIZADO, DescriptionFormInterveners.builder().formaIntervencion(FORM_AUTORIZADO).descripcion("descripcion autorizado").build()
        ));

        Mockito.when(this.coreSecurityContext.getSantanderChannel()).thenReturn("OFI");
        SecurityContextHolder.setContext(this.coreSecurityContext);
    }

    @Test
    void testGetIntervenerInformation() {
        IntervenerInfo intervInfo = intervenerService.getIntervenerInformation(TYPE_TITULAR);
        assertThat(intervInfo).isNotNull();
        assertThat(NAME_TITULAR).isEqualToIgnoringCase(intervInfo.getNombreIntervencion().trim());
        assertThat(TYPE_TITULAR).isEqualToIgnoringCase(intervInfo.getTipoIntervencion());
    }

    @Test
    void testFindIntervenerInfoByContracts() {
        final List<TestContract> contractList = Collections.singletonList(TestContract.builder()
                .intervinientes(Arrays.asList(
                        Intervener.builder().ordenInterv(BaseContract.ORDEN_INTERV_PRIMER_TITULAR)
                                .tipoInterv(TestContract.TEST_TIPO_INTERVINIENTE).idCliente("F000000001").build(),
                        Intervener.builder().ordenInterv(BaseContract.ORDEN_INTERV_PRIMER_TITULAR).tipoInterv(TYPE_AUTORIZADO)
                                .idCliente("F000000002").build()))
                .build());

        List<IntervenerInfo> intervInfo = intervenerService.findIntervenerInfoByContracts(contractList);
        assertThat(intervInfo).isNotNull();
        assertThat(intervInfo.get(0).getNombreIntervencion().trim()).isEqualTo(NAME_TITULAR);
        assertThat(intervInfo.get(1).getNombreIntervencion().trim()).isEqualTo("AUTORIZADO");
    }

    @Test
    void testFindIntervenerInfoByInterveners() {
        final List<Intervener> intervenerList = Arrays.asList(
                Intervener.builder().ordenInterv(BaseContract.ORDEN_INTERV_PRIMER_TITULAR)
                        .tipoInterv(TestContract.TEST_TIPO_INTERVINIENTE).idCliente("F000000001").build(),
                Intervener.builder().ordenInterv(BaseContract.ORDEN_INTERV_PRIMER_TITULAR).tipoInterv(TYPE_AUTORIZADO)
                        .idCliente("F000000002").build());

        List<IntervenerInfo> intervInfo = intervenerService.findIntervenerInfoByInterveners(intervenerList);
        assertThat(intervInfo).isNotNull();
        assertThat(intervInfo.get(0).getNombreIntervencion().trim()).isEqualTo(NAME_TITULAR);
        assertThat(intervInfo.get(1).getNombreIntervencion().trim()).isEqualTo("AUTORIZADO");
    }

    @Test
    void testFindIntervenerInfoByIntervenersNoduplicates() {
        final List<Intervener> intervenerList = Arrays.asList(
                Intervener.builder().ordenInterv(BaseContract.ORDEN_INTERV_PRIMER_TITULAR)
                        .tipoInterv(TestContract.TEST_TIPO_INTERVINIENTE).idCliente("F000000001").build(),
                Intervener.builder().ordenInterv(2)
                        .tipoInterv(TestContract.TEST_TIPO_INTERVINIENTE).idCliente("F000000002").build(),
                Intervener.builder().ordenInterv(3)
                        .tipoInterv(TestContract.TEST_TIPO_INTERVINIENTE).idCliente("F000000003").build());

        List<IntervenerInfo> intervInfo = intervenerService.findIntervenerInfoByInterveners(intervenerList);
        assertThat(intervInfo).isNotNull();
        assertThat(intervInfo.size()).isEqualTo(1);
    }

    @Test
    void testfillAndFilterIntervenerParticipantField() {

        Mockito.when(this.coreSecurityContext.getSantanderChannel()).thenReturn("OFI");
        CustomerProductQueryParams params = CustomerProductQueryParams.getBuilder().participant_type(OWN_FILTER).build();

        Intervener inter1 = Intervener.builder().fechaBaja(null).ordenInterv(1).tipoInterv("01").participant(null).idCliente("inter1").build();
        Intervener inter2 = Intervener.builder().fechaBaja(null).ordenInterv(13).tipoInterv("01").participant(null).idCliente("inter2").build();
        Intervener inter3 = Intervener.builder().fechaBaja(LocalDate.of(2018, 01, 01)).ordenInterv(3).tipoInterv("01").participant(null).idCliente("inter3").build(); //inactivo
        List<Intervener> interveners = Arrays.asList(inter1, inter2, inter3, null);

        List<Intervener> resultA = intervenerService.fillAndFilterIntervenerParticipantField(interveners, false,
                params.getParticipant_type(), DEFAULT_APPLICATION);
        assertThat(resultA.get(0).getParticipant().trim()).isEqualTo("1 Titular");
        assertThat(resultA.get(0).getIdCliente().trim()).isEqualTo("inter1");
        assertThat(resultA.get(1).getParticipant().trim()).isEqualTo("13 Titular");
        assertThat(resultA.get(1).getIdCliente().trim()).isEqualTo("inter2");
    }

    /**
     * If participant type is null then is applied "own" default filter
     */
    @Test
    void testfillAndFilterIntervenerParticipantFieldWithInterventionNull() {

        Mockito.when(this.coreSecurityContext.getSantanderChannel()).thenReturn("OFI");
        CustomerProductQueryParams params = CustomerProductQueryParams.getBuilder().participant_type(null).build();

        Intervener interB1 = Intervener.builder().fechaBaja(null).ordenInterv(1).tipoInterv("01").participant(null).idCliente("inter1").build();
        Intervener interB2 = Intervener.builder().fechaBaja(null).ordenInterv(13).tipoInterv("01").participant(null).idCliente("inter2").build();
        List<Intervener> intervenersB = Arrays.asList(interB1, interB2, null);

        List<Intervener> resultB = intervenerService.fillAndFilterIntervenerParticipantField(intervenersB, false,
                params.getParticipant_type(), DEFAULT_APPLICATION);
        assertThat(resultB.get(0).getParticipant().trim()).isEqualTo("1 Titular");
        assertThat(resultB.get(1).getParticipant().trim()).isEqualTo("13 Titular");
    }

    /**
     * If participant type is null then is applied "own" default filter
     */
    @Test
    void testfillAndFilterIntervenerParticipantAndFormFieldsWithInterventionNull() {

        Mockito.when(this.descriptionFormIntervenersRepository.findAllAsMap())
                .thenReturn(Map.of("33",
                        DescriptionFormInterveners.builder().formaIntervencion("33")
                                .descripcion("descripcion 33").build()));

        Mockito.when(this.coreSecurityContext.getSantanderChannel()).thenReturn("OFI");
        CustomerProductQueryParams params = CustomerProductQueryParams.getBuilder().participant_type(null).build();

        Intervener interB1 = Intervener.builder().fechaBaja(null).ordenInterv(1).tipoInterv("01").participant(null).idCliente("inter1").formaInterv("33").build();
        Intervener interB2 = Intervener.builder().fechaBaja(null).ordenInterv(13).tipoInterv("01").participant(null).idCliente("inter2").formaInterv("33").build();
        List<Intervener> intervenersB = Arrays.asList(interB1, interB2, null);

        List<Intervener> resultB = intervenerService.fillAndFilterIntervenerParticipantAndFormFields(intervenersB, false,
                params.getParticipant_type(), DEFAULT_APPLICATION);
        assertThat(resultB.get(0).getParticipant().trim()).isEqualTo("1 Titular");
        assertThat(resultB.get(0).getDescripcionFormaIntervencion()).isEqualTo("descripcion 33");
        assertThat(resultB.get(1).getParticipant().trim()).isEqualTo("13 Titular");
        assertThat(resultB.get(1).getDescripcionFormaIntervencion()).isEqualTo("descripcion 33");
    }

    @Test
    void testfillAndFilterIntervenerParticipantFieldWithInterventionTotal() {
        CustomerProductQueryParams params = CustomerProductQueryParams.getBuilder().participant_type(ALL_FILTER).build();
        Intervener interB1 = Intervener.builder().fechaBaja(null).ordenInterv(1).tipoInterv("08").participant(null).build();
        Intervener interB2 = Intervener.builder().fechaBaja(null).ordenInterv(13).tipoInterv("08").participant(null).build();
        List<Intervener> intervenersC = Arrays.asList(interB1, interB2, null);
        List<Intervener> resultC = intervenerService.fillAndFilterIntervenerParticipantField(intervenersC, false,
                params.getParticipant_type(),DEFAULT_APPLICATION);
        assertThat(resultC.get(0).getParticipant().trim()).isEqualTo("1 Avalista");
        assertThat(resultC.get(1).getParticipant().trim()).isEqualTo("13 Avalista");
    }

    /**
     * If participant type is null then is applied "own" default filter
     */
    @Test
    void testfillAndFilterIntervenerParticipantFieldWithMultipleIntervener() {

        CustomerProductQueryParams params = CustomerProductQueryParams.getBuilder().participant_type(null).build();

        Intervener interB1 = Intervener.builder().fechaBaja(null).ordenInterv(1).tipoInterv("01").idCliente("inter1").build();
        Intervener interB2 = Intervener.builder().fechaBaja(null).ordenInterv(13).tipoInterv("02").idCliente("inter2").build();
        List<Intervener> intervenersB = Arrays.asList(interB1, interB2, null);

        List<Intervener> resultB = intervenerService.fillAndFilterIntervenerParticipantField(intervenersB, false,
                params.getParticipant_type(),DEFAULT_APPLICATION);
        assertThat(resultB.get(0).getParticipant().trim()).isEqualTo("1 Titular");
        assertThat(resultB.get(1).getParticipant()).isNullOrEmpty();
    }

    /**
     * If participant type is null then is applied "own" default filter
     */
    @Test
    void testfillAndFilterIntervenerParticipantAndFormFieldsWithMultipleIntervener() {

        Mockito.when(this.descriptionFormIntervenersRepository.findAllAsMap())
                .thenReturn(Map.of("95",
                        DescriptionFormInterveners.builder().formaIntervencion("95")
                                .descripcion("descripcion 95").build(),
                        "96",
                        DescriptionFormInterveners.builder().formaIntervencion("96")
                                .descripcion("descripcion 96").build()));

        CustomerProductQueryParams params = CustomerProductQueryParams.getBuilder().participant_type(null).build();

        Intervener interB1 = Intervener.builder().fechaBaja(null).ordenInterv(1).tipoInterv("01").idCliente("inter1").formaInterv("95").build();
        Intervener interB2 = Intervener.builder().fechaBaja(null).ordenInterv(13).tipoInterv("02").idCliente("inter2").formaInterv("96").build();
        List<Intervener> intervenersB = Arrays.asList(interB1, interB2, null);

        List<Intervener> resultB = intervenerService.fillAndFilterIntervenerParticipantAndFormFields(intervenersB, false,
                params.getParticipant_type(),DEFAULT_APPLICATION);
        assertThat(resultB.get(0).getParticipant().trim()).isEqualTo("1 Titular");
        assertThat(resultB.get(1).getParticipant()).isNullOrEmpty();
        assertThat(resultB.get(0).getDescripcionFormaIntervencion()).isEqualTo("descripcion 95");
        assertThat(resultB.get(1).getDescripcionFormaIntervencion()).isEqualTo("descripcion 96");
    }

    /**
     * If allParticipant is true then method should return all participant ( active and not active)
     */
    @Test
    void testfillAndFilterIntervenerParticipantFieldWithAllInterveners() {

        CustomerProductQueryParams params = CustomerProductQueryParams.getBuilder().participant_type(null).build();

        Intervener inter1 = Intervener.builder().fechaBaja(null).ordenInterv(1).tipoInterv("01").idCliente("inter1").build();
        Intervener inter2 = Intervener.builder().fechaBaja(null).ordenInterv(13).tipoInterv("01").idCliente("inter2").build();
        Intervener inter3 = Intervener.builder().fechaBaja(LocalDate.of(2018, 01, 01)).ordenInterv(13).tipoInterv("01").idCliente("inter3").build();


        List<Intervener> intervenersB = Arrays.asList(inter1, inter2, inter3);

        List<Intervener> result = intervenerService.fillAndFilterIntervenerParticipantField(intervenersB, true,
                params.getParticipant_type(),null);
        assertThat(result.size()).isEqualTo(3);
        assertThat(result.get(0).getParticipant().trim()).isEqualTo("1 Titular");
        assertThat(result.get(1).getParticipant().trim()).isEqualTo("13 Titular");
        assertThat(result.get(2).getParticipant().trim()).isEqualTo("13 Titular");
    }

    /**
     * If participant type is null then is applied "own" default filter
     */
    @Test
    void testfillAndFilterIntervenerParticipantFieldWithMultipleIntervenerSorted() {

        CustomerProductQueryParams params = CustomerProductQueryParams.getBuilder().participant_type(null).build();

        Intervener interB1 = Intervener.builder().fechaBaja(null).ordenInterv(1).tipoInterv("01").idCliente("inter1").build();
        Intervener interB2 = Intervener.builder().fechaBaja(null).ordenInterv(13).tipoInterv("05").idCliente("inter2").build();
        Intervener interB3 = Intervener.builder().fechaBaja(null).ordenInterv(13).tipoInterv("02").idCliente("inter2").build();

        List<Intervener> intervenersB = Arrays.asList(interB1, interB2, interB3);

        List<Intervener> resultB = intervenerService.fillAndFilterIntervenerParticipantField(intervenersB, false, "","");
        assertThat(resultB.get(0).getTipoInterv()).isEqualTo("01");
        assertThat(resultB.get(1).getTipoInterv()).isEqualTo("02");
        assertThat(resultB.get(2).getTipoInterv()).isEqualTo("05");
    }

    @Test
    void fillAndSortFilterIntervenerParticipantField() {
        CustomerProductQueryParams params = CustomerProductQueryParams.getBuilder().participant_type("OWN").build();

        Intervener inter1 = Intervener.builder().fechaBaja(null).ordenInterv(1).tipoInterv("01").participant(null).idCliente("inter1").build();
        Intervener inter2 = Intervener.builder().fechaBaja(null).ordenInterv(13).tipoInterv("01").participant(null).idCliente("inter2").build();
        Intervener inter3 = Intervener.builder().fechaBaja(LocalDate.of(2018, 01, 01)).ordenInterv(3).tipoInterv("01").participant(null).idCliente("inter3").build(); //inactivo
        Intervener inter4 = Intervener.builder().fechaBaja(null).ordenInterv(5).tipoInterv("01").participant(null).idCliente("inter4").build();
        List<Intervener> interveners = Arrays.asList(inter1, inter2, inter3, inter4, null);

        List<Intervener> resultA = intervenerService.fillAndSortFilterIntervenerParticipantField(interveners);
        assertThat(resultA.get(0).getIdCliente().trim()).isEqualTo("inter1");
        assertThat(resultA.get(0).getParticipant().trim()).isEqualTo("1 Titular");
        assertThat(resultA.get(1).getIdCliente().trim()).isEqualTo("inter2");
        assertThat(resultA.get(1).getParticipant().trim()).isEqualTo("3 Titular");
        assertThat(resultA.get(2).getIdCliente().trim()).isEqualTo("inter4");
        assertThat(resultA.get(2).getParticipant().trim()).isEqualTo("2 Titular");
    }

    @Test
    void testFindInterventionCodes_with_EMP_NWE_OWN_Filter() {
        //Mock EMP
        Mockito.when(this.coreSecurityContext.getSantanderChannel()).thenReturn("EMP");
        Map<String, String> intervInfo = intervenerService.findInterventionCodes(OWN_FILTER, "NWE");
        assertThat(intervInfo).isNotNull();
        assertThat(intervInfo.keySet().size()).isEqualTo(1);
        assertThat(intervInfo.get(TYPE_TITULAR)).isEqualToIgnoringCase(TITLE_TITULAR);
    }

    @Test
    void testFindInterventionCodes_with_EMP_NWE_ALL_Filter() {
        //Mock EMP
        Mockito.when(this.coreSecurityContext.getSantanderChannel()).thenReturn("EMP");
        Map<String, String> intervInfo = intervenerService.findInterventionCodes(ALL_FILTER, "NWE");
        assertThat(intervInfo).isNotNull();
        assertThat(intervInfo.keySet().size()).isEqualTo(3);
        assertThat(intervInfo.get(TYPE_TITULAR)).isEqualToIgnoringCase(TITLE_TITULAR);
        assertThat(intervInfo.get(TYPE_AVALISTA)).isEqualToIgnoringCase(TITLE_AVALISTA);
        assertThat(intervInfo.get(TYPE_APODERADO)).isEqualToIgnoringCase(TITLE_APODERADO);
    }

    @Test
    void testFindInterventionCodes_with_not_valid_Application_OWNFilter_ShouldReturnDefaultCfg() {
        //Mock EMP
        Mockito.when(this.coreSecurityContext.getSantanderChannel()).thenReturn("EMP");
        Map<String, String> intervInfo = intervenerService.findInterventionCodes(OWN_FILTER,null);
        assertThat(intervInfo).isNotNull();
        assertThat(intervInfo.keySet().size()).isEqualTo(1);
        assertThat(intervInfo.get(TYPE_TITULAR)).isEqualToIgnoringCase(TITLE_TITULAR);
    }

    @Test
    void testFindInterventionCodes_with_NullApplication_ALLFilter_ShouldReturnDefaultCfg() {
        //Mock EMP
        Mockito.when(this.coreSecurityContext.getSantanderChannel()).thenReturn("EMP");
        Map<String, String> intervInfo = intervenerService.findInterventionCodes(ALL_FILTER,null);
        assertThat(intervInfo).isNotNull();
        assertThat(intervInfo.keySet().size()).isEqualTo(3);
        assertThat(intervInfo.get(TYPE_TITULAR)).isEqualToIgnoringCase(TITLE_TITULAR);
        assertThat(intervInfo.get(TYPE_AVALISTA)).isEqualToIgnoringCase(TITLE_AVALISTA);
        assertThat(intervInfo.get(TYPE_APODERADO)).isEqualToIgnoringCase(TITLE_APODERADO);
    }

    @Test
    void testFindInterventionCodes_with_NullFilter_NullApplication_ShouldReturnDefaultsValues() {
        //Mock EMP
        Mockito.when(this.coreSecurityContext.getSantanderChannel()).thenReturn("EMP");
        Map<String, String> intervInfo = intervenerService.findInterventionCodes(null,null);
        assertThat(intervInfo.keySet().size()).isEqualTo(1);
        assertThat(intervInfo.get(TYPE_TITULAR)).isEqualToIgnoringCase(TITLE_TITULAR);
    }

    @Test
    void testFindInterventionCodes_with_ATM_NOAPP_OWN_Filter_DefaultConfig() {
        //Mock ATM
        Mockito.when(this.coreSecurityContext.getSantanderChannel()).thenReturn("ATM");
        Map<String, String> intervInfo = intervenerService.findInterventionCodes(OWN_FILTER, null);
        assertThat(intervInfo).isNotNull();
        assertThat(intervInfo.keySet().size()).isEqualTo(1);
        assertThat(intervInfo.get(TYPE_TITULAR)).isEqualToIgnoringCase(TITLE_TITULAR);
    }

    @Test
    void testFindInterventionCodes_with_NOCHANNEL_NOAPP_OWN_Filter_DefaultConfig() {
        //Mock null
        Mockito.when(this.coreSecurityContext.getSantanderChannel()).thenReturn(null);
        Map<String, String> intervInfo = intervenerService.findInterventionCodes(OWN_FILTER, null);
        assertThat(intervInfo).isNotNull();
        assertThat(intervInfo.keySet().size()).isEqualTo(1);
        assertThat(intervInfo.get(TYPE_TITULAR)).isEqualToIgnoringCase(TITLE_TITULAR);

        intervInfo = intervenerService.findInterventionCodes(ALL_FILTER, null);
        assertThat(intervInfo).isNotNull();
        assertThat(intervInfo.keySet().size()).isEqualTo(1);
        assertThat(intervInfo.get(TYPE_TITULAR)).isEqualToIgnoringCase(TITLE_TITULAR);
    }

    @Test
    void testFindInterventionCodes_with_INT_LISBOA_ALL_Filter_Exception() {
        Mockito.when(this.coreSecurityContext.getSantanderChannel()).thenReturn("INT");
        assertThrows(FunctionalException.class, () ->  intervenerService.findInterventionCodes(ALL_FILTER, "LISBOA"));
    }

    @Test
    void testFindInterventionCodes_with_INT_GLOBAL_ALL_Filter_Only_ALL() {
        Mockito.when(this.coreSecurityContext.getSantanderChannel()).thenReturn("INT");
        Map<String, String> intervInfo = intervenerService.findInterventionCodes(ALL_FILTER, "GLOBAL");
        assertThat(intervInfo).isNotNull();
        assertThat(intervInfo.keySet().size()).isEqualTo(1);
        assertThat(intervInfo.get(TYPE_APODERADO)).isEqualToIgnoringCase(TITLE_APODERADO);
    }

    @Test
    void testFindInterventionCodes_with_EMP() {
        Mockito.when(this.coreSecurityContext.getSantanderChannel()).thenReturn("EMP");
        Map<String, String> intervInfo = intervenerService.findInterventionCodes();
        assertThat(intervInfo).isNotNull();
    }

    @Test
    void testFindInterventionCodes_with_EMP_OWN() {
        Mockito.when(this.coreSecurityContext.getSantanderChannel()).thenReturn("EMP");
        Map<String, String> intervInfo = intervenerService.findInterventionCodes(OWN_FILTER);
        assertThat(intervInfo).isNotNull();
    }

    @Test
    void testGetDescriptionForm() {
        DescriptionFormInterveners description = intervenerService.getDescriptionForm(FORM_AUTORIZADO);
        assertThat(description).isNotNull();
        assertThat(description.getFormaIntervencion()).isEqualTo(FORM_AUTORIZADO);
        assertThat(description.getDescripcion()).isEqualToIgnoringCase("descripcion autorizado");
        description = intervenerService.getDescriptionForm(FORM_TITULAR);
        assertThat(description).isNotNull();
        assertThat(description.getFormaIntervencion()).isEqualTo(FORM_TITULAR);
        assertThat(description.getDescripcion()).isEqualToIgnoringCase("descripcion titular");
    }


    @Test
    void testGetDescriptionFormEmptyList() {
        final List<Intervener> intervenerList = Arrays.asList(
                Intervener.builder().ordenInterv(BaseContract.ORDEN_INTERV_PRIMER_TITULAR)
                        .tipoInterv(TestContract.TEST_TIPO_INTERVINIENTE).idCliente("F000000001").build(),
                Intervener.builder().ordenInterv(BaseContract.ORDEN_INTERV_PRIMER_TITULAR).tipoInterv(TYPE_AUTORIZADO)
                        .idCliente("F000000002").build());
        List<DescriptionFormInterveners> description = intervenerService.findDescriptionFormByInterveners(intervenerList);
        assertThat(description).isNotNull();
        assertThat(description.get(0)).isNull();
    }

    @Test
    void testGetDescriptionFormList() {
        final List<Intervener> intervenerList = Arrays.asList(
                Intervener.builder().ordenInterv(BaseContract.ORDEN_INTERV_PRIMER_TITULAR)
                        .formaInterv(FORM_TITULAR)
                        .tipoInterv(TestContract.TEST_TIPO_INTERVINIENTE).idCliente("F000000001").build(),
                Intervener.builder().ordenInterv(BaseContract.ORDEN_INTERV_PRIMER_TITULAR).tipoInterv(TYPE_AUTORIZADO)
                        .idCliente("F000000002").build());
        List<DescriptionFormInterveners> description = intervenerService.findDescriptionFormByInterveners(intervenerList);
        assertThat(description).isNotNull();
        assertThat(description.get(0).getFormaIntervencion()).isEqualToIgnoringCase(FORM_TITULAR);
        assertThat(description.get(0).getDescripcion()).isEqualToIgnoringCase("descripcion titular");
    }

    @Test
    void testGetDescriptionFormContractList() {
        final List<TestContract> contractList = Collections.singletonList(TestContract.builder()
                .intervinientes(Arrays.asList(
                        Intervener.builder().ordenInterv(BaseContract.ORDEN_INTERV_PRIMER_TITULAR)
                                .formaInterv(FORM_TITULAR)
                                .tipoInterv(TestContract.TEST_TIPO_INTERVINIENTE).idCliente("F000000001").build(),
                        Intervener.builder().ordenInterv(BaseContract.ORDEN_INTERV_PRIMER_TITULAR).tipoInterv(TYPE_AUTORIZADO)
                                .idCliente("F000000002").build()))
                .build());
        List<DescriptionFormInterveners> descriptions = intervenerService.findDescriptionFormByContracts(contractList);
        assertThat(descriptions).isNotNull();
        assertThat(descriptions.get(0).getDescripcion().trim()).isEqualToIgnoringCase("descripcion titular");
    }

}
