package es.santander.adn360.products.common.switchhost;

import org.springframework.stereotype.Repository;

@Repository
public class CircuitBrakerTestRepository {

    public String testMethodOK(){
        return "OK";
    }

    public String testMethodFallback1(){
        return "OK";
    }

    public String testMethodFallback2(){
        return "OK";
    }

}
