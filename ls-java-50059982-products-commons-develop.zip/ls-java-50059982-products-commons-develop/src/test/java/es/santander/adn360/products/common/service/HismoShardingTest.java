package es.santander.adn360.products.common.service;

import org.apache.commons.io.FileUtils;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.springframework.core.io.ClassPathResource;

import java.io.IOException;
import java.nio.charset.Charset;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.MockitoAnnotations.initMocks;

class HismoShardingTest {

    private static final Integer RANGE_MONTHS = 6;
    private static final Integer PARTITIONS = 6;

    private static final Integer DEFAULT_RANGE_MONTHS = 1;
    private static final Integer DEFAULT_PARTITIONS = 1;

    @InjectMocks
    private HismoShardingImpl hismoSharding;

    List<String> lines;

    @BeforeEach
    public void setUp() throws IOException {
        initMocks(this);

        lines = FileUtils.readLines(new ClassPathResource("json/adn360.sharding.csv").getFile(),
                Charset.defaultCharset());

    }

    @Test
    void getShard() {
        for (int i = 0; i < lines.size(); i++) {
            String[] monthYear = lines.get(0).split(";");
            LocalDate date = LocalDate.of(Integer.valueOf(monthYear[1]),Integer.valueOf(monthYear[0]),1);
            Integer shard = hismoSharding.getShard(date, PARTITIONS, RANGE_MONTHS);
            Assertions.assertThat(this.getExpectedShard(date)).isEqualTo(shard);
        }

        LocalDate currentDate = LocalDate.now();
        Integer shardCollection = hismoSharding.getShard(currentDate, DEFAULT_PARTITIONS, DEFAULT_RANGE_MONTHS);
        Assertions.assertThat(0).isEqualTo(shardCollection);

    }

    @Test
    void getShard_with_Partitions_and_months_equals_0() {
        assertThrows(IllegalArgumentException.class, () -> hismoSharding.getShard(LocalDate.now(), 0, RANGE_MONTHS));
    }

    @Test
    void getShard_with_monthsRange_equals_0() {
        assertThrows(IllegalArgumentException.class, () -> hismoSharding.getShard(LocalDate.now(), PARTITIONS, 0));
    }

    @Test
    void getBeforeShard() {
        Integer current_shard = 5;
        Integer shard = hismoSharding.getBeforeShard(current_shard, PARTITIONS);
        Assertions.assertThat(current_shard-1).isEqualTo(shard);

        current_shard = 0;
        shard = hismoSharding.getBeforeShard(current_shard, PARTITIONS);
        Assertions.assertThat(5).isEqualTo(shard);
    }

    @Test
    void getAfterShard() {
        Integer current_shard = 5;
        Integer shard = hismoSharding.getAfterShard(current_shard, PARTITIONS);
        Assertions.assertThat(0).isEqualTo(shard);

        current_shard = 0;
        shard = hismoSharding.getAfterShard(current_shard, PARTITIONS);
        Assertions.assertThat(current_shard+1).isEqualTo(shard);

    }

    private Integer getExpectedShard(LocalDate date){
        String expectedShard = lines.stream()
                .map(line -> Arrays.asList(line.split(";")))
                .filter(list -> {
                    if (Integer.valueOf(list.get(0)) == date.getMonthValue() && Integer.valueOf(list.get(1)) == date.getYear())
                        return true;
                    else return false;
                })
                .collect(Collectors.toList()).get(0).get(2);
        return Integer.valueOf(expectedShard);
    }
}