package es.santander.adn360.products.common.service;

import es.santander.adn360.products.common.domain.ContractInfo;
import es.santander.adn360.products.common.domain.entity.BaseContract;
import es.santander.adn360.products.common.domain.repository.ContractInfoRepository;
import lombok.val;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

public class ContractInfoServiceTest {

    @Mock
    private ContractInfoRepository contractInfoRepository;

    @InjectMocks
    private ContractInfoServiceImpl contractInfoServiceImpl;

    @BeforeEach
    public void setup() {
        initMocks(this);
    }

    @Test
    public void findContractDescriptionsShouldReturnEmptyMapWhenNoFoundInfo() {
        when(contractInfoRepository.findContractInfo(any())).thenReturn(Collections.emptyList());

        assertThat(contractInfoServiceImpl.findContractDescriptions(Arrays.asList(new MockContract()))).isEmpty();
    }

    @Test
    public void findContractDescriptionsShouldReturnContractDescriptionsList() {
        when(contractInfoRepository.findContractInfo(any())).thenReturn(mockContractInfoList());

        val result = contractInfoServiceImpl.findContractDescriptions(Arrays.asList(new MockContract()));

        assertThat(result).isNotEmpty();
        assertThat(result.size()).isEqualTo(3);

        assertThat(result.get("123123123")).isEqualTo("Test 123");
        assertThat(result.get("121")).isEqualTo("Test 2");
        assertThat(result.get("42null")).isEqualTo("Test 3");

        String emp = "4";
        String prod = "2";
        String subp = null;

        assertThat(result.get(emp + prod + subp)).isEqualTo("Test 3");
    }

    @Test
    public void findContractInfoShouldReturnEmptyMapWhenNoFoundInfo() {
        when(contractInfoRepository.findContractInfo(any())).thenReturn(Collections.emptyList());

        assertThat(contractInfoServiceImpl.findContractInfo(Arrays.asList(new MockContract()))).isEmpty();
    }

    @Test
    public void findContractInfoShouldReturnContractDescriptionsList() {
        when(contractInfoRepository.findContractInfo(any())).thenReturn(mockContractInfoList());

        val result = contractInfoServiceImpl.findContractInfo(Arrays.asList(new MockContract()));

        assertThat(result).isNotEmpty();
        assertThat(result.size()).isEqualTo(3);

        assertThat(result.get("123123123")).isEqualTo(ContractInfo.builder()
                .id(null)
                .empresa("123")
                .producto("123")
                .subproducto("123")
                .descripcion("Test 123")
                .descripcionLarga("Test 123 completo")
                .nombreProducto("PRODUCTO 1")
                .indicadorProducto("2")
                .build());
        assertThat(result.get("121")).isEqualTo(ContractInfo.builder()
                .id(null)
                .empresa("1")
                .producto("2")
                .subproducto("1")
                .descripcion("Test 2")
                .descripcionLarga("Test 2 completo")
                .nombreProducto("PRODUCTO 2")
                .indicadorProducto("3")
                .build());
        assertThat(result.get("42null")).isEqualTo(ContractInfo.builder()
                .id(null)
                .empresa("4")
                .producto("2")
                .subproducto(null)
                .descripcion("Test 3")
                .descripcionLarga("Test 3 completo")
                .nombreProducto("PRODUCTO 3")
                .indicadorProducto("6")
                .build());

        String emp = "4";
        String prod = "2";
        String subp = null;

        assertThat(result.get(emp + prod + subp)).isEqualTo(ContractInfo.builder()
                .id(null)
                .empresa("4")
                .producto("2")
                .subproducto(null)
                .descripcion("Test 3")
                .descripcionLarga("Test 3 completo")
                .nombreProducto("PRODUCTO 3")
                .indicadorProducto("6")
                .build());
    }

    private List<ContractInfo> mockContractInfoList() {
        return Arrays.asList(
                ContractInfo.builder()
                        .empresa("123")
                        .producto("123")
                        .subproducto("123")
                        .descripcion("Test 123")
                        .descripcionLarga("Test 123 completo")
                        .nombreProducto("PRODUCTO 1")
                        .indicadorProducto("2")
                        .build(),
                ContractInfo.builder()
                        .empresa("1")
                        .producto("2")
                        .subproducto("1")
                        .descripcion("Test 2")
                        .descripcionLarga("Test 2 completo")
                        .nombreProducto("PRODUCTO 2")
                        .indicadorProducto("3")
                        .build(),
                ContractInfo.builder()
                        .empresa("4")
                        .producto("2")
                        .descripcion("Test 3")
                        .descripcionLarga("Test 3 completo")
                        .nombreProducto("PRODUCTO 3")
                        .indicadorProducto("6")
                        .build());
    }

    class MockContract extends BaseContract {
        @Override
        public List<String> getTipoIntervinientesTitular() {
            return Collections.singletonList("01");
        }
    }
}