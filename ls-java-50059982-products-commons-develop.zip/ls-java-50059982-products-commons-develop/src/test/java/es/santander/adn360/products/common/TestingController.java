package es.santander.adn360.products.common;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Only for integration testing purposes
 */
@Profile("test")
@RestController
@RequestMapping("/testingController")
public class TestingController {

    @Autowired
    TestingService testingService;

    @GetMapping
    public Integer endPoint(@RequestParam int numberOfContracts) {
        return testingService.get(numberOfContracts);
    }

    @GetMapping(path = "/no-limit")
    public Integer endPointNoLimit(@RequestParam int numberOfContracts) {
        return testingService.getNoLimit(numberOfContracts);
    }

    @GetMapping(path = "/with-limit-fallback")
    public Integer endPointWithLimit(@RequestParam int numberOfContracts) {
        return testingService.getWithLimit(numberOfContracts);
    }

}
