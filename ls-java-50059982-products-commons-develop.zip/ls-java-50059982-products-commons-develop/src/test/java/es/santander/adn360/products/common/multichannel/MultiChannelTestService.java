package es.santander.adn360.products.common.multichannel;

import es.santander.adn360.products.common.multichannel.annotation.MultiChannelPostProcessor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class MultiChannelTestService {

    @MultiChannelPostProcessor(
            {MultiChannelTestProcessor.class, MultiChannelTest2Processor.class}
    )
    public List<MultiChannelTestModel> processList(List<MultiChannelTestModel> contracts){
        contracts.get(0).setDivisa("EUR");
        contracts.get(1).setDivisa("USA");
        contracts.get(2).setDivisa("EUR");
        contracts.get(3).setDivisa("USA");
        return contracts.stream().map( contract -> {
            contract.setDataExample("set data in MultiChannelServiceTest.processList");
            return contract;
        }).collect(Collectors.toList());
    }

    @MultiChannelPostProcessor(
            {MultiChannelTestProcessor.class, MultiChannelTest2Processor.class}
    )
    public MultiChannelTestModel processContract(MultiChannelTestModel contract){
        contract.setDataExample("set data in MultiChannelServiceTest.contract");
        return contract;
    }

    @MultiChannelPostProcessor(
            {MultiChannelTestErrorProcessor.class}
    )
    public List<MultiChannelTestModel> processListError(List<MultiChannelTestModel> contracts){
        contracts.get(0).setDivisa("EUR");
        contracts.get(1).setDivisa("USA");
        contracts.get(2).setDivisa("EUR");
        contracts.get(3).setDivisa("USA");
        return contracts.stream().map( contract -> {
            contract.setDataExample("set data in MultiChannelServiceTest.processList");
            return contract;
        }).collect(Collectors.toList());
    }

}
