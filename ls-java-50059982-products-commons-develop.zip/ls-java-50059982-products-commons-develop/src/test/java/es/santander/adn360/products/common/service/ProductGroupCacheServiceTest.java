package es.santander.adn360.products.common.service;

import es.santander.adn360.core.model.document.Product;
import es.santander.adn360.core.model.document.ProductGroup;
import es.santander.adn360.core.util.ProductQueryParams;
import es.santander.adn360.products.common.config.ServicesProperties;
import lombok.val;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.actuate.observability.AutoConfigureObservability;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.Collections;
import java.util.List;

import static es.santander.adn360.products.common.service.ProductGroupCacheServiceImpl.PARAM_CHANNEL;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.when;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureObservability
public class ProductGroupCacheServiceTest {

    private final String mockUri = "http://mock-url.com";
    private final String channel1 = "channel1";
    private final String channel2 = "channel2";

    private final URI channelUri1 = UriComponentsBuilder
            .fromHttpUrl(mockUri)
            .queryParam(PARAM_CHANNEL, channel1)
            .build().encode().toUri();

    private final URI channelUri2 = UriComponentsBuilder
            .fromHttpUrl(mockUri)
            .queryParam(PARAM_CHANNEL, channel2)
            .build().encode().toUri();

    private final ProductGroup productChannel1 = ProductGroup.builder().id("P1").build();
    private final ProductGroup productChannel2 = ProductGroup.builder().id("P2").build();
    private final List<ProductGroup> products1 = Collections.singletonList(productChannel1);
    private final List<ProductGroup> products2 = Collections.singletonList(productChannel2);

    @Autowired
    private ProductGroupCacheService productGroupCacheService;

    @Autowired
    private ProductGroupService productGroupService;

    @MockBean(name = "restTemplate")
    private RestTemplate restTemplate;

    @Autowired
    private ServicesProperties servicesProperties;

    @BeforeEach
    public void setUp(){
        productGroupService.cleanProductgroupCache();

        val uris = servicesProperties.getProductGroupsService();
        uris.setCatalogUri(mockUri);
        uris.setProductGroupsUri(mockUri);
        uris.setProductGroupUri(mockUri);
        uris.setProductsUri(mockUri);
        uris.setProductUri(mockUri);
    }

    @Test
    public void getProductGroups_checkCache() {
        val params = ProductQueryParams.builder().build();

        when(restTemplate.exchange(
                eq(channelUri1),
                eq(HttpMethod.GET),
                isNull(),
                ArgumentMatchers.<ParameterizedTypeReference<List<ProductGroup>>>any()
        )).thenReturn(new ResponseEntity<>(products1, HttpStatus.OK));

        when(restTemplate.exchange(
                eq(channelUri2),
                eq(HttpMethod.GET),
                isNull(),
                ArgumentMatchers.<ParameterizedTypeReference<List<ProductGroup>>>any()
        )).thenReturn(new ResponseEntity<>(products2, HttpStatus.OK));

        val p1 = productGroupCacheService.getProductGroups(params, channel1);
        val p2 = productGroupCacheService.getProductGroups(params, channel2);

        assertThat(p1.get(0).getId()).isNotEqualTo(p2.get(0).getId());

        assertThat(productChannel1.getId()).isEqualTo(p1.get(0).getId());
        assertThat(productChannel2.getId()).isEqualTo(p2.get(0).getId());
    }

    @Test
    public void getProductGroup_checkCache() {
        val params = ProductQueryParams.builder().build();

        when(restTemplate.exchange(
                eq(channelUri1),
                eq(HttpMethod.GET),
                isNull(),
                ArgumentMatchers.<ParameterizedTypeReference<ProductGroup>>any()
        )).thenReturn(new ResponseEntity<>(productChannel1, HttpStatus.OK));

        when(restTemplate.exchange(
                eq(channelUri2),
                eq(HttpMethod.GET),
                isNull(),
                ArgumentMatchers.<ParameterizedTypeReference<ProductGroup>>any()
        )).thenReturn(new ResponseEntity<>(productChannel2, HttpStatus.OK));

        val p1 = productGroupCacheService.getProductGroup(params, null, channel1);
        val p2 = productGroupCacheService.getProductGroup(params, null, channel2);

        assertThat(p1.getId()).isNotEqualTo(p2.getId());

        assertThat(productChannel1.getId()).isEqualTo(p1.getId());
        assertThat(productChannel2.getId()).isEqualTo(p2.getId());

    }

    @Test
    public void getProducts_checkCache() {
        val params = ProductQueryParams.builder().build();
        val pro1 = Product.builder().type("1").build();
        val pro2 = Product.builder().type("2").build();

        when(restTemplate.exchange(
                eq(channelUri1),
                eq(HttpMethod.GET),
                isNull(),
                ArgumentMatchers.<ParameterizedTypeReference<List<Product>>>any()
        )).thenReturn(new ResponseEntity<>(Collections.singletonList(pro1), HttpStatus.OK));

        when(restTemplate.exchange(
                eq(channelUri2),
                eq(HttpMethod.GET),
                isNull(),
                ArgumentMatchers.<ParameterizedTypeReference<List<Product>>>any()
        )).thenReturn(new ResponseEntity<>(Collections.singletonList(pro2), HttpStatus.OK));

        val p1 = productGroupCacheService.getProducts(params, null, channel1).get(0);
        val p2 = productGroupCacheService.getProducts(params, null, channel2).get(0);

        assertThat(p1.getType()).isNotEqualTo(p2.getType());

        assertThat(pro1.getType()).isEqualTo(p1.getType());
        assertThat(pro2.getType()).isEqualTo(p2.getType());
    }

    @Test
    public void getCatalogIds_checkCache() {
        val params = ProductQueryParams.builder().build();
        val pro1 = "1";
        val pro2 = "2";

        when(restTemplate.exchange(
                eq(channelUri1),
                eq(HttpMethod.GET),
                isNull(),
                ArgumentMatchers.<ParameterizedTypeReference<List<String>>>any()
        )).thenReturn(new ResponseEntity<>(Collections.singletonList(pro1), HttpStatus.OK));

        when(restTemplate.exchange(
                eq(channelUri2),
                eq(HttpMethod.GET),
                isNull(),
                ArgumentMatchers.<ParameterizedTypeReference<List<String>>>any()
        )).thenReturn(new ResponseEntity<>(Collections.singletonList(pro2), HttpStatus.OK));

        val p1 = productGroupCacheService.getCatalogIds(params, null, channel1).get(0);
        val p2 = productGroupCacheService.getCatalogIds(params, null, channel2).get(0);

        assertThat(p1).isNotEqualTo(p2);

        assertThat(pro1).isEqualTo(p1);
        assertThat(pro2).isEqualTo(p2);

    }

    @Test
    public void getRelatedProducts_checkCache() {
        val params = ProductQueryParams.builder().build();
        val pro1 = Product.builder().type("1").build();
        val pro2 = Product.builder().type("2").build();

        when(restTemplate.exchange(
                eq(channelUri1),
                eq(HttpMethod.GET),
                isNull(),
                ArgumentMatchers.<ParameterizedTypeReference<List<Product>>>any()
        )).thenReturn(new ResponseEntity<>(Collections.singletonList(pro1), HttpStatus.OK));

        when(restTemplate.exchange(
                eq(channelUri2),
                eq(HttpMethod.GET),
                isNull(),
                ArgumentMatchers.<ParameterizedTypeReference<List<Product>>>any()
        )).thenReturn(new ResponseEntity<>(Collections.singletonList(pro2), HttpStatus.OK));

        val p1 = productGroupCacheService.getProductsAndRelatedProducts(params, null, channel1, null, null).get(0);
        val p2 = productGroupCacheService.getProductsAndRelatedProducts(params, null, channel2, null, null).get(0);

        assertThat(p1.getType()).isNotEqualTo(p2.getType());

        assertThat(pro1.getType()).isEqualTo(p1.getType());
        assertThat(pro2.getType()).isEqualTo(p2.getType());
    }
}
