package es.santander.adn360.products.common.domain.repository;

import com.mongodb.BasicDBList;
import es.santander.adn360.products.common.config.CommonMongoCollectionsProperties;
import es.santander.adn360.products.common.domain.IntervenerInfo;
import es.santander.adn360.products.common.domain.entity.Intervener;
import org.apache.commons.io.FileUtils;
import org.bson.BsonArray;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.actuate.observability.AutoConfigureObservability;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.mongodb.core.MongoOperations;

import java.nio.charset.Charset;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

@SpringBootTest
@AutoConfigureObservability
class IntervenerInfoRepositoryTest {

    @Autowired
    private CommonMongoCollectionsProperties commonMongoCollectionsProperties;

    @Autowired
    private IntervenerInfoRepository intervenerRepository;

    @Autowired
    private MongoOperations mongoOperations;

    @BeforeEach
    public void setUp() throws Exception {
        // Save all documents from json file
        String doc = FileUtils.readFileToString(new ClassPathResource("json/adn360.tiposIntervencion.json").getFile(),
                Charset.defaultCharset());
		final BsonArray parse = BsonArray.parse(doc);
		BasicDBList dbList = new BasicDBList();
		dbList.addAll(parse);
		dbList.forEach(dbo -> mongoOperations.save(dbo, this.commonMongoCollectionsProperties.getTiposIntervencion()));
    }

    /**
     * Should return 117 Descriptions inserted from JSON
     *
     * @throws Exception exception control
     */
    @Test
    public void findAll() throws Exception {
    	List<IntervenerInfo> intervList = intervenerRepository.findAll();

    	assertThat(intervList).isNotNull();
		assertThat(intervList.size()).isEqualTo(117);
    }

	@Test
	public void testFindByIntervenerList() {
		List<IntervenerInfo> intervInfo = intervenerRepository.findByIntervenerList(mockearInterveners());

		assertThat(intervInfo).isNotNull();
		assertThat(intervInfo.stream()
				.filter(x ->
						x.getTipoIntervencion().equals("01"))
				.findFirst()
				.map(IntervenerInfo::getNombreIntervencion)
				.get()
				.trim()).isEqualToIgnoringCase("TITULAR");
	}

	@Test
	public void findByIntervenerTypeShouldReturnTITULAR() {
		IntervenerInfo intervInfo = intervenerRepository.findByIntervenerType("01");

		assertThat(intervInfo).isNotNull();
		assertThat(intervInfo.getNombreIntervencion().trim()).isEqualToIgnoringCase("TITULAR");
	}

	@Test
	public void findByIntervenerTypeNULL() throws Exception{
		assertThrows(IllegalArgumentException.class, () -> this.intervenerRepository.findByIntervenerType(null));
	}

	private List<Intervener> mockearInterveners() {
		return Arrays.asList(Intervener.builder()
								.idCliente("F035906363")
								.tipoInterv("01")
								.ordenInterv(1)
								.fechaBaja(LocalDate.of(2019, 12, 31))
						.build(),
						Intervener.builder()
							.idCliente("F034199876")
							.tipoInterv("08")
							.ordenInterv(1)
							.fechaBaja(LocalDate.of(2019, 12, 31))
						.build()
				);
	}

}
