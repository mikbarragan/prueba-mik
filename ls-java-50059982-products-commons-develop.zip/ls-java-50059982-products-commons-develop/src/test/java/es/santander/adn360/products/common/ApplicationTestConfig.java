package es.santander.adn360.products.common;

import es.santander.adn360.core.model.document.repository.InternalUserRepositoryImpl;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.reactive.ReactiveSecurityAutoConfiguration;
import org.springframework.boot.autoconfigure.security.reactive.ReactiveUserDetailsServiceAutoConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cloud.client.loadbalancer.reactive.LoadBalancerBeanPostProcessorAutoConfiguration;

/**
 * SpringBootApplication for testing.
 */
@SpringBootApplication(exclude = {
        ReactiveSecurityAutoConfiguration.class,
        ReactiveUserDetailsServiceAutoConfiguration.class,
        LoadBalancerBeanPostProcessorAutoConfiguration.class
})
@EnableCaching
public class ApplicationTestConfig {
  // Initialization
  @MockBean
  InternalUserRepositoryImpl internalUserRepository;

}
