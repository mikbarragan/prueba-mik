package es.santander.adn360.products.common.util;

import es.santander.adn360.products.common.domain.entity.MockContract;
import es.santander.adn360.products.common.web.request.BodyRequest;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class HideContractsUtilsTest {

    BodyRequest body = BodyRequest.builder()
            .hideContracts(Arrays.asList("004900753150072196","004900753150072196","004900753150072197"))
            .build();

    @Test
    void testHideContractsUtils() {
        List<MockContract> contracts = Arrays.asList(
                MockContract.builder().idContrato("004900753150072196").build(),
                MockContract.builder().idContrato("004900753150072197").build(),
                MockContract.builder().idContrato("004900753150072198").build(),
                MockContract.builder().idContrato("004900753150072199").build(),
                MockContract.builder().idContrato("004900753150072195").build()
        );

        HideContractsUtil util = HideContractsUtil.builder().bodyRequest(body).build();
        assertThat(util.isEmpyHideContracts()).isFalse();
        assertThat(util.notEmpyHideContracts()).isTrue();

        List<MockContract> filtered = util.calculateAndFilterHiddenContracts(contracts);
        assertThat(filtered.size()).isEqualTo(3);
        assertThat(util.getHideContracts().size()).isEqualTo(2);
        assertThat(util.getHiddenContractsCount()).isEqualTo(2);

        util = HideContractsUtil.builder().bodyRequest(null).build();
        assertThat(util.isEmpyHideContracts()).isTrue();

        filtered = util.calculateAndFilterHiddenContracts(contracts);
        assertThat(filtered.size()).isEqualTo(contracts.size());
        assertThat(util.getHideContracts()).isEmpty();
        assertThat(util.getHiddenContractsCount()).isNull();
    }

}
