package es.santander.adn360.products.common.domain.entity;

import java.time.LocalDate;
import java.util.List;

import es.santander.adn360.products.common.domain.PortfolioBaseContract;
import es.santander.adn360.products.common.domain.PortfolioContract;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@NoArgsConstructor
@Data
public class MockContract extends PortfolioBaseContract {

    /**
     * Constructor.
     *
     * @param id                      id
     * @param idContrato              idContrato
     * @param contratoCartera         contratoCartera
     * @param cuentaLocal             cuentaLocal
     * @param empresa                 empresa
     * @param centro                  centro
     * @param producto                producto
     * @param contrato                contrato
     * @param productoNuevo           productoNuevo
     * @param subproducto             subproducto
     * @param contratoNuevo           contratoNuevo
     * @param descripcion             descripcion
     * @param descripcionLarga        descripcionLarga
     * @param divisa                  divisa
     * @param situacionGSI            situacionGSI
     * @param intervinientes          intervinientes
     * @param informacionUsuarios     informacionUsuarios
     * @param siga                    siga
     * @param estado                  estado
     * @param fechaSituacionOperativa fechaSituacionOperativa
     * @param fechaAltaContrato       fechaAltaContrato
     * @param fechaBajaContrato       fechaBajaContrato
     * @param contratosCarteras       contratosCarteras
     * @param usuariosEmpresas        usuariosEmpresas
     * @param propuestasRelacionadas the propuestas relacionadas
     */
    @Builder(toBuilder = true)
    public MockContract(String id, String idContrato, String contratoCartera, String cuentaLocal, String empresa,
                        String centro, String producto, String contrato, String productoNuevo, String subproducto,
                        String contratoNuevo, String descripcion, String descripcionLarga, String divisa,
                        RiskSituation situacionGSI, List<Intervener> intervinientes,
                        List<UserInformation> informacionUsuarios, String siga, String estado,
                        LocalDate fechaSituacionOperativa, LocalDate fechaAltaContrato, LocalDate fechaBajaContrato,
                        List<PortfolioContract> contratosCarteras, List<CompaniesUsers> usuariosEmpresas,
                        List<RelatedProposal> propuestasRelacionadas, String relatedProposalId) {

        super(id, idContrato, contratoCartera, cuentaLocal, empresa, centro, producto, contrato, productoNuevo,
                subproducto, contratoNuevo, descripcion, descripcionLarga, divisa, situacionGSI, intervinientes,
                informacionUsuarios, siga, estado, fechaSituacionOperativa, fechaAltaContrato, fechaBajaContrato,
                contratosCarteras, usuariosEmpresas, propuestasRelacionadas, relatedProposalId);
    }

    @Override
    public List<String> getTipoIntervinientesTitular() {
        return null;
    }

}