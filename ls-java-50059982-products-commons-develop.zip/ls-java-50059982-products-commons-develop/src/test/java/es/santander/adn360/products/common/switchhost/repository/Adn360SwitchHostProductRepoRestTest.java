package es.santander.adn360.products.common.switchhost.repository;

import es.santander.adn360.core.util.CustomerProductQueryParams;
import es.santander.adn360.mongodb.starter.domain.QueryParams;
import es.santander.adn360.products.common.config.SwitchHostProperties;
import es.santander.adn360.products.common.domain.bean.AggregationBean;
import es.santander.adn360.products.common.domain.bean.BalanceBean;
import es.santander.adn360.products.common.util.BalanceConstants;
import lombok.Data;
import lombok.val;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.actuate.observability.AutoConfigureObservability;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import jakarta.servlet.http.HttpServletResponse;
import java.math.BigDecimal;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

@SpringBootTest
@AutoConfigureObservability
public class Adn360SwitchHostProductRepoRestTest {

    @Autowired
    Adn360SwitchHostProductRepo adn360SwitchHostProductRepo;

    @Autowired
    private HttpServletResponse httpServletResponse;

    @MockBean(name = "restTemplate") //name included because it conflicts with nuarRestTemplate
    private RestTemplate restTemplate;

    @Autowired
    private SwitchHostProperties switchHostProperties;

    @Test
    public void findByCustomerId() {
        ListProduct expectedResponse = new ListProduct();

        Mockito.when(this.restTemplate.exchange(
                ArgumentMatchers.any(),
                ArgumentMatchers.eq(HttpMethod.GET),
                ArgumentMatchers.isNotNull(),
                ArgumentMatchers.<Class<ListProduct>>any())
        ).thenReturn(new ResponseEntity(expectedResponse, HttpStatus.OK));

        ListProduct response = adn360SwitchHostProductRepo.findByCustomerId(new QueryParams(), new CustomerProductQueryParams(), ListProduct.class);

        assertThat(response).isNotNull();
        assertThat(response).isEqualToComparingFieldByField(expectedResponse);

    }

    @Test
    public void findByCustomerId_extraParams() {
        ListProduct expectedResponse = new ListProduct();
        Map<String, String> extraParams = new HashMap<>();
        extraParams.put("garantee_type", "all_garantees");

        Mockito.when(this.restTemplate.exchange(
        		ArgumentMatchers.any(),
        		ArgumentMatchers.eq(HttpMethod.GET),
        		ArgumentMatchers.isNotNull(),
        		ArgumentMatchers.<Class<ListProduct>>any()
                )
        ).thenReturn(new ResponseEntity(expectedResponse, HttpStatus.OK));

        ListProduct response = adn360SwitchHostProductRepo.findByCustomerId(new QueryParams(), new CustomerProductQueryParams(), ListProduct.class, extraParams);

        assertThat(response).isNotNull();
        assertThat(response).isEqualToComparingFieldByField(expectedResponse);
    }

    @Test
    public void findByCustomerIdWhenHostReturnLinkHeader() {
        ListProduct expectedResponse = new ListProduct();
        MultiValueMap headers = mockHeaders();

        Mockito.when(this.restTemplate.exchange(
        		ArgumentMatchers.any(),
        		ArgumentMatchers.eq(HttpMethod.GET),
        		ArgumentMatchers.isNotNull(),
        		ArgumentMatchers.<Class<ListProduct>>any())
        ).thenReturn(new ResponseEntity(expectedResponse, headers, HttpStatus.OK));

        adn360SwitchHostProductRepo.findByCustomerId(new QueryParams(), new CustomerProductQueryParams(), ListProduct.class);

        assertThat(httpServletResponse.getHeader("Link"))
                .isEqualToIgnoringCase("</test/paginationEvaluateValidLinkHeader?_limit=3&_offset=septimo>; rel=next");
    }

    @Test
    public void findByCustomerIdInputValidation() {
    	assertThrows(IllegalArgumentException.class, () -> this.adn360SwitchHostProductRepo.findByCustomerId(null, null, ListProduct.class));
    }

    @Test
    public void getAggregations() {
        List<AggregationBean> expectedResponse = Arrays.asList(
                AggregationBean.builder()
                        .field("field")
                        .title("title")
                        .value(BalanceBean.builder()
                                .currency(BalanceConstants.CUR_EUR)
                                .amount(BigDecimal.TEN)
                                .build())
                        .build()
        );

        Mockito.when(this.restTemplate.exchange(
                ArgumentMatchers.any(),
                ArgumentMatchers.eq(HttpMethod.GET),
                ArgumentMatchers.isNotNull(),
                ArgumentMatchers.<Class<List>>any())
        ).thenReturn(new ResponseEntity(expectedResponse, HttpStatus.OK));

        val response = adn360SwitchHostProductRepo.getAggregations(new QueryParams(), new CustomerProductQueryParams(), List.class);

        assertThat(response).isNotNull();
        assertThat(response).hasSize(1);
        assertThat(response.get(0))
                .isEqualTo(AggregationBean.builder()
                        .field("field")
                        .title("title")
                        .value(BalanceBean.builder()
                                .currency(BalanceConstants.CUR_EUR)
                                .amount(BigDecimal.TEN)
                                .build())
                        .build());
    }

    @Test
    public void getAggregations_extraParams() {
        List<AggregationBean> expectedResponse = Arrays.asList(
                AggregationBean.builder()
                        .field("field")
                        .title("title")
                        .value(BalanceBean.builder()
                                .currency(BalanceConstants.CUR_EUR)
                                .amount(BigDecimal.TEN)
                                .build())
                        .build()
        );

        Map<String, String> extraParams = new HashMap<>();
        extraParams.put("garantee_type", "all_garantees");
        Mockito.when(this.restTemplate.exchange(
        		ArgumentMatchers.any(),
        		ArgumentMatchers.eq(HttpMethod.GET),
        		ArgumentMatchers.isNotNull(),
        		ArgumentMatchers.<Class<List>>any())
        ).thenReturn(new ResponseEntity(expectedResponse, HttpStatus.OK));

        val response = adn360SwitchHostProductRepo.getAggregations(new QueryParams(), new CustomerProductQueryParams(), List.class, extraParams);

        assertThat(response).isNotNull();
        assertThat(response).hasSize(1);
        assertThat(response.get(0))
                .isEqualTo(AggregationBean.builder()
                        .field("field")
                        .title("title")
                        .value(BalanceBean.builder()
                                .currency(BalanceConstants.CUR_EUR)
                                .amount(BigDecimal.TEN)
                                .build())
                        .build());
    }

    @Test
    public void getAggregationsValidation() {
    	assertThrows(IllegalArgumentException.class, () -> this.adn360SwitchHostProductRepo.getAggregations(null, null, List.class));
    }

    private UriComponentsBuilder setOptionalQueryParam(UriComponentsBuilder builder, String param, Object value) {
        return value == null ? builder : builder.queryParam(param, value);
    }

    private MultiValueMap mockHeaders() {
        Map<String, List<String>> map = new HashMap<>();

        map.put("Link", Arrays.asList("</test/paginationEvaluateValidLinkHeader?_limit=3&_offset=septimo>; rel=next"));

        return CollectionUtils.toMultiValueMap(map);
    }

    @Data
    private class ListProduct {
        private String attr = "aaa";
    }
}