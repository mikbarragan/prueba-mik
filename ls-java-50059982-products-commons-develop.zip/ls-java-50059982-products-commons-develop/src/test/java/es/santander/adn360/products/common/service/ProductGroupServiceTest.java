package es.santander.adn360.products.common.service;

import es.santander.adn360.core.model.document.Product;
import es.santander.adn360.core.model.document.ProductGroup;
import es.santander.adn360.core.model.exception.FunctionalException;
import es.santander.adn360.core.util.ProductQueryParams;
import es.santander.adn360.products.common.domain.entity.BaseContract;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.actuate.observability.AutoConfigureObservability;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.assertj.core.api.Java6Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureObservability
public class ProductGroupServiceTest {

    @Autowired
    private ProductGroupService productGroupService;

    @MockBean(name = "restTemplate") //name included because it conflicts with nuarRestTemplate
    private RestTemplate restTemplate;

    @BeforeEach
    public void setUp(){
        productGroupService.cleanProductgroupCache();
    }

    @Test
    public void getProductGroupsUnauthorized() {
        Mockito.when(this.restTemplate.exchange(
        		ArgumentMatchers.<URI>any(),
        		ArgumentMatchers.eq(HttpMethod.GET),
        		ArgumentMatchers.isNull(),
        		ArgumentMatchers.<ParameterizedTypeReference<List<ProductGroup>>>any())
        ).thenThrow(new HttpClientErrorException(HttpStatus.UNAUTHORIZED));

        assertThrows(HttpClientErrorException.class, () -> this.productGroupService.getProductGroups(ProductQueryParams.builder().application("test").segment("test").build()));
    }

    @Test
    public void getProductGroupsEmpty() {
        Mockito.when(this.restTemplate.exchange(
        		ArgumentMatchers.<URI>any(),
        		ArgumentMatchers.eq(HttpMethod.GET),
        		ArgumentMatchers.isNull(),
        		ArgumentMatchers.<ParameterizedTypeReference<List<ProductGroup>>>any())
        ).thenReturn(new ResponseEntity(Arrays.asList(), HttpStatus.OK));

        assertThrows(FunctionalException.class, () -> this.productGroupService.getProductGroups(ProductQueryParams.builder().application("test").segment("test").build()));
    }

    @Test
    public void getProductGroupsOk() {
        Mockito.when(this.restTemplate.exchange(
        		ArgumentMatchers.<URI>any(),
        		ArgumentMatchers.eq(HttpMethod.GET),
        		ArgumentMatchers.isNull(),
        		ArgumentMatchers.<ParameterizedTypeReference<List<ProductGroup>>>any())
        ).thenReturn(new ResponseEntity(Arrays.asList(ProductGroup.builder().id("id1").build()), HttpStatus.ACCEPTED));

        List<ProductGroup> productGroups = this.productGroupService.getProductGroups(ProductQueryParams.builder().application("test").segment("test").build());

        Assertions.assertThat(productGroups).hasSize(1);
        Assertions.assertThat(productGroups.get(0).getId()).isEqualTo("id1");
    }

    @Test
    public void getProductGroupUnauthorized() {
        Mockito.when(this.restTemplate.exchange(
        		ArgumentMatchers.<URI>any(),
        		ArgumentMatchers.eq(HttpMethod.GET),
        		ArgumentMatchers.isNull(),
        		ArgumentMatchers.<ParameterizedTypeReference<ProductGroup>>any())
        ).thenThrow(new HttpClientErrorException(HttpStatus.UNAUTHORIZED));

        assertThrows(HttpClientErrorException.class, () -> this.productGroupService.getProductGroup(ProductQueryParams.builder().application("test").segment("test").build(), "id1"));
    }

    @Test
    public void getProductGroupNull() {
        Mockito.when(this.restTemplate.exchange(
        		ArgumentMatchers.<URI>any(),
        		ArgumentMatchers.eq(HttpMethod.GET),
        		ArgumentMatchers.isNull(),
        		ArgumentMatchers.<ParameterizedTypeReference<ProductGroup>>any())
        ).thenReturn(new ResponseEntity<>((ProductGroup) null, HttpStatus.NO_CONTENT));

        assertThrows(FunctionalException.class, () -> this.productGroupService.getProductGroup(ProductQueryParams.builder().application("test").segment("test").build(), "id2"));
    }

    @Test
    public void getProductGroupOk() {
        Mockito.when(this.restTemplate.exchange(
        		ArgumentMatchers.<URI>any(),
        		ArgumentMatchers.eq(HttpMethod.GET),
        		ArgumentMatchers.isNull(),
        		ArgumentMatchers.<ParameterizedTypeReference<ProductGroup>>any())
        ).thenReturn(new ResponseEntity<>(ProductGroup.builder().id("id3").build(), HttpStatus.OK));

        ProductGroup productGroup
                = this.productGroupService.getProductGroup(ProductQueryParams.builder().application("test").segment("test").build(), "id1");
        Assertions.assertThat(productGroup).isNotNull();
        Assertions.assertThat(productGroup.getId()).isEqualTo("id3");
    }

    @Test
    public void getProductsUnauthorized() {
        Mockito.when(this.restTemplate.exchange(
        		ArgumentMatchers.<URI>any(),
        		ArgumentMatchers.eq(HttpMethod.GET),
        		ArgumentMatchers.isNull(),
        		ArgumentMatchers.<ParameterizedTypeReference<List<Product>>>any())
        ).thenThrow(new HttpClientErrorException(HttpStatus.UNAUTHORIZED));

        assertThrows(HttpClientErrorException.class, () -> this.productGroupService.getProducts(ProductQueryParams.builder().application("test").build(), "id1"));
    }

    @Test
    public void getProductsEmpty() {
        Mockito.when(this.restTemplate.exchange(
        		ArgumentMatchers.<URI>any(),
        		ArgumentMatchers.eq(HttpMethod.GET),
        		ArgumentMatchers.isNull(),
        		ArgumentMatchers.<ParameterizedTypeReference<List<Product>>>any())
        ).thenReturn(new ResponseEntity<>(Arrays.asList(), HttpStatus.OK));

        assertThrows(FunctionalException.class, () -> this.productGroupService.getProducts(ProductQueryParams.builder().application("test").build(), "id1"));
    }

    @Test
    public void getProductsNull() {
        Mockito.when(this.restTemplate.exchange(
                ArgumentMatchers.<URI>any(),
                ArgumentMatchers.eq(HttpMethod.GET),
                ArgumentMatchers.isNull(),
                ArgumentMatchers.<ParameterizedTypeReference<List<Product>>>any())
        ).thenReturn(new ResponseEntity<>(null, HttpStatus.NO_CONTENT));

        assertThrows(FunctionalException.class, () -> this.productGroupService.getProducts(ProductQueryParams.builder().application("test").build(), "id1"));
    }

    @Test
    public void getProductsOk() {
        Mockito.when(this.restTemplate.exchange(
        		ArgumentMatchers.<URI>any(),
        		ArgumentMatchers.eq(HttpMethod.GET),
        		ArgumentMatchers.isNull(),
        		ArgumentMatchers.<ParameterizedTypeReference<List<Product>>>any())
        ).thenReturn(new ResponseEntity<>(Arrays.asList(Product.builder().type("type1").build()), HttpStatus.OK));

        List<Product> products
                = this.productGroupService.getProducts(ProductQueryParams.builder().application("test").build(), "id1");
        Assertions.assertThat(products).hasSize(1);
        Assertions.assertThat(products.get(0).getType()).isEqualTo("type1");
    }

    @Test
    public void cleanCacheOk() throws InterruptedException {
        Mockito.when(this.restTemplate.exchange(
        		ArgumentMatchers.<URI>any(),
        		ArgumentMatchers.eq(HttpMethod.GET),
        		ArgumentMatchers.isNull(),
        		ArgumentMatchers.<ParameterizedTypeReference<List<Product>>>any())
        ).thenReturn(new ResponseEntity<>(Arrays.asList(Product.builder().type("type1").build()), HttpStatus.OK));

        List<Product> products
                = this.productGroupService.getProducts(ProductQueryParams.builder().application("test").build(), "id1");
        Assertions.assertThat(products).hasSize(1);
        Assertions.assertThat(products.get(0).getType()).isEqualTo("type1");

        // change response
        Mockito.when(this.restTemplate.exchange(
        		ArgumentMatchers.<URI>any(),
        		ArgumentMatchers.eq(HttpMethod.GET),
        		ArgumentMatchers.isNull(),
        		ArgumentMatchers.<ParameterizedTypeReference<List<Product>>>any())
        ).thenReturn(new ResponseEntity<>(Arrays.asList(Product.builder().type("type2").build()), HttpStatus.OK));

        // obtain same information from cache
        products
                = this.productGroupService.getProducts(ProductQueryParams.builder().application("test").build(), "id1");
        Assertions.assertThat(products).hasSize(1);
        Assertions.assertThat(products.get(0).getType()).isEqualTo("type1");

        // wait 5 seconds waiting cache cleaning
        Thread.sleep(10000);

        // obtain new response
        products
                = this.productGroupService.getProducts(ProductQueryParams.builder().application("test").build(), "id1");
        Assertions.assertThat(products).hasSize(1);
        Assertions.assertThat(products.get(0).getType()).isEqualTo("type2");
    }


    @Test
    public void filterProducts() {

        List<TestContract> contracts = Arrays.asList(
                TestContract.builder().idContrato("004903001000000000").productoNuevo("100").subproducto("200").build(),
                TestContract.builder().idContrato("004903001000000001").productoNuevo("100").subproducto("300").build(),
                TestContract.builder().idContrato("004903001000000002").productoNuevo("200").subproducto("200").build(),
                TestContract.builder().idContrato("004903001000000003").productoNuevo("200").subproducto("300").build(),
                TestContract.builder().idContrato("004903001000000004").productoNuevo("300").subproducto("200").build(),
                TestContract.builder().idContrato("004903001000000005").productoNuevo("300").subproducto("300").build(),
                TestContract.builder().idContrato("004903001000000006").productoNuevo("400").subproducto("200").build(),
                TestContract.builder().idContrato("004903001000000007").productoNuevo("400").subproducto("300").build());

        List<Product> products = Arrays.asList(
                Product.builder().type("100").subType("200").build(),
                Product.builder().type("400").subType("200").build(),
                Product.builder().type("400").subType("300").build()
        );


        List<TestContract> result = this.productGroupService.filterByProducts(contracts, products);

        assertThat(result).hasSize(3);
        assertThat(result.get(0).getProductoNuevo()).isEqualToIgnoringCase("100");
        assertThat(result.get(0).getSubproducto()).isEqualToIgnoringCase("200");

        assertThat(result.get(1).getProductoNuevo()).isEqualToIgnoringCase("400");
        assertThat(result.get(1).getSubproducto()).isEqualToIgnoringCase("200");

        assertThat(result.get(2).getProductoNuevo()).isEqualToIgnoringCase("400");
        assertThat(result.get(2).getSubproducto()).isEqualToIgnoringCase("300");

    }

    @Test
    public void filterProductsWithNull() {

        List<TestContract> contracts = Arrays.asList(
                TestContract.builder().idContrato("004903001000000000").productoNuevo("100").subproducto("200").build(),
                TestContract.builder().idContrato("004903001000000001").productoNuevo(null).subproducto("300").build(),
                TestContract.builder().idContrato("004903001000000002").productoNuevo("200").subproducto(null).build(),
                TestContract.builder().idContrato("004903001000000003").productoNuevo("200").subproducto("300").build(),
                TestContract.builder().idContrato("004903001000000004").productoNuevo("300").subproducto("200").build(),
                TestContract.builder().idContrato("004903001000000005").productoNuevo("300").subproducto("300").build(),
                TestContract.builder().idContrato("004903001000000006").productoNuevo("400").subproducto("200").build(),
                TestContract.builder().idContrato("004903001000000007").productoNuevo("400").subproducto("300").build());

        List<Product> products = Arrays.asList(
                Product.builder().type("100").subType("200").build(),
                Product.builder().type("400").subType("200").build(),
                Product.builder().type("400").subType("300").build()
        );


        List<TestContract> result = this.productGroupService.filterByProducts(contracts, products);

        assertThat(result).hasSize(3);
        assertThat(result.get(0).getProductoNuevo()).isEqualToIgnoringCase("100");
        assertThat(result.get(0).getSubproducto()).isEqualToIgnoringCase("200");

        assertThat(result.get(1).getProductoNuevo()).isEqualToIgnoringCase("400");
        assertThat(result.get(1).getSubproducto()).isEqualToIgnoringCase("200");

        assertThat(result.get(2).getProductoNuevo()).isEqualToIgnoringCase("400");
        assertThat(result.get(2).getSubproducto()).isEqualToIgnoringCase("300");

    }

    @Test
    public void filterProducts_withSubtypeNull() {

        List<TestContract> contracts = Arrays.asList(
                TestContract.builder().idContrato("004903001000000000").productoNuevo("100").subproducto("200").build(),
                TestContract.builder().idContrato("004903001000000001").productoNuevo(null).subproducto("300").build(),
                TestContract.builder().idContrato("004903001000000002").productoNuevo("200").subproducto(null).build(),
                TestContract.builder().idContrato("004903001000000003").productoNuevo("200").subproducto("300").build(),
                TestContract.builder().idContrato("004903001000000004").productoNuevo("300").subproducto("200").build(),
                TestContract.builder().idContrato("004903001000000005").productoNuevo("300").subproducto("300").build(),
                TestContract.builder().idContrato("004903001000000006").productoNuevo("400").subproducto("200").build(),
                TestContract.builder().idContrato("004903001000000007").productoNuevo("400").subproducto("300").build());

        List<Product> products = Arrays.asList(
                Product.builder().type("100").subType(null).build(),
                Product.builder().type("400").subType(null).build(),
                Product.builder().type("400").subType("300").build()
        );


        List<TestContract> result = this.productGroupService.filterByProducts(contracts, products);

        assertThat(result).hasSize(3);
        assertThat(result.get(0).getProductoNuevo()).isEqualToIgnoringCase("100");
        assertThat(result.get(0).getSubproducto()).isEqualToIgnoringCase("200");

        assertThat(result.get(1).getProductoNuevo()).isEqualToIgnoringCase("400");
        assertThat(result.get(1).getSubproducto()).isEqualToIgnoringCase("200");

        assertThat(result.get(2).getProductoNuevo()).isEqualToIgnoringCase("400");
        assertThat(result.get(2).getSubproducto()).isEqualToIgnoringCase("300");

    }

    @Test
    public void filterProductsContractNull() {

        List<Product> products = Arrays.asList(
                Product.builder().type("100").subType("200").build(),
                Product.builder().type("400").subType("200").build(),
                Product.builder().type("400").subType("300").build()
        );


        assertThrows(IllegalArgumentException.class, () -> this.productGroupService.filterByProducts(null, products));


    }

    @Test
    public void filterProductsWithProductgsNull() {

        List<BaseContract> contracts = Arrays.asList(
                TestContract.builder().idContrato("004903001000000000").productoNuevo("100").subproducto("200").build(),
                TestContract.builder().idContrato("004903001000000001").productoNuevo(null).subproducto("300").build(),
                TestContract.builder().idContrato("004903001000000002").productoNuevo("200").subproducto(null).build(),
                TestContract.builder().idContrato("004903001000000003").productoNuevo("200").subproducto("300").build(),
                TestContract.builder().idContrato("004903001000000004").productoNuevo("300").subproducto("200").build(),
                TestContract.builder().idContrato("004903001000000005").productoNuevo("300").subproducto("300").build(),
                TestContract.builder().idContrato("004903001000000006").productoNuevo("400").subproducto("200").build(),
                TestContract.builder().idContrato("004903001000000007").productoNuevo("400").subproducto("300").build());



        assertThrows(IllegalArgumentException.class, () -> this.productGroupService.filterByProducts(contracts, null));

    }

    @Test
    public void getCatalogIds_shouldReturnEmpty() {
        Mockito.when(this.restTemplate.exchange(
        		ArgumentMatchers.<URI>any(),
        		ArgumentMatchers.eq(HttpMethod.GET),
        		ArgumentMatchers.isNull(),
        		ArgumentMatchers.<ParameterizedTypeReference<List<Product>>>any())
        ).thenReturn(new ResponseEntity<>(Arrays.asList(), HttpStatus.NO_CONTENT));

        assertThrows(FunctionalException.class, () -> this.productGroupService.getCatalogIds(ProductQueryParams.builder().application("test").build(), "accident_insurance"));

    }

    @Test
    public void getCatalogIds_shouldReturnOk() {
        Mockito.when(this.restTemplate.exchange(
        		ArgumentMatchers.<URI>any(),
        		ArgumentMatchers.eq(HttpMethod.GET),
        		ArgumentMatchers.isNull(),
        		ArgumentMatchers.<ParameterizedTypeReference<List<String>>>any())
        ).thenReturn(new ResponseEntity<>(Arrays.asList("P211", "P234"), HttpStatus.OK));

        List<String> catalog
                = this.productGroupService.getCatalogIds(ProductQueryParams.builder().application("test").build(), "accident_insurance");
        Assertions.assertThat(catalog).hasSize(2);
        Assertions.assertThat(catalog).isEqualTo(Arrays.asList("P211","P234"));
    }

    @Test
    public void getCatalogIds_checkCache() throws InterruptedException {
        Mockito.when(this.restTemplate.exchange(
        		ArgumentMatchers.<URI>any(),
                ArgumentMatchers.eq(HttpMethod.GET),
                ArgumentMatchers.isNull(),
                ArgumentMatchers.<ParameterizedTypeReference<List<String>>>any())
        ).thenReturn(new ResponseEntity<>(Arrays.asList("P211", "P234"), HttpStatus.OK));

        List<String> catalog
                = this.productGroupService.getCatalogIds(ProductQueryParams.builder().application("test").build(), "accident_insurance");
        Assertions.assertThat(catalog).hasSize(2);
        Assertions.assertThat(catalog).isEqualTo(Arrays.asList("P211","P234"));

        // change response
        Mockito.when(this.restTemplate.exchange(
        		ArgumentMatchers.<URI>any(),
        		ArgumentMatchers.eq(HttpMethod.GET),
        		ArgumentMatchers.isNull(),
        		ArgumentMatchers.<ParameterizedTypeReference<List<String>>>any())
        ).thenReturn(new ResponseEntity<>(Arrays.asList("P666"), HttpStatus.OK));

        // obtain same information from cache
        catalog = this.productGroupService.getCatalogIds(ProductQueryParams.builder().application("test").build(), "accident_insurance");
        Assertions.assertThat(catalog).hasSize(2);
        Assertions.assertThat(catalog).isEqualTo(Arrays.asList("P211","P234"));

        // wait seconds waiting cache cleaning
        Thread.sleep(10000);

        // obtain new response
        catalog = this.productGroupService.getCatalogIds(ProductQueryParams.builder().application("test").build(), "accident_insurance");
        Assertions.assertThat(catalog).hasSize(1);
        Assertions.assertThat(catalog).isEqualTo(Arrays.asList("P666"));
    }

    @Test
    public void getProductEmpty() {
        Mockito.when(this.restTemplate.exchange(
        		ArgumentMatchers.<URI>any(),
        		ArgumentMatchers.eq(HttpMethod.GET),
        		ArgumentMatchers.isNull(),
        		ArgumentMatchers.<ParameterizedTypeReference<List<ProductGroup>>>any())
        ).thenReturn(new ResponseEntity(null, HttpStatus.OK));

        assertThrows(FunctionalException.class, () -> this.productGroupService.getProduct("empty","empty"));
    }

    @Test
    public void getProductOk() {
        Mockito.when(this.restTemplate.exchange(
        		ArgumentMatchers.<URI>any(),
        		ArgumentMatchers.eq(HttpMethod.GET),
        		ArgumentMatchers.isNull(),
        		ArgumentMatchers.<ParameterizedTypeReference<List<Product>>>any())
        ).thenReturn(new ResponseEntity(Product.builder().type("type1").subType("subtype1").attribute("debit").build(), HttpStatus.OK));

        Product product
                = this.productGroupService.getProduct("type1", "subtype1");
        Assertions.assertThat(product).isNotNull();
        Assertions.assertThat(product.getType()).isEqualTo("type1");
        Assertions.assertThat(product.getSubType()).isEqualTo("subtype1");
        Assertions.assertThat(product.getAttribute()).isEqualTo("debit");
    }

    @Test
    public void getRelatedProductsUnauthorized() {
        Mockito.when(this.restTemplate.exchange(
                ArgumentMatchers.<URI>any(),
                ArgumentMatchers.eq(HttpMethod.GET),
                ArgumentMatchers.isNull(),
                ArgumentMatchers.<ParameterizedTypeReference<List<Product>>>any())
        ).thenThrow(new HttpClientErrorException(HttpStatus.UNAUTHORIZED));

        assertThrows(HttpClientErrorException.class, () -> this.productGroupService.getProductsAndRelatedProducts(
                ProductQueryParams.builder().application("test").build(), "id1", null, null));
    }

    @Test
    public void getRelatedProductsEmpty() {
        Mockito.when(this.restTemplate.exchange(
                ArgumentMatchers.<URI>any(),
                ArgumentMatchers.eq(HttpMethod.GET),
                ArgumentMatchers.isNull(),
                ArgumentMatchers.<ParameterizedTypeReference<List<Product>>>any())
        ).thenReturn(new ResponseEntity<>(Arrays.asList(), HttpStatus.OK));

        assertThrows(FunctionalException.class, () -> this.productGroupService.getProductsAndRelatedProducts(
                ProductQueryParams.builder().application("test").build(), "id1", null, null));
    }

    @Test
    public void getRelatedProductsNull() {
        Mockito.when(this.restTemplate.exchange(
                ArgumentMatchers.<URI>any(),
                ArgumentMatchers.eq(HttpMethod.GET),
                ArgumentMatchers.isNull(),
                ArgumentMatchers.<ParameterizedTypeReference<List<Product>>>any())
        ).thenReturn(new ResponseEntity<>(null, HttpStatus.NO_CONTENT));

        assertThrows(FunctionalException.class, () -> this.productGroupService.getProductsAndRelatedProducts(
                ProductQueryParams.builder().application("test").build(), "id1", null, null));
    }

    @Test
    public void getRelatedProductsOk() {
        Mockito.when(this.restTemplate.exchange(
                ArgumentMatchers.<URI>any(),
                ArgumentMatchers.eq(HttpMethod.GET),
                ArgumentMatchers.isNull(),
                ArgumentMatchers.<ParameterizedTypeReference<List<Product>>>any())
        ).thenReturn(new ResponseEntity<>(Collections.singletonList(Product.builder().type("type1").build()), HttpStatus.OK));

        List<Product> products
                = this.productGroupService.getProductsAndRelatedProducts(
                        ProductQueryParams.builder().application("test").build(), "id1", "type1", "subtype1");
        Assertions.assertThat(products).hasSize(1);
        Assertions.assertThat(products.get(0).getType()).isEqualTo("type1");
    }
}
