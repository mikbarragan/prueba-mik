package es.santander.adn360.products.common.web.request;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.actuate.observability.AutoConfigureObservability;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import jakarta.validation.ConstraintViolationException;
import jakarta.validation.Valid;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureObservability
public class BodyRequestTest {

    private BodyRequest bodyRequest = BodyRequest.builder().build();

    @Autowired
    private ValidatingService service;

    @Service
    @Validated
    static class ValidatingService{
        List<String> validate(@Valid BodyRequest bodyRequest) {
            return bodyRequest.getHideContracts();
        }
    }

    @Test
    void testBodyRequest() {
        BodyRequest.builder().hideContracts(Collections.singletonList("X")).build();

        bodyRequest.setHideContracts(null);
        assertDoesNotThrow(() -> service.validate(bodyRequest));

        bodyRequest.setHideContracts(Collections.singletonList("004900753150072196"));
        assertDoesNotThrow(() -> service.validate(bodyRequest));

        bodyRequest.setHideContracts(Collections.singletonList("X"));
        assertThrows(ConstraintViolationException.class, () -> service.validate(bodyRequest));

        bodyRequest.setHideContracts(Collections.singletonList("00490075315007219X"));
        assertThrows(ConstraintViolationException.class, () -> service.validate(bodyRequest));
    }

}
