package es.santander.adn360.products.common.web.response;

import es.santander.adn360.products.common.service.TestContract;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class TestBaseContractPaginatedResponseImpl extends BaseContractPaginatedResponse<TestContract> {

    private List<TestContract> testContracts;

    @Override
    public List<TestContract> getPaginatedField() {
        return testContracts;
    }

    @Override
    public void setPaginatedField(List<TestContract> paginatedField) {
        testContracts = paginatedField;
    }
}
