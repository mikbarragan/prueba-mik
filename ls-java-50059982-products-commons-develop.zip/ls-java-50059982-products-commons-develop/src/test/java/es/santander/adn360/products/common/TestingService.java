package es.santander.adn360.products.common;

import es.santander.adn360.products.common.domain.PortfolioBaseContract;
import es.santander.adn360.products.common.util.PartialInformationUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * Only for integration testing purposes
 * TestingService class description
 */
@Service
public class TestingService {

    @Autowired
    private PartialInformationUtil partialInformationUtil;

    public int get(int numberOfContracts) {
        PortfolioBaseContract contract;
        List<PortfolioBaseContract> contractList = new ArrayList<>();
        for (int i=0;i<numberOfContracts;i++){
            contract = new PortfolioBaseContract();
            contract.setIdContrato(""+i);
            contractList.add(contract);
        }

        contractList = partialInformationUtil.applyLimit(contractList);
        return  contractList.size();
    }

    public int getNoLimit(int numberOfContracts) {
        PortfolioBaseContract contract;
        List<PortfolioBaseContract> contractList = new ArrayList<>();
        for (int i=0;i<numberOfContracts;i++){
            contract = new PortfolioBaseContract();
            contract.setIdContrato(""+i);
            contractList.add(contract);
        }
        partialInformationUtil.setPartialInformationDuetoFallback("remote service postion list fail-Internal Server Error");
        return  contractList.size();
    }

    public int getWithLimit(int numberOfContracts) {
        PortfolioBaseContract contract;
        List<PortfolioBaseContract> contractList = new ArrayList<>();
        for (int i=0;i<numberOfContracts;i++){
            contract = new PortfolioBaseContract();
            contract.setIdContrato(""+i);
            contractList.add(contract);
        }

        contractList = partialInformationUtil.applyLimit(contractList);
        partialInformationUtil.setPartialInformationDuetoFallback("remote service postion list fail-Internal Server Error");
        return  contractList.size();
    }

}

