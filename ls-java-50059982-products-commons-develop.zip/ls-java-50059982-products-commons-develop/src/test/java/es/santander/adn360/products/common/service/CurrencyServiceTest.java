package es.santander.adn360.products.common.service;

import es.santander.adn360.core.model.document.Exchange;
import es.santander.adn360.products.common.domain.bean.ExchangeBalanceBean;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.actuate.observability.AutoConfigureObservability;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertThrows;


@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureObservability
class CurrencyServiceTest {

    @Autowired
    private CurrencyService currencyService;

    @MockBean(name="restTemplate") //name included because it conflicts with nuarRestTemplate
    private RestTemplate restTemplate;

    @BeforeEach
    public void setUp() {
        // Clean cache before every test.
        this.currencyService.cleanCurrenciesCache();
    }

    @Test
    void getExchangeNullTest() {
        Mockito.when(this.restTemplate.exchange(
        		ArgumentMatchers.<URI>any(),
        		ArgumentMatchers.eq(HttpMethod.GET),
        		ArgumentMatchers.isNull(),
        		ArgumentMatchers.<ParameterizedTypeReference<List<Exchange>>>any())
        ).thenReturn(new ResponseEntity(new ArrayList<>(), HttpStatus.NO_CONTENT));

        Assertions.assertThat(this.currencyService.getExchange("test", "test")).isEqualTo(Exchange.builder().divisaDestino("test").divisaOrigen("test").build());
    }


    @Test
    void testConvertCurrencyKO() {
    	assertThrows(IllegalArgumentException.class, () -> this.currencyService.convertCurrency(null, new BigDecimal(1L)));
    }

    @Test
    void testConvertCurrencyKO2() {
    	assertThrows(IllegalArgumentException.class, () -> this.currencyService.convertCurrency(Exchange.builder().cambioFijo(new BigDecimal(2L)).build(), null));
    }

    @Test
    void testConvertCurrencyKO3() {
    	Assertions.assertThat(this.currencyService.convertCurrency(Exchange.builder().build(), new BigDecimal(1L))).isEqualTo(BigDecimal.ZERO);
    }

    @Test
    void testConvertCurrencyOK() {
        Exchange exchange = Exchange.builder()
                .cambioFijo(new BigDecimal(1.1).setScale(2, BigDecimal.ROUND_HALF_UP))
                .build();

        Assertions.assertThat(this.currencyService.convertCurrency(exchange, new BigDecimal(25800.59).setScale(2, BigDecimal.ROUND_HALF_UP)))
                .isEqualTo(new BigDecimal(23455.08).setScale(2, BigDecimal.ROUND_HALF_UP));

        Assertions.assertThat(this.currencyService.convertCurrency(exchange, new BigDecimal(0)))
                .isEqualTo(new BigDecimal(0).setScale(2, BigDecimal.ROUND_HALF_UP));

        Assertions.assertThat(this.currencyService.convertCurrency(exchange, new BigDecimal(-1.99).setScale(2, BigDecimal.ROUND_HALF_UP)))
                .isEqualTo(new BigDecimal(-1.81).setScale(2, BigDecimal.ROUND_HALF_UP));
    }

    @Test
    void testGetExchangeBalanceBeanOK() {
        Exchange exchange = Exchange.builder()
                .cambioFijo(new BigDecimal(1.1).setScale(2, BigDecimal.ROUND_HALF_UP))
                .divisaOrigen("USD")
                .divisaDestino("EUR")
                .build();

        ExchangeBalanceBean exchangeBalanceBean
                = this.currencyService.getExchangeBalanceBean(exchange, new BigDecimal(25800.59).setScale(2, BigDecimal.ROUND_HALF_UP));

        Assertions.assertThat(exchangeBalanceBean.getAmount())
                .isEqualTo(new BigDecimal(25800.59).setScale(2, BigDecimal.ROUND_HALF_UP));
        Assertions.assertThat(exchangeBalanceBean.getExchange().getAmount())
                .isEqualTo(new BigDecimal(23455.08).setScale(2, BigDecimal.ROUND_HALF_UP));
        Assertions.assertThat(exchangeBalanceBean.getExchange().getCurrency()).isEqualTo("EUR");

        // Test with an ExchangeBalanceBean
        ExchangeBalanceBean amountExchangeBalanceBean
                = ExchangeBalanceBean.builder().amount(new BigDecimal(25800.59).setScale(2, BigDecimal.ROUND_HALF_UP)).build();
        exchangeBalanceBean
                = this.currencyService.getExchangeBalanceBean(exchange, amountExchangeBalanceBean);

        Assertions.assertThat(exchangeBalanceBean.getAmount())
                .isEqualTo(new BigDecimal(25800.59).setScale(2, BigDecimal.ROUND_HALF_UP));
        Assertions.assertThat(exchangeBalanceBean.getExchange().getAmount())
                .isEqualTo(new BigDecimal(23455.08).setScale(2, BigDecimal.ROUND_HALF_UP));
        Assertions.assertThat(exchangeBalanceBean.getExchange().getCurrency()).isEqualTo("EUR");
    }

    @Test
    void testGetExchangeBalanceBean_ExchangeNull_AmountOK() {

        ExchangeBalanceBean exchangeBalanceBean
                = this.currencyService.getExchangeBalanceBean(null, new BigDecimal(25800.59).setScale(2, BigDecimal.ROUND_HALF_UP));

        Assertions.assertThat(exchangeBalanceBean.getAmount())
                .isEqualTo(new BigDecimal(25800.59).setScale(2, BigDecimal.ROUND_HALF_UP));
        Assertions.assertThat(exchangeBalanceBean.getExchange()).isNull();
    }

    @Test
    void testGetExchangeBalanceBean_ExchangeNull_AmountNull() {

        ExchangeBalanceBean exchangeBalanceBean
                = this.currencyService.getExchangeBalanceBean(null, ExchangeBalanceBean.builder().build());
        Assertions.assertThat(exchangeBalanceBean.getAmount()).isNull();
        Assertions.assertThat(exchangeBalanceBean.getExchange()).isNull();
    }
}
