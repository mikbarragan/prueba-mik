package es.santander.adn360.products.common.domain.repository;

import com.mongodb.BasicDBList;
import es.santander.adn360.products.common.config.CommonMongoCollectionsProperties;
import es.santander.adn360.products.common.domain.Person;
import es.santander.adn360.products.common.domain.entity.Intervener;
import org.apache.commons.io.FileUtils;
import org.bson.BsonArray;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.actuate.observability.AutoConfigureObservability;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.mongodb.core.MongoOperations;

import java.nio.charset.Charset;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@AutoConfigureObservability
public class PersonRepositoryTest {

    @Autowired
    private CommonMongoCollectionsProperties commonMongoCollectionsProperties;

    @Autowired
    private PersonRepository personRepository;

    @Autowired
    private MongoOperations mongoOperations;

    @BeforeEach
    public void setUp() throws Exception {
        // Save all documents from json file
        String doc = FileUtils.readFileToString(new ClassPathResource("json/adn360.people.json").getFile(),
                Charset.defaultCharset());
        final BsonArray parse = BsonArray.parse(doc);
        BasicDBList dbList = new BasicDBList();
        dbList.addAll(parse);
        dbList.forEach(dbo -> mongoOperations.save(dbo, this.commonMongoCollectionsProperties.getPerson()));
    }

    /**
     * Should return ten Card Descriptions inserted from JSON
     *
     * @throws Exception
     */
    @Test
    public void findAll() throws Exception {
        List<Person> persons = personRepository.findAll();
        assertThat(persons).isNotNull();
        assertThat(persons.size()).isEqualTo(7);
    }

    /**
     * Should return one person for type F
     *
     * @throws Exception exception
     */
    @Test
    public void findOneByTypeAndCode_F() throws Exception {
        Person p = personRepository.findOneByTypeAndCode("F", "000000001");
        assertThat(p).isNotNull();
        assertThat(p.getName()).isEqualToIgnoringCase("OLGA DEL CARMEN ONTIVEROS");
    }

    /**
     * Should return one person for type J
     *
     * @throws Exception
     */
    @Test
    public void findOneByTypeAndCode_J() throws Exception {
        Person p = personRepository.findOneByTypeAndCode("J", "000000001");
        assertThat(p).isNotNull();
        assertThat(p.getName()).isEqualToIgnoringCase("NOMBRE JURIDICO");
    }
    @Test
    public void testBanestoField() throws Exception {
        Person p = personRepository.findOneByTypeAndCode("F", "000000001");
        assertThat(p).isNotNull();
        assertThat(p.getName()).isEqualToIgnoringCase("OLGA DEL CARMEN ONTIVEROS");
        assertThat(p.getBanesto()).isFalse();

        p = personRepository.findOneByTypeAndCode("J", "000000001");
        assertThat(p).isNotNull();
        assertThat(p.getName()).isEqualToIgnoringCase("NOMBRE JURIDICO");
        assertThat(p.getBanesto()).isTrue();

    }
    @Test
    public void testFindByIntervenerList() {
        final List<Person> people = this.personRepository.findByIntervenerList(Collections.singletonList(
                Intervener.builder()
                        .idCliente("J000000001")
                        .build()
        ));

        assertThat(people).hasSize(1);
        assertThat(people.get(0).getName()).isEqualTo("NOMBRE JURIDICO");
    }

    @Test
    public void testFindByIntervenerListRepeated() {
        final List<Person> people = this.personRepository.findByIntervenerList(Arrays.asList(
                Intervener.builder()
                        .idCliente("J000000001")
                        .formaInterv("00")
                        .build(),
                Intervener.builder()
                        .idCliente("J000000001")
                        .formaInterv("01")
                        .build(),
                Intervener.builder()
                        .idCliente("J000000001")
                        .formaInterv("02")
                        .build()
        ));

        assertThat(people).hasSize(1);
        assertThat(people.get(0).getName()).isEqualTo("NOMBRE JURIDICO");
    }

    @Test
    public void testFindByTypeCodeCompany()  {
        Person p = personRepository.findOneByTypeAndCodeAndCompany("J", "000000003","0049");
        assertThat(p).isNotNull();
        assertThat(p.getName()).isEqualToIgnoringCase("FRANCO JESUS CABRERA");
        assertThat(p.getSegment()).isEqualToIgnoringCase("CA");
        assertThat(p.getCompany()).isEqualToIgnoringCase("0049");
    }

}
