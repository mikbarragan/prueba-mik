package es.santander.adn360.products.common.web;

import org.junit.Assert;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.actuate.observability.AutoConfigureObservability;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.ResponseEntity;
import org.springframework.web.util.UriComponentsBuilder;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureObservability
public class PartialInformationUtilTest {

    @Autowired
    private TestRestTemplate restTemplate;

    /**
     * TestingController creates a response with the number of
     * contracts passed as argument and applies the technical limit
     * If contract list length is less than the limit then no header in response
     */
    @Test
    public void mainTest() {

        /**
         * If the length of the contract list is greater than the limit then it should return the header in the response
         */
        UriComponentsBuilder builder = UriComponentsBuilder.fromPath("/testingController")
                .queryParam("numberOfContracts", 5001);
        ResponseEntity<Object> response = restTemplate.getForEntity(builder.build().toUri(), Object.class);

        Assert.assertEquals(response.getBody(), Integer.valueOf(5000));
        Assert.assertTrue(response.getHeaders().containsKey("Partial-Information"));
        Assert.assertTrue(response.getHeaders().get("Partial-Information").get(0).equalsIgnoreCase("reason=technical limit reached"));

        /**
         * If the length of the contract list is less than the limit then it should not return the header
         */
        builder = UriComponentsBuilder.fromPath("/testingController")
                .queryParam("numberOfContracts", 100);
        response = restTemplate.getForEntity(builder.build().toUri(), Object.class);

        Assert.assertEquals(response.getBody(), Integer.valueOf(100));
        Assert.assertFalse(response.getHeaders().containsKey("Partial-Information"));

        /**
         * No exists techical limit but exists fail remote service message
         */
        builder = UriComponentsBuilder.fromPath("/testingController/no-limit")
                .queryParam("numberOfContracts", 100);
        response = restTemplate.getForEntity(builder.build().toUri(), Object.class);

        Assert.assertEquals(response.getBody(), Integer.valueOf(100));
        Assert.assertTrue(response.getHeaders().containsKey("Partial-Information"));
        Assert.assertTrue(response.getHeaders().get("Partial-Information").get(0)
                .equalsIgnoreCase("reason=remote service postion list fail-Internal Server Error"));

        /**
         * No exists techical limit but exists fail remote service message
         */
        builder = UriComponentsBuilder.fromPath("/testingController/with-limit-fallback")
                .queryParam("numberOfContracts", 5001);
        response = restTemplate.getForEntity(builder.build().toUri(), Object.class);

        Assert.assertEquals(response.getBody(), Integer.valueOf(5000));
        Assert.assertTrue(response.getHeaders().containsKey("Partial-Information"));
        Assert.assertTrue(response.getHeaders().get("Partial-Information").get(0)
                .equalsIgnoreCase("reason=technical limit reached;remote service postion list fail-Internal Server Error"));
    }

}
