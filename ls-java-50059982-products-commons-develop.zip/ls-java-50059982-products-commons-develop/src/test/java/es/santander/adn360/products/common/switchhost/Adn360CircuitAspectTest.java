package es.santander.adn360.products.common.switchhost;

import es.santander.adn360.core.config.TestConfiguration;
import es.santander.adn360.core.model.exception.FunctionalException;
import es.santander.adn360.core.util.ExceptionEnum;
import es.santander.adn360.core.web.CoreSecurityContextImpl;
import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.actuate.observability.AutoConfigureObservability;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import java.util.Collections;

import static org.junit.jupiter.api.Assertions.assertThrows;


@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureObservability
public class Adn360CircuitAspectTest {

    private static final CoreSecurityContextImpl CORE_SECURITY_CONTEXT = (CoreSecurityContextImpl) Mockito.mock(CoreSecurityContextImpl.class);

    @Autowired
    CircuitBreakerTestService circuitBreakerTestService;

    @MockBean
    CircuitBrakerTestRepository circuitBrakerTestRepository;

    @Autowired
    CircuitBreakerRegistry circuitBreakerRegistry;

    CircuitBreaker circuitBreaker;

    @BeforeEach
    public void setUp() throws Exception {

        Assertions.assertThat(circuitBreakerTestService).isNotNull().withFailMessage("CircuitBrakerTestService should be autowired");
        Assertions.assertThat(circuitBrakerTestRepository).isNotNull().withFailMessage("circuitBrakerTestRepository should be autowired");

        circuitBreaker = circuitBreakerRegistry.circuitBreaker("switchHost");
    }

    @Test
    public void testOKOFI() {

        // Mock channel to get OFI channel.
        TestConfiguration.mockSantanderChannel("OFI");
        String result = circuitBreakerTestService.testMethod("test", Collections.emptyList(), "test");

        Assertions.assertThat(result).isEqualTo("method OK");

    }

    @Test
    public void testOKEMP() {

        // Mock channel to get EMP channel.
        TestConfiguration.mockSantanderChannel("EMP");
        String result = circuitBreakerTestService.testMethod("test", Collections.emptyList(), "test");

        Assertions.assertThat(result).isEqualTo("method OK");

    }

    @Test
    public void testOKEMPB() {

        // Mock channel to get EMPB channel.
        TestConfiguration.mockSantanderChannel("EMPB");
        String result = circuitBreakerTestService.testMethod("test", Collections.emptyList(), "test");

        Assertions.assertThat(result).isEqualTo("fallback HOST");

    }

    @Test
    public void testExceptionOFI() {
        // Mock channel to get OFI channel.
        TestConfiguration.mockSantanderChannel("OFI");
        Mockito.when(circuitBrakerTestRepository.testMethodOK()).thenThrow(new FunctionalException(ExceptionEnum.INTERNAL_SERVER_ERROR));

        assertThrows(FunctionalException.class, () -> circuitBreakerTestService.testMethod("test", Collections.emptyList(), "test"));

    }

    @Test
    public void testFallbackEMP() {
        // Mock channel to get EMP channel.
        TestConfiguration.mockSantanderChannel("EMP");
        Mockito.when(circuitBrakerTestRepository.testMethodOK()).thenThrow(new FunctionalException(ExceptionEnum.INTERNAL_SERVER_ERROR));

        String result = circuitBreakerTestService.testMethod("test", Collections.emptyList(), "test");

        Assertions.assertThat(result).isEqualTo("fallback HOST");

    }

    @Test
    public void testFallbackEMPB() {
        // Mock channel to get EMPB channel.
        TestConfiguration.mockSantanderChannel("EMPB");
        Mockito.when(circuitBrakerTestRepository.testMethodOK()).thenThrow(new FunctionalException(ExceptionEnum.INTERNAL_SERVER_ERROR));

        String result = circuitBreakerTestService.testMethod("test", Collections.emptyList(), "test");

        Assertions.assertThat(result).isEqualTo("fallback HOST");

    }

    @Test
    public void testFallbackEMPWhenCircuitOpen() {
        // Mock channel to get EMP channel.
        TestConfiguration.mockSantanderChannel("EMP");
        //open circuit
        circuitBreaker.transitionToOpenState();
        String result = circuitBreakerTestService.testMethod("test", Collections.emptyList(), "test");

        Assertions.assertThat(result).isEqualTo("fallback HOST");

    }


    @Test
    public void testOFIWhenCircuitOpen() {
        // Mock channel to get OFI channel.
        TestConfiguration.mockSantanderChannel("OFI");
        //open circuit
        circuitBreaker.transitionToOpenState();
        String result = circuitBreakerTestService.testMethod("test", Collections.emptyList(), "test");

        Assertions.assertThat(result).isEqualTo("method OK");

    }

    @Test
    public void testFallbackEMPBWhenCircuitOpen() {
        // Mock channel to get EMP channel.
        TestConfiguration.mockSantanderChannel("EMPB");
        //open circuit
        circuitBreaker.transitionToOpenState();
        String result = circuitBreakerTestService.testMethod("test", Collections.emptyList(), "test");

        Assertions.assertThat(result).isEqualTo("fallback HOST");

    }

    @Test
    public void testInvokationWithNull() {
        // Mock channel to get EMPB channel.
        TestConfiguration.mockSantanderChannel("EMPB");
        String result = circuitBreakerTestService.testMethod("test", null, "test");

        Assertions.assertThat(result).isEqualTo("fallback HOST");

    }



}