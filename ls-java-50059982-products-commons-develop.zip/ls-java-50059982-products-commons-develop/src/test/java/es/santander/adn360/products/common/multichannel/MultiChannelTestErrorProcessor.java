package es.santander.adn360.products.common.multichannel;

import es.santander.adn360.products.common.domain.entity.BaseContract;
import es.santander.adn360.products.common.multichannel.processors.MultiChannelProcessor;

import java.util.List;
import java.util.stream.Collectors;

public class MultiChannelTestErrorProcessor implements MultiChannelProcessor {

    @Override
    public List processListContracts(List contracts) {

        return ((List<? extends BaseContract>) contracts).stream()
                .map(contract -> {
                    contract.setDescripcion("Descripcion seteada desde MultiChannelErrorProcessorTest");
                    return contract;
                }).collect(Collectors.toList());
    }

    public MultiChannelTestModel processContract(BaseContract contract) {
        MultiChannelTestModel response = (MultiChannelTestModel) contract;
        response.setAlias("Alias actualizado desde MultiChannelErrorProcessorTest");
        return response;
    }
}