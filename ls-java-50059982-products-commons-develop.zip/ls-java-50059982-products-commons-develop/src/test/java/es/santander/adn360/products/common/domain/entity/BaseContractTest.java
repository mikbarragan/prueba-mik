package es.santander.adn360.products.common.domain.entity;

import java.io.IOException;
import java.nio.charset.Charset;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.assertj.core.api.Assertions;
import org.bson.BsonArray;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.actuate.observability.AutoConfigureObservability;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.mongodb.core.MongoOperations;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mongodb.BasicDBList;

import es.santander.adn360.core.config.TestConfiguration;
import es.santander.adn360.products.common.service.TestContract;
import es.santander.adn360.products.common.service.TestContractRepository;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureObservability
public class BaseContractTest {

    @Autowired
    private MongoOperations mongoOperations;

    @Autowired
    private TestContractRepository testContractRepository;

    @BeforeEach
    public void setUp() throws Exception {
        TestConfiguration.mockSantanderChannel("OFI");
        // Save all documents from json file
        String doc = FileUtils.readFileToString(new ClassPathResource("json/adn360.testContracts.json").getFile(),
                Charset.defaultCharset());
        final BsonArray parse = BsonArray.parse(doc);
        BasicDBList dbList = new BasicDBList();
        dbList.addAll(parse);
        dbList.forEach(dbo -> mongoOperations.save(dbo, "test"));
    }

    @Test
    public void testOldContractNumber_withouth_localAccount() {
        final TestContract contract = this.testContractRepository.findById("59cbccdd952705545bc520dc").get();
        Assertions.assertThat(contract.getCuentaLocal()).isNullOrEmpty();
        Assertions.assertThat(contract.getNumeroContratoViejo()).isNotEqualTo(contract.getCuentaLocal());
        Assertions.assertThat(contract.getNumeroContratoViejo()).isEqualTo("004913311030000143");

    }

    @Test
    public void testLocalAccountNumber() {
        final TestContract contract = this.testContractRepository.findById("59cbccdd952705545bc52000").get();
        Assertions.assertThat(contract.getCuentaLocal()).isNotEmpty();
        Assertions.assertThat(contract.getCuentaLocal()).isEqualTo("004913311030000103");
        Assertions.assertThat(contract.getNumeroContratoViejo()).isEqualTo(contract.getCuentaLocal());

    }

    @Test
    public void testOldContractNumber_with_localAccount() {
        final TestContract contract = this.testContractRepository.findById("59cbccdd952705545bc52000").get();
        Assertions.assertThat(contract.getNumeroContratoViejo()).isNotNull();
        Assertions.assertThat(contract.getNumeroContratoViejo()).isEqualTo(contract.getCuentaLocal());
    }


    @Test
    public void testContractHolder_withoutContractHolder() {
        final TestContract contract = this.testContractRepository.findById("59cbccdd952705545bc520dc").get();
        Assertions.assertThat(contract.getTitular()).isEqualTo("Test intervener");
    }

    @Test
    public void testContractHolder_OrdenInterv() {
        final TestContract contract = this.testContractRepository.findById("59cbccdd952705545bc520dc").get();
        contract.getIntervinientes().addAll(
                Arrays.asList(
                        Intervener.builder()
                                .fechaBaja(LocalDate.now().plusMonths(1L))
                                .formaInterv("01")
                                .ordenInterv(2)
                                .nombreCompleto("Este no sale")
                                .build(),
                        Intervener.builder()
                                .fechaBaja(LocalDate.now().plusMonths(1L))
                                .formaInterv("44")
                                .ordenInterv(1)
                                .nombreCompleto("Este no sale")
                                .build(),
                        Intervener.builder()
                                .fechaBaja(LocalDate.now().plusMonths(1L))
                                .formaInterv("01")
                                .ordenInterv(3)
                                .nombreCompleto("Este no sale")
                                .build(),
                        Intervener.builder()
                                .fechaBaja(LocalDate.now().plusMonths(1L))
                                .formaInterv("01")
                                .ordenInterv(4)
                                .nombreCompleto("Este no sale")
                                .build()
                )
        );

        Collections.shuffle(contract.getIntervinientes());
        Assertions.assertThat(contract.getTitular()).isEqualTo("Test intervener");

        Collections.shuffle(contract.getIntervinientes());
        Assertions.assertThat(contract.getTitular()).isEqualTo("Test intervener");

        Collections.shuffle(contract.getIntervinientes());
        Assertions.assertThat(contract.getTitular()).isEqualTo("Test intervener");
    }

    @Test
    public void testContractHolder_withContractHolder() {
        final TestContract contract = this.testContractRepository.findById("67cbccdd952705545bc520dc").get();
        Assertions.assertThat(contract.getTitular()).isEqualTo("contractHolder");
    }

    @Test
    public void testAlias_withAlias() {
        TestConfiguration.mockInternalUser("UETEST");
        final TestContract contract = this.testContractRepository.findById("67cbccdd952705545bc520dc").get();
        Assertions.assertThat(contract.getAliasContrato()).isEqualTo("with alias");
    }

    @Test
    public void testParticipant()  {
        final TestContract contract = this.testContractRepository.findById("59cbccdd952705545bc520dc").get();
        Assertions.assertThat(contract.getIntervinientes().get(0).getParticipant()).isEqualTo("1 Interviniente");
    }
    @Test
    public void testFechaSituacionOperativa() {
        final TestContract contract = this.testContractRepository.findById("59cbccdd952705545bc520dc").get();
        Assertions.assertThat(contract.getFechaSituacionOperativa()).isNotNull();
        Assertions.assertThat(contract.getFechaSituacionOperativa().toString()).isEqualTo("2020-01-31");
    }
    @Test
    public void testFechaAltaContratoAndFechaBajaContrato() {
        final TestContract contract = this.testContractRepository.findById("59cbccdd952705545bc520dc").get();
        Assertions.assertThat(contract.getFechaAltaContrato()).isNotNull();
        Assertions.assertThat(contract.getFechaAltaContrato().toString()).isEqualTo("2010-01-31");
        Assertions.assertThat(contract.getFechaBajaContrato()).isNotNull();
        Assertions.assertThat(contract.getFechaBajaContrato().toString()).isEqualTo("2030-01-31");
    }

    @Test
    public void testSerializationOrder() throws IOException {
        final ObjectMapper om = new ObjectMapper();
        final String json = om.writeValueAsString(TestContract.builder().dummy("test").estado("test").idContrato("123456789").centro("1331").build());
        final Object[] propertyMap = om.readValue(json, Map.class).keySet().toArray();

        // First property should be contractNumber, others are sorted alphabetically
        Assertions.assertThat(propertyMap[0]).isEqualTo("contractNumber");
        Assertions.assertThat(propertyMap[1]).isEqualTo("activationDate");
        Assertions.assertThat(propertyMap[8]).isEqualTo("dummy");
        Assertions.assertThat(propertyMap[9]).isEqualTo("expiryDate");
        Assertions.assertThat(propertyMap[10]).isEqualTo("fechaSituacionOperativa");
        Assertions.assertThat(propertyMap[17]).isEqualTo("productType");
    }

    @Test
    public void nullpointerPrevent() {
        BaseContract contractToTest = TestContract.builder().intervinientes(null).informacionUsuarios(null).build();
        Assertions.assertThat(contractToTest.getTitular()).isNull();
        Assertions.assertThat(contractToTest.getAliasContrato()).isNull();
    }

    @Test
    public void testContractWithNoContractHolder() {
        BaseContract contractToTest = TestContract.builder()
                .intervinientes(
                        Collections.singletonList(
                                Intervener.builder()
                                        .fechaBaja(LocalDate.now().plusMonths(1L))
                                        .formaInterv("XX")
                                        .ordenInterv(1)
                                        .nombreCompleto("Este no sale")
                                        .build()
                        )
                ).build();
        Assertions.assertThat(contractToTest.getTitular()).isNull();
    }

    @Test
    public void getRelatedProposalIdTest() {
    	BaseContract contractToTest = TestContract.builder().propuestasRelacionadas(
    			List.of(RelatedProposal.builder().idPropuesta("00490075201612105").fechaVencimientoAsoc(LocalDate.of(9999, 12, 31))
    					.fechaFormalizacion(LocalDate.of(9999, 12, 31)).build(),
    					RelatedProposal.builder().idPropuesta("00490075201612106").fechaVencimientoAsoc(LocalDate.of(2000, 12, 31))
    					.fechaFormalizacion(LocalDate.of(2000, 12, 31)).build()))
    			.build();
        Assertions.assertThat(contractToTest.getRelatedProposalId()).isEqualTo("00490075201612105");

        contractToTest = TestContract.builder().propuestasRelacionadas(
    			List.of(RelatedProposal.builder().idPropuesta("00490075201612105").fechaVencimientoAsoc(LocalDate.of(2020, 12, 31))
    					.fechaFormalizacion(LocalDate.of(9999, 12, 31)).build(),
    					RelatedProposal.builder().idPropuesta("00490075201612106").fechaVencimientoAsoc(LocalDate.of(2000, 12, 31))
    					.fechaFormalizacion(LocalDate.of(2000, 12, 31)).build()))
    			.build();
        Assertions.assertThat(contractToTest.getRelatedProposalId()).isNull();

        contractToTest = TestContract.builder().propuestasRelacionadas(
    			List.of(RelatedProposal.builder().idPropuesta("00490075201612105").fechaVencimientoAsoc(LocalDate.of(2020, 12, 31))
    					.fechaFormalizacion(LocalDate.of(9999, 12, 31)).build(),
    					RelatedProposal.builder().idPropuesta("00490075201612106").fechaVencimientoAsoc(LocalDate.now())
    					.fechaFormalizacion(LocalDate.of(2000, 12, 31)).build()))
    			.build();
        Assertions.assertThat(contractToTest.getRelatedProposalId()).isNull();

        contractToTest = TestContract.builder().propuestasRelacionadas(List.of()).build();
        Assertions.assertThat(contractToTest.getRelatedProposalId()).isNull();
    }
}
