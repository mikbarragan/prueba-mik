package es.santander.adn360.products.common.multichannel;


import es.santander.adn360.products.common.domain.entity.BaseContract;
import es.santander.adn360.products.common.multichannel.processors.MultiChannelProcessor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class MultiChannelTest2Processor implements MultiChannelProcessor {

    public List processListContracts(List contracts){
        return ((List<? extends BaseContract>) contracts).stream()
                .filter( contract -> "EUR".equals(contract.getDivisa()))
                .map(
                    contract -> {
                        contract.setDescripcionLarga("Descripcion larga seteada desde MultiChannelProcessorTest2");
                        return contract;
                    }
                 ).collect(Collectors.toList());
    };

    public MultiChannelTestModel processContract(BaseContract contract) {
        MultiChannelTestModel response = (MultiChannelTestModel) contract;
        response.setDescripcion("Descripcion actualizado desde MultiChannelProcessorTest2");
        return response;
    }
}
