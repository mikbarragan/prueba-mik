package es.santander.adn360.products.common.service;

import com.mongodb.BasicDBList;
import com.mongodb.DBObject;
import es.santander.adn360.core.config.TestConfiguration;
import es.santander.adn360.core.model.document.Product;
import es.santander.adn360.core.model.document.ProductGroup;
import es.santander.adn360.core.util.CustomerProductQueryParams;
import es.santander.adn360.products.common.domain.bean.ProductQueryBuilderParams;
import org.apache.commons.io.FileUtils;
import org.assertj.core.api.Assertions;
import org.bson.BsonArray;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.actuate.observability.AutoConfigureObservability;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Criteria;

import java.nio.charset.Charset;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertThrows;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureObservability
class ProductQueryBuilderTest {

    @Autowired
    private ProductQueryBuilder productQueryBuilder;

    @Autowired
    private TestContractRepository testContractRepository;

    @Autowired
    private MongoOperations mongoOperations;

    @MockBean
    private ProductGroupService productGroupService;

    @BeforeEach
    void setUp() throws Exception {
        TestConfiguration.mockSantanderChannel("OFI");
        // Save all documents from json file
        String doc = FileUtils.readFileToString(new ClassPathResource("json/adn360.testContracts.json").getFile(),
                Charset.defaultCharset());
        final BsonArray parse = BsonArray.parse(doc);
        BasicDBList dbList = new BasicDBList();
        dbList.addAll(parse);
        DBObject dbObject = dbList;
        ((BasicDBList) dbObject).forEach(dbo -> mongoOperations.save(dbo, "test"));

        // Mock products and product group
        Mockito.when(this.productGroupService.getProducts(ArgumentMatchers.any(), ArgumentMatchers.any()))
                .thenReturn(Arrays.asList(
                        Product.builder().type("103").subType("001").build(),
                        Product.builder().type("103").subType("501").build()
                ));
    }

    @Test
    void getProductCriteriaNullProductQueryParamsTest() {
        assertThrows(IllegalArgumentException.class, () -> this.productQueryBuilder.getProductCriteria(null,
                null, null));
    }

    @Test
    void getProductCriteriaNullProductQueryBuilderParamsTest() {
        assertThrows(IllegalArgumentException.class, () -> this.productQueryBuilder.getProductCriteria(
                CustomerProductQueryParams.getBuilder().build(), null, null));
    }

    @Test
    void getProductCriteriaNullProductGroupIdTest() {
        assertThrows(IllegalArgumentException.class, () -> this.productQueryBuilder.getProductCriteria(
                CustomerProductQueryParams.getBuilder().build(), ProductQueryBuilderParams.builder().build(),
                null));
    }

    @Test
    void getProductCriteriaNullIntervenerTypeTest() {
        assertThrows(IllegalArgumentException.class, () -> this.productQueryBuilder.getProductCriteria(
                CustomerProductQueryParams.getBuilder().build(),
                ProductQueryBuilderParams.builder()
                        .productGroupId("test")
                        .build(), null));
    }

    @Test
    void getProductCriteriaNoChannelEMPUseProductConfigurationTest(){
        final Criteria criteria = this.productQueryBuilder.getProductCriteria(
                CustomerProductQueryParams.getBuilder().application("test").segment("test")
                        .customer_id("F000000001").build(),
                ProductQueryBuilderParams.builder()
                        .productGroupId("test")
                        .contractStates(Optional.of(Collections.singletonList("NR")))
                        .intervenerType(Collections.singletonList("01"))
                        .intervenerOrder(Optional.of(1))
                        .useProductConfiguration(true)
                        .build(),
                Arrays.asList("F000000001")
        );

        final List<TestContract> contracts = this.testContractRepository.findAll(null, TestContract.class,
                criteria).getContent();
        Assertions.assertThat(contracts).hasSize(1);
        Assertions.assertThat(contracts.get(0).getIdContrato()).isEqualTo("004913311030000100");
    }

    @Test
    void getProductCriteriaNoChannelEMPContractTypeTest(){
        final Criteria criteria = this.productQueryBuilder.getProductCriteria(
                CustomerProductQueryParams.getBuilder().application("test").segment("test")
                        .customer_id("F000000001").build(),
                ProductQueryBuilderParams.builder()
                        .productGroupId("test")
                        .contractStates(Optional.of(Collections.singletonList("NR")))
                        .intervenerType(Collections.singletonList("01"))
                        .intervenerOrder(Optional.of(1))
                        .useProductConfiguration(false)
                        .contractType(Optional.of("testContract"))
                        .build(),
                Arrays.asList("F000000001")
        );

        final List<TestContract> contracts = this.testContractRepository.findAll(null, TestContract.class,
                criteria).getContent();
        Assertions.assertThat(contracts).hasSize(1);
        Assertions.assertThat(contracts.get(0).getIdContrato()).isEqualTo("004913311030000100");
    }

    @Test
    void getProductCriteriaUserIncludedContractTest(){
        final CustomerProductQueryParams productQueryParams
                = CustomerProductQueryParams.getBuilder().application("test").segment("test")
                .customer_id("F000000002").build();
        final ProductQueryBuilderParams productQueryBuilderParams = ProductQueryBuilderParams.builder()
                .productGroupId("test")
                .contractStates(Optional.of(Collections.singletonList("NR")))
                .intervenerType(Collections.singletonList("01"))
                .intervenerOrder(Optional.of(1))
                .useProductConfiguration(true)
                .build();
        var customerIdList = Arrays.asList("F000000002");

        // Mock channel to get EMP channel.
        TestConfiguration.mockSantanderChannel("EMP");

        // Mock filters for included contracts
        this.mockFilters(Collections.singletonList(ProductGroup.FILTER_OB_INCLUDED_CONTRACTS));

        // This user has an included contract in the past, so no contract should be returned
        this.mockTokenUser("ATEST1");
        Criteria criteria = this.productQueryBuilder.getProductCriteria(
                productQueryParams,
                productQueryBuilderParams,
                customerIdList);
        List<TestContract> contracts = this.testContractRepository.findAll(null,
                TestContract.class, criteria).getContent();
        Assertions.assertThat(contracts.size()).isEqualTo(3);

        // This user has an included contract at this moment
        this.mockTokenUser("ATEST2");
        criteria = this.productQueryBuilder.getProductCriteria(
                productQueryParams,
                productQueryBuilderParams,
                customerIdList);
        contracts = this.testContractRepository.findAll(null, TestContract.class, criteria).getContent();
        Assertions.assertThat(contracts).hasSize(3);
        Assertions.assertThat(contracts.get(0).getIdContrato()).isEqualTo("004913311030000102");
    }

    @Test
    void getProductCriteriaUserExcludedContractsTest() {
        CustomerProductQueryParams productQueryParams
                = CustomerProductQueryParams.getBuilder().application("test").segment("test")
                .customer_id("F000000002").build();
        final ProductQueryBuilderParams productQueryBuilderParams = ProductQueryBuilderParams.builder()
                .productGroupId("test")
                .contractStates(Optional.of(Collections.singletonList("NR")))
                .intervenerType(Collections.singletonList("01"))
                .intervenerOrder(Optional.of(1))
                .useProductConfiguration(true)
                .build();
        var customerIdList = Arrays.asList("F000000002");

        // Mock channel to get EMP channel.
        TestConfiguration.mockSantanderChannel("EMP");

        // Mock filters for excluded contracts
        this.mockFilters(Collections.singletonList(ProductGroup.FILTER_OB_EXCLUDED_CONTRACTS));

        // This user has only one excluded contract for this customer.
        productQueryParams.setCustomer_id("F000000003");
        var customerIdListF3 = Arrays.asList("F000000003");
        this.mockTokenUser("ATEST3");
        Criteria criteria = this.productQueryBuilder.getProductCriteria(
                productQueryParams,
                productQueryBuilderParams,
                customerIdListF3);
        List<TestContract> contracts = this.testContractRepository.findAll(null,
                TestContract.class, criteria).getContent();
        Assertions.assertThat(contracts.size()).isEqualTo(1);

        // This user has 1 contract included and excluded at the same time so no contract will be returned.
        this.mockTokenUser("ATEST4");
        criteria = this.productQueryBuilder.getProductCriteria(
                productQueryParams,
                productQueryBuilderParams,
                customerIdListF3);
        contracts = this.testContractRepository.findAll(null, TestContract.class, criteria).getContent();
        Assertions.assertThat(contracts.size()).isEqualTo(1);

        // This user has an included contract and an excluded contract for this customer, so only 1 contract will
        // be returned
        productQueryParams.setCustomer_id("F000000002");
        this.mockFilters(Arrays.asList(ProductGroup.FILTER_OB_INCLUDED_CONTRACTS,
                ProductGroup.FILTER_OB_EXCLUDED_CONTRACTS));
        this.mockTokenUser("ATEST2");
        criteria = this.productQueryBuilder.getProductCriteria(
                productQueryParams,
                productQueryBuilderParams,
                customerIdList);
        contracts = this.testContractRepository.findAll(null, TestContract.class, criteria).getContent();
        Assertions.assertThat(contracts).hasSize(3);
        Assertions.assertThat(contracts.get(0).getIdContrato()).isEqualTo("004913311030000102");
    }

    @Test
    void getProductCriteriaUserAllFundsContractTest(){
        final CustomerProductQueryParams productQueryParams
                = CustomerProductQueryParams.getBuilder().application("test").segment("test")
                .customer_id("F000000002").build();
        final ProductQueryBuilderParams productQueryBuilderParams = ProductQueryBuilderParams.builder()
                .productGroupId("test")
                .contractStates(Optional.of(Collections.singletonList("NR")))
                .intervenerType(Collections.singletonList("01"))
                .intervenerOrder(Optional.of(1))
                .useProductConfiguration(true)
                .build();
        var customerIdList = Arrays.asList("F000000002");

        // Mock channel to get EMP channel.
        TestConfiguration.mockSantanderChannel("EMP");

        // Mock filters for included contracts
        this.mockFilters(Collections.singletonList(ProductGroup.FILTER_OB_INCLUDED_OR_EXCLUDED_AND_INTERVENER));

        // 3 contracts as titular with F000000002
        this.mockTokenUser("ATEST1");
        Criteria criteria = this.productQueryBuilder.getProductCriteria(
                productQueryParams,
                productQueryBuilderParams,
                customerIdList);
        List<TestContract> contracts = this.testContractRepository.findAll(null,
                TestContract.class, criteria).getContent();
        Assertions.assertThat(contracts).hasSize(3);

        this.mockTokenUser("ATEST2");
        criteria = this.productQueryBuilder.getProductCriteria(
                productQueryParams,
                productQueryBuilderParams,
                customerIdList);
        contracts = this.testContractRepository.findAll(null, TestContract.class, criteria).getContent();
        Assertions.assertThat(contracts).hasSize(3);
        Assertions.assertThat(contracts.get(0).getIdContrato()).isEqualTo("004913311030000102");

        // 4 contracts, 3 as titular and 1 as filial
        this.mockTokenUser("ATEST13");
        criteria = this.productQueryBuilder.getProductCriteria(
                productQueryParams,
                productQueryBuilderParams,
                customerIdList);
        contracts = this.testContractRepository.findAll(null, TestContract.class, criteria).getContent();
        Assertions.assertThat(contracts).hasSize(3);
    }

    @Test
    void getProductCriteriaExcludedCustomerIdTest(){
        final CustomerProductQueryParams productQueryParams
                = CustomerProductQueryParams.getBuilder().application("test").segment("test")
                .excluded_customer_id("F000000002").build();
        final ProductQueryBuilderParams productQueryBuilderParams = ProductQueryBuilderParams.builder()
                .productGroupId("test")
                .contractStates(Optional.of(Collections.singletonList("NR")))
                .intervenerType(Collections.singletonList("01"))
                .intervenerOrder(Optional.of(1))
                .useProductConfiguration(true)
                .build();

        // Mock channel to get OFI channel.
        TestConfiguration.mockSantanderChannel("OFI");

        final Criteria criteria = this.productQueryBuilder.getProductCriteria(
                productQueryParams,
                productQueryBuilderParams,
                Collections.emptyList());
        List<TestContract> contracts = this.testContractRepository.findAll(null, TestContract.class,
                criteria).getContent();
        Assertions.assertThat(contracts).hasSize(4);
        Assertions.assertThat(contracts.get(0).getIdContrato()).isEqualTo("004913311030000100");
        Assertions.assertThat(contracts.get(1).getIdContrato()).isEqualTo("004913311030000103");
        Assertions.assertThat(contracts.get(2).getIdContrato()).isEqualTo("004956688090000355");
    }

    @Test
    void checkContractStatesOnlyActives(){
        final CustomerProductQueryParams productQueryParams
                = CustomerProductQueryParams.getBuilder().application("test").segment("test")
                .customer_id("F000000711").build();
        final ProductQueryBuilderParams productQueryBuilderParams = ProductQueryBuilderParams.builder()
                .productGroupId("test")
                .contractStates(Optional.of(Arrays.asList("NR")))
                .intervenerType(Collections.singletonList("01"))
                .intervenerOrder(Optional.of(1))
                .useProductConfiguration(true)
                .build();
        var customerIdList = Arrays.asList("F000000711");

        // Mock channel to get EMP channel.
        TestConfiguration.mockSantanderChannel("OFI");

        final Criteria criteria = this.productQueryBuilder.getProductCriteria(productQueryParams,
                productQueryBuilderParams, customerIdList);
        List<TestContract> contracts = this.testContractRepository.findAll(null,
                TestContract.class, criteria).getContent();
        Assertions.assertThat(contracts).hasSize(1);
        Assertions.assertThat(contracts.get(0).getIdContrato()).isEqualTo("004956688090000355");

    }

    @Test
    void checkContractStatesALL(){
        final CustomerProductQueryParams productQueryParams
                = CustomerProductQueryParams.getBuilder().application("test").segment("test")
                .customer_id("F000000711").build();
        final ProductQueryBuilderParams productQueryBuilderParams = ProductQueryBuilderParams.builder()
                .productGroupId("test")
                .contractStates(Optional.of(Arrays.asList("NR","CA")))
                .intervenerType(Collections.singletonList("01"))
                .intervenerOrder(Optional.of(1))
                .interveneerExpirationFilter(false)
                .useProductConfiguration(true)
                .build();
        var customerIdList = Arrays.asList("F000000711");

        // Mock channel to get EMP channel.
        TestConfiguration.mockSantanderChannel("OFI");

        final Criteria criteria = this.productQueryBuilder.getProductCriteria(productQueryParams,
                productQueryBuilderParams, customerIdList);
        List<TestContract> contracts = this.testContractRepository.findAll(null,
                TestContract.class, criteria).getContent();
        Assertions.assertThat(contracts).hasSize(3);
        Assertions.assertThat(contracts.get(0).getIdContrato()).isEqualTo("004956688090000355");

    }


    /**
     * Mocks token user for tests
     *
     * @param user User id
     */
    private void mockTokenUser(String user) {
        TestConfiguration.mockInternalUser(user);
    }

    /**
     * Mocks user filters
     * @param filters Filter list
     */
    private void mockFilters(List<String> filters) {
        Mockito.when(this.productGroupService.getProductGroup(ArgumentMatchers.any(), ArgumentMatchers.any()))
                .thenReturn(ProductGroup.builder().filters(filters).build());
    }
}