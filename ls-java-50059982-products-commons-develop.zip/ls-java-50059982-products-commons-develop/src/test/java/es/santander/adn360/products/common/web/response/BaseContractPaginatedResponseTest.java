package es.santander.adn360.products.common.web.response;

import es.santander.adn360.core.model.exception.FunctionalException;
import es.santander.adn360.products.common.service.TestContract;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Arrays;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class BaseContractPaginatedResponseTest {

    private TestBaseContractPaginatedResponseImpl baseContractPaginatedResponse;

    @BeforeEach
    public void setup() {
        this.baseContractPaginatedResponse = TestBaseContractPaginatedResponseImpl.builder()
                .testContracts(Arrays.asList(
                        TestContract.builder().idContrato("004903001000000000").build(),
                        TestContract.builder().idContrato("004903001000000001").build(),
                        TestContract.builder().idContrato("004903001000000002").build(),
                        TestContract.builder().idContrato("004903001000000003").build(),
                        TestContract.builder().idContrato("004903001000000004").build(),
                        TestContract.builder().idContrato("004903001000000005").build(),
                        TestContract.builder().idContrato("004903001000000006").build(),
                        TestContract.builder().idContrato("004903001000000007").build()))
                .build();
    }

    @Test
    public void testGetOffsetByIdWhenIdIsNull() {
        assertThat(baseContractPaginatedResponse.getOffsetById(null)).isEqualTo(0);
    }

    @Test
    public void testGetOffsetByIdWhenIdIsEmpty() {
        assertThat(baseContractPaginatedResponse.getOffsetById("")).isEqualTo(0);
    }

    @Test
    public void testGetOffsetByIdWhenIdIsZero() {
        assertThat(baseContractPaginatedResponse.getOffsetById("0")).isEqualTo(0);
    }

    @Test
    public void testGetOffsetByIdWhenNotFound() {
    	assertThrows(FunctionalException.class, () -> this.baseContractPaginatedResponse.getOffsetById("004903001000000008"));
    }

    @Test
    public void testGetOffsetByIdOk() {
        assertThat(baseContractPaginatedResponse.getOffsetById("004903001000000004")).isEqualTo(4);
    }

    @Test
    public void testGetIdByOffsetWhenIndexError() {
    	assertThrows(Exception.class, () -> this.baseContractPaginatedResponse.getIdByOffset(Long.valueOf(-1)));
    }

    @Test
    public void testGetIdByOffsetOk() {
        assertThat(baseContractPaginatedResponse.getIdByOffset(Long.valueOf(0)))
                .isEqualToIgnoringCase("004903001000000000");
    }

    @Test
    public void testIsValidOffsetWhenIdIsNull() {
        assertThat(baseContractPaginatedResponse.isValidOffset(null)).isTrue();
    }

    @Test
    public void testIsValidOffsetWhenIdIsEmpty() {
        assertThat(baseContractPaginatedResponse.isValidOffset("")).isTrue();
    }

    @Test
    public void testIsValidOffsetWhenIdIsZero() {
        assertThat(baseContractPaginatedResponse.isValidOffset("0")).isTrue();
    }

    @Test
    public void testIsValidOffsetWhenIsInvalidId() {
        assertThat(baseContractPaginatedResponse.isValidOffset("0000")).isFalse();
        assertThat(baseContractPaginatedResponse.isValidOffset("0000000000000000000000")).isFalse();
    }

    @Test
    public void testIsValidOffsetOk() {
        assertThat(baseContractPaginatedResponse.isValidOffset("000000000000000000")).isTrue();
    }

}
