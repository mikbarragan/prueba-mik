package es.santander.adn360.products.common.service;

import es.santander.adn360.mongodb.starter.autoconfigure.MongoQueryRepositoryAutoConfiguration;
import es.santander.adn360.mongodb.starter.domain.MongoQueryRepositoryImpl;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.repository.support.MongoRepositoryFactory;
import org.springframework.stereotype.Repository;

@Repository
@ConditionalOnClass(MongoQueryRepositoryAutoConfiguration.class)
public class TestContractRepository extends MongoQueryRepositoryImpl<TestContract, String> {

    /**
     * Class constructor with dependency injection for MongoQueryRepositoryImpl.
     *
     * @param mongoRepositoryFactory MongoRepositoryFactory
     * @param mongoOperations        MongoOperations
     */
    public TestContractRepository(MongoRepositoryFactory mongoRepositoryFactory, MongoOperations mongoOperations) {
        super(mongoRepositoryFactory.getEntityInformation(TestContract.class), mongoOperations);
    }
}
