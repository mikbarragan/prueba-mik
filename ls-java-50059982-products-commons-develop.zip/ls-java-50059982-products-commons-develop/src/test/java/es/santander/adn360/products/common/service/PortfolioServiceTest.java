package es.santander.adn360.products.common.service;


import es.santander.adn360.core.model.portfolio.PortfolioFilterType;
import es.santander.adn360.core.model.portfolio.PortfolioQueryParams;
import es.santander.adn360.core.util.CustomerProductQueryParams;
import es.santander.adn360.products.common.config.ServicesProperties;
import es.santander.adn360.products.common.domain.PortfolioBaseContract;
import es.santander.adn360.products.common.domain.PortfolioContract;
import es.santander.adn360.products.common.domain.PortfolioType;
import es.santander.adn360.products.common.repository.PortfoliosRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.Map;
import java.util.stream.Stream;

import static es.santander.adn360.products.common.service.PortfolioServiceImpl.ALL_FILTER;
import static es.santander.adn360.products.common.service.PortfolioServiceImpl.ANYPORTFOLIO_FILTER;
import static es.santander.adn360.products.common.service.PortfolioServiceImpl.DEFAULT_FILTER;
import static es.santander.adn360.products.common.service.PortfolioServiceImpl.MANAGED_FILTER;
import static es.santander.adn360.products.common.service.PortfolioServiceImpl.NONE_FILTER;
import static es.santander.adn360.products.common.service.PortfolioServiceImpl.UNMANAGED_FILTER;
import static java.util.stream.Collectors.toList;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

class PortfolioServiceTest {

    @Mock PortfoliosRepository pfRepo;

    @Mock ServicesProperties servicesProperties;

    @InjectMocks PortfolioServiceImpl pfService;

    PortfolioService portFolioServ = spy(PortfolioService.class);

    static final String CONTRATO_1 = "004906583050000286";
    static final String CONTRATO_2 = "004900101530910919";
    static final String CONTRATO_3 = "004900101530910920";
    static final String CONTRATO_4 = "004900101530910922";
    static final String CONTRATO_5 = "004900101530910923";
    static final String CONTRATO_6 = "004900101530910924";

    static final String CTR_GE = "004906583050000286";
    static final String CTR_AS = "004906583050000288";
    static final String CTR_NA = "004906583050000289";
    static final String CTR_ZZ = "004906583050000333";
    static final String CTR_EMPTY = "004906583050000334";
    static final String CTR_RELACION_BAJA = "004906583050000299";

    static final CustomerProductQueryParams emptyParams = CustomerProductQueryParams.getBuilder().build();

    @BeforeEach
    public void setUp() {
        initMocks(this);

        final var managedPortfolioService = new ServicesProperties.ManagedPortfolioService();
        managedPortfolioService.setTiposCartera(List.of("GE"));
        managedPortfolioService.setCarterasConGestion(List.of("GE"));
        managedPortfolioService.setCarterasSinGestion(List.of("AS", "NA"));
        managedPortfolioService.setPortfolioFilterTypeValues(
                Map.of(PortfolioFilterType.MANAGED.getValue(), List.of("GE"),
                        PortfolioFilterType.NOT_ADMINISTERED.getValue(), List.of("NA"),
                        PortfolioFilterType.ADVISED.getValue(), List.of("AS"),
                        PortfolioFilterType.NOT_MANAGED.getValue(), List.of("AS", "NA"),
                        PortfolioFilterType.REST.getValue(), List.of("GE", "NA", "AS")));

        when(servicesProperties.getManagedPortfolioService()).thenReturn(managedPortfolioService);
    }

    @Test void callWithContractsWithouthContratoCarteraReturnTheSameContracts() {

        final var contracts = List.of(buildContract(CONTRATO_1), buildContract(CONTRATO_2));

        final var sut = pfService.getContractsFilteredByCarteraType(contracts, emptyParams);

        assertThat(sut).isEqualTo(contracts);
        assertThat(sut.get(0).getSiga()).isNull();
        assertThat(sut.get(1).getSiga()).isNull();
    }

    @Test void callWithNullContratctsReturnError() {

        assertThrows(IllegalArgumentException.class, () -> this.pfService.getContractsFilteredByCarteraType(null, emptyParams));
    }

    @Test void callWithContractAndWithNullCustomerProductQueryParamsReturnError() {

        final var contracs = List.of(buildContract(CONTRATO_1), buildContract(CONTRATO_2));

        assertThrows(IllegalArgumentException.class, () -> this.pfService.getContractsFilteredByCarteraType(contracs, null));
    }

    @Test void callWithContractsWithContratoCarteraReturnContractsWithSigaANDfilterPortfoliosNotAllowed() {

        final var contract = new PortfolioBaseContract();
        contract.setIdContrato(CONTRATO_1);
        contract.setContratoCartera(CTR_GE);

        final var contract2 = new PortfolioBaseContract();
        contract2.setIdContrato(CONTRATO_2);
        contract2.setContratoCartera(CTR_AS);

        final var contract3 = new PortfolioBaseContract();
        contract3.setIdContrato(CONTRATO_3);
        contract3.setContratoCartera(CTR_NA);

        when(pfRepo.callToPortfolios(List.of(CTR_GE, CTR_AS, CTR_NA), emptyParams)).thenReturn(List.of(
                PortfolioType.builder().idPortfolioContract(CTR_GE).typePortfolio("GE").siga("58NPORERMASD32").build(),
                PortfolioType.builder().idPortfolioContract(CTR_AS).typePortfolio("AS").siga("58NPORERMASD22").build(),
                PortfolioType.builder().idPortfolioContract(CTR_NA).typePortfolio("NA").siga("58NPORERMA789").build()
        ));

        final var sut = pfService.getContractsFilteredByCarteraType(
                List.of(contract, contract2, contract3), emptyParams
        );

        assertThat(sut).hasSize(2);
        assertThat(sut.get(0).getSiga()).isEqualTo("58NPORERMASD22");
        assertThat(sut.get(1).getSiga()).isEqualTo("58NPORERMA789");

        sut.stream()
                .filter(c -> ! CollectionUtils.isEmpty(c.getContratosCarteras()))
                .flatMap(c -> c.getContratosCarteras().stream())
                .map(PortfolioContract::getContratoCartera)
                .distinct()
                .forEach(c -> assertThat(c).isNotEqualTo(CTR_RELACION_BAJA));
    }

    @Test void callWithContractsWithouthContratoCarteraAndWithouthANDfilterPortfoliosNotAllowed() {

        final var contract = new PortfolioBaseContract();
        contract.setIdContrato(CONTRATO_1);
        contract.setContratoCartera(CTR_GE);

        final var contract2 = new PortfolioBaseContract();
        contract2.setIdContrato(CONTRATO_2);
        contract2.setContratoCartera(CTR_AS);

        final var contract3 = new PortfolioBaseContract();
        contract3.setIdContrato(CONTRATO_3);
        contract3.setContratoCartera(CTR_NA);

        final var contract4 = new PortfolioBaseContract();
        contract4.setIdContrato(CONTRATO_4);

        when(pfRepo.callToPortfolios(List.of(CTR_GE, CTR_AS, CTR_NA), emptyParams)).thenReturn(List.of(
                PortfolioType.builder().idPortfolioContract(CTR_GE).typePortfolio("GE").siga("58NPORERMASD32").build(),
                PortfolioType.builder().idPortfolioContract(CTR_AS).typePortfolio("AS").siga("58NPORERMASD22").build(),
                PortfolioType.builder().idPortfolioContract(CTR_NA).typePortfolio("NA").siga("58NPORERMA789").build()
        ));

        final var sut = pfService.getContractsFilteredByCarteraType(
                List.of(contract, contract2, contract3, contract4), emptyParams
        );

        assertThat(sut).hasSize(3);
        assertThat(sut.get(0).getSiga()).isEqualTo("58NPORERMASD22");
        assertThat(sut.get(1).getSiga()).isEqualTo("58NPORERMA789");
        assertThat(sut.get(2).getSiga()).isNull();

        sut.stream()
                .filter(c -> ! CollectionUtils.isEmpty(c.getContratosCarteras()))
                .flatMap(c -> c.getContratosCarteras().stream())
                .map(PortfolioContract::getContratoCartera)
                .distinct()
                .forEach(c -> assertThat(c).isNotEqualTo(CTR_RELACION_BAJA));
    }

    @Test void responseSameRequestWhenPortfolioRequestResponseEmptyList() {

        final var contract = new PortfolioBaseContract();
        contract.setIdContrato(CONTRATO_1);
        contract.setContratoCartera(CTR_GE);

        final var contract2 = new PortfolioBaseContract();
        contract2.setIdContrato(CONTRATO_2);
        contract2.setContratoCartera(CTR_AS);

        final var contract3 = new PortfolioBaseContract();
        contract3.setIdContrato(CONTRATO_3);
        contract3.setContratoCartera(CTR_NA);

        final var contract4 = new PortfolioBaseContract();
        contract4.setIdContrato(CONTRATO_4);
        contract4.setContratoCartera(CTR_ZZ);

        final var contract5 = new PortfolioBaseContract();
        contract5.setIdContrato(CONTRATO_5);

        when(pfRepo.callToPortfolios(List.of(CTR_GE, CTR_AS, CTR_NA, CTR_ZZ), emptyParams)).thenReturn(Collections.emptyList());

        final var sut = pfService.getContractsFilteredByCarteraType(
                List.of(contract, contract2, contract3, contract4, contract5), emptyParams);

        assertThat(sut).hasSize(5);

        sut.stream()
                .filter(c -> ! CollectionUtils.isEmpty(c.getContratosCarteras()))
                .flatMap(c -> c.getContratosCarteras().stream())
                .map(PortfolioContract::getContratoCartera)
                .distinct()
                .forEach(c -> assertThat(c).isNotEqualTo(CTR_RELACION_BAJA));
    }

    @Test void getContractsFilteredByContratosCarterasType() {

        final var c1 = buildContract(CONTRATO_1, CTR_GE, CTR_GE, CTR_RELACION_BAJA, CTR_EMPTY, CTR_ZZ);
        final var c2 = buildContract(CONTRATO_2,CTR_AS, CTR_RELACION_BAJA, CTR_EMPTY, CTR_ZZ);

        when(pfRepo.callToPortfolios(any(), any())).thenReturn(List.of(
                PortfolioType.builder().idPortfolioContract(CTR_GE).typePortfolio("GE").siga("58NPORERMASD32").build(),
                PortfolioType.builder().idPortfolioContract(CTR_AS).typePortfolio("AS").siga("58NPORERMASD22").build(),
                PortfolioType.builder().idPortfolioContract(CTR_NA).typePortfolio("NA").siga("58NPORERMA789").build(),
                PortfolioType.builder().idPortfolioContract(CTR_ZZ).typePortfolio("ZZ").siga("58NPORERMASD23").build(),
                PortfolioType.builder().idPortfolioContract(CTR_EMPTY).siga("58NPORERMA790").build()
        ));

        final var sut = pfService.getContractsFilteredByContratosCarterasType(
                List.of(c1, c2), emptyParams
        );

        assertThat(sut).hasSize(1);

        final var sut0 = sut.get(0);
        assertThat(sut0.getIdContrato()).isEqualTo(CONTRATO_2);
        assertThat(sut0.getContratosCarteras()).hasSize(4);

    }

    @Test void getContractsFilteredByContratosCarterasType_UNMANAGED() {

        final var c1 = buildContract(CONTRATO_1, CTR_GE, CTR_GE, CTR_RELACION_BAJA, CTR_EMPTY);
        final var c2 = buildContract(CONTRATO_2, CTR_RELACION_BAJA, CTR_EMPTY);
        final var c3 = buildContract(CONTRATO_3, CTR_AS, CTR_AS, CTR_RELACION_BAJA, CTR_EMPTY); // NO GESTIONADA
        final var c4 = buildContract(CONTRATO_4, CTR_NA, CTR_AS, CTR_EMPTY); // NO GESTIONADA
        final var c5 = buildContract(CONTRATO_5, CTR_EMPTY);
        final var c6 = buildContract(CONTRATO_6, CTR_EMPTY, CTR_ZZ);

        when(pfRepo.callToPortfolios(any(), any())).thenReturn(List.of(
                PortfolioType.builder().idPortfolioContract(CTR_GE).typePortfolio("GE").siga("58NPORERMASD32").build(),
                PortfolioType.builder().idPortfolioContract(CTR_AS).typePortfolio("AS").siga("58NPORERMASD22").build(),
                PortfolioType.builder().idPortfolioContract(CTR_NA).typePortfolio("NA").siga("58NPORERMA789").build(),
                PortfolioType.builder().idPortfolioContract(CTR_ZZ).typePortfolio("ZZ").siga("58NPORERMASD23").build(),
                PortfolioType.builder().idPortfolioContract(CTR_EMPTY).siga("58NPORERMA790").build()
        ));

        final var sut = pfService.getContractsFilteredByContratosCarterasType(
                List.of(c1, c2, c3, c4, c5, c6), emptyParams, UNMANAGED_FILTER
        );

        assertThat(sut).hasSize(2);

        final var sut0 = sut.get(0);
        assertThat(sut0.getIdContrato()).isEqualTo(CONTRATO_3);
        assertThat(sut0.getContratosCarteras()).hasSize(2);
        assertThat(sut0.getContratosCarteras().get(0).getTipoCartera()).isEqualTo("AS");
        assertThat(sut0.getContratosCarteras().get(0).getSiga()).isEqualTo("58NPORERMASD22");
        assertThat(sut0.getContratosCarteras().get(1).getTipoCartera()).isEqualTo("AS");
        assertThat(sut0.getContratosCarteras().get(1).getSiga()).isEqualTo("58NPORERMASD22");

        final var sut1 = sut.get(1);
        assertThat(sut1.getIdContrato()).isEqualTo(CONTRATO_4);
        assertThat(sut1.getContratosCarteras().get(0).getTipoCartera()).isEqualTo("NA");
        assertThat(sut1.getContratosCarteras().get(0).getSiga()).isEqualTo("58NPORERMA789");
        assertThat(sut1.getContratosCarteras().get(1).getTipoCartera()).isEqualTo("AS");
        assertThat(sut1.getContratosCarteras().get(1).getSiga()).isEqualTo("58NPORERMASD22");

        sut.stream()
                .filter(c -> ! CollectionUtils.isEmpty(c.getContratosCarteras()))
                .flatMap(c -> c.getContratosCarteras().stream())
                .map(PortfolioContract::getContratoCartera)
                .distinct()
                .forEach(c -> assertThat(c).isNotEqualTo(CTR_RELACION_BAJA));
    }

    @Test void getContractsFilteredByContratosCarterasTypeTest_MANAGED() {

        final var c1 = buildContract(CONTRATO_1, CTR_GE, CTR_GE, CTR_RELACION_BAJA, CTR_EMPTY);
        final var c2 = buildContract(CONTRATO_2, CTR_RELACION_BAJA, CTR_EMPTY);
        final var c3 = buildContract(CONTRATO_3, CTR_AS, CTR_NA, CTR_EMPTY);
        final var c4 = buildContract(CONTRATO_4, CTR_AS, CTR_NA, CTR_RELACION_BAJA, CTR_EMPTY);
        final var c5 = buildContract(CONTRATO_5, CTR_EMPTY);
        final var c6 = buildContract(CONTRATO_6, CTR_EMPTY, CTR_ZZ);

        when(pfRepo.callToPortfolios(any(), any())).thenReturn(List.of(
                PortfolioType.builder().idPortfolioContract(CTR_GE).typePortfolio("GE").siga("58NPORERMASD32").build(),
                PortfolioType.builder().idPortfolioContract(CTR_AS).typePortfolio("AS").siga("58NPORERMASD22").build(),
                PortfolioType.builder().idPortfolioContract(CTR_NA).typePortfolio("NA").siga("58NPORERMA789").build(),
                PortfolioType.builder().idPortfolioContract(CTR_RELACION_BAJA).typePortfolio("BJ").siga("58NPORERMA790").build(),
                PortfolioType.builder().idPortfolioContract(CTR_ZZ).typePortfolio("ZZ").siga("58NPORERMASD23").build(),
                PortfolioType.builder().idPortfolioContract(CTR_EMPTY).siga("58NPORERMA790").build()
        ));

        final var sut = pfService.getContractsFilteredByContratosCarterasType(
                List.of(c1, c2, c3, c4, c5, c6), emptyParams, MANAGED_FILTER
        );

        assertThat(sut).hasSize(1);
        assertThat(sut.get(0).getIdContrato()).isEqualTo(CONTRATO_1);
        assertThat(sut.get(0).getContratosCarteras()).hasSize(2);
        assertThat(sut.get(0).getContratosCarteras().get(0).getSiga()).isEqualTo("58NPORERMASD32");
        assertThat(sut.get(0).getContratosCarteras().get(0).getTipoCartera()).isEqualTo("GE");
        assertThat(sut.get(0).getContratosCarteras().get(1).getSiga()).isEqualTo("58NPORERMASD32");
        assertThat(sut.get(0).getContratosCarteras().get(1).getTipoCartera()).isEqualTo("GE");

        sut.stream()
                .filter(c -> ! CollectionUtils.isEmpty(c.getContratosCarteras()))
                .flatMap(c -> c.getContratosCarteras().stream())
                .map(PortfolioContract::getContratoCartera)
                .distinct()
                .forEach(c -> assertThat(c).isNotEqualTo(CTR_RELACION_BAJA));
    }

    @Test void getContractsFilteredByContratosCarterasTypeTest_ALL() {

        final var contracts = List.of(
                buildContract(CONTRATO_1, CTR_GE, CTR_RELACION_BAJA, CTR_EMPTY), // GESTIONADA
                buildContract(CONTRATO_2, CTR_RELACION_BAJA, CTR_EMPTY), // NONE
                buildContract(CONTRATO_3, CTR_AS, CTR_RELACION_BAJA, CTR_EMPTY), // NO GESTIONADA
                buildContract(CONTRATO_4, CTR_NA, CTR_GE, CTR_RELACION_BAJA, CTR_EMPTY),
                buildContract(CONTRATO_5, CTR_EMPTY),
                buildContract(CONTRATO_6, CTR_EMPTY, CTR_ZZ)
        );

        when(pfRepo.callToPortfolios(any(), any())).thenReturn(List.of(
                PortfolioType.builder().idPortfolioContract(CTR_GE).typePortfolio("GE").siga("58NPORERMASD32").build(),
                PortfolioType.builder().idPortfolioContract(CTR_AS).typePortfolio("AS").siga("58NPORERMASD22").build(),
                PortfolioType.builder().idPortfolioContract(CTR_NA).typePortfolio("NA").siga("58NPORERMA789").build(),
                PortfolioType.builder().idPortfolioContract(CTR_RELACION_BAJA).typePortfolio("BJ").siga("58NPORERMA790").build(),
                PortfolioType.builder().idPortfolioContract(CTR_ZZ).typePortfolio("ZZ").siga("58NPORERMASD23").build(),
                PortfolioType.builder().idPortfolioContract(CTR_EMPTY).siga("58NPORERMA790").build()
        ));

        final var sut = pfService.getContractsFilteredByContratosCarterasType(
                contracts, emptyParams, ALL_FILTER
        );

        assertThat(sut).hasSize(6);

        sut.stream()
                .filter(c -> ! CollectionUtils.isEmpty(c.getContratosCarteras()))
                .flatMap(c -> c.getContratosCarteras().stream())
                .map(PortfolioContract::getContratoCartera)
                .distinct()
                .forEach(c -> assertThat(c).isNotEqualTo(CTR_RELACION_BAJA));
    }

    @Test void getContractsFilteredByContratosCarterasTypeTest_NONE() {

        final var c1 = buildContract(CONTRATO_1, CTR_GE, CTR_RELACION_BAJA, CTR_EMPTY);
        final var c2 = buildContract(CONTRATO_2, CTR_EMPTY);
        final var c3 = buildContract(CONTRATO_3, CTR_AS, CTR_NA, CTR_EMPTY);
        final var c4 = buildContract(CONTRATO_4, CTR_NA, CTR_EMPTY);
        final var c5 = buildContract(CONTRATO_6, CTR_EMPTY, CTR_ZZ);

        when(pfRepo.callToPortfolios(any(), any())).thenReturn(List.of(
                PortfolioType.builder().idPortfolioContract(CTR_GE).typePortfolio("GE").siga("58NPORERMASD32").build(),
                PortfolioType.builder().idPortfolioContract(CTR_AS).typePortfolio("AS").siga("58NPORERMASD22").build(),
                PortfolioType.builder().idPortfolioContract(CTR_NA).typePortfolio("NA").siga("58NPORERMA789").build(),
                PortfolioType.builder().idPortfolioContract(CTR_RELACION_BAJA).typePortfolio("BJ").siga("58NPORERMA790").build(),
                PortfolioType.builder().idPortfolioContract(CTR_ZZ).typePortfolio("ZZ").siga("58NPORERMASD23").build(),
                PortfolioType.builder().idPortfolioContract(CTR_EMPTY).siga("58NPORERMA790").build()
        ));

        final var sut = pfService.getContractsFilteredByContratosCarterasType(
                List.of(c1, c2, c3, c4, c5), emptyParams, NONE_FILTER
        );

        assertThat(sut).hasSize(1);
        assertThat(sut.get(0).getIdContrato()).isEqualTo(CONTRATO_2);

        sut.stream()
                .filter(c -> ! CollectionUtils.isEmpty(c.getContratosCarteras()))
                .flatMap(c -> c.getContratosCarteras().stream())
                .map(PortfolioContract::getContratoCartera)
                .distinct()
                .forEach(c -> assertThat(c).isNotEqualTo(CTR_RELACION_BAJA));
    }

    @Test void getContractsFilteredByContratosCarterasType_ANYPORTFOLIO() {

        final var c1 = buildContract(CONTRATO_1, CTR_GE, CTR_GE, CTR_RELACION_BAJA, CTR_EMPTY);
        final var c2 = buildContract(CONTRATO_2, CTR_RELACION_BAJA, CTR_EMPTY);
        final var c3 = buildContract(CONTRATO_3, CTR_AS, CTR_AS, CTR_EMPTY); // NO GESTIONADA
        final var c4 = buildContract(CONTRATO_4, CTR_NA, CTR_AS, CTR_EMPTY); // NO GESTIONADA
        final var c5 = buildContract(CONTRATO_5, CTR_EMPTY);
        final var c6 = buildContract(CONTRATO_6, CTR_EMPTY, CTR_ZZ);

        when(pfRepo.callToPortfolios(any(), any())).thenReturn(List.of(
                PortfolioType.builder().idPortfolioContract(CTR_GE).typePortfolio("GE").siga("58NPORERMASD32").build(),
                PortfolioType.builder().idPortfolioContract(CTR_AS).typePortfolio("AS").siga("58NPORERMASD22").build(),
                PortfolioType.builder().idPortfolioContract(CTR_NA).typePortfolio("NA").siga("58NPORERMA789").build(),
                PortfolioType.builder().idPortfolioContract(CTR_ZZ).typePortfolio("ZZ").siga("58NPORERMASD23").build(),
                PortfolioType.builder().idPortfolioContract(CTR_EMPTY).siga("58NPORERMA790").build()
        ));

        final var sut = pfService.getContractsFilteredByContratosCarterasType(
                List.of(c1, c2, c3, c4, c5, c6), emptyParams, ANYPORTFOLIO_FILTER
        );

        assertThat(sut).hasSize(3);
        assertThat(sut.get(0).getIdContrato()).isEqualTo(CONTRATO_1);
        assertThat(sut.get(1).getIdContrato()).isEqualTo(CONTRATO_3);
        assertThat(sut.get(2).getIdContrato()).isEqualTo(CONTRATO_4);

        sut.stream()
                .filter(c -> ! CollectionUtils.isEmpty(c.getContratosCarteras()))
                .flatMap(c -> c.getContratosCarteras().stream())
                .map(PortfolioContract::getContratoCartera)
                .distinct()
                .forEach(c -> assertThat(c).isNotEqualTo(CTR_RELACION_BAJA));
    }

    @Test void getContractsFilteredByContratosCarterasType_DEFAULT() {

        final var c1 = buildContract(CONTRATO_1, CTR_GE, CTR_GE, CTR_RELACION_BAJA, CTR_EMPTY);
        final var c2 = buildContract(CONTRATO_2, CTR_RELACION_BAJA, CTR_EMPTY);
        final var c3 = buildContract(CONTRATO_3, CTR_AS, CTR_AS, CTR_EMPTY); // NO GESTIONADA
        final var c4 = buildContract(CONTRATO_4, CTR_NA, CTR_AS, CTR_EMPTY); // NO GESTIONADA
        final var c5 = buildContract(CONTRATO_5, CTR_EMPTY);
        final var c6 = buildContract(CONTRATO_6, CTR_EMPTY, CTR_ZZ);

        when(pfRepo.callToPortfolios(any(), any())).thenReturn(List.of(
                PortfolioType.builder().idPortfolioContract(CTR_GE).typePortfolio("GE").siga("58NPORERMASD32").build(),
                PortfolioType.builder().idPortfolioContract(CTR_AS).typePortfolio("AS").siga("58NPORERMASD22").build(),
                PortfolioType.builder().idPortfolioContract(CTR_NA).typePortfolio("NA").siga("58NPORERMA789").build(),
                PortfolioType.builder().idPortfolioContract(CTR_ZZ).typePortfolio("ZZ").siga("58NPORERMASD23").build(),
                PortfolioType.builder().idPortfolioContract(CTR_EMPTY).siga("58NPORERMA790").build()
        ));

        final var sut = pfService.getContractsFilteredByContratosCarterasType(
                List.of(c1, c2, c3, c4, c5, c6), emptyParams, DEFAULT_FILTER
        );

        assertThat(sut).hasSize(4);
        assertThat(sut.get(0).getIdContrato()).isEqualTo(CONTRATO_2);
        assertThat(sut.get(1).getIdContrato()).isEqualTo(CONTRATO_3);
        assertThat(sut.get(2).getIdContrato()).isEqualTo(CONTRATO_4);
        assertThat(sut.get(3).getIdContrato()).isEqualTo(CONTRATO_5);

        sut.stream()
                .filter(c -> ! CollectionUtils.isEmpty(c.getContratosCarteras()))
                .flatMap(c -> c.getContratosCarteras().stream())
                .map(PortfolioContract::getContratoCartera)
                .distinct()
                .forEach(c -> assertThat(c).isNotEqualTo(CTR_RELACION_BAJA));
    }

    @Test void cheackAllStages() {

        final var CTR_NOT_EXIST = "noExiste";
        final var CTR_CON_BAJA = "baja";

        List<PortfolioBaseContract> contracts = new ArrayList<>();
        // NONE 5
        contracts.add(buildContract("none1"));
        contracts.add(buildContract("none2", CTR_RELACION_BAJA));
        contracts.add(buildContract("none3", CTR_NOT_EXIST));
        contracts.add(buildContract("none4", CTR_CON_BAJA));
        contracts.add(buildContract("none5", CTR_RELACION_BAJA, CTR_NOT_EXIST, CTR_CON_BAJA));

        // MAN 6
        contracts.add(buildContract("mana1", CTR_GE));
        contracts.add(buildContract("mana2", CTR_GE, CTR_NOT_EXIST));
        contracts.add(buildContract("mana3", CTR_GE, CTR_CON_BAJA));
        contracts.add(buildContract("mana4", CTR_GE, CTR_RELACION_BAJA));
        contracts.add(buildContract("mana5", CTR_GE, CTR_GE));
        contracts.add(buildContract("mana6", CTR_GE, CTR_GE, CTR_RELACION_BAJA, CTR_NOT_EXIST, CTR_CON_BAJA));

        // UN 10
        contracts.add(buildContract("unma1", CTR_AS));
        contracts.add(buildContract("unma2", CTR_AS, CTR_NOT_EXIST));
        contracts.add(buildContract("unma3", CTR_AS, CTR_CON_BAJA));
        contracts.add(buildContract("unma4", CTR_AS, CTR_RELACION_BAJA));
        contracts.add(buildContract("unma5", CTR_NA));
        contracts.add(buildContract("unma6", CTR_NA, CTR_NOT_EXIST));
        contracts.add(buildContract("unma7", CTR_NA, CTR_CON_BAJA));
        contracts.add(buildContract("unma8", CTR_NA, CTR_RELACION_BAJA));
        contracts.add(buildContract("unma9", CTR_NA, CTR_AS));
        contracts.add(buildContract("unma10", CTR_NA, CTR_AS, CTR_RELACION_BAJA, CTR_NOT_EXIST, CTR_CON_BAJA));

        // MIX 15
        contracts.add(buildContract("mixe1", CTR_AS, CTR_GE));
        contracts.add(buildContract("mixe2", CTR_AS, CTR_GE, CTR_NOT_EXIST));
        contracts.add(buildContract("mixe3", CTR_AS, CTR_GE, CTR_CON_BAJA));
        contracts.add(buildContract("mixe4", CTR_AS, CTR_GE, CTR_RELACION_BAJA));
        contracts.add(buildContract("mixe5", CTR_AS, CTR_GE, CTR_RELACION_BAJA, CTR_NOT_EXIST, CTR_CON_BAJA));
        contracts.add(buildContract("mixe6", CTR_NA, CTR_GE));
        contracts.add(buildContract("mixe7", CTR_NA, CTR_GE, CTR_NOT_EXIST));
        contracts.add(buildContract("mixe8", CTR_NA, CTR_GE, CTR_CON_BAJA));
        contracts.add(buildContract("mixe9", CTR_NA, CTR_GE, CTR_RELACION_BAJA));
        contracts.add(buildContract("mixe10", CTR_NA, CTR_GE, CTR_RELACION_BAJA, CTR_NOT_EXIST, CTR_CON_BAJA));
        contracts.add(buildContract("mixe11", CTR_AS, CTR_NA, CTR_GE));
        contracts.add(buildContract("mixe12", CTR_AS, CTR_NA, CTR_GE, CTR_NOT_EXIST));
        contracts.add(buildContract("mixe13", CTR_AS, CTR_NA, CTR_GE, CTR_CON_BAJA));
        contracts.add(buildContract("mixe14", CTR_AS, CTR_NA, CTR_GE, CTR_RELACION_BAJA));
        contracts.add(buildContract("mixe15", CTR_AS, CTR_NA, CTR_GE, CTR_RELACION_BAJA, CTR_NOT_EXIST, CTR_CON_BAJA));

        // MIX with ZZ and EMPTY
        contracts.add(buildContract("zzempty1", CTR_ZZ));
        contracts.add(buildContract("zzempty2", CTR_EMPTY));
        contracts.add(buildContract("zzempty3", CTR_ZZ, CTR_EMPTY));
        contracts.add(buildContract("zzempty4", CTR_AS, CTR_GE, CTR_RELACION_BAJA, CTR_EMPTY));
        contracts.add(buildContract("zzempty5", CTR_AS, CTR_GE, CTR_RELACION_BAJA, CTR_NOT_EXIST, CTR_CON_BAJA, CTR_EMPTY));
        contracts.add(buildContract("zzempty6", CTR_NA, CTR_GE, CTR_EMPTY));
        contracts.add(buildContract("zzempty7", CTR_NA, CTR_GE, CTR_NOT_EXIST, CTR_EMPTY));
        contracts.add(buildContract("zzempty8", CTR_GE, CTR_EMPTY, CTR_ZZ));
        contracts.add(buildContract("zzempty9", CTR_AS, CTR_GE, CTR_RELACION_BAJA, CTR_ZZ));
        contracts.add(buildContract("zzempty10", CTR_AS, CTR_GE, CTR_RELACION_BAJA, CTR_NOT_EXIST, CTR_CON_BAJA, CTR_EMPTY, CTR_ZZ ));
        contracts.add(buildContract("zzempty11", CTR_NA, CTR_GE, CTR_EMPTY, CTR_ZZ));
        contracts.add(buildContract("zzempty12", CTR_NA, CTR_GE, CTR_NOT_EXIST, CTR_EMPTY, CTR_ZZ));
        contracts.add(buildContract("zzempty13", CTR_GE, CTR_EMPTY, CTR_ZZ, CTR_ZZ));

        when(pfRepo.callToPortfolios(any(), any())).thenReturn(List.of(
                PortfolioType.builder().idPortfolioContract(CTR_GE).typePortfolio("GE").siga("58NPORERMASD32").build(),
                PortfolioType.builder().idPortfolioContract(CTR_AS).typePortfolio("AS").siga("58NPORERMASD22").build(),
                PortfolioType.builder().idPortfolioContract(CTR_NA).typePortfolio("NA").siga("58NPORERMA789").build(),
                PortfolioType.builder().idPortfolioContract(CTR_CON_BAJA).typePortfolio("BJ").siga("58NPORERMA789").build(),
                PortfolioType.builder().idPortfolioContract(CTR_ZZ).typePortfolio("ZZ").siga("58NPORERMASD23").build(),
                PortfolioType.builder().idPortfolioContract(CTR_EMPTY).siga("58NPORERMA790").build()
                // NO existe noExiste
        ));

        var sut = pfService.getContractsFilteredByContratosCarterasType(contracts, emptyParams, ALL_FILTER);
        assertThat(sut).hasSize(49);
        checkNotBJ(sut);

        sut = pfService.getContractsFilteredByContratosCarterasType(contracts, emptyParams, MANAGED_FILTER);
        assertThat(sut).hasSize(6);
        checkNotBJ(sut);

        sut = pfService.getContractsFilteredByContratosCarterasType(contracts, emptyParams, UNMANAGED_FILTER);
        assertThat(sut).hasSize(10);
        checkNotBJ(sut);

        sut = pfService.getContractsFilteredByContratosCarterasType(contracts, emptyParams, ANYPORTFOLIO_FILTER);
        assertThat(sut).hasSize(16);
        checkNotBJ(sut);

        sut = pfService.getContractsFilteredByContratosCarterasType(contracts, emptyParams, NONE_FILTER);
        assertThat(sut).hasSize(6);
        checkNotBJ(sut);

        sut = pfService.getContractsFilteredByContratosCarterasType(contracts, emptyParams, DEFAULT_FILTER);
        assertThat(sut).hasSize(16);
        checkNotBJ(sut);

    }

    @Test void checkAllStagesForNewFilter() {

        final var CTR_NOT_EXIST = "noExiste";
        final var CTR_CON_BAJA = "baja";

        List<PortfolioBaseContract> contracts = new ArrayList<>();
        // NONE 5
        contracts.add(buildContract("none1"));
        contracts.add(buildContract("none2", CTR_RELACION_BAJA));
        contracts.add(buildContract("none3", CTR_NOT_EXIST));
        contracts.add(buildContract("none4", CTR_CON_BAJA));
        contracts.add(buildContract("none5", CTR_RELACION_BAJA, CTR_NOT_EXIST, CTR_CON_BAJA));

        // MANAGED 6
        contracts.add(buildContract("mana1", CTR_GE));
        contracts.add(buildContract("mana2", CTR_GE, CTR_NOT_EXIST));
        contracts.add(buildContract("mana3", CTR_GE, CTR_CON_BAJA));
        contracts.add(buildContract("mana4", CTR_GE, CTR_RELACION_BAJA));
        contracts.add(buildContract("mana5", CTR_GE, CTR_GE));
        contracts.add(buildContract("mana6", CTR_GE, CTR_GE, CTR_RELACION_BAJA, CTR_NOT_EXIST, CTR_CON_BAJA));

        // NOT_MANAGED 10
        contracts.add(buildContract("unma1", CTR_AS));
        contracts.add(buildContract("unma2", CTR_AS, CTR_NOT_EXIST));
        contracts.add(buildContract("unma3", CTR_AS, CTR_CON_BAJA));
        contracts.add(buildContract("unma4", CTR_AS, CTR_RELACION_BAJA));
        contracts.add(buildContract("unma5", CTR_NA));
        contracts.add(buildContract("unma6", CTR_NA, CTR_NOT_EXIST));
        contracts.add(buildContract("unma7", CTR_NA, CTR_CON_BAJA));
        contracts.add(buildContract("unma8", CTR_NA, CTR_RELACION_BAJA));
        contracts.add(buildContract("unma9", CTR_NA, CTR_AS));
        contracts.add(buildContract("unma10", CTR_NA, CTR_AS, CTR_RELACION_BAJA, CTR_NOT_EXIST, CTR_CON_BAJA));

        // REST 6
        contracts.add(buildContract("rest1", CTR_ZZ));
        contracts.add(buildContract("rest2", CTR_ZZ, CTR_NOT_EXIST));
        contracts.add(buildContract("rest3", CTR_ZZ, CTR_CON_BAJA));
        contracts.add(buildContract("rest4", CTR_ZZ, CTR_RELACION_BAJA));
        contracts.add(buildContract("rest5", CTR_ZZ, CTR_ZZ));
        contracts.add(buildContract("rest6", CTR_ZZ, CTR_ZZ, CTR_RELACION_BAJA, CTR_NOT_EXIST, CTR_CON_BAJA));

        // MIX 15
        contracts.add(buildContract("mixe1", CTR_AS, CTR_GE));
        contracts.add(buildContract("mixe2", CTR_AS, CTR_GE, CTR_NOT_EXIST));
        contracts.add(buildContract("mixe3", CTR_AS, CTR_GE, CTR_CON_BAJA));
        contracts.add(buildContract("mixe4", CTR_AS, CTR_GE, CTR_RELACION_BAJA));
        contracts.add(buildContract("mixe5", CTR_AS, CTR_GE, CTR_RELACION_BAJA, CTR_NOT_EXIST, CTR_CON_BAJA));
        contracts.add(buildContract("mixe6", CTR_NA, CTR_GE));
        contracts.add(buildContract("mixe7", CTR_NA, CTR_GE, CTR_NOT_EXIST));
        contracts.add(buildContract("mixe8", CTR_NA, CTR_GE, CTR_CON_BAJA));
        contracts.add(buildContract("mixe9", CTR_NA, CTR_GE, CTR_RELACION_BAJA));
        contracts.add(buildContract("mixe10", CTR_NA, CTR_GE, CTR_RELACION_BAJA, CTR_NOT_EXIST, CTR_CON_BAJA));
        contracts.add(buildContract("mixe11", CTR_AS, CTR_NA, CTR_GE));
        contracts.add(buildContract("mixe12", CTR_AS, CTR_NA, CTR_GE, CTR_NOT_EXIST));
        contracts.add(buildContract("mixe13", CTR_AS, CTR_NA, CTR_GE, CTR_CON_BAJA));
        contracts.add(buildContract("mixe14", CTR_AS, CTR_NA, CTR_GE, CTR_RELACION_BAJA));
        contracts.add(buildContract("mixe15", CTR_AS, CTR_NA, CTR_GE, CTR_RELACION_BAJA, CTR_NOT_EXIST, CTR_CON_BAJA));

        // MIX REST 35
        contracts.add(buildContract("mixe16", CTR_GE, CTR_ZZ));
        contracts.add(buildContract("mixe17", CTR_GE, CTR_ZZ, CTR_NOT_EXIST));
        contracts.add(buildContract("mixe18", CTR_GE, CTR_ZZ, CTR_CON_BAJA));
        contracts.add(buildContract("mixe19", CTR_GE, CTR_ZZ, CTR_RELACION_BAJA));
        contracts.add(buildContract("mixe20", CTR_GE, CTR_ZZ, CTR_RELACION_BAJA, CTR_NOT_EXIST, CTR_CON_BAJA));
        contracts.add(buildContract("mixe21", CTR_NA, CTR_ZZ));
        contracts.add(buildContract("mixe22", CTR_NA, CTR_ZZ, CTR_NOT_EXIST));
        contracts.add(buildContract("mixe23", CTR_NA, CTR_ZZ, CTR_CON_BAJA));
        contracts.add(buildContract("mixe24", CTR_NA, CTR_ZZ, CTR_RELACION_BAJA));
        contracts.add(buildContract("mixe25", CTR_NA, CTR_ZZ, CTR_RELACION_BAJA, CTR_NOT_EXIST, CTR_CON_BAJA));
        contracts.add(buildContract("mixe26", CTR_AS, CTR_ZZ));
        contracts.add(buildContract("mixe27", CTR_AS, CTR_ZZ, CTR_NOT_EXIST));
        contracts.add(buildContract("mixe28", CTR_AS, CTR_ZZ, CTR_CON_BAJA));
        contracts.add(buildContract("mixe29", CTR_AS, CTR_ZZ, CTR_RELACION_BAJA));
        contracts.add(buildContract("mixe30", CTR_AS, CTR_ZZ, CTR_RELACION_BAJA, CTR_NOT_EXIST, CTR_CON_BAJA));
        contracts.add(buildContract("mixe31", CTR_AS, CTR_GE, CTR_ZZ));
        contracts.add(buildContract("mixe32", CTR_AS, CTR_GE, CTR_ZZ, CTR_NOT_EXIST));
        contracts.add(buildContract("mixe33", CTR_AS, CTR_GE, CTR_ZZ, CTR_CON_BAJA));
        contracts.add(buildContract("mixe34", CTR_AS, CTR_GE, CTR_ZZ, CTR_RELACION_BAJA));
        contracts.add(buildContract("mixe35", CTR_AS, CTR_GE, CTR_ZZ, CTR_RELACION_BAJA, CTR_NOT_EXIST, CTR_CON_BAJA));
        contracts.add(buildContract("mixe36", CTR_NA, CTR_GE, CTR_ZZ));
        contracts.add(buildContract("mixe37", CTR_NA, CTR_GE, CTR_ZZ, CTR_NOT_EXIST));
        contracts.add(buildContract("mixe38", CTR_NA, CTR_GE, CTR_ZZ, CTR_CON_BAJA));
        contracts.add(buildContract("mixe39", CTR_NA, CTR_GE, CTR_ZZ, CTR_RELACION_BAJA));
        contracts.add(buildContract("mixe40", CTR_NA, CTR_GE, CTR_ZZ, CTR_RELACION_BAJA, CTR_NOT_EXIST, CTR_CON_BAJA));
        contracts.add(buildContract("mixe41", CTR_AS, CTR_NA, CTR_ZZ));
        contracts.add(buildContract("mixe42", CTR_AS, CTR_NA, CTR_ZZ, CTR_NOT_EXIST));
        contracts.add(buildContract("mixe43", CTR_AS, CTR_NA, CTR_ZZ, CTR_CON_BAJA));
        contracts.add(buildContract("mixe44", CTR_AS, CTR_NA, CTR_ZZ, CTR_RELACION_BAJA));
        contracts.add(buildContract("mixe45", CTR_AS, CTR_NA, CTR_ZZ, CTR_RELACION_BAJA, CTR_NOT_EXIST, CTR_CON_BAJA));
        contracts.add(buildContract("mixe46", CTR_AS, CTR_NA, CTR_GE, CTR_ZZ));
        contracts.add(buildContract("mixe47", CTR_AS, CTR_NA, CTR_GE, CTR_ZZ, CTR_NOT_EXIST));
        contracts.add(buildContract("mixe48", CTR_AS, CTR_NA, CTR_GE, CTR_ZZ, CTR_CON_BAJA));
        contracts.add(buildContract("mixe49", CTR_AS, CTR_NA, CTR_GE, CTR_ZZ, CTR_RELACION_BAJA));
        contracts.add(buildContract("mixe50", CTR_AS, CTR_NA, CTR_GE, CTR_ZZ, CTR_RELACION_BAJA, CTR_NOT_EXIST, CTR_CON_BAJA));

        // MIX EMPTY
        contracts.add(buildContract("empty1", CTR_EMPTY));
        contracts.add(buildContract("empty2", CTR_ZZ));
        contracts.add(buildContract("empty3", CTR_ZZ, CTR_EMPTY));
        contracts.add(buildContract("empty4", CTR_GE, CTR_ZZ, CTR_EMPTY));
        contracts.add(buildContract("empty5", CTR_GE, CTR_ZZ, CTR_NOT_EXIST, CTR_EMPTY));
        contracts.add(buildContract("empty6", CTR_GE, CTR_ZZ, CTR_CON_BAJA, CTR_EMPTY));
        contracts.add(buildContract("empty7", CTR_AS, CTR_GE, CTR_ZZ, CTR_RELACION_BAJA, CTR_EMPTY));
        contracts.add(buildContract("empty8", CTR_AS, CTR_GE, CTR_ZZ, CTR_RELACION_BAJA, CTR_NOT_EXIST, CTR_CON_BAJA, CTR_EMPTY));
        contracts.add(buildContract("empty9", CTR_NA, CTR_GE, CTR_ZZ, CTR_EMPTY));
        contracts.add(buildContract("empty10", CTR_NA, CTR_GE, CTR_ZZ, CTR_NOT_EXIST, CTR_EMPTY));
        contracts.add(buildContract("empty11", CTR_AS, CTR_NA, CTR_GE, CTR_ZZ, CTR_CON_BAJA, CTR_EMPTY));
        contracts.add(buildContract("empty12", CTR_AS, CTR_NA, CTR_GE, CTR_ZZ, CTR_RELACION_BAJA, CTR_EMPTY));
        contracts.add(buildContract("empty13", CTR_AS, CTR_NA, CTR_GE, CTR_ZZ, CTR_RELACION_BAJA, CTR_NOT_EXIST, CTR_CON_BAJA, CTR_EMPTY));



        when(pfRepo.callToPortfolios(any(), any())).thenReturn(List.of(
                PortfolioType.builder().idPortfolioContract(CTR_GE).typePortfolio("GE").siga("58NPORERMASD32").build(),
                PortfolioType.builder().idPortfolioContract(CTR_AS).typePortfolio("AS").siga("58NPORERMASD22").build(),
                PortfolioType.builder().idPortfolioContract(CTR_NA).typePortfolio("NA").siga("58NPORERMA789").build(),
                PortfolioType.builder().idPortfolioContract(CTR_ZZ).typePortfolio("ZZ").siga("58NPORERMA333").build(),
                PortfolioType.builder().idPortfolioContract(CTR_CON_BAJA).typePortfolio("BJ").siga("58NPORERMA789").build(),
                PortfolioType.builder().idPortfolioContract(CTR_EMPTY).siga("58NPORERMA790").build()
                // NO existe noExiste
        ));

        var sut = pfService.getContractsFilteredByPortfolioTypes(contracts, emptyParams, PortfolioQueryParams.builder()
                .build());
        assertThat(sut).hasSize(90);
        checkNotBJ(sut);

        sut = pfService.getContractsFilteredByPortfolioTypes(contracts, emptyParams, PortfolioQueryParams.builder()
                .related_to_portfolio_types(Set.of(PortfolioFilterType.NO_PORTFOLIO))
                .build());
        assertThat(sut).hasSize(5);
        checkNotBJ(sut);

        sut = pfService.getContractsFilteredByPortfolioTypes(contracts, emptyParams, PortfolioQueryParams.builder()
                .related_to_portfolio_types(Set.of(PortfolioFilterType.MANAGED))
                .build());
        assertThat(sut).hasSize(51);
        checkNotBJ(sut);

        sut = pfService.getContractsFilteredByPortfolioTypes(contracts, emptyParams, PortfolioQueryParams.builder()
                .related_to_portfolio_types(Set.of(PortfolioFilterType.NOT_ADMINISTERED))
                .build());
        assertThat(sut).hasSize(41);
        checkNotBJ(sut);

        sut = pfService.getContractsFilteredByPortfolioTypes(contracts, emptyParams, PortfolioQueryParams.builder()
                .related_to_portfolio_types(Set.of(PortfolioFilterType.ADVISED))
                .build());
        assertThat(sut).hasSize(41);
        checkNotBJ(sut);

        sut = pfService.getContractsFilteredByPortfolioTypes(contracts, emptyParams, PortfolioQueryParams.builder()
                .related_to_portfolio_types(Set.of(PortfolioFilterType.NOT_MANAGED))
                .build());
        assertThat(sut).hasSize(10);
        checkNotBJ(sut);

        sut = pfService.getContractsFilteredByPortfolioTypes(contracts, emptyParams, PortfolioQueryParams.builder()
                .related_to_portfolio_types(Set.of(PortfolioFilterType.ALL_MANAGED))
                .build());
        assertThat(sut).hasSize(6);
        checkNotBJ(sut);

        sut = pfService.getContractsFilteredByPortfolioTypes(contracts, emptyParams, PortfolioQueryParams.builder()
                .related_to_portfolio_types(Set.of(PortfolioFilterType.ALL_NOT_ADMINISTERED))
                .build());
        assertThat(sut).hasSize(4);
        checkNotBJ(sut);

        sut = pfService.getContractsFilteredByPortfolioTypes(contracts, emptyParams, PortfolioQueryParams.builder()
                .related_to_portfolio_types(Set.of(PortfolioFilterType.ALL_ADVISED))
                .build());
        assertThat(sut).hasSize(4);
        checkNotBJ(sut);

        sut = pfService.getContractsFilteredByPortfolioTypes(contracts, emptyParams, PortfolioQueryParams.builder()
                .related_to_portfolio_types(Set.of(PortfolioFilterType.REST))
                .build());
        assertThat(sut).hasSize(54);
        checkNotBJ(sut);

        sut = pfService.getContractsFilteredByPortfolioTypes(contracts, emptyParams, PortfolioQueryParams.builder()
                .related_to_portfolio_types(Set.of(PortfolioFilterType.ALL_REST))
                .build());
        assertThat(sut).hasSize(9);
        checkNotBJ(sut);

        sut = pfService.getContractsFilteredByPortfolioTypes(contracts, emptyParams, PortfolioQueryParams.builder()
                .unrelated_to_portfolio_types(Set.of(PortfolioFilterType.NO_PORTFOLIO))
                .build());
        assertThat(sut).hasSize(85);
        checkNotBJ(sut);

        sut = pfService.getContractsFilteredByPortfolioTypes(contracts, emptyParams, PortfolioQueryParams.builder()
                .unrelated_to_portfolio_types(Set.of(PortfolioFilterType.MANAGED))
                .build());
        assertThat(sut).hasSize(39);
        checkNotBJ(sut);

        sut = pfService.getContractsFilteredByPortfolioTypes(contracts, emptyParams, PortfolioQueryParams.builder()
                .unrelated_to_portfolio_types(Set.of(PortfolioFilterType.NOT_ADMINISTERED))
                .build());
        assertThat(sut).hasSize(49);
        checkNotBJ(sut);

        sut = pfService.getContractsFilteredByPortfolioTypes(contracts, emptyParams, PortfolioQueryParams.builder()
                .unrelated_to_portfolio_types(Set.of(PortfolioFilterType.ADVISED))
                .build());
        assertThat(sut).hasSize(49);
        checkNotBJ(sut);

        sut = pfService.getContractsFilteredByPortfolioTypes(contracts, emptyParams, PortfolioQueryParams.builder()
                .unrelated_to_portfolio_types(Set.of(PortfolioFilterType.NOT_MANAGED))
                .build());
        assertThat(sut).hasSize(80);
        checkNotBJ(sut);

        sut = pfService.getContractsFilteredByPortfolioTypes(contracts, emptyParams, PortfolioQueryParams.builder()
                .unrelated_to_portfolio_types(Set.of(PortfolioFilterType.ALL_MANAGED))
                .build());
        assertThat(sut).hasSize(84);
        checkNotBJ(sut);

        sut = pfService.getContractsFilteredByPortfolioTypes(contracts, emptyParams, PortfolioQueryParams.builder()
                .unrelated_to_portfolio_types(Set.of(PortfolioFilterType.ALL_NOT_ADMINISTERED))
                .build());
        assertThat(sut).hasSize(86);
        checkNotBJ(sut);

        sut = pfService.getContractsFilteredByPortfolioTypes(contracts, emptyParams, PortfolioQueryParams.builder()
                .unrelated_to_portfolio_types(Set.of(PortfolioFilterType.ALL_ADVISED))
                .build());
        assertThat(sut).hasSize(86);
        checkNotBJ(sut);

        sut = pfService.getContractsFilteredByPortfolioTypes(contracts, emptyParams, PortfolioQueryParams.builder()
                .unrelated_to_portfolio_types(Set.of(PortfolioFilterType.REST))
                .build());
        assertThat(sut).hasSize(36);
        checkNotBJ(sut);

        sut = pfService.getContractsFilteredByPortfolioTypes(contracts, emptyParams, PortfolioQueryParams.builder()
                .unrelated_to_portfolio_types(Set.of(PortfolioFilterType.ALL_REST))
                .build());
        assertThat(sut).hasSize(81);
        checkNotBJ(sut);

        // 5 combinaciones
        sut = pfService.getContractsFilteredByPortfolioTypes(contracts, emptyParams, PortfolioQueryParams.builder()
                .related_to_portfolio_types(Set.of(PortfolioFilterType.NO_PORTFOLIO, PortfolioFilterType.MANAGED,
                        PortfolioFilterType.NOT_ADMINISTERED, PortfolioFilterType.ADVISED, PortfolioFilterType.REST))
                .build());
        assertThat(sut).hasSize(90);
        checkNotBJ(sut);

        sut = pfService.getContractsFilteredByPortfolioTypes(contracts, emptyParams, PortfolioQueryParams.builder()
                .related_to_portfolio_types(Set.of(PortfolioFilterType.NO_PORTFOLIO))
                .unrelated_to_portfolio_types(Set.of(PortfolioFilterType.NO_PORTFOLIO))
                .build());
        assertThat(sut).hasSize(0);
        checkNotBJ(sut);

        sut = pfService.getContractsFilteredByPortfolioTypes(contracts, emptyParams, PortfolioQueryParams.builder()
                .related_to_portfolio_types(Set.of(PortfolioFilterType.ALL_ADVISED, PortfolioFilterType.NO_PORTFOLIO))
                .build());
        assertThat(sut).hasSize(9);
        checkNotBJ(sut);

        sut = pfService.getContractsFilteredByPortfolioTypes(contracts, emptyParams, PortfolioQueryParams.builder()
                .related_to_portfolio_types(Set.of(PortfolioFilterType.NOT_ADMINISTERED, PortfolioFilterType.ADVISED))
                .unrelated_to_portfolio_types(Set.of(PortfolioFilterType.MANAGED))
                .build());
        assertThat(sut).hasSize(25);
        checkNotBJ(sut);

        sut = pfService.getContractsFilteredByPortfolioTypes(contracts, emptyParams, PortfolioQueryParams.builder()
                .unrelated_to_portfolio_types(Set.of(PortfolioFilterType.MANAGED, PortfolioFilterType.NOT_ADMINISTERED,
                        PortfolioFilterType.NO_PORTFOLIO, PortfolioFilterType.ADVISED))
                .build());
        assertThat(sut).hasSize(9);
        checkNotBJ(sut);

        sut = pfService.getContractsFilteredByPortfolioTypes(contracts, emptyParams, PortfolioQueryParams.builder()
                .unrelated_to_portfolio_types(Set.of(PortfolioFilterType.MANAGED, PortfolioFilterType.NOT_ADMINISTERED,
                        PortfolioFilterType.NO_PORTFOLIO, PortfolioFilterType.ADVISED, PortfolioFilterType.REST))
                .build());
        assertThat(sut).hasSize(0);
        checkNotBJ(sut);

    }

    @Test void testFilterByType() {

        PortfolioBaseContract contract = new PortfolioBaseContract();  // Un contrato sin portafolios asociados
        Map<String, PortfolioType> portfolioMap = Collections.emptyMap();  // Un mapa de portafolio vacío

        PortfolioQueryParams portfolioQueryParams = PortfolioQueryParams.builder()
                .related_to_portfolio_types(Set.of(PortfolioFilterType.NO_PORTFOLIO))  // No incluye todos los tipos de portafolio
                .unrelated_to_portfolio_types(Set.of(PortfolioFilterType.MANAGED))  // Excluye al menos un tipo de portafolio
                .build();

        // Call the filterByType method
        boolean result = portFolioServ.filterByType(contract, portfolioMap, portfolioQueryParams);

        // Verify the result
        assertFalse(result, "The filterByType method should return false");
    }

    private void checkNotBJ(List<PortfolioBaseContract> contracts) {
        contracts.stream()
                .filter(c -> ! CollectionUtils.isEmpty(c.getContratosCarteras()))
                .flatMap(c -> c.getContratosCarteras().stream())
                .map(PortfolioContract::getContratoCartera)
                .distinct()
                .forEach(c -> assertThat(c).isNotEqualTo(CTR_RELACION_BAJA));
    }

    private PortfolioBaseContract buildContract(String contractId, String... portfolios) {

        final var contract = new PortfolioBaseContract();
        contract.setIdContrato(contractId);

        if (portfolios != null && portfolios.length != 0) {
            contract.setContratosCarteras(buildPortfolios(portfolios));
        }

        return contract;
    }

    private List<PortfolioContract> buildPortfolios(String... portfolios) {
        return Stream.of(portfolios)
                .map(this::buildPortfolio)
                .collect(toList());
    }

    private PortfolioContract buildPortfolio(String portfolio) {
        return PortfolioContract.builder()
                .contratoCartera(portfolio)
                .fechaVencimiento(CTR_RELACION_BAJA.equals(portfolio) ? "2019-12-31" : "9999-12-31")
                .build();
    }

}
