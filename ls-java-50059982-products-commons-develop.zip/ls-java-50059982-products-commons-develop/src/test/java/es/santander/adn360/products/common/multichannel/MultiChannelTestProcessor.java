package es.santander.adn360.products.common.multichannel;


import es.santander.adn360.products.common.domain.entity.BaseContract;
import es.santander.adn360.products.common.multichannel.processors.MultiChannelProcessor;
import es.santander.adn360.products.common.service.ContractInfoService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class MultiChannelTestProcessor implements MultiChannelProcessor {

    private final ContractInfoService contractInfoService;

    @Override
    public List processListContracts(List contracts) {

        return ((List<? extends BaseContract>) contracts).stream()
                .map( contract -> {
                        contract.setDescripcion("Descripcion seteada desde MultiChannelProcessorTest");
                        return contract;
                    }).collect(Collectors.toList());
    }

    public MultiChannelTestModel processContract(BaseContract contract) {
        MultiChannelTestModel response = (MultiChannelTestModel) contract;
            response.setAlias("Alias actualizado desde MultiChannelProcessorTest");
        return response;
    }
}
