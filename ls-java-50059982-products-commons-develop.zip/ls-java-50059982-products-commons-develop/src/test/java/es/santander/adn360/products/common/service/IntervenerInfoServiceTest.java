package es.santander.adn360.products.common.service;

import com.mongodb.BasicDBList;
import es.santander.adn360.products.common.config.CommonMongoCollectionsProperties;
import org.apache.commons.io.FileUtils;
import org.bson.BsonArray;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.actuate.observability.AutoConfigureObservability;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.mongodb.core.MongoOperations;

import java.io.IOException;
import java.nio.charset.Charset;
import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@AutoConfigureObservability
class IntervenerInfoServiceTest {

    @Autowired
    private CommonMongoCollectionsProperties commonMongoCollectionsProperties;

    @Autowired
    private IntervenerInfoService service;

    @Autowired
    private MongoOperations mongoOperations;

    @BeforeEach
    public void beforeEach() throws IOException {

        // Save all documents from json file
        String doc = FileUtils.readFileToString(new ClassPathResource("json/adn360.tiposIntervencion.json").getFile(),
                Charset.defaultCharset());
        final BsonArray parse = BsonArray.parse(doc);
        BasicDBList dbList = new BasicDBList();
        dbList.addAll(parse);
        dbList.forEach(dbo -> mongoOperations.save(dbo, this.commonMongoCollectionsProperties.getTiposIntervencion()));
    }

    @Test
    void findByForma_ok() {

        assertThat(this.service.findByTipo("38")).isPresent();

        assertThat(this.service.findByTipo("NO_EXISTE")).isEmpty();
    }

    @Test void findDescriptionByForma_ok() {

        assertThat(this.service.findNombreByTipo("38")).isPresent();

        assertThat(this.service.findNombreByTipo("NO_EXISTE")).isEmpty();
    }

    @Test void cacheOk() {

        assertThat(this.service.findByTipo("38")).isPresent();

        mongoOperations.dropCollection(this.commonMongoCollectionsProperties.getTiposIntervencion());

        assertThat(this.service.findByTipo("38")).isPresent();

        this.service.cleanCache();

        assertThat(this.service.findByTipo("38")).isEmpty();
    }
}
