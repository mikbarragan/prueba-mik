package es.santander.adn360.products.common.validator;

import es.santander.adn360.mongodb.starter.domain.QueryParams;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.actuate.observability.AutoConfigureObservability;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
@AutoConfigureObservability
class QueryParamsValidatorTest {

    private final QueryParamsValidator queryParamsValidator = new QueryParamsValidator();

    @Test
    void testIsValidNullQueryParams() {
        Assertions.assertThat(this.queryParamsValidator.isValid(null, null))
                .isTrue();
    }

    @Test
    void testIsValidNullExpand() {
        Assertions.assertThat(this.queryParamsValidator.isValid(QueryParams.builder().build(), null))
                .isTrue();
    }

    @Test
    void testIsValidEmptyExpand() {
        Assertions.assertThat(this.queryParamsValidator.isValid(QueryParams.builder().expand("").build(), null))
                .isTrue();
    }

    @Test
    void testIsValidIncorrectValue() {
        Assertions.assertThat(this.queryParamsValidator.isValid(QueryParams.builder().expand("aggreg")
                .build(), null))
                .isFalse();
    }

    @Test
    void testIsValidOK() {
        Assertions.assertThat(this.queryParamsValidator.isValid(QueryParams.builder()
                .expand(QueryParamsValidator.EXPAND_AGGREGATIONS).build(), null))
                .isTrue();
    }

}
