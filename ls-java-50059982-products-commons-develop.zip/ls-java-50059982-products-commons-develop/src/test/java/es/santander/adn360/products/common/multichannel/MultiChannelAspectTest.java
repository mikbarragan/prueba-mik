package es.santander.adn360.products.common.multichannel;

import es.santander.adn360.core.model.exception.FunctionalException;
import es.santander.adn360.core.web.CoreSecurityContextImpl;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.actuate.observability.AutoConfigureObservability;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertThrows;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureObservability
class MultiChannelAspectTest {

     private static final CoreSecurityContextImpl CORE_SECURITY_CONTEXT = (CoreSecurityContextImpl) Mockito.mock(CoreSecurityContextImpl.class);

    @Autowired
    MultiChannelTestService multiChannelTestService;

    @BeforeEach
    public void setUp() throws Exception {
        SecurityContextHolder.setContext(CORE_SECURITY_CONTEXT);
    }

    @Test
    public void processListContractsIsCall() {
        List<MultiChannelTestModel> request = Arrays.asList(
                MultiChannelTestModel.builder().build(),
                MultiChannelTestModel.builder().build(),
                MultiChannelTestModel.builder().build(),
                MultiChannelTestModel.builder().build()
                );

        List<MultiChannelTestModel> response = this.multiChannelTestService.processList(request);

        Assertions.assertThat(response).isNotNull();
        Assertions.assertThat(response).isNotEmpty();
        Assertions.assertThat(response).hasSize(2);

        response.stream().forEach( c ->   {
            Assertions.assertThat(c.getDataExample() ).isEqualTo("set data in MultiChannelServiceTest.processList");
            Assertions.assertThat(c.getDescripcion() ).isEqualTo("Descripcion seteada desde MultiChannelProcessorTest");
            Assertions.assertThat(c.getDescripcionLarga() ).isEqualTo("Descripcion larga seteada desde MultiChannelProcessorTest2");
        } );
    }

    @Test
    public void processContractsIsCall() {
        MultiChannelTestModel response = this.multiChannelTestService.processContract(MultiChannelTestModel.builder().build());
        Assertions.assertThat(response).isNotNull();
        Assertions.assertThat(response.getDataExample() ).isEqualTo("set data in MultiChannelServiceTest.contract");
        Assertions.assertThat(response.getAlias() ).isEqualTo("Alias actualizado desde MultiChannelProcessorTest");
        Assertions.assertThat(response.getDescripcion() ).isEqualTo("Descripcion actualizado desde MultiChannelProcessorTest2");
    }

    @Test
    public void processListErrorShouldThorwError() {
        List<MultiChannelTestModel> request = Arrays.asList(
                MultiChannelTestModel.builder().build(),
                MultiChannelTestModel.builder().build(),
                MultiChannelTestModel.builder().build(),
                MultiChannelTestModel.builder().build()
        );

        assertThrows(FunctionalException.class ,() -> this.multiChannelTestService.processListError(request));
    }

}
