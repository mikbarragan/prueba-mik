package es.santander.adn360.products.common.switchhost.resilence4j;

import es.santander.adn360.core.model.exception.FunctionalException;
import es.santander.adn360.core.util.ExceptionEnum;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;

import static org.mockito.MockitoAnnotations.initMocks;

class Is4xxPredicateTest {

    @InjectMocks
    private Is4xxPredicate is4xxPredicate;

    @BeforeEach
    void setUp() {
        initMocks(this);
    }

    @Test
    void test_given4xxStatusException_shouldReturnTrue() {
        boolean result = is4xxPredicate.test(new FunctionalException(ExceptionEnum.INVALID_INPUT_PARAMETERS));
        Assertions.assertThat(result).isTrue();
    }

    @Test
    void test_givenNot4xxStatusException_shouldReturnFalse() {
        boolean result = is4xxPredicate.test(new FunctionalException(ExceptionEnum.NO_DATA_FOUND));
        Assertions.assertThat(result).isFalse();
    }

    @Test
    void test_Contructor() {
        Is4xxPredicate is4xxPredicate = new Is4xxPredicate();
        Assertions.assertThat(is4xxPredicate).isNotNull();
    }
}