package es.santander.adn360.products.common.service;

import es.santander.adn360.core.model.exception.FunctionalException;
import es.santander.adn360.core.web.CoreSecurityContextImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.actuate.observability.AutoConfigureObservability;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

@SpringBootTest()
@AutoConfigureObservability
class SituationIndicatorServiceTest {

    private final static String ALL_CODES = "all";
    private final static String ACTIVES_CODES = "actives";
    private final static String PRECANCELED_CODES = "precanceled";
    private final static String CANCELED_CODES = "canceled";
    private final static String DEFAULT_APPLICATION = "ADN360";
    private final static String TEST_APPLICATION = "PRUEBA";
    private final static int MAXTIME = 25;

    private final CoreSecurityContextImpl coreSecurityContext = Mockito.mock(CoreSecurityContextImpl.class);

    @Autowired
    private SituationIndicatorServiceImpl situationIndicatorService;

    @BeforeEach
    public void setUp() {
        Mockito.when(this.coreSecurityContext.getSantanderChannel()).thenReturn("OFI");
        SecurityContextHolder.setContext(this.coreSecurityContext);
    }

    @Test
    void testGetMaxTimeCanceledContractsWithApps() {
        Integer maxtime = situationIndicatorService.getMaxTimeCanceledContracts(null);
        assertThat(maxtime).isNotNull();
        assertThat(maxtime).isEqualTo(MAXTIME);

        maxtime = situationIndicatorService.getMaxTimeCanceledContracts(DEFAULT_APPLICATION);
        assertThat(maxtime).isNotNull();
        assertThat(maxtime).isEqualTo(MAXTIME);
    }

    @Test
    void testCodesWithChannel() {
        List<String> allCodes = situationIndicatorService.findContractCodes(ALL_CODES);
        assertThat(allCodes).isNotNull();
        assertThat(allCodes.size()).isEqualTo(6);

        List<String> activesCodes = situationIndicatorService.findContractCodes(ACTIVES_CODES);
        assertThat(activesCodes).isNotNull();
        assertThat(activesCodes.size()).isEqualTo(1);
        assertThat(activesCodes.get(0)).isEqualToIgnoringCase("PRUEBA");
        assertThrows(FunctionalException.class, () ->  situationIndicatorService.findContractCodes(PRECANCELED_CODES));

        List<String> canceledCodes = situationIndicatorService.findContractCodes(CANCELED_CODES);
        assertThat(canceledCodes).isNotNull();
        assertThat(canceledCodes.size()).isEqualTo(5);
    }

    @Test
    void testCodesWithChannelAndApplication() {
        List<String> allCodes = situationIndicatorService.findContractCodes(ALL_CODES, TEST_APPLICATION);
        assertThat(allCodes).isNotNull();
        assertThat(allCodes.size()).isEqualTo(3);

        List<String> activesCodes = situationIndicatorService.findContractCodes(ACTIVES_CODES, TEST_APPLICATION);
        assertThat(activesCodes).isNotNull();
        assertThat(activesCodes.size()).isEqualTo(1);
        assertThat(activesCodes.get(0)).isEqualToIgnoringCase("G1");

        List<String> precanceledCodes = situationIndicatorService.findContractCodes(PRECANCELED_CODES, TEST_APPLICATION);
        assertThat(precanceledCodes).isNotNull();
        assertThat(precanceledCodes.size()).isEqualTo(1);
        assertThat(precanceledCodes.get(0)).isEqualToIgnoringCase("P1");

        List<String> canceledCodes = situationIndicatorService.findContractCodes(CANCELED_CODES, TEST_APPLICATION);
        assertThat(canceledCodes).isNotNull();
        assertThat(canceledCodes.size()).isEqualTo(1);
        assertThat(canceledCodes.get(0)).isEqualToIgnoringCase("C1");
    }

    @Test
    void testCodesLoadbydefault() {
        Mockito.when(this.coreSecurityContext.getSantanderChannel()).thenReturn(null);
        List<String> allCodes = situationIndicatorService.findContractCodes(ALL_CODES);
        assertThat(allCodes).isNotNull();
        assertThat(allCodes.size()).isEqualTo(6);
    }

}
