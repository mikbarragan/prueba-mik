package es.santander.adn360.products.common.repository;

import es.santander.adn360.core.util.CustomerProductQueryParams;
import es.santander.adn360.products.common.domain.PortfolioType;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.actuate.observability.AutoConfigureObservability;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureObservability
public class PortfoliosRepositoryImplTest {


    @MockBean(name="restTemplate")
    private RestTemplate restTemplate;

    @Autowired
    private PortfoliosRepository portfoliosRepository;

    static final String CONTRACT_ONE = "004906583050000286";
    static final String CONTRACT_TWO = "004900101530910919";


    @BeforeEach
    public void setUp() {
        this.portfoliosRepository.cleanCache();
    }


    /**
     * The service must return an empty list when we make the request with another empty list.
     * */
    @Test
    public void callToPortfoliosShouldReturnEmptyListWhenPortfoliosReturnEmptyList() {

        Mockito.when(this.restTemplate.exchange(
                any(URI.class),
                any(HttpMethod.class),
                any(HttpEntity.class),
                any(ParameterizedTypeReference.class))
        ).thenReturn(ResponseEntity.ok(null));

        List<PortfolioType> portfoliosType = portfoliosRepository
                .callToPortfolios(Collections.emptyList(), new CustomerProductQueryParams());

        Assertions.assertThat(portfoliosType).isEqualTo(Collections.emptyList());
    }

    /**
     * The service must return an empty list when the request to the portfolio service returns null
     * */
    @Test
    public void callToPortfoliosShouldReturnEmptyListWhenPortfoliosReturnNull() {

        Mockito.when(this.restTemplate.exchange(
                any(String.class),
                any(HttpMethod.class),
                any(HttpEntity.class),
                any(ParameterizedTypeReference.class))
        ).thenReturn(ResponseEntity.ok(Collections.emptyList()));

        List<PortfolioType> portfoliosType = portfoliosRepository
                .callToPortfolios(Arrays.asList(CONTRACT_ONE, CONTRACT_TWO), new CustomerProductQueryParams());

        Assertions.assertThat(portfoliosType).isEqualTo(Collections.emptyList());

    }

    /**
     * The service must return an empty list when the request to the portfolio service returns an empty list.
     *
     * */
    @Test
    public void callToPortfoliosWithEmptyListShouldReturnAnEmptyList() {

        Mockito.when(this.restTemplate.exchange(
                any(String.class),
                any(HttpMethod.class),
                any(HttpEntity.class),
                any(ParameterizedTypeReference.class))
        ).thenReturn(ResponseEntity.ok(Collections.emptyList()));

        List<PortfolioType> portfoliosType = portfoliosRepository
                .callToPortfolios(Arrays.asList(CONTRACT_ONE, CONTRACT_TWO), new CustomerProductQueryParams());

        Assertions.assertThat(portfoliosType).isEqualTo(Collections.emptyList());

    }


    /**
     * The service must return a list of the types when the portfolio service returns data
     * */
    @Test
    public void callToPortfoliosShouldReturnTwoTypes() {

        List<PortfolioType> expectedResponse = Arrays.asList(
                PortfolioType.builder().idPortfolioContract(CONTRACT_ONE).typePortfolio("GE").build(),
                PortfolioType.builder().idPortfolioContract(CONTRACT_TWO).typePortfolio("AS").build()

        );

        Mockito.when(this.restTemplate.exchange(
                any(String.class),
                any(HttpMethod.class),
                any(HttpEntity.class),
                any(ParameterizedTypeReference.class))
        ).thenReturn(ResponseEntity.ok(expectedResponse));

        List<PortfolioType> portfoliosType = portfoliosRepository
                .callToPortfolios(Arrays.asList(CONTRACT_ONE, CONTRACT_TWO), new CustomerProductQueryParams());

        Assertions.assertThat(portfoliosType).isNotEmpty();
        Assertions.assertThat(portfoliosType.size()).isEqualTo(2);
        Assertions.assertThat(portfoliosType.get(0).getTypePortfolio()).isEqualTo("GE");
        Assertions.assertThat(portfoliosType.get(1).getTypePortfolio()).isEqualTo("AS");

    }


    /**
     *  The service should cache when second call
     */
    @Test
    public void checkCache() {
        // Mockeamos la llamada  al micro de portfolios y hacemos una llamada que devolverá dicha respuesta
        List<PortfolioType> expectedResponse = Arrays.asList(
                PortfolioType.builder().idPortfolioContract(CONTRACT_ONE).typePortfolio("GE").build(),
                PortfolioType.builder().idPortfolioContract(CONTRACT_TWO).typePortfolio("AS").build()

        );

        Mockito.when(this.restTemplate.exchange(
                any(String.class),
                any(HttpMethod.class),
                any(HttpEntity.class),
                any(ParameterizedTypeReference.class))
        ).thenReturn(ResponseEntity.ok(expectedResponse));

        List<PortfolioType> portfoliosType = portfoliosRepository
                .callToPortfolios(Arrays.asList(CONTRACT_ONE, CONTRACT_TWO), new CustomerProductQueryParams());


        // comprobamos que la peticion es correcta
        Assertions.assertThat(portfoliosType).isNotEmpty();
        Assertions.assertThat(portfoliosType.size()).isEqualTo(2);
        Assertions.assertThat(portfoliosType.get(0).getTypePortfolio()).isEqualTo("GE");
        Assertions.assertThat(portfoliosType.get(1).getTypePortfolio()).isEqualTo("AS");


        // Mockeamos una segunda llamada al template con datos diferentes
        expectedResponse = Arrays.asList(
                PortfolioType.builder().idPortfolioContract(CONTRACT_ONE).typePortfolio("NOGE").build(),
                PortfolioType.builder().idPortfolioContract(CONTRACT_TWO).typePortfolio("NOAS").build()

        );

        Mockito.when(this.restTemplate.exchange(
                any(String.class),
                any(HttpMethod.class),
                any(HttpEntity.class),
                any(ParameterizedTypeReference.class))
        ).thenReturn(ResponseEntity.ok(expectedResponse));

       portfoliosType = portfoliosRepository
                .callToPortfolios(Arrays.asList(CONTRACT_ONE, CONTRACT_TWO), new CustomerProductQueryParams());

       // Comprobamos que ha devuelto el primer dato moqueado y no se ha hecho la peticiona portfolios
        Assertions.assertThat(portfoliosType).isNotEmpty();
        Assertions.assertThat(portfoliosType.size()).isEqualTo(2);
        Assertions.assertThat(portfoliosType.get(0).getTypePortfolio()).isEqualTo("GE");
        Assertions.assertThat(portfoliosType.get(1).getTypePortfolio()).isEqualTo("AS");

        // Limpiamos la caché
        this.portfoliosRepository.cleanCache();


        // Al volver a llamar, al no tener caché. debe devolver los nuevos datos de portfolios
        portfoliosType = portfoliosRepository
                .callToPortfolios(Arrays.asList(CONTRACT_ONE, CONTRACT_TWO), new CustomerProductQueryParams());

        Assertions.assertThat(portfoliosType).isNotEmpty();
        Assertions.assertThat(portfoliosType.size()).isEqualTo(2);
        Assertions.assertThat(portfoliosType.get(0).getTypePortfolio()).isEqualTo("NOGE");
        Assertions.assertThat(portfoliosType.get(1).getTypePortfolio()).isEqualTo("NOAS");


    }

    /**
     * The service shouldn't cache when diferents contracts but should cache with same contracts
     * */
    @Test
    public void checkNoCacheWithDiferentsContractsButYesWithSameContract() {

        // Mokeamos la llamada al rest template con dos contratos diferentes
        List<PortfolioType> expectedResponseGE = Arrays.asList(
                PortfolioType.builder().idPortfolioContract(CONTRACT_ONE).typePortfolio("GE").build()
        );

        List<PortfolioType> expectedResponseAS = Arrays.asList(
                PortfolioType.builder().idPortfolioContract(CONTRACT_TWO).typePortfolio("AS").build()
        );
        Mockito.when(this.restTemplate.exchange(
                any(String.class),
                any(HttpMethod.class),
                any(HttpEntity.class),
                any(ParameterizedTypeReference.class))
        ).thenReturn(new ResponseEntity(expectedResponseGE, HttpStatus.OK));


        // Hacemos la peticion con el primero y nos devuelve el dato moqueado en el rest template del primero
        List<PortfolioType> portfoliosType = portfoliosRepository
                .callToPortfolios(Arrays.asList(CONTRACT_ONE), new CustomerProductQueryParams());

        Assertions.assertThat(portfoliosType).isNotEmpty();
        Assertions.assertThat(portfoliosType.size()).isEqualTo(1);
        Assertions.assertThat(portfoliosType.get(0).getTypePortfolio()).isEqualTo("GE");


        Mockito.when(this.restTemplate.exchange(
                any(String.class),
                any(HttpMethod.class),
                any(HttpEntity.class),
                any(ParameterizedTypeReference.class))
        ).thenReturn(new ResponseEntity(expectedResponseAS, HttpStatus.OK));
        // Hacemos la peticion con el segudno y nos devuelve el dato moqueado del segundo en el rest template por lo que no se ha cacheado para un contrato diferente
        portfoliosType = portfoliosRepository
                .callToPortfolios(Arrays.asList(CONTRACT_TWO), new CustomerProductQueryParams());

        Assertions.assertThat(portfoliosType).isNotEmpty();
        Assertions.assertThat(portfoliosType.size()).isEqualTo(1);
        Assertions.assertThat(portfoliosType.get(0).getTypePortfolio()).isEqualTo("AS");

        // Cambiamos el moqueo del prmier contrato para que el rest template devuelva un typo de portfolio diferente
       expectedResponseGE = Arrays.asList(
                PortfolioType.builder().idPortfolioContract(CONTRACT_ONE).typePortfolio("NOGE").build()
        );

        Mockito.when(this.restTemplate.exchange(
                any(String.class),
                any(HttpMethod.class),
                any(HttpEntity.class),
                any(ParameterizedTypeReference.class))
        ).thenReturn(new ResponseEntity(expectedResponseGE, HttpStatus.OK));

        // La petición con el primer contrato debe devolver el primer valor mockeado  por lo que la caché se habrá hecho correctamente
        portfoliosType = portfoliosRepository.callToPortfolios(Arrays.asList(CONTRACT_ONE), new CustomerProductQueryParams());

        Assertions.assertThat(portfoliosType).isNotEmpty();
        Assertions.assertThat(portfoliosType.size()).isEqualTo(1);
        Assertions.assertThat(portfoliosType.get(0).getTypePortfolio()).isEqualTo("GE");
    }

    /**
     * The service shouldn't cache when diferents contracts but should cache with same contracts
     * */
    @Test
    public void checkNoCacheWithContractAndSecondCallwithSameAndOther() {

        // Mockeamos la llamada de una lista con un contrato y una llamada con otra lista ese mismo contrato y otro contrato diferente en el restTemplate
        List<PortfolioType> expectedResponse = Arrays.asList(
                PortfolioType.builder().idPortfolioContract(CONTRACT_ONE).typePortfolio("GE").build()
        );

        List<PortfolioType> expectedResponse2 = Arrays.asList(
                PortfolioType.builder().idPortfolioContract(CONTRACT_ONE).typePortfolio("NOGE").build(),
                PortfolioType.builder().idPortfolioContract(CONTRACT_TWO).typePortfolio("AS").build()
        );


        Mockito.when(this.restTemplate.exchange(
                any(String.class),
                any(HttpMethod.class),
                any(HttpEntity.class),
                any(ParameterizedTypeReference.class))
        ).thenReturn(new ResponseEntity(expectedResponse, HttpStatus.OK));


        // Hacemos la peticion con la primera lista y devolvera el dato mockeado del retTemplate
        List<PortfolioType> portfoliosType = portfoliosRepository
                .callToPortfolios(Arrays.asList(CONTRACT_ONE), new CustomerProductQueryParams());

        Assertions.assertThat(portfoliosType).isNotEmpty();
        Assertions.assertThat(portfoliosType.size()).isEqualTo(1);
        Assertions.assertThat(portfoliosType.get(0).getTypePortfolio()).isEqualTo("GE");

        Mockito.when(this.restTemplate.exchange(
                any(String.class),
                any(HttpMethod.class),
                any(HttpEntity.class),
                any(ParameterizedTypeReference.class))
        ).thenReturn(new ResponseEntity(expectedResponse2, HttpStatus.OK));
        // Hacemos la llamada con la segunda lista. Aunque comparte un contrato como la lista es diferente, la cache no le afectará, se llama al restemplate
        // y devolvera lo mockeado para esta lista
        portfoliosType = portfoliosRepository
                .callToPortfolios(Arrays.asList(CONTRACT_ONE,CONTRACT_TWO), new CustomerProductQueryParams());

        Assertions.assertThat(portfoliosType).isNotEmpty();
        Assertions.assertThat(portfoliosType.size()).isEqualTo(2);
        Assertions.assertThat(portfoliosType.get(0).getTypePortfolio()).isEqualTo("NOGE");
        Assertions.assertThat(portfoliosType.get(1).getTypePortfolio()).isEqualTo("AS");

        // Cambiamos los datos mokeados para las dos listas
        List<PortfolioType> expectedResponse3 = Arrays.asList(
                PortfolioType.builder().idPortfolioContract(CONTRACT_ONE).typePortfolio("NOGE").build()
        );

        List<PortfolioType> expectedResponse4 = Arrays.asList(
                PortfolioType.builder().idPortfolioContract(CONTRACT_ONE).typePortfolio("GE").build(),
                PortfolioType.builder().idPortfolioContract(CONTRACT_TWO).typePortfolio("NOAS").build()
        );


        Mockito.when(this.restTemplate.exchange(
                any(String.class),
                any(HttpMethod.class),
                any(HttpEntity.class),
                any(ParameterizedTypeReference.class))
        ).thenReturn(new ResponseEntity(expectedResponse3, HttpStatus.OK));

        Mockito.when(this.restTemplate.exchange(
                any(String.class),
                any(HttpMethod.class),
                any(HttpEntity.class),
                any(ParameterizedTypeReference.class))
        ).thenReturn(new ResponseEntity(expectedResponse4, HttpStatus.OK));

        // Al hacer la llamada, como la petición está cacheada, devolverá los valores respectivos antes cacheados ignorando los nuevos mockeaos ya que no se hará la llamada restTemplate
        portfoliosType = portfoliosRepository
                .callToPortfolios(Arrays.asList(CONTRACT_ONE), new CustomerProductQueryParams());

        Assertions.assertThat(portfoliosType).isNotEmpty();
        Assertions.assertThat(portfoliosType.size()).isEqualTo(1);
        Assertions.assertThat(portfoliosType.get(0).getTypePortfolio()).isEqualTo("GE");

        portfoliosType = portfoliosRepository
                .callToPortfolios(Arrays.asList(CONTRACT_ONE,CONTRACT_TWO), new CustomerProductQueryParams());

        Assertions.assertThat(portfoliosType).isNotEmpty();
        Assertions.assertThat(portfoliosType.size()).isEqualTo(2);
        Assertions.assertThat(portfoliosType.get(0).getTypePortfolio()).isEqualTo("NOGE");
        Assertions.assertThat(portfoliosType.get(1).getTypePortfolio()).isEqualTo("AS");
    }

}
