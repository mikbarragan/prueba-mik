package es.santander.adn360.products.common.switchhost.resilence4j;

import es.santander.adn360.core.model.exception.FunctionalException;
import es.santander.adn360.core.util.ExceptionEnum;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;

import static org.mockito.MockitoAnnotations.initMocks;

class Is5xxPredicateTest {

    @InjectMocks
    private Is5xxPredicate is5xxPredicate;

    @BeforeEach
    void setUp() {
        initMocks(this);
    }

    @Test
    void test_given5xxStatusException_shouldReturnTrue() {
        boolean result = is5xxPredicate.test(new FunctionalException(ExceptionEnum.INTERNAL_SERVER_ERROR));
        Assertions.assertThat(result).isTrue();
    }

    @Test
    void test_givenNot5xxStatusException_shouldReturnFalse() {
        boolean result = is5xxPredicate.test(new FunctionalException(ExceptionEnum.NO_DATA_FOUND));
        Assertions.assertThat(result).isFalse();
    }

    @Test
    void test_Contructor() {
        Is5xxPredicate is5xxPredicate = new Is5xxPredicate();
        Assertions.assertThat(is5xxPredicate).isNotNull();
    }

}