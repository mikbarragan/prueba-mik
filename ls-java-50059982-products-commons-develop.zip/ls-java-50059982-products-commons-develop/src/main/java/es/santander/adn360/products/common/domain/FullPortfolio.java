package es.santander.adn360.products.common.domain;

import lombok.Data;

import java.util.Map;

import static es.santander.adn360.products.common.service.PortfolioServiceImpl.BAJA_KEY;

/**
 * FullPortfolio
 */
@Data
public class FullPortfolio {

    /** contract */
    private PortfolioContract contract;

    /** type */
    private PortfolioType type;

    /**
     * Constructor
     *
     * @param contract PortfolioContract
     * @param typeMap Map
     */
    public FullPortfolio(PortfolioContract contract, Map<String, PortfolioType> typeMap) {
        this.contract = contract;
        this.type = typeMap.get(contract.getContratoCartera());
    }

    /**
     * Esta activo
     *
     * @return bool
     */
    public boolean isTypeActive() {
        return ! BAJA_KEY.equalsIgnoreCase(type.getTypePortfolio());
    }

    /**
     * getSetContract
     *
     * @return PortfolioContract s
     */
    public PortfolioContract getSetContract() {

        contract.setSiga(type.getSiga());
        contract.setTipoCartera(type.getTypePortfolio());
        contract.setPortfolioDescription(type.getPortfolioDescription());

        return contract;
    }

}
