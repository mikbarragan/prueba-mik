package es.santander.adn360.products.common.domain;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.Document;

import java.io.Serial;
import java.io.Serializable;
import java.util.Objects;

/**
 * Intervener information
 *
 * nonsense commentary to comply with a nonsense rule nonsense commentary to
 * comply with a nonsense rule nonsense commentary to comply with a nonsense
 * rule nonsense commentary to comply with a nonsense rule
 *
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "#{@commonMongoCollectionsProperties.getTiposIntervencion()}")
public class IntervenerInfo implements Serializable {

	/**
	 * Generated serial version UID
	 */
	@Serial
	private static final long serialVersionUID = 1L;

	/**
	 * Participant type
	 */
	@Schema(description = "Participant type", example = "01")
	private String tipoIntervencion;

	/**
	 * Participant name
	 */
	@Schema(description = "Participant name")
	private String nombreIntervencion;

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		IntervenerInfo that = (IntervenerInfo) o;
		return Objects.equals(tipoIntervencion, that.tipoIntervencion);
	}

	@Override
	public int hashCode() {
		return Objects.hash(tipoIntervencion);
	}
}
