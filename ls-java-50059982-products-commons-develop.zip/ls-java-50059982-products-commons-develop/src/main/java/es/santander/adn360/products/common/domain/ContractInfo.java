package es.santander.adn360.products.common.domain;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * Contract information
 */
@Data
@Builder
@Document(collection = "#{@commonMongoCollectionsProperties.getEmpresaSubprod()}")
public class ContractInfo {
	/**
	 * id
	 */
	@Id
	@Schema(description = "Id")
	private String id;
	/**
	 * empresa
	 */
	@Schema(description = "Company", example = "0049")
	private String empresa;
	/**
	 * producto
	 */
	@Schema(description = "Product")
	private String producto;
	/**
	 * subproducto
	 */
	@Schema(description = "Subproduct", example = "002")
	private String subproducto;
	/**
	 * descripcion
	 */
	@Schema(description = "Description")
	private String descripcion;
	/**
	 * descripcionLarga
	 */
	@Schema(description = "Large description", example = "FORWARD AMERICANO - PROPUESTA TIPO L�NEA")
	private String descripcionLarga;
	/**
	 * nombreProducto
	 */
	@Schema(description = "Product name", example = "FORW.AMER.-PRO.TIP.LIN.")
	private String nombreProducto;
	/**
	 * indicadorProducto
	 */
	@Schema(description = "Product indicator", example = "0")
	private String indicadorProducto;

	/**
	 * Get map id
	 *
	 * @return empresa producto subproducto
	 */
	public String getMapId() {
		return empresa + producto + subproducto;
	}
}
