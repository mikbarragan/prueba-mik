package es.santander.adn360.products.common.service;

import es.santander.adn360.core.util.CustomerProductQueryParams;
import es.santander.adn360.products.common.domain.bean.ProductQueryBuilderParams;
import org.springframework.data.mongodb.core.query.Criteria;

import java.util.List;

/**
 * Service for creating main product criteria.
 */
public interface ProductQueryBuilder {

    /**
     * Gets product main criteria based on query string params ,Santander channel and given parameters.
     * This criteria should be used as main query criteria in product repositories.
     *
     * @param customerProductQueryParams    Query string params
     * @param productQueryBuilderParams     Parameters needed to apply proper contract queries
     * @param customerIdList                Customer list
     * @return Criteria
     */
    Criteria getProductCriteria(CustomerProductQueryParams customerProductQueryParams,
                                ProductQueryBuilderParams productQueryBuilderParams,
                                List<String> customerIdList);
}
