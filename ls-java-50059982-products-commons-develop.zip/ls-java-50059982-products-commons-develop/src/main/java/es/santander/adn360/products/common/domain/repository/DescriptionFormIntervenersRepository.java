package es.santander.adn360.products.common.domain.repository;

import es.santander.adn360.products.common.domain.DescriptionFormInterveners;

import java.util.List;
import java.util.Map;

/**
 * Description Form Interveners
 * Repository interface
 */
public interface DescriptionFormIntervenersRepository {

	/**
	 * Find all descriptions interveners forms
	 *
	 * @return list of descriptions interveners forms
	 */
	List<DescriptionFormInterveners> findAll();


	/**
	 * Find all descriptions interveners forms
	 *
	 * @return Map of descriptions interveners forms
	 */
	Map<String, DescriptionFormInterveners> findAllAsMap();


}
