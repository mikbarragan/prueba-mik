package es.santander.adn360.products.common.service;

import es.santander.adn360.core.model.document.Product;
import es.santander.adn360.core.model.document.ProductGroup;
import es.santander.adn360.core.model.exception.FunctionalException;
import es.santander.adn360.core.util.ExceptionEnum;
import es.santander.adn360.core.util.ProductQueryParams;
import es.santander.adn360.core.web.WebUtils;
import es.santander.adn360.products.common.config.ServicesProperties;
import es.santander.adn360.products.common.domain.entity.BaseContract;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import lombok.val;
import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import static java.lang.String.format;

/**
 * Implementation for ProductGroupService
 */
@Service
@Slf4j
@RequiredArgsConstructor
@ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
public class ProductGroupServiceImpl implements ProductGroupService {

    private final ServicesProperties servicesProperties;
    private final RestTemplate restTemplate;
    private final ProductGroupCacheService productGroupCacheService;

    /**
     * Get product groups
     *
     * @param channel     Application channel
     * @param application Application name
     * @param segment     Application segment
     * @return list of product groups
     */
    @Override
    public List<ProductGroup> getProductGroups(
            String channel,
            String application,
            String segment
    ) {
        return this.getProductGroups(
                ProductQueryParams.builder().application(application).segment(segment).build()
        );
    }

    /**
     * Gets product groups from specific channel, application and segment
     *
     * @param productQueryParams ProductQueryParams
     * @return Product Group list
     */
    @Override
    public List<ProductGroup> getProductGroups(
            ProductQueryParams productQueryParams
    ) {
        return productGroupCacheService.getProductGroups(
                productQueryParams,
                WebUtils.getSantanderChannel()
        );
    }

    /**
     * Get product group
     *
     * @param channel        Application channel
     * @param application    Application name
     * @param segment        Application segment
     * @param productGroupId Product group identification
     * @return found product group
     */
    @Override
    public ProductGroup getProductGroup(
            String channel,
            String application,
            String segment,
            String productGroupId
    ) {
        return this.getProductGroup(
                ProductQueryParams.builder().application(application).segment(segment).build(),
                productGroupId
        );
    }

    /**
     * Gets product group
     *
     * @param productQueryParams ProductQueryParams
     * @return Product Group
     */
    @Override
    public ProductGroup getProductGroup(
            ProductQueryParams productQueryParams,
            String productGroupId
    ) {
        return productGroupCacheService.getProductGroup(
                productQueryParams,
                productGroupId,
                WebUtils.getSantanderChannel()
        );
    }

    /**
     * get products
     *
     * @param channel        Application channel
     * @param application    Application name
     * @param segment        Application segment
     * @param productGroupId Product group identification
     * @return list of products
     */
    @Override
    public List<Product> getProducts(
            String channel,
            String application,
            String segment,
            String productGroupId
    ) {
        return this.getProducts(
                ProductQueryParams.builder().application(application).segment(segment).build(),
                productGroupId
        );
    }

    /**
     * Gets product configuration
     *
     * @param productQueryParams ProductQueryParams
     * @param productGroupId     Product group identification
     * @return Product list.
     */
    @Override
    public List<Product> getProducts(
            ProductQueryParams productQueryParams,
            String productGroupId
    ) {
        return productGroupCacheService.getProducts(
                productQueryParams,
                productGroupId,
                WebUtils.getSantanderChannel()
        );
    }

    /**
     * Gets product configuration
     *
     * @param productQueryParams ProductQueryParams
     * @param productGroupId     Product group identification
     * @return Product list.
     */
    @Override
    public List<Product> getProductsAndRelatedProducts(
            ProductQueryParams productQueryParams,
            String productGroupId,
            String relProd,
            String relSubprod
    ) {
        return productGroupCacheService.getProductsAndRelatedProducts(
                productQueryParams,
                productGroupId,
                WebUtils.getSantanderChannel(),
                relProd,
                relSubprod
        );
    }

    /**
     * Filter the contractList returning only those whose type-subtype are in the list of products.
     *
     * @param contracts list of contracts to be filtered
     * @param products  list of products allowed
     *
     * @return filtered list
     */
    public <T extends BaseContract> List<T> filterByProducts(
            List<T> contracts,
            List<Product> products
    ) {
        Assert.notNull(contracts, "contracts parameter cannot be null");
        Assert.notNull(products, "products parameter cannot be null");

        Set<String> productSet = products.stream()
                .map((Product product) -> {

                    val type = Optional.ofNullable(product.getType()).orElse(StringUtils.EMPTY);
                    val subtype = Optional.ofNullable(product.getSubType()).orElse(StringUtils.EMPTY);

                    return type + subtype;

                }).collect(Collectors.toCollection(HashSet::new));

        return contracts.stream()
                .filter((T contract) -> {

                    val product = Optional.ofNullable(contract.getProductoNuevo()).orElse(StringUtils.EMPTY);
                    val subproduct = Optional.ofNullable(contract.getSubproducto()).orElse(StringUtils.EMPTY);

                    val productKey = product + subproduct;

                    return productSet.contains(productKey) || productSet.contains(contract.getProductoNuevo());

                })
                .collect(Collectors.toList());
    }


    /**
     * Method needed to clean product group cache.
     */
    @Override
    @Scheduled(cron = "${services.productGroupsService.cacheCron}")
    @Caching(
            evict = {
                    @CacheEvict(
                            cacheNames = {
                                    "getProductGroups_queryParamsChannel_cache",
                                    "getProductGroup_queryPGroupIdChannel_cache",
                                    "getProducts_qpPgiChn_cache",
                                    "product_configurations_catalog",
                                    "related_product_configurations"
                            },
                            allEntries = true
                    ),
                    @CacheEvict(
                            cacheNames = {
                                    "getProduct_typeSubtype_cache"
                            },
                            allEntries = true
                    )
            }
    )
    public void cleanProductgroupCache() {
        log.info("Cleaning caches.");
    }

    /**
     * Get Catalog ids
     *
     * @param productQueryParams productQueryParams
     * @param productGroupId     productGroupId
     * @return products
     */
    @Override
    public List<String> getCatalogIds(
            ProductQueryParams productQueryParams,
            String productGroupId
    ) {
        return productGroupCacheService.getCatalogIds(
                productQueryParams,
                productGroupId,
                WebUtils.getSantanderChannel()
        );
    }

    /**
     * Get a single product by type and subtype
     *
     * @param type    input product type
     * @param subtype input product subtype
     * @return a product
     */
    @Override
    @Cacheable(
            cacheNames = { "getProduct_typeSubtype_cache" },
            unless = "#result == null"
    )
    public Product getProduct(
            String type,
            String subtype
    ) {
        URI uri = this.getServiceURIAgnostic(
                servicesProperties.getProductGroupsService().getProductUri(),
                type,
                subtype
        );

        Product result = restTemplate.exchange(
                uri, HttpMethod.GET, null, new ParameterizedTypeReference<Product>() {
                }
        ).getBody();

        if (result == null) {
            throw new FunctionalException(
                    ExceptionEnum.INVALID_INPUT_PARAMETERS,
                    format("No product found for type=%s, subtype=%s", type, subtype)
            );
        }

        return result;
    }

    /**
     * Método para la obtención de la uri para la llamada al servicio
     *
     * @param uriString uri del micro
     * @param type      tipo del producto
     * @param subtype   subtipo del producto
     * @return Devolución del uri compuesto para llamar al servicio
     */
    public URI getServiceURIAgnostic(
            String uriString,
            String type,
            String subtype
    ) {
        val url = String.format(uriString, type, subtype);

        return UriComponentsBuilder
                .fromHttpUrl(url)
                .build()
                .encode()
                .toUri();
    }

    /**
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     *
     */

}
