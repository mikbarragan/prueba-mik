package es.santander.adn360.products.common.domain.repository;

import es.santander.adn360.products.common.domain.Person;
import es.santander.adn360.products.common.domain.entity.Intervener;
import org.springframework.data.repository.NoRepositoryBean;

import java.util.List;
import java.util.Map;

// TODO: This repository should be removed. A call to customer microservice
//  needs to be done in order to accomplish this functionality.

/**
 * Person repository
 */
@NoRepositoryBean
public interface PersonRepository {

    /**
     * Find all persons
     * @return list of persons
     */
    List<Person> findAll();
    /**
     * Find the Person by Type and Code [F-000000001]
     *
     * @param type Type
     * @param code Code
     * @return the Person
     */
    Person findOneByTypeAndCode(String type, String code);

    /**
     * Gets persons for interveners
     *
     * @param interveners Intervener list.
     * @return Person list.
     */
    List<Person> findByIntervenerList(List<Intervener> interveners);

    /**
     * Find the Person by Type and Code [F-000000001] and fecha baja
     *
     * @param type Type
     * @param code Code
     * @param company Company
     * @return the Person
     */
    Person findOneByTypeAndCodeAndCompany(String type, String code, String company);

    /**
     * findAsMapByInterveners
     * @param interveners to find
     * @return map
     */
    Map<String, Person> findAsMapByInterveners(List<Intervener> interveners);
}
