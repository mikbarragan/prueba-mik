package es.santander.adn360.products.common.service;

import es.santander.adn360.core.model.document.Exchange;
import es.santander.adn360.products.common.config.ServicesProperties;
import es.santander.adn360.products.common.domain.bean.BalanceBean;
import es.santander.adn360.products.common.domain.bean.ExchangeBalanceBean;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import java.util.Optional;

/**
 * Currency service implementation.
 *
 * nonsense commentary to comply with a nonsense rule
 * nonsense commentary to comply with a nonsense rule
 * nonsense commentary to comply with a nonsense rule
 * nonsense commentary to comply with a nonsense rule
 *
 */
@Service
@Slf4j
@RequiredArgsConstructor
@ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
public class CurrencyServiceImpl implements CurrencyService {

    /**
     * Constants
     */
    private static final String PARAM_DIVISA_ORIGEN = "divisa_origen";
    private static final String PARAM_DIVISA_DESTINO = "divisa_destino";

    private final ServicesProperties servicesProperties;
    private final RestTemplate restTemplate;

    /**
     * Gets exchange between currencies.
     *
     * @param originCurrency  Origin currency
     * @param destinyCurrency Destiny currency
     * @return Exchange
     */
    @Override
    @Cacheable(cacheNames = {"currencies"},
            unless = "#result == null")
    @CircuitBreaker(name = "getExchangeCB", fallbackMethod = "getFallBackExchange")
    public Exchange getExchange(String originCurrency, String destinyCurrency) {
        log.info("Getting exchange.");
        UriComponentsBuilder builder = UriComponentsBuilder
                .fromHttpUrl(this.servicesProperties.getCurrenciesService().getCurrenciesUri())
                .queryParam(PARAM_DIVISA_ORIGEN, originCurrency)
                .queryParam(PARAM_DIVISA_DESTINO, destinyCurrency);

        ResponseEntity<List<Exchange>> response = restTemplate.exchange(builder.build().encode().toUri(),
                HttpMethod.GET, null
                , new ParameterizedTypeReference<List<Exchange>>() {
                });

        return Optional.of(response)
                .filter(r -> HttpStatus.NO_CONTENT != r.getStatusCode())
                .map(HttpEntity::getBody)
                .filter(e -> !e.isEmpty())
                .map(e -> e.get(0))
                .orElse(Exchange.builder()
                        .divisaOrigen(originCurrency).divisaDestino(destinyCurrency).build());
    }

    /**
     * Fallback circuit breaker command method for getting the exchange.
     *
     * @param originCurrency  origin currency
     * @param destinyCurrency destiny currency
     * @return Exchange
     */
    private Exchange getFallBackExchange(String originCurrency, String destinyCurrency, Throwable commandException) {
        log.error(String.format("Error getting exchange for %s and %s. Returning fallback null exchange."
                , originCurrency, destinyCurrency), commandException);

        return Exchange.builder()
                .divisaOrigen(originCurrency)
                .divisaDestino(destinyCurrency)
                .build();
    }

    /**
     * Converts an amount to a given currency.
     *
     * @param exchange Exchange
     * @param amount   Amount
     * @return Converted value
     */
    @Override
    public BigDecimal convertCurrency(Exchange exchange, BigDecimal amount) {
        Assert.notNull(exchange, "Exchange cannot be null.");
        Assert.notNull(amount, "Amount cannot be null.");
        return exchange.getCambioFijo() == null ? BigDecimal.ZERO
                : amount.divide(exchange.getCambioFijo(), 2, RoundingMode.HALF_UP);
    }

	/**
	 * Converts an amount to a given currency and return an ExchangeBalanceBean
	 *
	 * @param exchange
	 *            Exchange
	 * @param amount
	 *            BigDecimal
	 * @return ExchangeBalanceBean
	 */
	@Override
	public ExchangeBalanceBean getExchangeBalanceBean(Exchange exchange, BigDecimal amount) {

		return Optional.ofNullable(exchange).filter(e -> amount != null)
				.map(e -> ExchangeBalanceBean.builder().amount(amount)
						.exchange(BalanceBean.builder().amount(this.convertCurrency(e, amount))
								.currency(e.getDivisaDestino()).build())
						.build())
				.orElse(ExchangeBalanceBean.builder().amount(amount).build());
	}

    /**
     * Converts the amount of an ExchangeBalanceBean to given currency and return an ExchangeBalanceBean
     *
     * @param exchange            Exchange
     * @param exchangeBalanceBean ExchangeBalanceBean
     * @return ExchangeBalanceBean
     */
    @Override
    public ExchangeBalanceBean getExchangeBalanceBean(Exchange exchange, ExchangeBalanceBean exchangeBalanceBean) {
        final BigDecimal amount = exchangeBalanceBean == null ? null : exchangeBalanceBean.getAmount();
        return this.getExchangeBalanceBean(exchange, amount);
    }

    /**
     * Method needed to clean currencies cache.
     */
    @Override
    @Scheduled(cron = "${services.currenciesService.cacheCron}")
    @CacheEvict(cacheNames = {"currencies"},
            allEntries = true)
    public void cleanCurrenciesCache() {
        log.info("Cleaning currencies cache.");
    }
}
