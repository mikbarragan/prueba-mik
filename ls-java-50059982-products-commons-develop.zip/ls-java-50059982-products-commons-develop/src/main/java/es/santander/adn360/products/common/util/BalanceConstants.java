package es.santander.adn360.products.common.util;

/**
 * Balances constants
 */
public final class BalanceConstants {

    /**
     * Currency default value EUR
     */
    public static final String CUR_EUR = "EUR";

    /**
     * Empty constructor
     */
    private BalanceConstants() {
    }
}
