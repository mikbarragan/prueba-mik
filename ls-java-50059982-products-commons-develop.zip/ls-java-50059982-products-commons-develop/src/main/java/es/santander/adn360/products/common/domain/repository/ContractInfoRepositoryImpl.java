package es.santander.adn360.products.common.domain.repository;

import es.santander.adn360.mongodb.starter.autoconfigure.MongoQueryRepositoryAutoConfiguration;
import es.santander.adn360.mongodb.starter.domain.MongoQueryRepositoryImpl;
import es.santander.adn360.mongodb.starter.domain.QueryParams;
import es.santander.adn360.products.common.domain.ContractInfo;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.aggregation.AggregationOperation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.repository.support.MongoRepositoryFactory;
import org.springframework.stereotype.Repository;
import org.springframework.util.Assert;

import java.util.List;

import static org.springframework.data.mongodb.core.aggregation.Aggregation.match;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.project;

/**
 * ContractInfoRepositoryImpl
 * nonsense commentary to comply with a nonsense rule
 * nonsense commentary to comply with a nonsense rule
 * nonsense commentary to comply with a nonsense rule
 * nonsense commentary to comply with a nonsense rule
 * nonsense commentary to comply with a nonsense rule
 */
@ConditionalOnClass(MongoQueryRepositoryAutoConfiguration.class)
@Repository
public class ContractInfoRepositoryImpl extends MongoQueryRepositoryImpl<ContractInfo, String>
        implements ContractInfoRepository {

    /**
     * Constructor
     *
     * @param mongoRepositoryFactory mongoRepositoryFactory
     * @param mongoOperations        mongoOperations
     */
    public ContractInfoRepositoryImpl(MongoRepositoryFactory mongoRepositoryFactory, MongoOperations mongoOperations) {
        super(mongoRepositoryFactory.getEntityInformation(ContractInfo.class), mongoOperations);
    }

    /**
     * Find contract info
     *
     * @param contractInfoList input list
     * @return list of found contracts
     */
    @Override
    public List<ContractInfo> findContractInfo(final List<ContractInfo> contractInfoList) {
        Assert.notEmpty(contractInfoList, "ContractInfoList should not be empty");

        final AggregationOperation[] operations = new AggregationOperation[]{
                match(this.matchContracts(contractInfoList)),
                project("empresa", "producto", "subproducto",
                        "descripcion", "descripcionLarga", "nombreProducto", "indicadorProducto")
        };

        return this.findAll(QueryParams.builder().build(), ContractInfo.class, operations).getContent();
    }

    /**
     * Criteria match contracts builder
     *
     * @param contractInfoList contract list
     * @return criteria
     */
    private Criteria matchContracts(List<ContractInfo> contractInfoList) {
        return new Criteria()
                .orOperator(
                        contractInfoList.stream()
                                .map((ContractInfo contractInfo) -> {
                                    Criteria criteria = Criteria
                                            .where("empresa").is(contractInfo.getEmpresa())
                                            .and("producto").is(contractInfo.getProducto());
                                    if (contractInfo.getSubproducto() != null) {
                                        criteria.and("subproducto").is(contractInfo.getSubproducto());
                                    }
                                    return criteria;
                                })
                                .toArray(Criteria[]::new)
                );
    }
}
