package es.santander.adn360.products.common.service;

import es.santander.adn360.core.model.exception.FunctionalException;
import es.santander.adn360.core.util.CustomerProductQueryParams;
import es.santander.adn360.core.util.ExceptionEnum;
import es.santander.adn360.core.util.ProductQueryParams;
import es.santander.adn360.core.web.WebUtils;
import es.santander.adn360.products.common.config.SituationIndicatorFiltersProperties;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

/**
 * Situation Indicator Service
 * Implementation
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class SituationIndicatorServiceImpl implements SituationIndicatorService {

    private final SituationIndicatorFiltersProperties situationIndicatorFiltersProperties;

    private static final String ACTIVES_INDICATOR = "actives";
    private static final String ALL_INDICATOR = "all";
    private static final String CANCELED_INDICATOR = "canceled";
    private static final String PRECANCELED_INDICATOR = "precanceled";

    private static final String DEFAULT_APPLICATION_CFG = "default";
    private static final String NOCONFIG = "noconfig";

    /**
     * Return all contract codes and names configured by channel and appliation and status
     * into application.yml under key:
     * situation-indicator-filter.*
     *
     *
     * Ej: Funds product has AC code as ACTIVES with filter equals ACTIVES
     *
     * @param status      references to contract status (ACTIVES,CANCELED, ALL) {@link CustomerProductQueryParams}
     * @param application references to application name param value (ADN360, PSD2, NWE,..) {@link ProductQueryParams}
     * @return a List String with codes.
     */
    @Override
    public List<String> findContractCodes(
            final String status,
            final String application
    ) {
        // lista de estados
        SituationIndicatorFiltersProperties.Status listStatus = getChannelConfig(application);

        List<String> actives;
        List<String> precanceled;
        List<String> canceled;

        switch (status.toLowerCase(Locale.getDefault())) {
            case PRECANCELED_INDICATOR:
                precanceled = getCodes(listStatus, PRECANCELED_INDICATOR);
                if (precanceled == null) {
                    throw new FunctionalException(ExceptionEnum.INTERNAL_SERVER_ERROR,
                            "Situation indicator for Precanceled is not configured");
                }
                return precanceled;
            case CANCELED_INDICATOR:
                canceled = getCodes(listStatus, CANCELED_INDICATOR);
                if (canceled == null) {
                    throw new FunctionalException(ExceptionEnum.INTERNAL_SERVER_ERROR,
                            "Situation indicator for Canceled is not configured");
                }
                return canceled;
            case ALL_INDICATOR:
                List<String> all = new ArrayList<>();
                actives = getCodes(listStatus, ACTIVES_INDICATOR);
                precanceled = getCodes(listStatus, PRECANCELED_INDICATOR);
                canceled = getCodes(listStatus, CANCELED_INDICATOR);
                all.addAll(actives == null ? Collections.emptyList() : actives);
                all.addAll(canceled == null ? Collections.emptyList() : canceled);
                all.addAll(precanceled == null ? Collections.emptyList() : precanceled);
                if (CollectionUtils.isEmpty(all)) {
                    throw new FunctionalException(ExceptionEnum.INTERNAL_SERVER_ERROR,
                            "Situation indicator is not configured");
                }
                return all;
            default:
                // Active codes by default
                actives = getCodes(listStatus, ACTIVES_INDICATOR);
                if (actives == null) {
                    throw new FunctionalException(ExceptionEnum.INTERNAL_SERVER_ERROR,
                            "Situation indicator for Actives is not configured");
                }
                return actives;
        }
    }

    /**
     * Return all contract codes and names configured by channel and status into application.yml under key:
     * situation-indicator-filter.*
     *
     *
     * Ej: Funds product has AC code as ACTIVES with filter equals ACTIVES
     *
     * @param status references to contract status (ACTIVES,CANCELED, ALL) {@link CustomerProductQueryParams}
     * @return a List String with codes.
     */
    @Override
    public List<String> findContractCodes(final String status) {
        return findContractCodes(status, null);
    }

    /**
     * Get max time to find contracts
     *
     * @param application input application
     * @return months number
     */
    @Override
    public Integer getMaxTimeCanceledContracts(final String application) {
        // lista de estados
        SituationIndicatorFiltersProperties.Status listStatus = getChannelConfig(application);
        // Comprobar configuraciones obtenidas
        checkMaxTimeConfiguration(listStatus);

        return listStatus.getCanceled().getMaxTime();
    }

    /**
     * Búsqueda aplicación por canal
     *
     * @param application aplicación de entrada
     * @return devolución de aplicación properties
     */
    private SituationIndicatorFiltersProperties.Status getChannelConfig(final String application) {
        SituationIndicatorFiltersProperties.Channel channelCfg = this.situationIndicatorFiltersProperties.getChannel()
                == null ? null
                : this.situationIndicatorFiltersProperties.getChannel().get(WebUtils.getSantanderChannel());
        return channelCfg == null
                ? loadDefaultApplication()
                : getApplicationCodesCfg(channelCfg, application);
    }

    /**
     * Check default application
     *
     * @param channelCfg  channelCfg
     * @param application application
     * @return application codes
     */
    private SituationIndicatorFiltersProperties.Status getApplicationCodesCfg(
            final SituationIndicatorFiltersProperties.Channel channelCfg,
            final String application
    ) {
        String appName = application;
        if (StringUtils.isNoneEmpty(application) && application.equalsIgnoreCase(DEFAULT_APPLICATION_CFG)) {
            appName = channelCfg.getApplication().stream()
                    .map(SituationIndicatorFiltersProperties.ApplicationCodesCfg::getName)
                    .filter(s -> s.equalsIgnoreCase(DEFAULT_APPLICATION_CFG))
                    .findFirst()
                    .orElse(NOCONFIG);
        }
        String finalAppName = appName;
        return channelCfg.getApplication()
                .stream()
                .filter(app -> app.getName().equalsIgnoreCase(application))
                .findFirst()
                .map(SituationIndicatorFiltersProperties.ApplicationCodesCfg::getStatus)
                .orElseGet(() -> {
                    if (StringUtils.isNoneEmpty(finalAppName) && finalAppName.equalsIgnoreCase(NOCONFIG)) {
                        return loadDefaultApplication();
                    } else {
                        return getApplicationCodesCfg(channelCfg, DEFAULT_APPLICATION_CFG);
                    }
                });
    }

    /**
     * Check the configuration laoded,
     * if there not app or channel config
     * load default config
     *
     * @param status status config
     */
    private void checkMaxTimeConfiguration(final SituationIndicatorFiltersProperties.Status status) {
        if (status.getCanceled() == null) {
            if (this.situationIndicatorFiltersProperties.getCanceled() == null) {
                throw new FunctionalException(ExceptionEnum.CONTRACT_SITUATION_ERROR,
                        "Situation indicator by Canceled is not configured");
            } else {
                status.setCanceled(this.situationIndicatorFiltersProperties.getCanceled());
            }
        }
        if (status.getCanceled().getMaxTime() == null) {
            throw new FunctionalException(ExceptionEnum.CONTRACT_SITUATION_ERROR,
                    "Max time for canceled contract on Situation indicator is not configured");
        }
    }

    /**
     * Set a default configuration on application
     *
     * @return ApplicationCodesCfg
     */
    private SituationIndicatorFiltersProperties.Status loadDefaultApplication() {
        SituationIndicatorFiltersProperties.Status status = new SituationIndicatorFiltersProperties.Status();
        status.setActives(this.situationIndicatorFiltersProperties.getActives());
        status.setCanceled(this.situationIndicatorFiltersProperties.getCanceled());
        status.setPrecanceled(this.situationIndicatorFiltersProperties.getPrecanceled());
        return status;
    }

    /**
     * Get codes needs to search contracts
     *
     * @param status             status configuration
     * @param situationContracts status contract
     * @return code list
     */
    private List<String> getCodes(
            final SituationIndicatorFiltersProperties.Status status,
            final String situationContracts
    ) {
        switch (situationContracts) {
            case PRECANCELED_INDICATOR:
                return Optional.ofNullable(status.getPrecanceled())
                        .map(SituationIndicatorFiltersProperties.Types::getCodes)
                        .orElse(Optional.ofNullable(this.situationIndicatorFiltersProperties.getPrecanceled())
                                .map(SituationIndicatorFiltersProperties.Types::getCodes)
                                .orElse(null));
            case CANCELED_INDICATOR:
                return Optional.ofNullable(status.getCanceled())
                        .map(SituationIndicatorFiltersProperties.Types::getCodes)
                        .orElse(Optional.ofNullable(this.situationIndicatorFiltersProperties.getCanceled())
                                .map(SituationIndicatorFiltersProperties.Types::getCodes)
                                .orElse(null));
            default:
                return Optional.ofNullable(status.getActives())
                        .map(SituationIndicatorFiltersProperties.Types::getCodes)
                        .orElse(Optional.ofNullable(this.situationIndicatorFiltersProperties.getActives())
                                .map(SituationIndicatorFiltersProperties.Types::getCodes)
                                .orElse(null));
        }
    }

    /**
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     *
     */
}
