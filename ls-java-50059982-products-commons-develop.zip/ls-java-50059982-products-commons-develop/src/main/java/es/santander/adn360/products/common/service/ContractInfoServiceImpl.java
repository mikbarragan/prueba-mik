package es.santander.adn360.products.common.service;

import es.santander.adn360.products.common.domain.ContractInfo;
import es.santander.adn360.products.common.domain.entity.BaseContract;
import es.santander.adn360.products.common.domain.repository.ContractInfoRepository;
import lombok.val;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Contract infor service implementation
 */
@Service
public class ContractInfoServiceImpl implements ContractInfoService {

    @Autowired(required = false)
    private ContractInfoRepository contractInfoRepository;

    /**
     * Find the Contract Descriptions by contracts list.
     *
     * @param contracts contracts
     * @return  mapper
     */
    @Override
    public Map<String, String> findContractDescriptions(List<? extends BaseContract> contracts) {
        Assert.notNull(contractInfoRepository, "Mongo dependency is required");

        // find contract info
        val contractInfoList = contractInfoRepository.findContractInfo(getContractList(contracts));

        if (CollectionUtils.isEmpty(contractInfoList)){
            return Collections.emptyMap();
        }
        // return map with contract if and description
        return contractInfoList.stream().collect(Collectors.toMap(ContractInfo::getMapId,
                ContractInfo::getDescripcion));
    }

    /**
     * Find the Contract Info by contracts list.
     *
     * @param contracts contracts
     * @return  mapper
     */
    @Override
    public Map<String, ContractInfo> findContractInfo(List<? extends BaseContract> contracts) {
        Assert.notNull(contractInfoRepository, "Mongo dependency is required");

        val contractInfoList = contractInfoRepository.findContractInfo(getContractList(contracts));

        if (CollectionUtils.isEmpty(contractInfoList)){
            return Collections.emptyMap();
        }

        return contractInfoList.stream().collect(Collectors.toMap(ContractInfo::getMapId, Function.identity()));
    }

    /**
     * Get contract list
     * @param contracts contracts
     * @return list
     */
    private List<ContractInfo> getContractList(List<? extends BaseContract> contracts) {
        return contracts.stream().map(contract ->
                ContractInfo.builder()
                        .empresa(contract.getEmpresa())
                        .producto(contract.getProductoNuevo())
                        .subproducto(contract.getSubproducto())
                        .build())
                .distinct()
                .collect(Collectors.toList());
    }
}
