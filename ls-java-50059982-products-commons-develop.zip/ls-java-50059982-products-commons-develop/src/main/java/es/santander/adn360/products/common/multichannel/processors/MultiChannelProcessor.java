package es.santander.adn360.products.common.multichannel.processors;

import es.santander.adn360.products.common.domain.entity.BaseContract;

import java.util.List;

/**
 * Interface de la que deberán heredar todos los procesadores del
 * MultichannelPostProcessor
 * @param <T> model of BaseContract
 */
public interface MultiChannelProcessor <T extends BaseContract> {
    /**
     * procesa lista de contratos
     * @param contracts contratos
     * @return lista procesada
     */
    List<T> processListContracts(List<T> contracts);

    /**
     * Procesa un contrato
     * @param contract contrato
     * @return contrato procesado
     */
    T processContract(T contract);
}
