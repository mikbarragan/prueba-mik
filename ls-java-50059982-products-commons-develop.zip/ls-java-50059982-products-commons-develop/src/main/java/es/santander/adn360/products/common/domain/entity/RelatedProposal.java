package es.santander.adn360.products.common.domain.entity;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDate;

/**
 * RelatedProposal model
 *
 * nonsense commentary to comply with a nonsense rule nonsense commentary to
 * comply with a nonsense rule nonsense commentary to comply with a nonsense
 * rule nonsense commentary to comply with a nonsense rule nonsense commentary
 * to comply with a nonsense rule
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RelatedProposal implements Serializable {

	/**
	 * Generated serial version UID
	 */
	@Serial
	private static final long serialVersionUID = 1L;

	/**
	 * idPropuesta related proposal identifier
	 */
	@Schema(description = "Related proposal identifier")
	private String idPropuesta;

	/**
	 * idPropuestaPMP related proposal identifier
	 */
	@Schema(description = "Related proposal identifier")
	private String idPropuestaPMP;

	/**
	 * fechaFormalizacion formalized date
	 */
	@Schema(description = "Formalized date of related proposal")
	private LocalDate fechaFormalizacion;

	/**
	 * fechaVencimiento due date
	 */
	@Schema(description = "Due date of related proposal")
	private LocalDate fechaVencimientoAsoc;

	/**
	 * fechaVencimientoPMP due date
	 */
	@Schema(description = "Due date of related proposal")
	private LocalDate fechaVencimientoPMP;

}
