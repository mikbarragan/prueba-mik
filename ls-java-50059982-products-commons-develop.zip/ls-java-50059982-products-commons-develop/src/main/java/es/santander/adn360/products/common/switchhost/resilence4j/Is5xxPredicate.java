package es.santander.adn360.products.common.switchhost.resilence4j;

import es.santander.adn360.core.model.exception.FunctionalException;

import java.util.function.Predicate;

/**
 * Is5xxPredicate class description
 * implements predicate throwable
 */
public class Is5xxPredicate implements Predicate<Throwable> {

    /**
     * constructor
     * */
    public Is5xxPredicate() {
        // Constructor Is5xxPredicate
    }


    /**
     * test function
     * @param throwable error
     *
     * @return check if is functional exception
     * */
    @Override
    public boolean test(Throwable throwable) {
       return throwable instanceof FunctionalException &&
               ((FunctionalException) throwable).getInfo().getHttpStatus().is5xxServerError();
    }
}
