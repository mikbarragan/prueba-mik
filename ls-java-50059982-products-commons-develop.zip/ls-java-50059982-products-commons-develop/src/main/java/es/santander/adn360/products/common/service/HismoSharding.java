package es.santander.adn360.products.common.service;

import java.time.LocalDate;

/**
 * Interface for hismo sharding service
 */
public interface HismoSharding {
    /**
     * getShard
     * @param date  date
     * @param partitions    partitions
     * @param monthsPerPartition    monthsPerPartition
     * @return shard number
     */
    Integer getShard(LocalDate date, Integer partitions, Integer monthsPerPartition);
    /**
     * getBeforeShard
     * @param currentShard currentShard
     * @param partitions partitions
     * @return before shard
     */
    Integer getBeforeShard(Integer currentShard, Integer partitions);
    /**
     * After shard
     * @param currentShard currentShard
     * @param partitions partitions
     * @return after shard
     */
    Integer getAfterShard(Integer currentShard, Integer partitions);

}
