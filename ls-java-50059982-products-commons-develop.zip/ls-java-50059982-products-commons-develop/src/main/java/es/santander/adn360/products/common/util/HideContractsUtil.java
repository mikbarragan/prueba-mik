package es.santander.adn360.products.common.util;

import es.santander.adn360.products.common.domain.entity.BaseContract;
import es.santander.adn360.products.common.web.request.BodyRequest;
import lombok.Builder;
import lombok.Getter;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Payload Util
 */
@Getter
public class HideContractsUtil {
    /**
     * Contracts to hide
     */
    private final List<String> hideContracts;
    /**
     * Number of contracts hidden
     */
    private Integer hiddenContractsCount;

    /**
     * Constructor
     * @param bodyRequest payload
     */
    @Builder
    HideContractsUtil(BodyRequest bodyRequest) {
        this.hiddenContractsCount = null;
        this.hideContracts = Optional.ofNullable(bodyRequest)
                .map(BodyRequest::getHideContracts)
                .orElse(Collections.emptyList())
                .stream().distinct().collect(Collectors.toUnmodifiableList());
    }

    /**
     * Sets the number of hidden contracts and returns the filtered list
     * @param contracts         contract list
     * @return  contract list
     */
    public <T extends BaseContract> List<T> calculateAndFilterHiddenContracts(List<T> contracts){
        Assert.notNull(contracts, "Contract list should not be null");
        this.hiddenContractsCount = null;
        // Return same list if no contracts to hide
        if (this.isEmpyHideContracts()) {
            return contracts;
        }

        int listSize = contracts.size();
        contracts = contracts.stream()
                .filter(loan -> !this.hideContracts.contains(loan.getIdContrato()))
                .collect(Collectors.toList());

        this.hiddenContractsCount = listSize - contracts.size();
        return contracts;
    }

    /**
     * hideContracts is empty
     * @return boolean
     */
    public boolean isEmpyHideContracts() {
        return CollectionUtils.isEmpty(this.hideContracts);
    }

    /**
     * hideContracts is not empty
     * @return boolean
     */
    public boolean notEmpyHideContracts() {
        return !this.isEmpyHideContracts();
    }
}
