package es.santander.adn360.products.common.repository;

import es.santander.adn360.core.util.CustomerProductQueryParams;
import es.santander.adn360.products.common.config.ServicesProperties;
import es.santander.adn360.products.common.domain.PortfolioType;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Repository;
import org.springframework.util.Assert;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

/**
 * PortfoliosRepositoryImpl
 */
@Slf4j
@AllArgsConstructor
@Repository
@ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
public class PortfoliosRepositoryImpl implements PortfoliosRepository {

    /** ServicesProperties */
    private final ServicesProperties servicesProperties;

    /** http */
    private final RestTemplate restTemplate;

    /**
     * Funcion que llama al micro de carteras con ids contratos que devuelve los ids junto con sus typos
     * sigas respectivos
     *
     * @param contracts Contracts List of contracts
     * @param params Customer query string
     * @return List contracts filtered by managed portfolio type configured
     */
    @Override
    @Cacheable(
            cacheNames = { "portfolios" },
            key = "#contracts",
            unless = "#result == null or #result.size() == 0"
    )
    public List<PortfolioType> callToPortfolios(
            final List<String> contracts,
            final CustomerProductQueryParams params
    ) {
        Assert.notNull(contracts, "Contract should not be null");
        Assert.notNull(params, "\"customerProductQueryParams\" parameter is required");

        // Comprobamos que la lista no es vacia. Si lo es devolverá una lista vacia y no se ejecutará más código
        if (contracts.isEmpty()){
            return Collections.emptyList();
        }

        // Componemos la url
        var uriBuilder = UriComponentsBuilder.fromHttpUrl(servicesProperties.getManagedPortfolioService()
                .getEndpoint());
        uriBuilder = setOptionalQueryParam(uriBuilder, "customer_id", params.getCustomer_id());
        uriBuilder = setOptionalQueryParam(uriBuilder, "application", params.getApplication());
        uriBuilder = setOptionalQueryParam(uriBuilder, "segment", params.getSegment());

        ParameterizedTypeReference<List<PortfolioType>> responsetype =
                new ParameterizedTypeReference<List<PortfolioType>>(){};

        HttpEntity<List<String>> request = new HttpEntity<>(contracts);
        ResponseEntity<List<PortfolioType>> result = this.restTemplate
                .exchange(uriBuilder.build().toUri().toString(), HttpMethod.POST, request, responsetype);

        return Optional.ofNullable(result.getBody())
                .orElse(Collections.emptyList());
    }

    /**
     * Method needed to clean portfolios cache.
     */
    @Override
    @Scheduled(cron = "${services.portfolioService.cacheCron}")
    @CacheEvict(cacheNames = {"portfolios"},
            allEntries = true)
    public void cleanCache() {
        log.info("Cleaning portfolios cache.");
    }

    /**
     * Method to set parameters
     *
     * @param builder   uri endpoint
     * @param param     parameter
     * @param value     the object with value
     * @return UriComponentsBuilder parameters
     */
    private UriComponentsBuilder setOptionalQueryParam(UriComponentsBuilder builder, String param, Object value) {
        return value == null ? builder : builder.queryParam(param, value);
    }
}
