package es.santander.adn360.products.common.domain.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import es.santander.adn360.core.web.WebUtils;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.annotation.Id;
import org.springframework.util.CollectionUtils;

import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

/**
 * Base class with common fields for contracts of all products.
 *
 * nonsense commentary to comply with a nonsense rule
 * nonsense commentary to comply with a nonsense rule
 * nonsense commentary to comply with a nonsense rule
 * nonsense commentary to comply with a nonsense rule
 * nonsense commentary to comply with a nonsense rule
 * nonsense commentary to comply with a nonsense rule
 * nonsense commentary to comply with a nonsense rule
 * nonsense commentary to comply with a nonsense rule
 *
 */
@NoArgsConstructor
@Data
@JsonPropertyOrder(value = {"contractNumber"}, alphabetic = true)
public abstract class BaseContract implements Serializable {

    /**
     * Generated serial version UID
     */
    @Serial
    private static final long serialVersionUID = 1L;

    /**
     * Tipos intervinientes
     */
    public static final String TIPO_INTERVINIENTE_TITULAR = "44";

    /**
     * ESTADO_CONTRATO_ACTIVO
     */
    public static final String ESTADO_CONTRATO_ACTIVO = "0";

    /**
     * ORDEN_INTERV_PRIMER_TITULAR
     */
    public static final Integer ORDEN_INTERV_PRIMER_TITULAR = 1;

    /**
     * OLD_CONTRACT_FORMAT
     */
    public static final String OLD_CONTRACT_FORMAT = "%s%s%s%s";
    /**
     * Participant comparators
     */
    private static final Comparator<Intervener> compareTipoInterv = Comparator.comparing(Intervener::getTipoInterv);
    private static final Comparator<Intervener> compareOrdenInterv = Comparator.comparing(Intervener::getOrdenInterv);
    private static final Comparator<Intervener> compareIntervencion = compareTipoInterv.thenComparing(compareOrdenInterv);

    @Id
    @JsonIgnore
    protected String id;

    @Schema(description = "Contract number identifier, partenon format")
    @JsonProperty("contractNumber")
    protected String idContrato;

    @JsonIgnore
    protected String contratoCartera;

    @Schema(description = "Local contract number identifier, number known by the customer")
    @JsonProperty("localContractNumber")
    protected String cuentaLocal;

    @Schema(description = "Contract company")
    @JsonProperty("company")
    protected String empresa;

    @Schema(description = "Contract headquarter (branch that manages the contract)")
    @JsonProperty("headquarter")
    protected String centro;

    @Schema(description = "Contract product identifier")
    @JsonIgnore
    protected String producto;

    @Schema(description = "Contract number")
    @JsonIgnore
    protected String contrato;

    @Schema(description = "Product type")
    @JsonProperty("productType")
    protected String productoNuevo;

    @Schema(description = "Product subtype")
    @JsonProperty("productSubtype")
    protected String subproducto;

    @Schema(description = "Last partenon contract code identifier")
    @JsonProperty("contractCode")
    protected String contratoNuevo;

    @Schema(description = "Product name description (short format)")
    @JsonProperty("productName")
    protected String descripcion;

    @Schema(description = "Product name description (long format)")
    @JsonProperty("completeProductName")
    protected String descripcionLarga;

    @Schema(description = "Contract currency")
    @JsonProperty("currency")
    protected String divisa;

    @Schema(description = "Contract status")
    @JsonProperty("status")
    protected String estado;

    @Schema(description = "GSI situation. Risk indicator")
    @JsonProperty("risks")
    protected RiskSituation situacionGSI;

    @Schema(description = "Contract participants list")
    @JsonProperty("participants")
    protected List<Intervener> intervinientes;

    @JsonIgnore
    protected List<UserInformation> informacionUsuarios;

    @Schema(description = "Pricipal participant of contract")
    protected String contractHolder;

    @Schema(description = "Contract alias")
    protected String alias;

    @Schema(description = "Contract number (partenon old contract number)")
    protected String oldContractNumber;

    @Schema(description = "Operative situation date")
    protected LocalDate fechaSituacionOperativa;

    @Schema(description = "Activation date")
    @JsonProperty("activationDate")
    protected LocalDate fechaAltaContrato;

    @Schema(description = "Expiry date, when the contract will expire")
    @JsonProperty("expiryDate")
    protected LocalDate fechaBajaContrato;

    @JsonIgnore
    protected List<CompaniesUsers> usuariosEmpresas;

    @Schema(description = "List of related proposals")
    @JsonIgnore
    protected List<RelatedProposal> propuestasRelacionadas;

    @Schema(description = "Proposal related identifier")
    protected String relatedProposalId;

    /**
     * Base contract builder.
     *
     * @param id id
     * @param idContrato idContrato
     * @param contratoCartera contratoCartera
     * @param cuentaLocal cuentaLocal
     * @param empresa empresa
     * @param centro centro
     * @param producto producto
     * @param contrato contrato
     * @param productoNuevo productoNuevo
     * @param subproducto subproducto
     * @param contratoNuevo contratoNuevo
     * @param descripcion descripcion
     * @param descripcionLarga descripcionLarga
     * @param divisa divisa
     * @param situacionGSI situacionGSI
     * @param intervinientes intervinientes
     * @param informacionUsuarios informacionUsuarios
     * @param estado estado
     * @param fechaSituacionOperativa fechaSituacionOperativa
     * @param fechaAltaContrato fechaAltaContrato
     * @param fechaBajaContrato fechaBajaContrato
     * @param usuariosEmpresas usuariosEmpresas
     * @param propuestasRelacionadas propuestasRelacionadas
     * @param relatedProposalId relatedProposalId
     */
    public BaseContract(String id, String idContrato, String contratoCartera, String cuentaLocal, String empresa,
                        String centro, String producto, String contrato, String productoNuevo, String subproducto,
                        String contratoNuevo, String descripcion, String descripcionLarga, String divisa,
                        RiskSituation situacionGSI, List<Intervener> intervinientes,
                        List<UserInformation> informacionUsuarios, String estado, LocalDate fechaSituacionOperativa,
                        LocalDate fechaAltaContrato, LocalDate fechaBajaContrato, List<CompaniesUsers> usuariosEmpresas,
                        List<RelatedProposal> propuestasRelacionadas, String relatedProposalId) {


        this.id = id;
        this.idContrato = idContrato;
        this.contratoCartera = contratoCartera;
        this.cuentaLocal = cuentaLocal;
        this.empresa = empresa;
        this.centro = centro;
        this.producto = producto;
        this.contrato = contrato;
        this.productoNuevo = productoNuevo;
        this.subproducto = subproducto;
        this.contratoNuevo = contratoNuevo;
        this.descripcion = descripcion;
        this.descripcionLarga = descripcionLarga;
        this.divisa = divisa;
        this.situacionGSI = situacionGSI;
        this.intervinientes = intervinientes;
        this.informacionUsuarios = informacionUsuarios;
        this.estado = estado;
        this.fechaSituacionOperativa = fechaSituacionOperativa;
        this.fechaAltaContrato = fechaAltaContrato;
        this.fechaBajaContrato = fechaBajaContrato;
        this.usuariosEmpresas = usuariosEmpresas;
        this.propuestasRelacionadas = propuestasRelacionadas;
    }

    /**
     * Gets first owner intervinier types.
     * This method will be used to get Contract Holder and shoul be implemented in all contracts classes.
     *
     * @return Intervener type list.
     */
    @JsonIgnore
    public abstract List<String> getTipoIntervinientesTitular();

    /**
     * Get old contract number
     * @return old contract number
     */
    @JsonProperty("oldContractNumber")
    public String getNumeroContratoViejo() {

    	return Optional.ofNullable(this.oldContractNumber)
    			.orElse(
    					Optional.ofNullable(this.cuentaLocal)
    						.orElse(
    							String.format(
    					                OLD_CONTRACT_FORMAT,
    					                Optional.ofNullable(this.empresa).orElse(StringUtils.EMPTY),
    					                Optional.ofNullable(this.centro).orElse(StringUtils.EMPTY),
    					                Optional.ofNullable(this.producto).orElse(StringUtils.EMPTY),
    					                Optional.ofNullable(this.contrato).orElse(StringUtils.EMPTY)
    					        )
							)
    					);
    }

    /**
     * Get titular
     * @return titular
     */
    @JsonProperty("contractHolder")
    public String getTitular() {
        final LocalDate currentDate = LocalDate.now();
        return Optional.ofNullable(this.contractHolder)
                .orElse(
                    Optional.ofNullable(this.intervinientes)
                            .flatMap(x -> x.stream()
                                // Filter by first contract holder
                                .filter(y -> this.getTipoIntervinientesTitular().stream()
                                        .anyMatch(z -> z.equals(y.getTipoInterv()))
                                        && (y.getFechaBaja() == null
                                        || y.getFechaBaja().compareTo(currentDate) >= 0))
                                // Keep first ordered OrdenInterv finded
                                .min(compareIntervencion)
                                .map(Intervener::getNombreCompleto))
                                .orElse(null)
                 );

    }

    /**
     * Get alias contract
     * @return  alias
     */
    @JsonProperty("alias")
    public String getAliasContrato() {
        final String internalUser = WebUtils.getInternalUser();
        if(this.alias != null) {
            return alias;
        }
        if (!StringUtils.isEmpty(internalUser) && !CollectionUtils.isEmpty(this.informacionUsuarios)) {
               return  this.informacionUsuarios.stream()
                            .filter(x -> x.getUsuarioInterno().equals(internalUser))
                            .findFirst()
                            .map(UserInformation::getAlias)
                            .orElse(null);

        }
        return null;
    }

    /**
     * Gets the related proposal id.
     *
     * @return the related proposal id
     */
    @JsonProperty("relatedProposalId")
    public String getRelatedProposalId() {

        return Optional.ofNullable(this.propuestasRelacionadas).orElseGet(() -> Collections.emptyList())
                .stream()
                .sorted(Comparator.comparing(RelatedProposal::getFechaVencimientoAsoc).reversed())
                .findFirst().filter(r -> r.getFechaVencimientoAsoc().isAfter(LocalDate.now()))
                .map(RelatedProposal::getIdPropuesta)
                .orElse(null);

    }

}
