package es.santander.adn360.products.common.service;

import es.santander.adn360.products.common.domain.DescriptionFormInterveners;
import es.santander.adn360.products.common.domain.repository.DescriptionFormIntervenersRepository;

import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.Optional;

/**
 * Description Form Interveners Service Implementation
 */
@Slf4j
@Service
public class DescriptionFormIntervenersServiceImpl implements DescriptionFormIntervenersService {

    /** repository */
    private final DescriptionFormIntervenersRepository repository;

    /**
     * A service constructor
     *
     * @param repository repo
     */
    public DescriptionFormIntervenersServiceImpl(final DescriptionFormIntervenersRepository repository) {
        this.repository = repository;
    }

    /**
     * Init cache
     */
    @PostConstruct
    public void initCache() {
        this.repository.findAllAsMap();
    }

    /**
     * find descriptions forms list
     *
     * @return list of descriptions
     */
    @Override
    public Optional<DescriptionFormInterveners> findByForma(final String forma) {

        if (! StringUtils.hasText(forma)) {
            return Optional.empty();
        }

        return Optional.ofNullable(repository.findAllAsMap().get(forma));
    }

    /**
     * find descriptions forms list
     *
     * @return list of descriptions
     */
    @Override
    public Optional<String> findDescriptionByForma(final String forma) {

        return this.findByForma(forma)
                .map(DescriptionFormInterveners::getFormaIntervencion);
    }

    /**
     * Clean cache
     */
    @CacheEvict(
            cacheNames = {"descriptionFormIntervenersMap"},
            allEntries = true)
    @Override
    public void cleanCache() {
        log.info("Cleaned DescriptionFormIntervenersService chache");
    }

}
