package es.santander.adn360.products.common.validator;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;
import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;


/**
 * Annotation for validating QueryParams fields.
 */
@Documented
@Constraint(validatedBy = QueryParamsValidator.class)
@Target({ElementType.PARAMETER, ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
public @interface QueryParamsConstraint {

    /**
     * Message.
     *
     * @return String with the message.
     */
    String message() default "Invalid expand value";

    /**
     * Groups.
     *
     * @return Classes array.
     */
    Class<?>[] groups() default {};

    /**
     * Payload.
     *
     * @return Classes array.
     */
    Class<? extends Payload>[] payload() default {};
}
