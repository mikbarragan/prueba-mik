package es.santander.adn360.products.common.service;

import es.santander.adn360.core.model.document.Product;
import es.santander.adn360.core.model.document.ProductGroup;
import es.santander.adn360.core.model.exception.FunctionalException;
import es.santander.adn360.core.util.ExceptionEnum;
import es.santander.adn360.core.util.ProductQueryParams;
import es.santander.adn360.products.common.config.ServicesProperties;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.List;
import java.util.Optional;

import static java.lang.String.format;

/**
 * ProductGroupCacheServiceImpl
 *
 */
@Service
@RequiredArgsConstructor
@ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
public class ProductGroupCacheServiceImpl implements ProductGroupCacheService {

    /**
     * Constants
     */
    public static final String PARAM_CHANNEL = "channel";
    private static final String PARAM_APPLICATION = "application";
    private static final String PARAM_SEGMENT = "segment";
    private static final String PARAM_REL_PROD = "rel_prod";
    private static final String PARAM_REL_SUBPROD = "rel_subprod";
    private static final String NOCONFIGAPP = "No configuration found for app=%s, segment=%s, groupId=%s";
    private final ServicesProperties servicesProperties;
    private final RestTemplate restTemplate;

    /**
     * Gets product groups from specific channel, application and segment
     *
     * @param productQueryParams ProductQueryParams
     * @return Product Group list
     */
    @Override
    @Cacheable(
            cacheNames = { "getProductGroups_queryParamsChannel_cache" },
            unless = "#result == null or #result.size() == 0"
    )
    public List<ProductGroup> getProductGroups(
            ProductQueryParams productQueryParams,
            String channel
    ) {

        URI uri = this.buildServiceURI(
                productQueryParams,
                servicesProperties.getProductGroupsService().getProductGroupsUri(),
                channel,null,null);

        List<ProductGroup> result = restTemplate.exchange(
                uri, HttpMethod.GET, null, new ParameterizedTypeReference<List<ProductGroup>>() {}
        ).getBody();

        if (CollectionUtils.isEmpty(result)) {
            throw new FunctionalException(
                    ExceptionEnum.INVALID_INPUT_PARAMETERS,
                    format(
                            "No configuration found for app=%s, segment=%s",
                            productQueryParams.getApplication(),
                            productQueryParams.getSegment()
                    )
            );
        }

        return result;
    }

    /**
     * Gets product group
     *
     * @param productQueryParams ProductQueryParams
     * @return Product Group
     */
    @Override
    @Cacheable(
            cacheNames = { "getProductGroup_queryPGroupIdChannel_cache" },
            unless = "#result == null"
    )
    public ProductGroup getProductGroup(
            ProductQueryParams productQueryParams,
            String productGroupId,
            String channel
    ) {
        URI uri = this.buildServiceURI(
                productQueryParams,
                format(servicesProperties.getProductGroupsService().getProductGroupUri(), productGroupId),
                channel,
                null,
                null
        );

        ProductGroup result = restTemplate.exchange(
                uri, HttpMethod.GET, null, new ParameterizedTypeReference<ProductGroup>() {}
        ).getBody();

        if (result == null) {
            throw new FunctionalException(
                    ExceptionEnum.INVALID_INPUT_PARAMETERS,
                    format(
                            NOCONFIGAPP,
                            productQueryParams.getApplication(),
                            productQueryParams.getSegment(),
                            productGroupId
                    )
            );
        }

        return result;
    }

    /**
     * Gets product configuration
     *
     * @param productQueryParams ProductQueryParams
     * @param productGroupId     Product group identification
     * @return Product list.
     */
    @Override
    @Cacheable(
            cacheNames = { "getProducts_qpPgiChn_cache" },
            unless = "#result == null or #result.size() == 0"
    )
    public List<Product> getProducts(
            ProductQueryParams productQueryParams,
            String productGroupId,
            String channel
    ) {
        URI uri = this.buildServiceURI(
                productQueryParams,
                format(servicesProperties.getProductGroupsService().getProductsUri(), productGroupId),
                channel,
                null,
                null
        );

        List<Product> result = restTemplate.exchange(
                uri, HttpMethod.GET, null, new ParameterizedTypeReference<List<Product>>() {}
        ).getBody();

        if (CollectionUtils.isEmpty(result)) {
            throw new FunctionalException(
                    ExceptionEnum.INVALID_INPUT_PARAMETERS,
                    format(
                            NOCONFIGAPP,
                            productQueryParams.getApplication(),
                            productQueryParams.getSegment(),
                            productGroupId
                    )
            );
        }

        return result;
    }

    /**
     * Get Catalog id
     *
     * @param productQueryParams productQueryParams
     * @param productGroupId     productGroupId
     * @param channel            channel
     * @return products
     */
    @Override
    @Cacheable(
            cacheNames = { "product_configurations_catalog" },
            unless = "#result == null or #result.size() == 0"
    )
    public List<String> getCatalogIds(
            ProductQueryParams productQueryParams,
            String productGroupId,
            String channel
    ) {
        URI uri = this.buildServiceURI(
                productQueryParams,
                format(servicesProperties.getProductGroupsService().getCatalogUri(), productGroupId),
                channel,
                null,
                null
        );

        List<String> result = restTemplate.exchange(
                uri, HttpMethod.GET, null, new ParameterizedTypeReference<List<String>>() {}
        ).getBody();

        if (CollectionUtils.isEmpty(result)) {
            throw new FunctionalException(
                    ExceptionEnum.INVALID_INPUT_PARAMETERS,
                    format(
                            "No catalog configuration found for app=%s, segment=%s, groupId=%s",
                            productQueryParams.getApplication(),
                            productQueryParams.getSegment(),
                            productGroupId
                    )
            );
        }

        return result;
    }

    /**
     * Get Products And Related Products
     *
     * @param params productQueryParams
     * @param productGroupId     productGroupId
     * @param channel            channel
     * @param relProd            relProd
     * @param relSubprod         relSubprod
     * @return products and related products
     */
    @Override
    @Cacheable(
            cacheNames = { "related_product_configurations" },
            unless = "#result == null or #result.size() == 0"
    )
    public List<Product> getProductsAndRelatedProducts(
            final ProductQueryParams params,
            final String productGroupId,
            final String channel,
            final String relProd,
            final String relSubprod
    ) {
        final var uri = this.buildServiceURI(
                params,
                format(servicesProperties.getProductGroupsService().getProductsUri(), productGroupId),
                channel,
                relProd,
                relSubprod
        );

        final var products = restTemplate.exchange(
                uri, HttpMethod.GET, null, new ParameterizedTypeReference<List<Product>>() {}
        ).getBody();

        if (CollectionUtils.isEmpty(products)) {


            String msg;

            if (relProd == null) {

                msg = format(NOCONFIGAPP, params.getApplication(), params.getSegment(), productGroupId);

            } else {
                msg = format(
                        "There are no related account contracts associated for app=%s, segment=%s, groupId=%s, rel_prod=%s, rel_subprod=%s",
                        params.getApplication(), params.getSegment(), productGroupId, relProd, relSubprod
                );
            }

            throw new FunctionalException(ExceptionEnum.INVALID_INPUT_PARAMETERS, msg);
        }

        return products;
    }


    /**
     * Get microservice call URI.
     *
     * @param productQueryParams ProductQueryParams
     * @param uriString          Service uri string
     * @param channel          channel
     * @param relProd          Related product
     * @param relSubprod          Related subproduct
     * @return URI.
     */
    private URI buildServiceURI(
            ProductQueryParams productQueryParams,
            String uriString,
            String channel,
            String relProd,
            String relSubprod
    ) {
        final UriComponentsBuilder builder = UriComponentsBuilder
                .fromHttpUrl(uriString)
                .queryParam(PARAM_CHANNEL, channel);

        Optional.ofNullable(productQueryParams.getApplication())
                .ifPresent(x -> builder.queryParam(PARAM_APPLICATION, productQueryParams.getApplication()));

        Optional.ofNullable(productQueryParams.getSegment())
                .ifPresent(x -> builder.queryParam(PARAM_SEGMENT, productQueryParams.getSegment()));

        Optional.ofNullable(relProd)
                .ifPresent(x -> builder.queryParam(PARAM_REL_PROD, relProd));
        Optional.ofNullable(relSubprod)
                .ifPresent(x -> builder.queryParam(PARAM_REL_SUBPROD, relSubprod));

        return builder.build().encode().toUri();
    }

    /**
     * ProductGroupCacheServiceImpl
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     *
     *
     */
}
