package es.santander.adn360.products.common.service;

import es.santander.adn360.core.model.document.Product;
import es.santander.adn360.core.util.CustomerProductQueryParams;
import es.santander.adn360.mongodb.starter.autoconfigure.MongoQueryRepositoryAutoConfiguration;
import es.santander.adn360.products.common.domain.bean.ProductQueryBuilderParams;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Optional;

/**
 * Implementation for ProductQueryBuilder.
 */
@Service
@ConditionalOnClass(MongoQueryRepositoryAutoConfiguration.class)
public class ProductQueryBuilderImpl implements ProductQueryBuilder {

    /**
     * ProductGroupService
     */
    private final ProductGroupService productGroupService;

    /**
     * Constructor
     *
     * @param productGroupService ProductGroupService
     */
    public ProductQueryBuilderImpl(final ProductGroupService productGroupService) {
        this.productGroupService = productGroupService;
    }

    /**
     * Gets product main criteria based on query string params ,Santander channel and given parameters.
     * This criteria should be used as main query criteria in product repositories.
     *
     * @param customerProductQueryParams Query string params
     * @param productQueryBuilderParams  Parameters needed to apply proper contract queries
     * @param customerIdList             Customer list
     * @return Criteria
     */
    @Override
    public Criteria getProductCriteria(CustomerProductQueryParams customerProductQueryParams,
                                       ProductQueryBuilderParams productQueryBuilderParams,
                                       List<String> customerIdList) {
        Assert.notNull(customerProductQueryParams, "customerProductQueryParams should not be null");
        Assert.notNull(productQueryBuilderParams, "productQueryBuilderParams should not be null");
        productQueryBuilderParams.checkValidParams();

        final Date currentDate = Calendar.getInstance().getTime();
        final List<Criteria> criteriaList = new ArrayList<>();

        // Add main criteria
        criteriaList.add(this.getMainProductCriteria(customerProductQueryParams, productQueryBuilderParams,
                currentDate, customerIdList));

        return criteriaList.size() == 1 ? criteriaList.get(0)
                : new Criteria().andOperator(criteriaList.toArray(new Criteria[0]));
    }


    /**
     * Gets main product criteria based on given parameters.
     *
     * @param customerProductQueryParams CustomerProductQueryParams
     * @param productQueryBuilderParams  ProductQueryBuilderParams
     * @param currentDate                Date
     * @param customerIdList             Customer list
     * @return Criteria
     */
    private Criteria getMainProductCriteria(CustomerProductQueryParams customerProductQueryParams,
                                            ProductQueryBuilderParams productQueryBuilderParams,
                                            Date currentDate, List<String> customerIdList) {
        // Add intervener criteria if customer_id or excluded_customer_id is not null
        Criteria mainProductCriteria;
        if (!CollectionUtils.isEmpty(customerIdList) ||
                !StringUtils.isEmpty(customerProductQueryParams.getExcluded_customer_id())) {
            final Criteria customerCriteria = Criteria.where("idCliente");
            if (!CollectionUtils.isEmpty(customerIdList)) {
                // Intervener is customer_id list
                customerCriteria.in(customerIdList);
            } else {
                // Intervener is not equal to  excluded_customer_id
                customerCriteria.ne(customerProductQueryParams.getExcluded_customer_id());
            }

            if (productQueryBuilderParams.getInterveneerExpirationFilter()) {
                customerCriteria.and("tipoInterv").in(productQueryBuilderParams.getIntervenerType())
                        .orOperator(Criteria.where("fechaBaja").exists(false),
                                Criteria.where("fechaBaja").gte(currentDate));
            } else {
                customerCriteria.and("tipoInterv").in(productQueryBuilderParams.getIntervenerType());
            }

            productQueryBuilderParams.getIntervenerOrder().ifPresent(x -> customerCriteria.and("ordenInterv").is(x));

            mainProductCriteria = Criteria.where("intervinientes").elemMatch(customerCriteria);
        } else {
            mainProductCriteria = new Criteria();
        }

        // Add product type/subtype conditions
        if (Optional.ofNullable(productQueryBuilderParams.getUseProductConfiguration()).orElse(Boolean.FALSE)) {
            // Get product configuration
            final List<Product> products = this.productGroupService.getProducts(
                    customerProductQueryParams,
                    productQueryBuilderParams.getProductGroupId()
            );

            Assert.notNull(products,
                    String.format("Product not configured for application: %s, segment: %s, group id: %s",
                            customerProductQueryParams.getApplication(),
                            customerProductQueryParams.getSegment(),
                            productQueryBuilderParams.getProductGroupId()));

            mainProductCriteria.orOperator(products.stream()
                    .map((Product p) -> {
                        final Criteria criteria = Criteria.where("productoNuevo").is(p.getType());
                        return p.getSubType() == null ? criteria : criteria.and("subproducto").is(p.getSubType());
                    })
                    .toArray(Criteria[]::new));
        }

        // Add estado and tipoContrato if present
        final List<Criteria> andConditions = new ArrayList<>();

        productQueryBuilderParams.getContractType().ifPresent(x -> andConditions
                .add(Criteria.where("tipoContrato").is(x)));
        productQueryBuilderParams.getContractStates().ifPresent(x -> andConditions
                .add(Criteria.where("estado").in(x)));
        if (!CollectionUtils.isEmpty(andConditions)) {
            mainProductCriteria.andOperator(andConditions.toArray(new Criteria[0]));
        }

        return mainProductCriteria;
    }

    /**
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     *
     */
}
