package es.santander.adn360.products.common.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.util.StringUtils;

import java.io.Serial;
import java.io.Serializable;
import java.util.Map;

import static es.santander.adn360.products.common.domain.PortfolioBaseContract.ACTIVE_PORTFOLIO_DATE;

/**
 * PortfolioContract
 */
@Builder
@NoArgsConstructor
@Data
@AllArgsConstructor
public class PortfolioContract implements Serializable {

	@JsonIgnore
	public static final String BAJA_CODE = "BJ";

	@JsonIgnore
	public static final PortfolioType BJ_TYPE = PortfolioType.builder().typePortfolio(BAJA_CODE).build();

	/**
	 * Generated serial version UID
	 */
	@Serial
	private static final long serialVersionUID = 1L;

	/** contrato cartera */
	@JsonProperty("contractNumber")
	@Schema(description = "Portfolio contract")
	private String contratoCartera;

	/** fecha vencimiento */
	@JsonIgnore
	@Schema(description = "Expiration date")
	private String fechaVencimiento;

	/** tipo de cartera */
	@JsonProperty("type")
	@Schema(description = "portfolio type")
	private String tipoCartera;


	/** SIGA */
	@JsonProperty("SIGA")
	@Schema(description = "SIGA")
	private String siga;

	/** The portfolio description. */
	@JsonProperty("portfolioDescription")
	@Schema(description = "Portfolio Description")
	private String portfolioDescription;

	/**
	 * Esta la relación activa???
	 *
	 * @return si la fecha vencimiento es 9999-12-31 sí
	 */
	@JsonIgnore
	public boolean isActive() {
		return ACTIVE_PORTFOLIO_DATE.equals(this.fechaVencimiento);
	}

	/**
	 * Es relación y cartera activa??
	 *
	 * @param portfolioTypeMap Map
	 * @return si tiene tipo y no es BJ sí, el resto no
	 */
	@JsonIgnore
	public boolean isActive(final Map<String, PortfolioType> portfolioTypeMap) {

		if (! StringUtils.hasText(contratoCartera)) {
			return false;
		}

		if (! this.isActive()) {
			return false;
		}

		final var pType = portfolioTypeMap.getOrDefault(contratoCartera, BJ_TYPE).getTypePortfolio();

		return ! BAJA_CODE.equalsIgnoreCase(pType);
	}
}
