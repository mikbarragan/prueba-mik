package es.santander.adn360.products.common.service;

import es.santander.adn360.core.model.document.Product;
import es.santander.adn360.core.model.document.ProductGroup;
import es.santander.adn360.core.util.ProductQueryParams;
import es.santander.adn360.products.common.domain.entity.BaseContract;

import java.util.List;

/**
 * Service for encapsulating product groups microservice calls.
 */
public interface ProductGroupService {

    /**
     * Gets product groups from specific channel, application and segment
     *
     * @param channel     Application channel
     * @param application Application name
     * @param segment     Application segment
     * @return Product Group list
     * @deprecated Use {@link #getProductGroups(ProductQueryParams)} instead
     */
    @Deprecated(since = "")
    List<ProductGroup> getProductGroups(String channel, String application, String segment);

    /**
     * Gets product groups from specific channel, application and segment
     *
     * @param productQueryParams ProductQueryParams
     * @return Product Group list
     */
    List<ProductGroup> getProductGroups(ProductQueryParams productQueryParams);

    /**
     * Gets product group
     *
     * @param channel        Application channel
     * @param application    Application name
     * @param segment        Application segment
     * @param productGroupId Product group identification
     * @return Product Group
     * @deprecated Use {@link #getProductGroup(ProductQueryParams, String)} instead
     */
    @Deprecated(since = "")
    ProductGroup getProductGroup(String channel, String application, String segment, String productGroupId);

    /**
     * Gets product group
     *
     * @param productQueryParams ProductQueryParams
     * @param productGroupId     Product group identification
     * @return Product Group
     */
    ProductGroup getProductGroup(ProductQueryParams productQueryParams, String productGroupId);

    /**
     * Gets product configuration
     *
     * @param channel        Application channel
     * @param application    Application name
     * @param segment        Application segment
     * @param productGroupId Product group identification
     * @return Product list.
     * @deprecated Use {@link #getProducts(ProductQueryParams, String)} instead
     */
    @Deprecated(since = "")
    List<Product> getProducts(String channel, String application, String segment, String productGroupId);

    /**
     * Gets product configuration
     *
     * @param productQueryParams ProductQueryParams
     * @param productGroupId     Product group identification
     * @return Product list.
     */
    List<Product> getProducts(ProductQueryParams productQueryParams, String productGroupId);

    /**
     * Filter the contractList returning only those whose type-subtype are in the list of products.
     *
     * @param contractsList list of contracts to be filtered
     * @param productList   list of products allowed
     * @return filtered list
     */
    <T extends BaseContract> List<T> filterByProducts(
            List<T> contractsList,
            List<Product> productList
    );

    /**
     * Method needed to clean product group cache.
     */
    void cleanProductgroupCache();

    /**
     * Gets list of catalogId from configuration
     *
     * @param productQueryParams ProductQueryParams
     * @param productGroupId     Product group identification
     * @return List of catalog id (Ej: ["P211","P263"]). If there is not catalog ids return an empty list
     */
    List<String> getCatalogIds(ProductQueryParams productQueryParams, String productGroupId);
    
    /**
     * Get a single product by type and subtype
     *
     * @param type input product type
     * @param subtype input product subtype
     * @return return a single product
     */
    Product getProduct(String type, String subtype);

    /**
     * Gets product configuration
     *
     * @param productQueryParams ProductQueryParams
     * @param productGroupId     Product group identification
     * @param relProd            Related product
     * @param relSubprod         Related subproduct
     * @return Product list and filter with related product
     */
    List<Product> getProductsAndRelatedProducts(
            ProductQueryParams productQueryParams,
            String productGroupId,
            String relProd,
            String relSubprod
    );
}
