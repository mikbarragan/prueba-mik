package es.santander.adn360.products.common.service;

import es.santander.adn360.products.common.domain.Person;
import es.santander.adn360.products.common.domain.entity.BaseContract;
import es.santander.adn360.products.common.domain.entity.Customer;

import java.util.List;

/**
 * Customers service interface.
 */
public interface CustomersService {

    /**
     * Gets from the service the Customer info [name]
     *
     * @param type customer type
     * @param code customer code
     * @return Customer info
     */
    Customer getCustomerInfo(final String type, final String code);

    /**
     * Method needed to clean currencies cache.
     */
    void cleanCustomerCache();

    /**
     * Find the Person by Type and Code [F-000000001]
     *
     * @param type Type
     * @param code Code
     * @return Person
     */
    Person findOneByTypeAndCode(final String type, final String code);

    /**
     * Set field nombreCompleto for first interveners in oontracts interveners.
     *
     * @param contracts Contract list
     */
    void setIntervenersName(final List<? extends BaseContract> contracts);

    /**
     * Set field nombreCompleto for first interveners in contracts interveners.
     * set field Only interveners actives
     *
     * @param contracts Contract list
     * @param showContractHolder boolean to display contract holder
     */
    void setIntervenersName(final List<? extends BaseContract> contracts, boolean showContractHolder);

    /**
     * Set field nombreCompleto for first interveners in contracts interveners.
     * set field to all Interveners ( canceled or actives)
     *
     * @param contracts Contract list
     * @param showContractHolder boolean to display contract holder
     */
    void setAllIntervenersName(final List<? extends BaseContract> contracts, boolean showContractHolder);

    /**
     * Fills NombreCompleto, TipoDocumento and CodDocumento of all interveners
     *
     * @param contracts contract list
     * @return contracts
     */
    <T extends BaseContract> List<T> fillPersonsInfo(List<T> contracts);

    /**
     * get customer info
     * @param clientId client identifier
     * @return customer found
     */
    Customer getCustomerInfo(final String clientId);
    
    /**
     *  Set field nombreIntervencion for all interveners belongs to contract
     *  
     * @param contracts List of contracts to be modified
     */
    void setIntervenersDescription(final List<? extends BaseContract> contracts);


    /**
     * Find customer by type, code and company
     *
     * @param type type
     * @param  code Code
     * @param company Company
     *
     * @return Found Person Data
     *
     */
    Person findOneByTypeAndCodeAndCompany(final String type, final String code, final String company);

    /**
     * Gets from Customer service additional information like telephone
     *
     * @param customerId customerId
     * @return Customer extended information
     */
    Customer getPhoneCustomerInfo(final String customerId);

    /**
     * Retrieve from Customer Service the customer address information
     * @param customerId    customer id
     * @param addressCode   address code
     * @return              Complete address information {@link es.santander.adn360.products.common.domain.entity.CustomerAddress}
     */
    Customer getCustomerAddress(final String customerId, final Integer addressCode);

}
