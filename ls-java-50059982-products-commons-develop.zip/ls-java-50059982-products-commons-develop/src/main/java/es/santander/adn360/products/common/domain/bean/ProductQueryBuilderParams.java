package es.santander.adn360.products.common.domain.bean;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Data;
import org.springframework.util.Assert;

import java.util.List;
import java.util.Optional;

/**
 * Parameters to build product contracts queries.
 */
@Data
@Builder
public class ProductQueryBuilderParams {

    private static final String PRODUCT_GROUP_ID_ERROR_MSG = "productGroupId should not be null";
    private static final String INTERVENER_TYPE_ERROR_MSG = "intervenerType should not be empty";
    private static final String NOT_NULL_ERROR_MSG = "Either you should use product configuration or contractType " +
            "should not be null";

    /**
     * Product group id
     */
    @Schema(name = "Product group id")
    private String productGroupId;

    /**
     * Contract states
     */
    @Builder.Default
    private Optional<List<String>> contractStates = Optional.empty();

    /**
     * Intervener type
     */
    private List<String> intervenerType;

    /**
     * Intervener order
     */
    @Builder.Default
    private Optional<Integer> intervenerOrder = Optional.empty();

    /**
     * Flag to use fechaBaja customer filter in queries
     */
    @Builder.Default
    private Boolean interveneerExpirationFilter = Boolean.TRUE;

    /**
     * Flag to use product type/subtype in queries
     */
    private Boolean useProductConfiguration;

    /**
     * Contract type
     */
    @Builder.Default
    private Optional<String> contractType = Optional.empty();

    /**
     * Checks mandatory fields for building product contracts query.
     */
    public void checkValidParams() {
        Assert.notNull(productGroupId, PRODUCT_GROUP_ID_ERROR_MSG);
        Assert.notEmpty(intervenerType, INTERVENER_TYPE_ERROR_MSG);
    }

}
