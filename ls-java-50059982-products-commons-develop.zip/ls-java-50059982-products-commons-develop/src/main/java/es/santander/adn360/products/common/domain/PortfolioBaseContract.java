package es.santander.adn360.products.common.domain;

import static java.util.stream.Collectors.toList;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Stream;

import org.springframework.data.mongodb.core.mapping.Field;
import org.springframework.util.CollectionUtils;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import es.santander.adn360.products.common.domain.entity.BaseContract;
import es.santander.adn360.products.common.domain.entity.CompaniesUsers;
import es.santander.adn360.products.common.domain.entity.Intervener;
import es.santander.adn360.products.common.domain.entity.RelatedProposal;
import es.santander.adn360.products.common.domain.entity.RiskSituation;
import es.santander.adn360.products.common.domain.entity.UserInformation;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Clase que se utiliza como esqueleto para los productos carterizados.
 * El siga se obtiene de la cartera a la que pertenece y con el se obtiene la entabilidad en los casos de
 * Banca privada
 */
@NoArgsConstructor
@Data
@JsonPropertyOrder(value = {"contractNumber"}, alphabetic = true)
public class PortfolioBaseContract extends BaseContract {

    private static final long serialVersionUID = 1L;

    @JsonIgnore
    public static final String ACTIVE_PORTFOLIO_DATE = "9999-12-31";

    @Schema(
            description = "SIGA number (Sistema Integrado de Gestión de Activos)",
            required = false
    )
    @JsonProperty("SIGA")
    @Field("SIGA")
    protected String siga;

    @JsonProperty("portfolios")
    protected List<PortfolioContract> contratosCarteras;

    /**
     * Constructor
     *
     * @param id                      id
     * @param idContrato              idContrato
     * @param contratoCartera         contratoCartera
     * @param cuentaLocal             cuentaLocal
     * @param empresa                 empresa
     * @param centro                  centro
     * @param producto                producto
     * @param contrato                contrato
     * @param productoNuevo           productoNuevo
     * @param subproducto             subproducto
     * @param contratoNuevo           contratoNuevo
     * @param descripcion             descripcion
     * @param descripcionLarga        descripcionLarga
     * @param divisa                  divisa
     * @param situacionGSI            situacionGSI
     * @param intervinientes          intervinientes
     * @param informacionUsuarios     informacionUsuarios
     * @param siga                    siga
     * @param estado                  estado
     * @param fechaSituacionOperativa fechaSituacionOperativa
     * @param fechaAltaContrato       fechaAltaContrato
     * @param fechaBajaContrato       fechaBajaContrato
     * @param contratosCarteras       contratosCarteras
     * @param usuariosEmpresas        usuariosEmpresas
     * @param propuestasRelacionadas propuestasRelacionadas
     * @param relatedProposalId relatedProposalId
     */
    public PortfolioBaseContract(
            final String id,
            final String idContrato,
            final String contratoCartera,
            final String cuentaLocal,

            final String empresa,
            final String centro,
            final String producto,
            final String contrato,

            final String productoNuevo,
            final String subproducto,
            final String contratoNuevo,
            final String descripcion,

            final String descripcionLarga,
            final String divisa,
            final RiskSituation situacionGSI,
            final List<Intervener> intervinientes,

            final List<UserInformation> informacionUsuarios,
            final String siga,
            final String estado,
            final LocalDate fechaSituacionOperativa,

            final LocalDate fechaAltaContrato,
            final LocalDate fechaBajaContrato,
            final List<PortfolioContract> contratosCarteras,
            final List<CompaniesUsers> usuariosEmpresas,
            final List<RelatedProposal> propuestasRelacionadas,
            final String relatedProposalId
    ) {

        super(id, idContrato, contratoCartera, cuentaLocal, empresa,
                centro, producto, contrato, productoNuevo, subproducto,
                contratoNuevo, descripcion, descripcionLarga, divisa,
                situacionGSI, intervinientes, informacionUsuarios, estado, fechaSituacionOperativa,
                fechaAltaContrato, fechaBajaContrato, usuariosEmpresas, propuestasRelacionadas,
                relatedProposalId);

        this.siga = siga;
        this.contratosCarteras = contratosCarteras;
    }

    /**
     * Get tipo intervinientes - titulares
     *
     * @return tipos titulares
     */
    @Override
    public List<String> getTipoIntervinientesTitular() {
        return Collections.singletonList(BaseContract.TIPO_INTERVINIENTE_TITULAR);
    }

    /**
     * Comprueba si tiene contratos cartera
     *
     * @return verdadero o falso
     */
    @JsonIgnore
    public boolean hasContratosCarteras() {

        if (CollectionUtils.isEmpty(this.contratosCarteras)) {
            return false;
        }

        return this.contratosCarteras.stream()
                .filter(Objects::nonNull)
                .anyMatch(PortfolioContract::isActive);
    }

    /**
     * Devuelve verdadero si no tiene cartera
     *
     * @return verdadero o falso
     */
    @JsonIgnore
    public boolean nonContratosCarteras() {
        return ! this.hasContratosCarteras();
    }

    /**
     * Comprueba si tiene contratos cartera activos
     *
     * @param portfolioTypeMap Map
     * @return verdadero o falso
     */
    @JsonIgnore
    public boolean hasContratosCarteras(final Map<String, PortfolioType> portfolioTypeMap) {

        if (CollectionUtils.isEmpty(this.contratosCarteras)) {
            return false;
        }

        return this.contratosCarteras.stream()
                .filter(Objects::nonNull)
                .anyMatch(c -> c.isActive(portfolioTypeMap));
    }

    /**
     * Devuelve verdadero si no tiene cartera activas
     * @param portfolioTypeMap Map
     * @return verdadero o falso
     */
    @JsonIgnore
    public boolean nonContratosCarteras(final Map<String, PortfolioType> portfolioTypeMap) {
        return ! this.hasContratosCarteras(portfolioTypeMap);
    }

    /**
     * getActiveContratosCarteras
     * @param portfolioTypeMap Map
     * @return active contracts stream
     */
    @JsonIgnore
    public Stream<PortfolioContract> getActiveContratosCarteras(final Map<String, PortfolioType> portfolioTypeMap) {

        if (CollectionUtils.isEmpty(this.contratosCarteras)) {
            return Stream.empty();
        }

        return contratosCarteras.stream()
                .filter(Objects::nonNull)
                .filter(cc -> cc.isActive(portfolioTypeMap));
    }

    /**
     * Get portfolio types
     *
     * @param portfolioTypeMap data
     * @return portfolio types
     */
    @JsonIgnore
    public List<String> getActivePortfolioTypes(final Map<String, PortfolioType> portfolioTypeMap) {

        return getActiveContratosCarteras(portfolioTypeMap)
                .map(PortfolioContract::getContratoCartera)
                .distinct()
                .map(portfolioTypeMap::get)
                .filter(Objects::nonNull)
                .map(PortfolioType::getTypePortfolio)
                .map(Optional::ofNullable)
                .map(portfolioType -> portfolioType.orElse(""))
                .distinct()
                .collect(toList());
    }
}
