package es.santander.adn360.products.common.service;

import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import java.time.LocalDate;

/**
 * Service to calculate shard numbers of mongo collection
 */
@Service
public class HismoShardingImpl implements HismoSharding{

    private static int MonthsYear = 12;

    /**
     * getShard
     * @param date  date
     * @param partitions    partitions
     * @param monthsPerPartition    monthsPerPartition
     * @return shard number
     */
    @Override
    public Integer getShard(LocalDate date, Integer partitions, Integer monthsPerPartition) {
        Assert.isTrue(monthsPerPartition > 0,"Months per partition must be greater than 0");
        Assert.isTrue(partitions > 0,"Partitions must be greater than 0");

        return ((MonthsYear * date.getYear() + date.getMonthValue() - 1) / monthsPerPartition) % partitions;
    }

    /**
     * getBeforeShard
     * @param currentShard currentShard
     * @param partitions partitions
     * @return before shard
     */
    @Override
    public Integer getBeforeShard(Integer currentShard, Integer partitions) {
        Assert.isTrue(partitions > 0,"Partitions must be greater than 0");

        return Math.floorMod(currentShard - 1, partitions);
    }

    /**
     * After shard
     * @param currentShard currentShard
     * @param partitions partitions
     * @return after shard
     */
    @Override
    public Integer getAfterShard(Integer currentShard, Integer partitions) {
        Assert.isTrue(partitions > 0,"Partitions must be greater than 0");

        return Math.floorMod(currentShard + 1, partitions);
    }
}
