package es.santander.adn360.products.common.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * class dedicated to obtaining situation indicator
 * filters configuration properties
 *
 * @author Santander Tecnologia
 */
@Data
@Configuration
@ConfigurationProperties(prefix = "situation-indicator-filter")
@PropertySource("classpath:/products-common.properties")
@RefreshScope
public class SituationIndicatorFiltersProperties {

    /**
     * Contracts active configured
     * - Default values
     */
    private Types actives;

    /**
     * Contracts canceled configured
     * - Default values
     */
    private Types canceled;

    /**
     * Contracts precanceled configured
     * - Default values
     */
    private Types precanceled;

    /**
     * Code list and max-time
     * - Default values
     */
    @Data
    public static class Types {
        private List<String> codes;
        private Integer maxTime;
    }

    /**
     * Canal desde el que se llama
     */
    private Map<String, Channel> channel;

    /**
     * Obtención de las aplicaciones del canal
     */
    @Data
    public static class Channel {
        private final List<ApplicationCodesCfg> application = new ArrayList<>();
    }

    /**
     * Obtención del nombre de la aplicación
     * y los estados asociados
     */
    @Data
    public static class ApplicationCodesCfg {
        private String name;
        private Status status;
    }

    /**
     * Obtención de los códigos activos y cancelados
     * por del canal y aplicación correspondiente
     */
    @Data
    public static class Status {
        private Types actives;
        private Types precanceled;
        private Types canceled;
    }

}
