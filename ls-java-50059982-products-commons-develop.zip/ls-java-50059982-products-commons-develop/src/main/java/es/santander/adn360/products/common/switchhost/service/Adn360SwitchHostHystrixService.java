package es.santander.adn360.products.common.switchhost.service;

import es.santander.adn360.products.common.switchhost.annotation.Adn360SwitchHost;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Service;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 * Adn360SwitchHostHystrixService
 */
@Slf4j
@Service
@RefreshScope
public class Adn360SwitchHostHystrixService {

    /**
     * Execution of joinPoint proceed protected by circuit braker
     *
     * @param joinPoint         joinPoint
     * @param adn360SwitchHost  adn360SwitchHost
     * @return method result
     * @throws Throwable exceptions
     */
    @CircuitBreaker(name="switchHost",fallbackMethod = "executeFallback")
    @Retry(name = "switchHost", fallbackMethod = "executeFallback")
    public Object execute(ProceedingJoinPoint joinPoint, Adn360SwitchHost adn360SwitchHost) throws Throwable {
        return joinPoint.proceed();
    }

    /**
     * Execute fallback configured at adn360SwitchHost annotation
     *
     * @param joinPoint joinPoint
     * @param adn360SwitchHost  adn360SwitchHost
     * @param ex exception
     * @return fallback method result
     * @throws InvocationTargetException InvocationTargetException
     * @throws IllegalAccessException   IllegalAccessException
     */
    public Object executeFallback(ProceedingJoinPoint joinPoint, Adn360SwitchHost adn360SwitchHost, Exception ex)
            throws InvocationTargetException, IllegalAccessException {

        //Datos de la anotación
        String fallback = adn360SwitchHost.fallback();
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        Class targetClass= signature.getDeclaringType();
        Method method = getMethodByName(targetClass,fallback,signature.getParameterTypes());

        if (method == null) {
            throw new RuntimeException(String.format("Método de fallback \"%s\" no existe en la clase %s",
                    fallback, joinPoint.getTarget().getClass().getCanonicalName()));
        }

        method.trySetAccessible();
        return method.invoke(joinPoint.getTarget(), joinPoint.getArgs());
    }
    /**
     * Obtiene el método a partir de la clase en la que está declarado, su nombre y sus parámetros
     * @param targetClass targetClass
     * @param methodName methodName
     * @param parameterTypes parameterTypes
     * @return Method
     */
    private Method getMethodByName(Class<?> targetClass, String methodName, Class... parameterTypes) {
        Method method=null;

        try {
            method= targetClass.getDeclaredMethod(methodName,parameterTypes);
        } catch (NoSuchMethodException e) {
            log.error("El método "+methodName+" no ha sido encontrado en la clase "+targetClass.getName());
        }
        return method;

    }
}
