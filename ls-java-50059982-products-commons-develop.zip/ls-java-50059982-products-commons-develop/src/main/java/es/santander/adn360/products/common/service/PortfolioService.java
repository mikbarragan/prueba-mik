package es.santander.adn360.products.common.service;

import es.santander.adn360.core.model.portfolio.PortfolioQueryParams;
import es.santander.adn360.core.util.CustomerProductQueryParams;
import es.santander.adn360.products.common.domain.PortfolioBaseContract;
import es.santander.adn360.products.common.domain.PortfolioType;

import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * Service to handle contracts that belongs to portfolios.
 */
public interface PortfolioService {
	/**
	 * Return contracts not belongs to determinate managed portfolio type (tipo de cartera gestionada) by configuration
	 *
	 * @param contracts Contracts List of contracts
	 * @param customerProductQueryParams Customer query string
	 * @return List contracts filtered by managed portfolio type configured
	 */
	<T extends PortfolioBaseContract> List<T> getContractsFilteredByCarteraType(
			List<T> contracts,
			CustomerProductQueryParams customerProductQueryParams
	);


	/**
	 * Return contracts not belongs to determinate managed portfolio type (tipo de cartera gestionada) by configuration
	 *
	 * @param contracts Contracts List of contracts
	 * @param customerProductQueryParams Customer query string
	 * @return List contracts filtered by managed portfolio type configured
	 */
	<T extends PortfolioBaseContract> List<T> getContractsFilteredByContratosCarterasType(
			List<T> contracts,
			CustomerProductQueryParams customerProductQueryParams
	);


	/**
	 * getContractsFilteredByContratosCarterasType
	 *
	 * @param contracts                  Contracts List of contracts
	 * @param customerProductQueryParams Customer query string
	 * @param portfolioTypeFilter    	 portFolioTypeFilter
	 * @return portfolio base contract list
	 *
	 * @deprecated  a more flexible way to include and/or exclude certain portfolio types has been implemented <br/>
	 *              use {@link #getContractsFilteredByPortfolioTypes} instead
	 *
	 */
	@Deprecated
	default <T extends PortfolioBaseContract> List<T> getContractsFilteredByContratosCarterasType(
			final List<T> contracts,
			final CustomerProductQueryParams customerProductQueryParams,
			final String portfolioTypeFilter
	) {
		return null;
	}

	/**
	 * Returns the initial list of contracts filtered by portfolio types.
	 * It also sets the list of portfolios of each contract.
	 *
	 * @param contracts                  Contracts List of contracts
	 * @param customerProductQueryParams customer product query params
	 * @param portfolioQueryParams    	 portfolio query params
	 * @return portfolio base contract list
	 *
	 */
	default <T extends PortfolioBaseContract> List<T> getContractsFilteredByPortfolioTypes(
			final List<T> contracts,
			final CustomerProductQueryParams customerProductQueryParams,
			final PortfolioQueryParams portfolioQueryParams
	) {
		return null;
	}

	/**
	 * findPortfolioTypesAsMap
	 *
	 * @param contracts to find
	 * @param params to filter
	 * @param keepEmptyPortfolioTypes  indicates if portfolios without a type should be kept
	 * @param <T> contract
	 * @return types map
	 */
	default <T extends PortfolioBaseContract> Map<String, PortfolioType> findPortfolioTypesAsMap(
			final List<T> contracts,
			final CustomerProductQueryParams params,
			final boolean keepEmptyPortfolioTypes
	) {
		return Collections.emptyMap();
	}

	/**
	 * Returns a boolean that indicates if a given contract should pass the portfolio type filter
	 *
	 * @param contract to check
	 * @param portfolioMap portfolio contract number-portfolioType map
	 * @param portfolioQueryParams portfolio query params
	 * @param <T> contract
	 *
	 * @return indicates if contract passes the filter
	 */
	default <T extends PortfolioBaseContract> boolean filterByType(
			final T contract,
			final Map<String, es.santander.adn360.products.common.domain.PortfolioType> portfolioMap,
			final PortfolioQueryParams portfolioQueryParams
	) {
		return false;
	}


}
