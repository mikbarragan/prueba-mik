package es.santander.adn360.products.common.service;

import es.santander.adn360.core.model.document.Exchange;
import es.santander.adn360.products.common.domain.bean.ExchangeBalanceBean;

import java.math.BigDecimal;

/**
 * Currencies exchange service interface.
 */
public interface CurrencyService {

    /**
     * Gets exchange between currencies.
     *
     * @param originCurrency  Origin currency
     * @param destinyCurrency Destiny currency
     * @return Exchange
     */
    Exchange getExchange(String originCurrency, String destinyCurrency);

    /**
     * Converts an amount to a given currency.
     *
     * @param exchange Exchange
     * @param amount   Amount
     * @return Converted value
     */
    BigDecimal convertCurrency(Exchange exchange, BigDecimal amount);

    /**
     * Converts an amount to a given currency and return an ExchangeBalanceBean
     *
     * @param exchange Exchange
     * @param amount BigDecimal
     * @return ExchangeBalanceBean
     */
    ExchangeBalanceBean getExchangeBalanceBean(Exchange exchange, BigDecimal amount);

    /**
     * Converts the amount of an ExchangeBalanceBean to given currency and return an ExchangeBalanceBean
     *
     * @param exchange Exchange
     * @param exchangeBalanceBean ExchangeBalanceBean
     * @return ExchangeBalanceBean
     */
    ExchangeBalanceBean getExchangeBalanceBean(Exchange exchange, ExchangeBalanceBean exchangeBalanceBean);

    /**
     * Method needed to clean currencies cache.
     */
    void cleanCurrenciesCache();
}
