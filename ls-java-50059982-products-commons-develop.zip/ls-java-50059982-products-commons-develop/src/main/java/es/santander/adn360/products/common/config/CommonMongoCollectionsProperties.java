package es.santander.adn360.products.common.config;

import jakarta.validation.constraints.NotNull;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;


/**
 * Common
 * Mongo Collections
 * Properties
 */
@Data
@Configuration
@ConfigurationProperties(prefix = "spring.data.mongodb.collections")
@PropertySource("classpath:/products-common.properties")
public class CommonMongoCollectionsProperties {

    /**
     * empresaSubprod
     */
    @NotNull
    private String empresaSubprod;

    /**
     * person
     */
    @NotNull
    private String person;

    /**
     * tipos intervención
     */
    @NotNull
    private String tiposIntervencion;

    /**
     * descripciones formas de intervención
     */
    @NotNull
    private String descripcionesFormaIntervencion;

}
