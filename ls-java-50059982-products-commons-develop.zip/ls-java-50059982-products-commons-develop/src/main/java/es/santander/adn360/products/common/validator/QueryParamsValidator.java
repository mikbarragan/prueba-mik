package es.santander.adn360.products.common.validator;

import es.santander.adn360.mongodb.starter.domain.QueryParams;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import org.apache.commons.lang3.StringUtils;

import java.util.Optional;

/**
 * Validator for QueryParams field.
 */
public class QueryParamsValidator implements ConstraintValidator<QueryParamsConstraint, Object> {

    /**
     * Constant representing the name of the aggregations expansion.
     */
    public static final String EXPAND_AGGREGATIONS = "aggregations";

    /**
     * Initialize
     * @param queryParamsConstraint query params contraint
     */
    @Override
    public void initialize(QueryParamsConstraint queryParamsConstraint) {
        // Do nothing
    }

    /**
     * Check if is valid context
     * @param target object
     * @param constraintValidatorContext constraint Validator Context
     * @return  true or false
     */
    @Override
    public boolean isValid(Object target, ConstraintValidatorContext constraintValidatorContext) {
        Optional<QueryParams> queryParams = Optional.ofNullable(target)
                .filter(QueryParams.class::isInstance)
                .map(QueryParams.class::cast);

        if (!queryParams.isPresent()){
            return true;
        }
        if (!isValidExpand(Optional.ofNullable(queryParams.get().getExpand()))) {
            return false;
        }
        return true;
    }

    /**
     * Validate if the "_expand" field is sent and if this field has a valid value.
     *
     * @param expand param to add the aggregations
     * @return check is valid input parameters
     */
    private boolean isValidExpand(Optional<String> expand) {
        return expand.map((String s) -> StringUtils.isEmpty(s) || EXPAND_AGGREGATIONS.equalsIgnoreCase(s))
                .orElse(Boolean.TRUE);
    }
}
