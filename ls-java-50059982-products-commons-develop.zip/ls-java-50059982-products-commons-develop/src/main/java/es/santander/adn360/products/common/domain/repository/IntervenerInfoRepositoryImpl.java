package es.santander.adn360.products.common.domain.repository;

import es.santander.adn360.mongodb.starter.autoconfigure.MongoQueryRepositoryAutoConfiguration;
import es.santander.adn360.mongodb.starter.domain.MongoQueryRepositoryImpl;
import es.santander.adn360.products.common.domain.IntervenerInfo;
import es.santander.adn360.products.common.domain.entity.Intervener;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.repository.support.MongoRepositoryFactory;
import org.springframework.stereotype.Repository;
import org.springframework.util.Assert;

import java.util.List;
import java.util.Map;
import java.util.function.Function;

import static java.util.stream.Collectors.toMap;

/**
 * IntervenerInfoRepositoryImpl
 *
 * nonsense commentary to comply with a nonsense rule
 * nonsense commentary to comply with a nonsense rule
 * nonsense commentary to comply with a nonsense rule
 * nonsense commentary to comply with a nonsense rule
 * nonsense commentary to comply with a nonsense rule
 *
 */

@ConditionalOnClass(MongoQueryRepositoryAutoConfiguration.class)
@Repository
public class IntervenerInfoRepositoryImpl extends MongoQueryRepositoryImpl<IntervenerInfo, String>
		implements IntervenerInfoRepository {

	/**
	 * Intervener repository constrcutor
	 * @param mongoRepositoryFactory mongoRepositoryFactory
	 * @param mongoOperations mongoOperations
	 */
	public IntervenerInfoRepositoryImpl(
			final MongoRepositoryFactory mongoRepositoryFactory,
			final MongoOperations mongoOperations
	) {
		super(mongoRepositoryFactory.getEntityInformation(IntervenerInfo.class), mongoOperations);
	}

	/**
	 * find inverner list
	 * @param interveners Interveners list
	 * @return list of interveners
	 */
	@Deprecated(since = "4.1.22")
	@Override
	public List<IntervenerInfo> findByIntervenerList(List<Intervener> interveners) {

		Assert.notEmpty(interveners, "Interveners list should not be empty");

        return this.findAll(null, new Criteria()
    			.orOperator(interveners.stream()
	                .filter(x -> x.getIdCliente() != null)
	                .map(x -> Criteria.where("tipoIntervencion").is(x.getTipoInterv()))
	                .toArray(Criteria[]::new))
        		).getContent();
	}

	/**
	 * Find interver by type
	 * @param intervenerType intervener type
	 * @return intervener found
	 */
	@Deprecated(since = "4.1.22")
	@Override
	public IntervenerInfo findByIntervenerType(String intervenerType) {
		Assert.notNull(intervenerType, "Intervener type should not be empty");

        return this.findAll(null, Criteria.where("tipoIntervencion").is(intervenerType))
        		.getContent().stream()
                .findFirst()
                .orElse(IntervenerInfo.builder().build());
	}

	/**
	 * find descriptions forms list
	 *
	 * @return list of descriptions
	 */
	@Cacheable(
			cacheNames = {"tipoNombreIntervenersMap"},
			unless = "#result == null or #result.size() == 0"
	)
	@Override
	public Map<String, IntervenerInfo> findAllAsMap() {
		return this.findAll().stream()
				.collect(toMap(
						IntervenerInfo::getTipoIntervencion,
						Function.identity(),
						(existing, replacement) -> existing
				));
	}



}
