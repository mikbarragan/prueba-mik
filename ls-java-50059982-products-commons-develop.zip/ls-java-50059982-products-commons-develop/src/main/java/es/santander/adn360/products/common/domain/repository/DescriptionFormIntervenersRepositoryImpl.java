package es.santander.adn360.products.common.domain.repository;

import es.santander.adn360.mongodb.starter.autoconfigure.MongoQueryRepositoryAutoConfiguration;
import es.santander.adn360.mongodb.starter.domain.MongoQueryRepositoryImpl;
import es.santander.adn360.products.common.domain.DescriptionFormInterveners;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.repository.support.MongoRepositoryFactory;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
import java.util.function.Function;

import static java.util.stream.Collectors.toMap;

/**
 * Description Form Interveners
 * Repository implementation
 */
@Slf4j
@ConditionalOnClass(MongoQueryRepositoryAutoConfiguration.class)
@Repository
public class DescriptionFormIntervenersRepositoryImpl
        extends MongoQueryRepositoryImpl<DescriptionFormInterveners, String>
        implements DescriptionFormIntervenersRepository {

    /**
     * Intervener repository constrcutor
     *
     * @param mongoRepositoryFactory mongoRepositoryFactory
     * @param mongoOperations        mongoOperations
     */
    public DescriptionFormIntervenersRepositoryImpl(
            final MongoRepositoryFactory mongoRepositoryFactory,
            final MongoOperations mongoOperations
    ) {
        super(mongoRepositoryFactory.getEntityInformation(DescriptionFormInterveners.class), mongoOperations);
    }

    /**
     * find descriptions forms list
     *
     * @return list of descriptions
     */
    @Deprecated(since = "4.1.22")
    @Cacheable(
            cacheNames = {"descriptionFormInterveners"},
            unless = "#result == null or #result.size() == 0"
    )
    @Override
    public List<DescriptionFormInterveners> findAll() {
        return super.findAll();
    }

    /**
     * find descriptions forms list
     *
     * @return list of descriptions
     */
    @Cacheable(
            cacheNames = {"descriptionFormIntervenersMap"},
            unless = "#result == null or #result.size() == 0"
    )
    @Override
    public Map<String, DescriptionFormInterveners> findAllAsMap() {
        return super.findAll().stream()
                .collect(toMap(
                        DescriptionFormInterveners::getFormaIntervencion,
                        Function.identity(),
                        (existing, replacement) -> existing
                ));
    }



}
