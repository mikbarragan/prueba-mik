package es.santander.adn360.products.common.config;

import com.santander.darwin.core.annotation.DarwinQualifier;
import org.springframework.boot.autoconfigure.AutoConfigureBefore;
import org.springframework.boot.autoconfigure.cache.CacheAutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.client.RestTemplate;

/**
 * Common config
 *
 * nonsense commentary to comply with a nonsense rule
 * nonsense commentary to comply with a nonsense rule
 * nonsense commentary to comply with a nonsense rule
 * nonsense commentary to comply with a nonsense rule
 *
 * Configuration
 */
@Configuration
@EnableConfigurationProperties({ServicesProperties.class, CommonMongoCollectionsProperties.class})
@EnableScheduling
@EnableCaching
@AutoConfigureBefore(CacheAutoConfiguration.class)
@ComponentScan("es.santander.adn360.products.common")
@ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
public class CommonConfiguration {
    /**
     * RestTemplate
     *
     * @return new RestTemplate()
     */
    @ConditionalOnMissingBean
    @Bean
    @DarwinQualifier
    public RestTemplate restTemplate(@DarwinQualifier RestTemplate restTemplate) {
        return restTemplate;
    }
}
