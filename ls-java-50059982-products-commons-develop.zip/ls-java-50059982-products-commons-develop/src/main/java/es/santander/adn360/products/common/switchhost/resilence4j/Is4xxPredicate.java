package es.santander.adn360.products.common.switchhost.resilence4j;

import es.santander.adn360.core.model.exception.FunctionalException;

import java.util.function.Predicate;

/**
 * Is4xxPredicate class description
 * implements predicate throwable
 */
public class Is4xxPredicate implements Predicate<Throwable> {

    /**
     * constructor
     * */
    public Is4xxPredicate() {
        // constructor Is4xxPredicate
    }

    /**
     * test function
     * @param throwable error
     *
     * @return check if is functional exception
     * */
    @Override
    public boolean test(Throwable throwable) {
        return throwable instanceof FunctionalException &&
                ((FunctionalException) throwable).getInfo().getHttpStatus().is4xxClientError();
    }
}
