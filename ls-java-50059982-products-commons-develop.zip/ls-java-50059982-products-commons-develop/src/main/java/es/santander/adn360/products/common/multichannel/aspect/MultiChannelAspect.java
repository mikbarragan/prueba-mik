package es.santander.adn360.products.common.multichannel.aspect;


import es.santander.adn360.core.model.exception.FunctionalException;
import es.santander.adn360.core.util.ExceptionEnum;
import es.santander.adn360.products.common.multichannel.annotation.MultiChannelPostProcessor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.aop.support.AopUtils;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;

/**
 * MultiChannelAspect
 */
@Component
@Slf4j
@Aspect
@RequiredArgsConstructor
public class MultiChannelAspect {

   private final ApplicationContext applicationContext;

    /**
     * Se ejecuta depues de ingresa en un metodo anotado.
     * Llama a los metodos de los procesadores que se reciban.
     * llamará a un metodo u otro dependiendo del parametro de salida que se recibe en el joinPoint
     *
     * @param joinPoint        Punto de intercepcion.
     * @return object to return
     * @throws Throwable exception
     */
    @Around("multiChannelPostProcessorAnnotationPointcut()")
    public Object postExecution(ProceedingJoinPoint joinPoint) throws Throwable {

        Object result = joinPoint.proceed();
        Signature signature =  joinPoint.getSignature();
        Class returnType = ((MethodSignature) signature).getReturnType();
        Method method = AopUtils.selectInvocableMethod(((MethodSignature) signature).getMethod(),joinPoint.getTarget().getClass());
        MultiChannelPostProcessor multiChannelPostProcessor = method.getAnnotation(MultiChannelPostProcessor.class);

        for ( Class<?> processor : multiChannelPostProcessor.value() ) {
            result = this.invokeMethodProcessor(processor, returnType, result);
        }

        return result;
    }

    /**
     * multiChannelPostProcessorAnnotationPointcut
     */
    @Pointcut("@annotation(es.santander.adn360.products.common.multichannel.annotation.MultiChannelPostProcessor)")
    public void multiChannelPostProcessorAnnotationPointcut(){
        // Do nothing
    }

    /**
     * function that invoke a method processor and set result with method called result
     *
     * @param  processor processor whose method will be called
     * @param returnType  type that return the method called in service anotated with MultiChannelPostProcessor
     * @param result  result thant return in service annotated with multiChannelPostProcessor and that we are going
     *                to update with the processors
     * @return name of the method to be called from the processor
     */
    private Object invokeMethodProcessor (Class<?> processor, Class returnType , Object result)
            throws InvocationTargetException, IllegalAccessException {
        try {

            Object processorInstance = applicationContext.getBean(processor);

            Method method = this.getMethodProcessor(processorInstance, returnType);

           return method.invoke(processorInstance, result);

        } catch (NoSuchMethodException error){
            throw new FunctionalException(error, ExceptionEnum.INTERNAL_SERVER_ERROR,
                    error.getMessage());
        }
        catch (NoSuchBeanDefinitionException error){
            throw new FunctionalException(error, ExceptionEnum.INTERNAL_SERVER_ERROR,
                    "Error in multiChannelPostProcessor when trying to run the processor "
                            + processor.getName() +
                            " because it is out of the spring context. Processor should be a Bean");
        }

    }

    /**
     * function that returns the method we're going to invoke
     *
     * @param  processor processor that will be called
     * @param returnType  type that return the method called in service anotated with MultiChannelPostProcessor
     * @return name of the method to be called from the processor
     */
    private Method getMethodProcessor(Object processor, Class returnType) throws NoSuchMethodException {

        if(returnType.isAssignableFrom(List.class)) {
            return processor.getClass().getMethod("processListContracts", returnType);
        }
        return processor.getClass().getMethod("processContract", returnType.getSuperclass());
    }

}
