package es.santander.adn360.products.common.domain.bean;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * AggregationBean
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AggregationBean {

	/**
	 * Aggregation field
	 */
	@Schema(description = "Aggregation field.", example = "GSI")
	private String field;

	/**
	 * Aggregation title
	 */
	@Schema(description = "Aggregation title.", example = "GSI")
	private String title;

	/**
	 * String value
	 */
	@Schema(description = "String value.", example = "GSI")
	private String stringValue;

	/**
	 * Aggregation value
	 */
	@Schema(description = "Aggregation value.")
	private BalanceBean value;

}
