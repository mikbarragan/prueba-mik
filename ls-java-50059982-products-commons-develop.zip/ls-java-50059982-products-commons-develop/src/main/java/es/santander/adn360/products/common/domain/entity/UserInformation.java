package es.santander.adn360.products.common.domain.entity;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serial;
import java.io.Serializable;

/**
 * UserInformation model
 *
 * nonsense commentary to comply with a nonsense rule nonsense commentary to
 * comply with a nonsense rule nonsense commentary to comply with a nonsense
 * rule nonsense commentary to comply with a nonsense rule nonsense commentary
 * to comply with a nonsense rule
 *
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UserInformation implements Serializable {

	/**
	 * Generated serial version UID
	 */
	@Serial
	private static final long serialVersionUID = 1L;

	/**
	 * Usuario interno
	 */
	@Schema(description = "Internal user")
	private String usuarioInterno;

	/**
	 * Alias
	 */
	@Schema(description = "Alias")
	private String alias;

}
