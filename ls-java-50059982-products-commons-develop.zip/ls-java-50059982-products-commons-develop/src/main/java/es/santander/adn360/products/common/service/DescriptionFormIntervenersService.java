package es.santander.adn360.products.common.service;

import es.santander.adn360.products.common.domain.DescriptionFormInterveners;

import java.util.Optional;

/**
 * DescriptionFormIntervenersService interface
 */
public interface DescriptionFormIntervenersService {

    /**
     * Find description by forma
     *
     * @param forma to find
     * @return description optinal
     */
    Optional<DescriptionFormInterveners> findByForma(String forma);

    /**
     * findDescriptionByForma
     *
     * @param forma to find
     * @return forma optional
     */
    Optional<String> findDescriptionByForma(String forma);

    /**
     * cleanCache
     */
    void cleanCache();
}
