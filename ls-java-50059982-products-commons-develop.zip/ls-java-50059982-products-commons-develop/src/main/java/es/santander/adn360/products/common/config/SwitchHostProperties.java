package es.santander.adn360.products.common.config;

import jakarta.validation.constraints.NotNull;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import java.util.List;

/**
 * SwitchHostProperties
 */
@Data
@Configuration
@ConfigurationProperties(prefix = "switch-host")
@PropertySource("classpath:/products-common.properties")
@RefreshScope
public class SwitchHostProperties {

    /**
     * forceHost
     */
    @NotNull
    private List<String> forceHost;

    /**
     * forceLake
     */
    @NotNull
    private List<String> forceLake;

    /**
     * circuitBraker
     */
    @NotNull
    private List<String> circuitBraker;

    /**
     * endpoints
     */
    @NotNull
    private Urls endpoints = new Urls();

    /**
     * Urls
     */
    @Data
    public static class Urls {

        /**
         * Product list URL
         */
        private String productList;

        /**
         * Aggregation URL
         */
        private String aggregation;
    }

}
