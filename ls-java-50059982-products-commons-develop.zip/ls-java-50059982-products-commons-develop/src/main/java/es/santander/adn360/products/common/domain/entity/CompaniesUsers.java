package es.santander.adn360.products.common.domain.entity;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDate;

/**
 * CompaniesUsers model
 *
 * nonsense commentary to comply with a nonsense rule nonsense commentary to
 * comply with a nonsense rule nonsense commentary to comply with a nonsense
 * rule nonsense commentary to comply with a nonsense rule nonsense commentary
 * to comply with a nonsense rule
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CompaniesUsers implements Serializable {

	/**
	 * Generated serial version UID
	 */
	@Serial
	private static final long serialVersionUID = 1L;

	/**
	 * idUsuario company user internal identifier
	 */
	@Schema(description = "Company user internal identifier")
	private String idUsuario;

	/**
	 * Indicator. Can be I (included) or E (excluded)
	 */
	@Schema(description = "Indicator. Can be I (included) or E (excluded)", example = "I")
	private String indicador;

	/**
	 * date from the register is valid
	 */
	@Schema(description = "Date from the register is valid")
	private LocalDate fechaDesde;

	/**
	 * Date until the register is valid
	 */
	@Schema(description = "Date until the register is valid")
	private LocalDate fechaHasta;

}
