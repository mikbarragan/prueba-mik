package es.santander.adn360.products.common.switchhost.aspect;

import es.santander.adn360.core.web.WebUtils;
import es.santander.adn360.products.common.config.SwitchHostProperties;
import es.santander.adn360.products.common.switchhost.annotation.Adn360SwitchHost;
import es.santander.adn360.products.common.switchhost.service.Adn360SwitchHostHystrixService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

/**
 * Adn360CircuitAspect
 */
@Component
@Slf4j
@Aspect
@RequiredArgsConstructor
public class Adn360CircuitAspect {

    private final SwitchHostProperties switchHostProperties;
    private final Adn360SwitchHostHystrixService adn360SwitchHostHystrixService;

    /**
     * Se ejecuta antes de ingresar a un m&eacute; t o d o anotado.
     *
     * @param joinPoint        Punto de intercepci&oacute;n.
     * @param adn360SwitchHost Anotaci&oacute;n.
     * @return object
     * @throws Throwable exception
     */
    @Order(1)
    @Around("@annotation(adn360SwitchHost)")
    public Object beforeExecution(ProceedingJoinPoint joinPoint, Adn360SwitchHost adn360SwitchHost) throws Throwable {

        String channel = WebUtils.getSantanderChannel();
        Object result;
        if (switchHostProperties.getCircuitBraker().contains(channel)) {
            // EMP channel whith circuit braker
            result = adn360SwitchHostHystrixService.execute(joinPoint, adn360SwitchHost);

        } else if (switchHostProperties.getForceHost().contains(channel)) {
            // EMPB channel, access to host forces
            result = adn360SwitchHostHystrixService.executeFallback(joinPoint, adn360SwitchHost, null);
        } else {
            // normal execution
            result = joinPoint.proceed();
        }
        return result;
    }

    /**
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     * nonsense commentary to comply with a nonsense rule
     *
     */
}
