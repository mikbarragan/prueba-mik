package es.santander.adn360.products.common.domain.entity;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serial;
import java.io.Serializable;

/**
 * Customer
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Customer implements Serializable {

    /**
     * Generated serial version UID
     */
    @Serial
    private static final long serialVersionUID = 1L;

    /**
     * customerId
     */
    @Schema(description = "Customer identifier")
    private String customerId;

    /**
     * name
     */
    @Schema(description = "Customer name")
    private String name;

    /**
     * documentType
     */
    @Schema(description = "Document type")
    private String documentType;

    /**
     * documentNumber
     */
    @Schema(description = "Document number")
    private String documentNumber;

    /**
     * channel
     */
    @Schema(description = "Channel")
    private String channel;

    /**
     * codeClientCompany
     */
    @Schema(description = "Code client company")
    private String codeClientCompany;

    /**
     * phone
     */
    @Schema(description = "Customer phone number")
    private String phone;

    /**
     * informacion sobre la direccion del cliente
     */
    @Schema(description = "Customer address")
    private CustomerAddress customerAddress;

}
