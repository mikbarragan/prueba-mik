package es.santander.adn360.products.common.service;

import es.santander.adn360.core.model.exception.FunctionalException;
import es.santander.adn360.core.util.CustomerProductQueryParams;
import es.santander.adn360.core.util.ExceptionEnum;
import es.santander.adn360.core.util.ProductQueryParams;
import es.santander.adn360.core.web.WebUtils;
import es.santander.adn360.products.common.config.IntervenerFiltersProperties;
import es.santander.adn360.products.common.domain.DescriptionFormInterveners;
import es.santander.adn360.products.common.domain.IntervenerInfo;
import es.santander.adn360.products.common.domain.entity.BaseContract;
import es.santander.adn360.products.common.domain.entity.Intervener;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import static java.util.stream.Collectors.toList;

/**
 * Intervener
 * Service Implementation
 */
@Service
@Slf4j
public class IntervenerServiceImpl implements IntervenerService {

    private static final String OWN_FILTER = "own";
    private static final String ALL_FILTER = "all";
    private static final String DEFAULT_APPLICATION_CFG = "default";
    private static final String NOCONFIG = "noconfig";

    /** Filter properties */
    private final IntervenerFiltersProperties intervenerFiltersProperties;

    /** Names service */
    private final IntervenerInfoService namesService;

    /** Description service */
    private final DescriptionFormIntervenersService descriptionService;

    /**
     * Constructor
     *
     * @param intervenerFiltersProperties service
     * @param namesService service
     * @param descriptionService service
     */
    public IntervenerServiceImpl(
            final IntervenerFiltersProperties intervenerFiltersProperties,
            final IntervenerInfoService namesService,
            final DescriptionFormIntervenersService descriptionService
    ) {
        this.intervenerFiltersProperties = intervenerFiltersProperties;
        this.namesService = namesService;
        this.descriptionService = descriptionService;
    }

    /**
     * Get intervener info associated participant type. Each contract has one to many
     * participants with differents descriptions each one.
     *
     * @param participantType participant type (01, 04, 0A,...)
     * @return IntervenerInfo or null if not exists
     */
    @Override
    public IntervenerInfo getIntervenerInformation(final String participantType) {

        return namesService.findByTipo(participantType).orElse(null);
    }

    /**
     * Find intervener info associated participant type. Each contract has one to many
     * participants with differents descriptions each one.
     *
     * @param participantType participant type (01, 04, 0A,...)
     * @return IntervenerInfo optional
     */
    @Override
    public Optional<IntervenerInfo> findInfo(final String participantType) {

        return namesService.findByTipo(participantType);
    }

    /**
     * Find intervener name associated participant type. Each contract has one to many
     * participants with differents descriptions each one.
     *
     * @param participantType participant type (01, 04, 0A,...)
     * @return Intervener name optional
     */
    @Override
    public Optional<String> findName(final String participantType) {

        return namesService.findNombreByTipo(participantType);
    }

    /**
     * Get intervener info associated participant form. Each contract has one to many
     * participants with differents descriptions each one.
     *
     * @param participantForm participant form (01, 04, 0A,...)
     * @return IntervenerInfo or null if not exists
     */
    @Override
    public DescriptionFormInterveners getDescriptionForm(final String participantForm) {

        return descriptionService.findByForma(participantForm).orElse(null);
    }

    /**
     * Find description-form by associated participant form. Each contract has one to many
     * participants with differents descriptions each one.
     *
     * @param participantForm participant form (01, 04, 0A,...)
     * @return DescriptionFormInterveners optional
     */
    @Override
    public Optional<DescriptionFormInterveners> findDescriptionForm(final String participantForm) {

        return descriptionService.findByForma(participantForm);
    }

    /**
     * Find description by associated participant form. Each contract has one to many
     * participants with differents descriptions each one.
     *
     * @param participantForm participant form (01, 04, 0A,...)
     * @return Description optional
     */
    @Override
    public Optional<String> findDescription(final String participantForm) {

        return descriptionService.findDescriptionByForma(participantForm);
    }

    /**
     * Get list interveners info within contracts list. Each contract has one to many
     * participants with differents descriptions each one.
     *
     * @param contracts Contracts list
     * @return List IntervenerInfo
     */
    @Override
    public List<IntervenerInfo> findIntervenerInfoByContracts(final List<? extends BaseContract> contracts) {
        Assert.notNull(contracts, "Contracts parameter is required.");

        final var now = LocalDate.now();

        return contracts.stream()
                .map(BaseContract::getIntervinientes)
                .filter(Objects::nonNull)
                .flatMap(List::stream)
                .filter(intr -> intr.isActive(now))
                .map(Intervener::getTipoInterv)
                .distinct()
                .map(this::getIntervenerInformation)
                .collect(toList());
    }

    /**
     * Get list Description Form Interveners info within contracts list.
     * Each contract has one to many participants
     * with differents descriptions each one.
     *
     * @param contracts Contracts list
     * @return List DescriptionFormInterveners
     */
    @Override
    public List<DescriptionFormInterveners> findDescriptionFormByContracts(final List<? extends BaseContract> contracts) {

        Assert.notNull(contracts, "Contracts parameter is required.");

        final var now = LocalDate.now();

        return contracts.stream()
                .map(BaseContract::getIntervinientes)
                .filter(Objects::nonNull)
                .flatMap(List::stream)
                .filter(intr -> intr.isActive(now))
                .map(Intervener::getFormaInterv)
                .distinct()
                .map(this::getDescriptionForm)
                .collect(toList());
    }

    /**
     * Get list interveners info within interveners list.
     *
     * @param interveners Intervener list
     * @return List IntervenerInfo
     */
    @Override
    public List<IntervenerInfo> findIntervenerInfoByInterveners(final List<Intervener> interveners) {
        return interveners.stream()
                .map(Intervener::getTipoInterv)
                .distinct()
                .map(this::getIntervenerInformation)
                .distinct()
                .collect(toList());
    }

    /**
     * Get list Description form info within interveners list.
     *
     * @param interveners Intervener list
     * @return List DescriptionFormInterveners
     */
    @Override
    public List<DescriptionFormInterveners> findDescriptionFormByInterveners(final List<Intervener> interveners) {
        return interveners.stream()
                .map(Intervener::getFormaInterv)
                .distinct()
                .map(this::getDescriptionForm)
                .distinct()
                .collect(toList());
    }

    /**
     * Clean cache
     */
    @Override
    @Scheduled(cron = "${services.intervenerService.cacheCron}")
    public void cleanCache() {

        this.descriptionService.cleanCache();
        this.namesService.cleanCache();
        log.info("Cleaning customers cache.");
    }

    /**
     * Se obtiene la configuración por la aplicación
     * @param application aplicación
     * @return configuración por aplicación
     *
     * SituationIndicatorFiltersProperties.Channel channelCfg = this.situationIndicatorFiltersProperties.getChannel()
     *                 == null ? null
     *                 :  this.situationIndicatorFiltersProperties.getChannel().get(WebUtils.getSantanderChannel());
     */
    private IntervenerFiltersProperties.ApplicationCfg getChannelConfig(final String application) {

        IntervenerFiltersProperties.Channel channelCfg = this.intervenerFiltersProperties.getChannel() == null ?
                null
                : this.intervenerFiltersProperties.getChannel().get(WebUtils.getSantanderChannel());

        return channelCfg == null ?
                loadApplicationDefault()
                : getApplicationCfg(channelCfg, application);
    }

    /**
     * Se carga la configuración por defecto sin canal ni aplicación,
     * en el caso de no existir se lanza una excepción controlada
     * para avisar de que no hay una configuración.
     *
     * @return configuración de aplicación
     */
    private IntervenerFiltersProperties.ApplicationCfg loadApplicationDefault(){
        IntervenerFiltersProperties.ApplicationCfg defaultApp = new IntervenerFiltersProperties.ApplicationCfg();
        defaultApp.setName(DEFAULT_APPLICATION_CFG);
        Map<String, List<String>> codes = new HashMap<>();
        codes.put(OWN_FILTER, this.intervenerFiltersProperties.getOwn());
        codes.put(ALL_FILTER, this.intervenerFiltersProperties.getAll());
        defaultApp.setFilters(codes);
        return defaultApp;
    }

    /**
     * Check default application
     *
     * @param channelCfg channelCfg
     * @param application application
     * @return application codes
     */
    private IntervenerFiltersProperties.ApplicationCfg getApplicationCfg(
            final IntervenerFiltersProperties.Channel channelCfg,
            final String application
    ){
        String appName = application;

        if (StringUtils.hasText(application) && application.equalsIgnoreCase(DEFAULT_APPLICATION_CFG)){
            appName = channelCfg.getApplication().stream()
                    .map(IntervenerFiltersProperties.ApplicationCfg::getName)
                    .filter(s -> s.equalsIgnoreCase(DEFAULT_APPLICATION_CFG))
                    .findFirst()
                    .orElse(NOCONFIG);
        }

        String finalAppName = appName;

        return channelCfg.getApplication()
                .stream()
                .filter(app -> app.getName().equalsIgnoreCase(application))
                .findFirst()
                .orElseGet(() -> {
                    if (StringUtils.hasText(finalAppName) && finalAppName.equalsIgnoreCase(NOCONFIG)) {
                        return loadApplicationDefault();
                    } else{
                        return getApplicationCfg(channelCfg, DEFAULT_APPLICATION_CFG);
                    }
                });
    }


    /**
     * Return all interventions codes and names configured into application.yaml under key:
     * intervenerFilters.*.filters:
     *
     *
     * Ej: Disscounts product has 44 code as TITULAR with filter equals OWN
     * @param filter references to participant type value (OWN,ALL) {@link CustomerProductQueryParams}
     * @param application references to application name param value (ADN360, PSD2, NWE,..) {@link ProductQueryParams}
     * @return a Map whose K is intervention code and V is then convention intervention name
     *          Devuelve un map del estilo: {01:titular, 44:titular}
     *
     * Ej: If filter is "OWN" the method return this map {01=Titular}
     *
     */
    @Override
    public Map<String, String> findInterventionCodes(final String filter, final String application) {

        IntervenerFiltersProperties.ApplicationCfg applicationCfg = getChannelConfig(application);

        String defaultFilter = Optional.ofNullable(filter).orElse(OWN_FILTER);

        List<String> interventionsByFilter = applicationCfg.getFilters()
                .entrySet()
                .stream()
                //filter values by key
                .filter(value ->  ALL_FILTER.equalsIgnoreCase(defaultFilter)
                        || defaultFilter.equalsIgnoreCase(value.getKey()))
                .map(Map.Entry::getValue)
                .filter(Objects::nonNull)
                .flatMap(List::stream)
                .collect(toList());

        if (interventionsByFilter.isEmpty() && StringUtils.hasText(filter)) {
            throw new FunctionalException(ExceptionEnum.INTERNAL_SERVER_ERROR,
                    String.format("Do not exist any configuration for intervener filters for %s type intervener",
                            defaultFilter));
        }

        return interventionsByFilter.stream()
                .collect(HashMap::new,
                        (map, codes) -> map.put(codes.split("-")[0], codes.split("-")[1]),
                        HashMap::putAll
                );
    }

    /**
     * Find intervention codes
     *
     * @param filter references to participant type value (OWN,ALL) {@link CustomerProductQueryParams}. If filter is
     * null then it will be applied "own" value as configuration.
     * @return  intervention codes
     */
    @Override
    public Map<String, String> findInterventionCodes(final String filter) {
        return this.findInterventionCodes(filter == null ? OWN_FILTER : filter, DEFAULT_APPLICATION_CFG);
    }

    /**
     * Find intervention codes without filter
     *
     * @return default intervention codes
     */
    @Override
    public Map<String, String> findInterventionCodes() {
        return this.findInterventionCodes(OWN_FILTER, DEFAULT_APPLICATION_CFG);
    }

    /**
     * Filling intervener information (participant and descripcionFormaIntervencion fields),
     * and filter interveners return only actives or every (depend on allInteveners value)
     *
     * @param interveners list
     * @param  allInterveners Indicator to obtain all the participants(true) or only the active participants(false)
     * @param filter references to participant type value (OWN,ALL) {@link CustomerProductQueryParams}
     * @param application references to application name param value (ADN360, PSD2, NWE,..) {@link ProductQueryParams}
     * @return intervener list
     */
    @Override
    public List<Intervener> fillAndFilterIntervenerParticipantField(
            final List<Intervener> interveners,
            final boolean allInterveners,
            final String filter,
            final String application
    ) {
        Assert.notNull(interveners, "interveners object should not be null");

        /* devuelve un map del estilo:  01=titular, 08=avalista  */
        Map<String, String> codeNameMap = findInterventionCodes(filter, application);

        final var now = LocalDate.now();

        return interveners.stream()
                .filter(intervener -> intervener != null && (allInterveners || intervener.isActive(now)))
                .map((Intervener intr) -> {

                    Optional.ofNullable(codeNameMap.get(intr.getTipoInterv()))
                            .map(name -> intr.getOrdenInterv().toString() + " " + name)
                            .ifPresent(intr::setParticipant);

                    final var description = Optional.ofNullable(getDescriptionForm(intr.getFormaInterv()))
                            .map(DescriptionFormInterveners::getDescripcion)
                            .orElse("");

                    intr.setDescripcionFormaIntervencion(description);

                    return intr;
                })
                .sorted(Comparator.comparing(Intervener::getTipoInterv))
                .collect(toList());

    }

    /**
     * Filling intervener information (participant and descripcionFormaIntervencion fields),
     * and filter interveners return only actives or every (depend on allInteveners value)
     * @deprecated
     * This method is no longer acceptable to retrieve information about intervener.
     * <p> Use {@link IntervenerService#fillAndFilterIntervenerParticipantField} instead.
     *
     * @param interveners list
     * @param  allInterveners . Indicator to obtain all the participants or only the active participants
     * @param filter references to participant type value (OWN,ALL) {@link CustomerProductQueryParams}
     * @param application references to application name param value (ADN360, PSD2, NWE,..) {@link ProductQueryParams}
     * @return intervener list
     */
    @Deprecated(since = "4.1.18")
    @Override
    public List<Intervener> fillAndFilterIntervenerParticipantAndFormFields(List<Intervener> interveners,
                                                                            boolean allInterveners,
                                                                            String filter,
                                                                            String application) {

        return this.fillAndFilterIntervenerParticipantField(interveners,allInterveners,filter,application);
    }

    /**
     * Fill and intervener participant
     *
     * @param interveners list
     * @param  allInterveners . Indicator to obtain all the participants or only the active participants
     * @return  intervener list
     */
    @Override
    public List<Intervener> fillAndFilterIntervenerParticipantField(
            final List<Intervener> interveners,
            final boolean allInterveners
    ) {
        return this.fillAndFilterIntervenerParticipantField(
                interveners,
                allInterveners,
                ALL_FILTER,
                DEFAULT_APPLICATION_CFG
        );
    }

    /**
     * @deprecated Esta función ya no se usa
     *
     * Fill and sort filter intervener participant
     *
     * @param interveners list
     * @return  intervener list
     */
    @Override
    @Deprecated(since = "")
    public List<Intervener> fillAndSortFilterIntervenerParticipantField(List<Intervener> interveners) {
        Assert.notNull(interveners, "interveners object should not be null");

        //devuelve un map del estilo: {01=titular, 08=avalista},
        Map<String, String> codeNameMap = findInterventionCodes(ALL_FILTER,"ADN360");

        final var now = LocalDate.now();

        //lista auxiliar ordenada por orden de intervencion
        List<Intervener> intervenerSortedList = interveners.stream()
                .filter(Objects::nonNull)
                .filter(intr -> intr.isActive(now))
                .filter(intervener -> codeNameMap.containsKey(intervener.getTipoInterv()))
                .sorted(Comparator.comparingInt(Intervener::getOrdenInterv))
                .collect(toList());

        //buscamos la posicion del intervener para sacer su orden y seteamos el participant con su intervencion
        return interveners.stream()
                .filter(Objects::nonNull)
                .filter(intr -> codeNameMap.containsKey(intr.getTipoInterv()) && intr.isActive(now))
                .map((Intervener intr) -> {

                    final int index = intervenerSortedList.indexOf(intr);

                    if (index != -1) {
                        intr.setParticipant(index + 1 + " " + codeNameMap.get(intr.getTipoInterv()));

                        final var description = descriptionService.findDescriptionByForma(intr.getFormaInterv())
                                .orElse("");

                        intr.setDescripcionFormaIntervencion(description);
                    }

                    return intr;
                }).collect(toList());
    }

}
