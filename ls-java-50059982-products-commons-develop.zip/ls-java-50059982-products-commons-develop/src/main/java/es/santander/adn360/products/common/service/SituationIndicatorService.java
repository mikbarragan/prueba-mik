package es.santander.adn360.products.common.service;

import es.santander.adn360.core.util.CustomerProductQueryParams;
import es.santander.adn360.core.util.ProductQueryParams;

import java.util.List;

/**
 * Situation Indicator Service
 */
public interface SituationIndicatorService {

    /**
     * Return all contract codes and names configured by channel and appliation and status
     * into application.yml under key:
     * situation-indicator-filter.*
     *
     *
     * Ej: Funds product has AC code as ACTIVES with filter equals ACTIVES
     * @param status references to contract status (ACTIVES,CANCELED, ALL) {@link CustomerProductQueryParams}
     * @param application references to application name param value (ADN360, PSD2, NWE,..) {@link ProductQueryParams}
     * @return a List String with codes.
     *
     */
    List<String> findContractCodes(String status, String application);

    /**
     * Return all contract codes and names configured by channel and status into application.yml under key:
     * situation-indicator-filter.*
     *
     *
     * Ej: Funds product has AC code as ACTIVES with filter equals ACTIVES
     * @param status references to contract status (ACTIVES,CANCELED, ALL) {@link CustomerProductQueryParams}
     * @return a List String with codes.
     *
     */
    List<String> findContractCodes(String status);

    /**
     * Get max time to find contracts
     *
     * @param application   input application
     * @return  months number
     */
     Integer getMaxTimeCanceledContracts(String application);
}
