package es.santander.adn360.products.common.service;

import es.santander.adn360.core.model.document.Product;
import es.santander.adn360.core.model.document.ProductGroup;
import es.santander.adn360.core.util.ProductQueryParams;

import java.util.List;

/**
 * ProductGroupCacheService
 */
public interface ProductGroupCacheService {

    /**
     * Get Product groups
     *
     * @param productQueryParams productQueryParams
     * @param channel            channel
     * @return products
     */
    List<ProductGroup> getProductGroups(
            ProductQueryParams productQueryParams,
            String channel
    );

    /**
     * Get Product group
     *
     * @param productQueryParams productQueryParams
     * @param productGroupId     productGroupId
     * @param channel            channel
     * @return products
     */
    ProductGroup getProductGroup(
            ProductQueryParams productQueryParams,
            String productGroupId,
            String channel
    );

    /**
     * Get Products
     *
     * @param productQueryParams productQueryParams
     * @param productGroupId     productGroupId
     * @param channel            channel
     * @return products
     */
    List<Product> getProducts(
            ProductQueryParams productQueryParams,
            String productGroupId,
            String channel
    );

    /**
     * Get Catalog id
     *
     * @param productQueryParams productQueryParams
     * @param productGroupId     productGroupId
     * @param channel            channel
     * @return products
     */
    List<String> getCatalogIds(
            ProductQueryParams productQueryParams,
            String productGroupId,
            String channel
    );

    /**
     * Get Products And Related Products
     *
     * @param productQueryParams productQueryParams
     * @param productGroupId     productGroupId
     * @param channel            channel
     * @param relProd            relProd
     * @param relSubprod         relSubprod
     * @return products and related products
     */
    List<Product> getProductsAndRelatedProducts(
            ProductQueryParams productQueryParams,
            String productGroupId,
            String channel,
            String relProd,
            String relSubprod
    );
}
