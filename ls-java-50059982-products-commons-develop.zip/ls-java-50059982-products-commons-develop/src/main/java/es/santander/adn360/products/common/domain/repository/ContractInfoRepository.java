package es.santander.adn360.products.common.domain.repository;

import es.santander.adn360.products.common.domain.ContractInfo;

import java.util.List;

/**
 * ContractInfoRepository
 */
public interface ContractInfoRepository  {
    /**
     * findContractInfo
     * @param contractInfoList input list
     * @return contract info list
     */
    List<ContractInfo> findContractInfo(final List<ContractInfo> contractInfoList);
}
