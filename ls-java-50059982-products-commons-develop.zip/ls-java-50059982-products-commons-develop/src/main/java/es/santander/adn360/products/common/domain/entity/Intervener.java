package es.santander.adn360.products.common.domain.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.Objects;

/**
 * Intervener model
 * nonsense commentary to comply with a nonsense rule
 * nonsense commentary to comply with a nonsense rule
 * nonsense commentary to comply with a nonsense rule
 * nonsense commentary to comply with a nonsense rule
 * nonsense commentary to comply with a nonsense rule
 * nonsense commentary to comply with a nonsense rule
 * nonsense commentary to comply with a nonsense rule
 * nonsense commentary to comply with a nonsense rule
 * nonsense commentary to comply with a nonsense rule
 * nonsense commentary to comply with a nonsense rule
 * nonsense commentary to comply with a nonsense rule
 * nonsense commentary to comply with a nonsense rule
 *
 *
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Intervener implements Serializable {

    /**
     * Generated serial version UID
     */
    @Serial
    private static final long serialVersionUID = 1L;

    /**
     * Identificador del cliente que participa en el proceso de intervención.
     */
    @JsonProperty("customerId")
    @Schema(description = "Customer identifier", example = "F000000001")
    private String idCliente;

    /**
     * Nombre completo del participante.
     */
    @Schema(description = "Complete customer name")
    @JsonProperty("name")
    private String nombreCompleto;

    /**
     * Tipo de participante (por ejemplo, "cliente", "proveedor", etc.).
     */
    @Schema(description = "Participant type")
    @JsonProperty("participantType")
    private String tipoInterv;

    /**
     * Orden de participación del participante.
     */
    @Schema(description = "Participant order")
    @JsonProperty("participantOrder")
    private Integer ordenInterv;

    /**
     * Descripción del participante.
     */
    @Schema(description = "Participant description")
    @JsonProperty("participant")
    private String participant;

    /**
     * Formato del participante (por ejemplo, "presencial", "remoto", etc.).
     */
    @Schema(description = "Participant form")
    @JsonProperty("participantForm")
    private String formaInterv;

    /**
     * Nombre Intervencion.
     */
    @Schema(description = "Participant description")
    @JsonProperty("participantDescription")
    private String nombreIntervencion;

    /**
     * Descripción del formato del participante.
     */
    @Schema(description = "Description participant form")
    @JsonProperty("descParticipantForm")
    private String descripcionFormaIntervencion;

    /**
     * Tipo de documento del participante (por ejemplo, "DNI", "pasaporte", etc.).
     */
    @Schema(description = "Participant document type")
    @JsonProperty("idDocumentType")
    private String tipoDocumento;

    /**
     * Número de identificación del documento del participante (por ejemplo, "123456789", etc.).
     */
    @Schema(description = "Contract number identifier, partenon format")
    @JsonProperty("idDocumentNumber")
    private String codDocumento;

    /**
     * Fecha de alta del participante.
     */
    @Schema(description = "Participant activation date")
    @JsonBackReference
    private LocalDate fechaAlta;

    /**
     * Fecha de baja del participante.
     */
    @Schema(description = "Participant due date")
    @JsonProperty("dueDate")
    private LocalDate fechaBaja;

    /**
     * Número de domicilio del participante.
     */
    @JsonIgnore
    private Integer numDomicilio;

	/**
	 * Return intervener state, true or false (active or inactive)
	 *
	 * @return true if the intervener is alive; is alive when fechaBaja is null or
	 *         future date
	 */
	@JsonIgnore
	public boolean isActive() {
		return fechaBaja == null || LocalDate.now().isBefore(fechaBaja);
	}

    /**
     * Return intervener state, true or false (active or inactive)
     *
     * @param now date
     * @return true if the intervener is alive; is alive when fechaBaja is null or
     *         future date
     */
    @JsonIgnore
    public boolean isActive(LocalDate now) {
        return fechaBaja == null || now.isBefore(fechaBaja);
    }

    /**
     * Compare equals
     *
     * @param o object to compare
     * @return true if is equal
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Intervener that = (Intervener) o;
        return Objects.equals(idCliente, that.idCliente);
    }

    /**
     * hashCode
     *
     * @return hash client code
     */
    @Override
    public int hashCode() {
        return Objects.hash(idCliente);
    }

}
