package es.santander.adn360.products.common.domain.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.Field;

import java.io.Serial;
import java.io.Serializable;

/**
 * Risk Situation model
 *
 * nonsense commentary to comply with a nonsense rule nonsense commentary to
 * comply with a nonsense rule nonsense commentary to comply with a nonsense
 * rule nonsense commentary to comply with a nonsense rule nonsense commentary
 * to comply with a nonsense rule
 *
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RiskSituation implements Serializable {

	/**
	 * Generated serial version UID
	 */
	@Serial
	private static final long serialVersionUID = 1L;

	/**
	 * Risk Situation
	 */
	@JsonIgnore
	public static final RiskSituation DEFAULT_RISK_SITUATION = RiskSituation.builder().id(0).situacion("NR").build();

	/**
	 * Situation id
	 */
	@Field("id")
	@JsonProperty("situationId")
	@Schema(description = "Situation id", example = "20")
	private Integer id;

	/**
	 * Situation
	 */
	@JsonProperty("situation")
	@Schema(description = "Situation", example = "DS")
	private String situacion;

}
