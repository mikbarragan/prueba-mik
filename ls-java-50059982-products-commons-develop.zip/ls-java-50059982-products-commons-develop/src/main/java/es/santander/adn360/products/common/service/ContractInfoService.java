package es.santander.adn360.products.common.service;

import es.santander.adn360.products.common.domain.ContractInfo;
import es.santander.adn360.products.common.domain.entity.BaseContract;

import java.util.List;
import java.util.Map;

/**
 * Service for ContractInfo.
 */
public interface ContractInfoService {

    /**
     * Find the Contract Descriptions by contracts list.
     *
     * @param contracts contracts
     * @return  mapper
     */
    Map<String, String> findContractDescriptions(List<? extends BaseContract> contracts);

    /**
     * Find the Contract Info by contracts list.
     *
     * @param contracts contracts
     * @return  mapper
     */
    Map<String, ContractInfo> findContractInfo(List<? extends BaseContract> contracts);
}
