package es.santander.adn360.products.common.web;

import es.santander.adn360.products.common.util.PartialInformationUtil;
import org.springframework.core.MethodParameter;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice;


/**
 * Controller Advice para añadir cabecera en salida
 * @param <T> Respuesta
 */
@ControllerAdvice
public class PartialInformationAdvice <T> implements ResponseBodyAdvice<T> {

    private final PartialInformationUtil partialInformationUtil;

    /**
     * Constructor
     * @param partialInformationUtil partial Information Util
     */
    public PartialInformationAdvice(PartialInformationUtil partialInformationUtil) {
        this.partialInformationUtil = partialInformationUtil;
    }

    /**
     * Queremos que siempre compruebe la utilidad
     *
     * @param methodParameter methodParameter
     * @param aClass aClass
     * @return siempre verdad
     */
    @Override
    public boolean supports(MethodParameter methodParameter, Class<? extends HttpMessageConverter<?>> aClass) {
        return true;
    }

    /**
     * Metodo principal
     *
     * @param t Respuesta
     * @param methodParameter methodParameter
     * @param mediaType mediaType
     * @param aClass aClass
     * @param serverHttpRequest serverHttpRequest
     * @param serverHttpResponse serverHttpResponse
     * @return respuesta
     */
    @Override
    public T beforeBodyWrite(
            T t,
            MethodParameter methodParameter,
            MediaType mediaType,
            Class<? extends HttpMessageConverter<?>> aClass,
            ServerHttpRequest serverHttpRequest,
            ServerHttpResponse serverHttpResponse
    ) {
        partialInformationUtil.setHeader(serverHttpResponse);
        return t;
    }
}
