package es.santander.adn360.products.common.domain;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serial;
import java.io.Serializable;

/**
 * PortfolioType
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PortfolioType implements Serializable {

	/**
	 * Generated serial version UID
	 */
	@Serial
	private static final long serialVersionUID = 1L;

	/**
	 * idPortfolioContract
	 */
	@Schema(description = "Portfolio Contract ID")
	private String idPortfolioContract;

	/**
	 * typePortfolio
	 */
	@Schema(description = "Portfolio type")
	private String typePortfolio;

	/**
	 * Siga
	 */
	@Schema(description = "Siga")
	private String siga;

	/** The portfolio description. */
	@Schema(description = "Portfolio Description")
	private String portfolioDescription;

}
