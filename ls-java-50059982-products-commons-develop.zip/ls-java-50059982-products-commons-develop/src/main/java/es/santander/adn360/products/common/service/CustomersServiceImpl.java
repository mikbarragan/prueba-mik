package es.santander.adn360.products.common.service;

import es.santander.adn360.core.web.WebUtils;
import es.santander.adn360.products.common.config.ServicesProperties;
import es.santander.adn360.products.common.domain.DescriptionFormInterveners;
import es.santander.adn360.products.common.domain.IntervenerInfo;
import es.santander.adn360.products.common.domain.Person;
import es.santander.adn360.products.common.domain.entity.BaseContract;
import es.santander.adn360.products.common.domain.entity.Customer;
import es.santander.adn360.products.common.domain.entity.Intervener;
import es.santander.adn360.products.common.domain.repository.PersonRepository;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import static java.util.function.Predicate.not;
import static java.util.stream.Collectors.toList;

/**
 * Customers service
 *
 * Rest implementation
 *
 * nonsense commentary to comply with a nonsense rule
 * nonsense commentary to comply with a nonsense rule
 * nonsense commentary to comply with a nonsense rule
 * nonsense commentary to comply with a nonsense rule
 * nonsense commentary to comply with a nonsense rule
 * nonsense commentary to comply with a nonsense rule
 * nonsense commentary to comply with a nonsense rule
 * nonsense commentary to comply with a nonsense rule
 *
 */
@Service
@Slf4j
@ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
public class CustomersServiceImpl implements CustomersService {

    private static final String PARAM_ADDRESS_CODE = "address_code";

    private final ServicesProperties servicesProperties;

    private final RestTemplate restTemplate;

    private final PersonRepository personRepository;

    private final IntervenerInfoService tipoNombreService;

    private final DescriptionFormIntervenersService descriptionFormService;

    public CustomersServiceImpl(
            final ServicesProperties servicesProperties,
            final RestTemplate restTemplate,
            final PersonRepository personRepository,
            final IntervenerInfoService tipoNombreService,
            final DescriptionFormIntervenersService descriptionFormService
    ) {
        this.servicesProperties = servicesProperties;
        this.restTemplate = restTemplate;
        this.personRepository = personRepository;
        this.tipoNombreService = tipoNombreService;
        this.descriptionFormService = descriptionFormService;
    }

    /**
     * Get customer info by type and code
     *
     * @param type customer type
     * @param code customer code
     * @return found customer
     */
    @Override
    @Cacheable(cacheNames = {"customers"},
            unless = "#result == null")
    public Customer getCustomerInfo(final String type, final String code) {

        final String httpUrl = this.getHttpUrl(type, code);
        return callCustomerService(httpUrl);
    }

    /**
     * Form destination URL with type and code
     *
     * @param type customer type
     * @param code customer code
     * @return formed URL
     */
    private String getHttpUrl(final String type, final String code) {

        return this.servicesProperties.getCustomersService().getCustomersUri() +
                "/" +
                type +
                this.getValidatedCode(code);
    }

    /**
     * Format customer code. Must be a 9 digit
     * @param code code to be validated
     * @return formatted code
     */
    private String getValidatedCode(final String code) {
        if (code.length() < 9) {
            return StringUtils.leftPad(code, 9, "0");
        } else {
            return code;
        }
    }

    /**
     * Invoke to customer REST service
     *
     * @param serviceUrl destination URL
     * @return result customer
     */
    private Customer callCustomerService(String serviceUrl) {

        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(serviceUrl);

        try {
            ResponseEntity<Customer> customer = restTemplate
                    .exchange(builder.build().encode().toUri(),
                            HttpMethod.GET,
                            null,
                            new ParameterizedTypeReference<Customer>() {
                            });

            return customer.getStatusCode().value() == HttpStatus.OK.value() ? customer.getBody() : null;

        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            return null;
        }
    }

    /**
     * Invoke to customer REST service
     *
     * @param uriBuilder destination URI
     * @return result customer
     */
    private Customer callCustomerService(UriComponentsBuilder uriBuilder) {

        try {
            ResponseEntity<Customer> customer = restTemplate
                    .exchange(uriBuilder.build().encode().toUri(),
                            HttpMethod.GET,
                            null,
                            new ParameterizedTypeReference<Customer>() {
                            });

            return customer.getStatusCode().value() == HttpStatus.OK.value() ? customer.getBody() : null;

        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            return null;
        }
    }

    /**
     * Method to evict cache
     */
    @Override
    @Scheduled(cron = "${services.customersService.cacheCron}")
    @CacheEvict(cacheNames = {"customers"},
            allEntries = true)
    public void cleanCustomerCache() {
        log.info("Cleaning customers cache.");
    }

    /**
     * Get pone customer info
     *
     * @param customerId customerId
     * @return found customer
     */
    @Override
    public Customer getPhoneCustomerInfo(String customerId) {
        String url = String.format(this.servicesProperties.getCustomersPhoneService().getUri(), customerId);

        return callCustomerService(url);
    }

    /**
     * Retrieve from Customer Service the customer address information
     *
     * @param customerId        customerId
     * @param addressCode       address code
     * @return                  Complete address information
     * {@link es.santander.adn360.products.common.domain.entity.CustomerAddress}
     */
    @Override
    public Customer getCustomerAddress(String customerId, Integer addressCode) {
        UriComponentsBuilder builder = UriComponentsBuilder
                .fromHttpUrl(this.servicesProperties.getCustomersService().getCustomersUri())
                .path("/").path(customerId)
                .queryParam(PARAM_ADDRESS_CODE, addressCode);

        return callCustomerService(builder);
    }

    /**
     * Find customer byu type and code
     *
     * @param type Type
     * @param code Code
     * @return found customer
     */
    @Override
    public Person findOneByTypeAndCode(final String type, final String code) {
        Assert.notNull(personRepository, "Mongo dependency is required");

        return this.personRepository.findOneByTypeAndCode(type, code);
    }

    /**
     * Find customer by type, code and company
     *
     * @param type type
     * @param  code Code
     * @param company Company
     *
     * @return found customer
     */
    @Override
    public Person findOneByTypeAndCodeAndCompany(final String type, final String code, final String company) {
        Assert.notNull(personRepository, "Mongo dependency is required");

        return this.personRepository.findOneByTypeAndCodeAndCompany(type, code, company);
    }

    /**
     * Resolve interveners name
     *
     * @param contracts Contract lisl
     */
    @Override
    public void setIntervenersName(final List<? extends BaseContract> contracts) {
        setIntervenersName(contracts, false);
    }

    /**
     * Resolve interveners name
     *
     * @param contracts Contract list
     * @param showContractHolder boolean to display contract holder
     */
    @Override
    public void setIntervenersName(final List<? extends BaseContract> contracts, boolean showContractHolder) {
        Assert.notNull(personRepository, "Mongo dependency is required");
        // TODO: call to customer microservice instead of to personRepository
        // Only for EMP channel
        if (WebUtils.isEmpChannel() || showContractHolder) {
            Assert.notNull(contracts, "Contracts parameter is required.");
            final var now = LocalDate.now();

            final var interveners = contracts.stream()
                    .map(BaseContract::getIntervinientes)
                    .filter(Objects::nonNull)
                    .flatMap(List::stream)
                    .filter(intr -> intr.isActive(now))
                    .collect(toList());

            final var personsMap = this.personRepository.findAsMapByInterveners(interveners);

            // Set Name of intervener to intervener list
            interveners.forEach(intervener -> {
                final var name = Optional.ofNullable(personsMap.get(intervener.getIdCliente()))
                        .map(Person::getName)
                        .orElse(null);

                intervener.setNombreCompleto(name);
            });
        }
    }

    /**
     * Resolve all interveners name
     *
     * @param contracts Contract list
     * @param showContractHolder boolean to display contract holder
     */
    @Override
    public void setAllIntervenersName(List<? extends BaseContract> contracts, boolean showContractHolder) {
        Assert.notNull(personRepository, "Mongo dependency is required");

        // Only for EMP channel
        if (WebUtils.SANTANDER_CHANNEL_EMP.equals(WebUtils.getSantanderChannel()) || showContractHolder) {
            Assert.notNull(contracts, "Contracts parameter is required.");

            final var interveners = contracts.stream()
                    .map(BaseContract::getIntervinientes)
                    .filter(Objects::nonNull)
                    .flatMap(List::stream)
                    .collect(toList());

            final Map<String, Person> persons = this.personRepository.findAsMapByInterveners(interveners);

            interveners.forEach(intr -> {
                final var name = Optional.ofNullable(persons.get(intr.getIdCliente()))
                        .map(Person::getName)
                        .orElse(null);

                intr.setNombreCompleto(name);
            });
        }
    }

    /**
     * Fills NombreCompleto, TipoDocumento and CodDocumento of all interveners
     *
     * @param contracts contract list
     */
    @Override
    public <T extends BaseContract> List<T> fillPersonsInfo(List<T> contracts) {
        Assert.isTrue(!CollectionUtils.isEmpty(contracts), "Contract list should not be empty");

        final var interveners = contracts.stream()
                .map(BaseContract::getIntervinientes)
                .filter(Objects::nonNull)
                .flatMap(List::stream)
                .collect(toList());

        // Get a map from the repo query. The method cares about duplicates.
        final Map<String, Person> personMap = this.personRepository.findAsMapByInterveners(interveners);

        // Sets person info
        interveners.stream()
                .forEach(inter -> {
                    final var person = personMap.get(inter.getIdCliente());

                    if (person != null) {
                        inter.setNombreCompleto(person.getName());
                        inter.setTipoDocumento(person.getIdType());
                        inter.setCodDocumento(person.getIdNumber());
                    }
                });

        return contracts;
    }

    /**
     * Get customer info by customer id
     *
     * @param clientId client identifier
     * @return found Customer
     */
    @Override
    public Customer getCustomerInfo(String clientId) {
        String customerUrl = this.servicesProperties.getCustomersService().getCustomersUri() +
                "/" +
                clientId;

        return callCustomerService(customerUrl);
    }

    /**
     * Resolve interveners descriptions
     *
     * @param contracts List of contracts to be modified
     */
	@Override
	public void setIntervenersDescription(final List<? extends BaseContract> contracts) {
		Assert.notNull(contracts, "Contracts parameter is required.");
        final var now = LocalDate.now();

        contracts.stream()
                .map(BaseContract::getIntervinientes)
                .filter(not(CollectionUtils::isEmpty))
                .flatMap(List::stream)
                .filter(inter -> inter.getFechaBaja() == null || inter.getFechaBaja().compareTo(now) >= 0)
        		.forEach((Intervener inter) -> {
                    final var description = this.descriptionFormService.findByForma(inter.getFormaInterv())
                            .map(DescriptionFormInterveners::getDescripcion)
                            .orElse(null);

                    final var nombre = this.tipoNombreService.findByTipo(inter.getTipoInterv())
                            .map(IntervenerInfo::getNombreIntervencion)
                            .orElse(null);

                    inter.setDescripcionFormaIntervencion(description);
                    inter.setNombreIntervencion(nombre);
                });
	}

}
