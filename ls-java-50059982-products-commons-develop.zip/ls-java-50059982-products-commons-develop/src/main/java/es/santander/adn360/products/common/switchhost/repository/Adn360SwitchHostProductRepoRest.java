package es.santander.adn360.products.common.switchhost.repository;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import es.santander.adn360.core.util.CustomerProductQueryParams;
import es.santander.adn360.mongodb.starter.autoconfigure.MongoQueryRepositoryAutoConfiguration;
import es.santander.adn360.mongodb.starter.domain.QueryParams;
import es.santander.adn360.products.common.config.SwitchHostProperties;
import es.santander.adn360.products.common.domain.bean.AggregationBean;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.List;
import java.util.Map;

/**
 * Repository for query
 */
@Service
@RequiredArgsConstructor()
@ConditionalOnClass(MongoQueryRepositoryAutoConfiguration.class)
public class Adn360SwitchHostProductRepoRest implements Adn360SwitchHostProductRepo {

    private final ObjectMapper mapper;
    private final RestTemplate restTemplate;
    private final SwitchHostProperties switchHostProperties;

    /**
     * Find information by customer id
     *
     * @param params    query params
     * @param customerProductQueryParams    customer params
     * @param responseType  response
     * @param <T>   abstract extra info
     * @return  abstract info
     */
    @Override
    public <T> T findByCustomerId(QueryParams params,
                                  CustomerProductQueryParams customerProductQueryParams,
                                  Class<T> responseType) {
        return findByCustomerId(params, customerProductQueryParams, responseType, null);
    }

    /**
     * Find information by customer id
     * @param params    query params
     * @param customerProductQueryParams    customer params
     * @param responseType  response
     * @param extraParams extra params
     * @param <T>   abstract extra info
     * @return  abstract info
     */
    @Override
    public <T> T findByCustomerId(QueryParams params,
                                  CustomerProductQueryParams customerProductQueryParams,
                                  Class<T> responseType,
                                  Map<String, String> extraParams) {
        Assert.notNull(params, "\"Params\" parameter is required");
        Assert.notNull(params, "\"customerProductQueryParams\" parameter is required");

        HttpHeaders headers = new HttpHeaders();
        headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);

        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(switchHostProperties.getEndpoints()
                .getProductList());
        builder = setOptionalQueryParam(builder, "_offset", params.getOffset());
        builder = setOptionalQueryParam(builder, "_limit", params.getLimit());
        builder = setOptionalQueryParam(builder, "_expand", params.getExpand());
        builder = setOptionalQueryParam(builder, "customer_id", customerProductQueryParams.getCustomer_id());
        builder = setOptionalQueryParam(builder, "excluded_customer_id", customerProductQueryParams
                .getExcluded_customer_id());
        builder = setOptionalQueryParam(builder, "participant_type", customerProductQueryParams
                .getParticipant_type());
        builder = setOptionalQueryParam(builder, "participant_order", customerProductQueryParams
                .getParticipant_order());
        builder = setOptionalQueryParam(builder, "application", customerProductQueryParams.getApplication());
        builder = setOptionalQueryParam(builder, "segment", customerProductQueryParams.getSegment());

        if (!CollectionUtils.isEmpty(extraParams)) {
            for (Map.Entry<String,String> entry : extraParams.entrySet()) {
                builder = setOptionalQueryParam(builder, entry.getKey(), extraParams.get(entry.getKey()));
            }
        }

        HttpEntity<?> entity = new HttpEntity<>(headers);
        ResponseEntity<T> result = this.restTemplate.exchange(builder.build().toUri(),
                HttpMethod.GET, entity, responseType);

        if (result.getHeaders().containsKey("Link")) {
            updateHttpServletResponse(result.getHeaders().get("Link"));
        }

        return result.hasBody() ? result.getBody() : null;
    }

    /**
     * Get aggregations
     *
     * @param params  params
     * @param customerProductQueryParams customerProductQueryParams
     * @param responseType responseType
     * @return  abstract aggregations
     */
    @Override
    public <K> K getAggregations(QueryParams params, CustomerProductQueryParams customerProductQueryParams,
                                 Class<K> responseType) {
        return getAggregations(params, customerProductQueryParams, responseType, null);
    }

    /**
     * Get aggregations
     *
     * @param params  params
     * @param customerProductQueryParams customerProductQueryParams
     * @param responseType responseType
     * @param <K> abstract
     * @param extraParams extra params
     * @return  abstract aggregations
     */
    @Override
    public <K> K getAggregations(QueryParams params, CustomerProductQueryParams customerProductQueryParams,
                                 Class<K> responseType, Map<String, String> extraParams) {
        Assert.notNull(params, "\"Params\" parameter is required");
        Assert.notNull(params, "\"customerProductQueryParams\" parameter is required");

        HttpHeaders headers = new HttpHeaders();
        headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);

        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(switchHostProperties.getEndpoints()
                .getAggregation());
        builder = setOptionalQueryParam(builder, "customer_id", customerProductQueryParams.getCustomer_id());
        builder = setOptionalQueryParam(builder, "excluded_customer_id", customerProductQueryParams
                .getExcluded_customer_id());
        builder = setOptionalQueryParam(builder, "participant_type", customerProductQueryParams
                .getParticipant_type());
        builder = setOptionalQueryParam(builder, "participant_order", customerProductQueryParams
                .getParticipant_order());
        builder = setOptionalQueryParam(builder, "application", customerProductQueryParams.getApplication());
        builder = setOptionalQueryParam(builder, "segment", customerProductQueryParams.getSegment());

        if (!CollectionUtils.isEmpty(extraParams)) {
            for (Map.Entry<String,String> entry : extraParams.entrySet()) {
                builder = setOptionalQueryParam(builder, entry.getKey(), extraParams.get(entry.getKey()));
            }
        }

        HttpEntity<?> entity = new HttpEntity<>(headers);
        ResponseEntity<K> result = this.restTemplate.exchange(builder.build().toUri(), HttpMethod.GET,
                entity, responseType);

        return result.hasBody() ? getListAggregationBean(result.getBody()) : null;
    }

    /**
     * Get list aggretation bean
     * @param body body of aggregation
     * @param <K> Type of class
     * @return class
     */
    private <K> K getListAggregationBean(K body) {
        return (K) mapper.convertValue(body, new TypeReference<List<AggregationBean>>() {});
    }

    /**
     * Get optional query param
     * @param builder Builder
     * @param param Param
     * @param value Value
     * @return URI builder
     */
    private UriComponentsBuilder setOptionalQueryParam(UriComponentsBuilder builder, String param, Object value) {
        return value == null ? builder : builder.queryParam(param, value);
    }

    /**
     * Change HTTP response with link headers
     *
     * @param headerLink link headers
     */
    private void updateHttpServletResponse(List<String> headerLink) {
        if (!CollectionUtils.isEmpty(headerLink)){

            HttpServletResponse response = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getResponse();

            headerLink.forEach((String header) -> response.addHeader("Link", header));
        }
    }
}
