package es.santander.adn360.products.common.util;

import es.santander.adn360.products.common.domain.entity.BaseContract;
import lombok.Builder;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.RequestScope;

import java.util.Collections;
import java.util.List;


/**
 * Partial information util class
 */
@Component
// Creates a bean for every request
@RequestScope
public class PartialInformationUtil {


    /**
     * max length for fallback message
     */
    private static final int MAX_LENGTH = 200;
    private static final String DEFAULT_MESSAGE = "technical limit reached";
    /**
     * Technical limit
     */
    @Value("${partial-information.technical-limit}")
    private Integer technicalLimit;

    /**
     * Partial information indicator
     */
    private boolean partialInformation;


    /**
     * Message information about partial information reason
     */
    private String message;


    /**
     * Constructor
     */
    @Builder
    PartialInformationUtil() {
        this.partialInformation = false;
    }

    /**
     * Cuts the contract list by the configured limit and stores if limit is applied
     *
     * @param contracts     contract list
     * @return  contract list
     */
    public <T extends BaseContract> List<T> applyLimit(List<T> contracts){
        if (technicalLimit <= contracts.size()) {
            this.partialInformation = true;
            this.message = DEFAULT_MESSAGE;
            return contracts.subList(0, technicalLimit-1);
        }
        return contracts;
    }

    public void setPartialInformationDuetoFallback(String msg) {
        this.partialInformation = true;
        if (StringUtils.isEmpty(getMessage())) {
            this.message = msg.substring(0,msg.length() > MAX_LENGTH ? MAX_LENGTH: msg.length());
        }
        else {
            this.message = String.join(";", getMessage(), msg.substring(0,msg.length() > MAX_LENGTH ? MAX_LENGTH: msg.length()));
        }
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Boolean isPartialInformation() {
        return this.partialInformation;
    }

    public int getTechnicalLimit() {
        return this.technicalLimit;
    }

    public void setHeader(ServerHttpResponse response) {
        if (isPartialInformation()) {
            response.getHeaders().put("Partial-Information", Collections.singletonList("reason=" + getMessage()));
        }
    }

}
