package es.santander.adn360.products.common.domain;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Managed profile contracts
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ManagedProfileContracts {
	/**
	 * contracts
	 */
	@Schema(description = "Contract list")
	private List<String> contracts;
	/**
	 * customerId
	 */
	@Schema(description = "Customer ID")
	private String customerId;
	/**
	 * segment
	 */
	@Schema(description = "Segment")
	private String segment;
	/**
	 * application
	 */
	@Schema(description = "Application")
	private String application;
	/**
	 * channel
	 */
	@Schema(description = "Channel")
	private String channel;
}
