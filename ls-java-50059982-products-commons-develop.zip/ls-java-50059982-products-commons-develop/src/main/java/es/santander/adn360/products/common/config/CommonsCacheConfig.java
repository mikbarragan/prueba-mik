package es.santander.adn360.products.common.config;

import com.github.benmanes.caffeine.cache.Caffeine;
import com.github.benmanes.caffeine.cache.CaffeineSpec;
import org.springframework.boot.autoconfigure.cache.CacheManagerCustomizer;
import org.springframework.cache.caffeine.CaffeineCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Cache config for cache manager.
 * Need to use cache manager instead of default
 * cacheManager
 */
@Configuration
public class CommonsCacheConfig {

    @Bean
    CacheManagerCustomizer<CaffeineCacheManager> commonsCacheManager(ServicesProperties servicesProperties) {
        return cacheManager -> {
            cacheManager.registerCustomCache("getProductGroup_queryPGroupIdChannel_cache",
                    Caffeine.from(CaffeineSpec.parse(servicesProperties.getProductGroupsService().getCacheSpec())).build());
            cacheManager.registerCustomCache("getProductGroups_queryParamsChannel_cache",
                    Caffeine.from(CaffeineSpec.parse(servicesProperties.getProductGroupsService().getCacheSpec())).build());
            cacheManager.registerCustomCache("getProducts_qpPgiChn_cache",
                    Caffeine.from(CaffeineSpec.parse(servicesProperties.getProductGroupsService().getCacheSpec())).build());
            cacheManager.registerCustomCache("currencies",
                    Caffeine.from(CaffeineSpec.parse(servicesProperties.getProductGroupsService().getCacheSpec())).build());
            cacheManager.registerCustomCache("customers",
                    Caffeine.from(CaffeineSpec.parse(servicesProperties.getProductGroupsService().getCacheSpec())).build());
            cacheManager.registerCustomCache("portfolios",
                    Caffeine.from(CaffeineSpec.parse(servicesProperties.getProductGroupsService().getCacheSpec())).build());
            cacheManager.registerCustomCache("product_configurations_catalog",
                    Caffeine.from(CaffeineSpec.parse(servicesProperties.getProductGroupsService().getCacheSpec())).build());
            cacheManager.registerCustomCache("related_product_configurations",
                    Caffeine.from(CaffeineSpec.parse(servicesProperties.getProductGroupsService().getCacheSpec())).build());
            cacheManager.registerCustomCache("descriptionFormInterveners",
                    Caffeine.from(CaffeineSpec.parse("maximumSize=100,expireAfterWrite=24h")).build());
            cacheManager.registerCustomCache("descriptionFormIntervenersMap",
                    Caffeine.from(CaffeineSpec.parse("maximumSize=1")).build());
            cacheManager.registerCustomCache("getProduct_typeSubtype_cache",
                    Caffeine.from(CaffeineSpec.parse(servicesProperties.getProductGroupsService().getCacheSpec())).build());
            cacheManager.registerCustomCache("tipoNombreIntervenersMap",
                    Caffeine.from(CaffeineSpec.parse("maximumSize=1")).build());
        };
    }

}