package es.santander.adn360.products.common.service;

import es.santander.adn360.core.model.portfolio.PortfolioFilterType;
import es.santander.adn360.core.model.portfolio.PortfolioQueryParams;
import es.santander.adn360.core.util.CustomerProductQueryParams;
import es.santander.adn360.products.common.config.ServicesProperties;
import es.santander.adn360.products.common.domain.FullPortfolio;
import es.santander.adn360.products.common.domain.PortfolioBaseContract;
import es.santander.adn360.products.common.domain.PortfolioContract;
import es.santander.adn360.products.common.domain.PortfolioType;
import es.santander.adn360.products.common.repository.PortfoliosRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;

import static java.util.stream.Collectors.toList;
import static java.util.stream.Collectors.toMap;

/**
 * PortfolioServiceImpl
 * <p>
 * nonsense commentary to comply with a nonsense rule
 * nonsense commentary to comply with a nonsense rule
 * nonsense commentary to comply with a nonsense rule
 * nonsense commentary to comply with a nonsense rule
 * nonsense commentary to comply with a nonsense rule
 * nonsense commentary to comply with a nonsense rule
 * nonsense commentary to comply with a nonsense rule
 */
@Slf4j
@Service
public class PortfolioServiceImpl implements PortfolioService {

    /**
     * Constant representing the key for the "no asesorada" filter.
     */
    private static final String C_NO_ASESORADA_KEY = "NA";

    /**
     * Constant representing the key for the "baja" filter.
     */
    public static final String BAJA_KEY = "BJ";

    /**
     * Constant representing the "all" filter.
     */
    public static final String ALL_FILTER = "ALL";

    /**
     * Constant representing the "managed" filter.
     */
    public static final String MANAGED_FILTER = "MANAGED";

    /**
     * Constant representing the "unmanaged" filter.
     */
    public static final String UNMANAGED_FILTER = "UNMANAGED";

    /**
     * Constant representing the "any portfolio" filter.
     */
    public static final String ANYPORTFOLIO_FILTER = "ANYPORTFOLIO";

    /**
     * Constant representing the "none" filter.
     */
    public static final String NONE_FILTER = "NONE";

    /**
     * Constant representing the "default" filter.
     */
    public static final String DEFAULT_FILTER = "DEFAULT";

    /**
     * Set of all possible portfolio filters.
     */
    private static final Set<String> PF_FILTERS = Set.of(
            ALL_FILTER, MANAGED_FILTER, UNMANAGED_FILTER, ANYPORTFOLIO_FILTER, NONE_FILTER, DEFAULT_FILTER
    );

    /** ServicesProperties */
    private final ServicesProperties servicesProperties;

    /** PortfoliosRepository */
    private final PortfoliosRepository portfoliosRepository;

    /**
     * Constructor
     *
     * @param servicesProperties ServicesProperties
     * @param portfoliosRepository PortfoliosRepository
     */
    public PortfolioServiceImpl(
            final ServicesProperties servicesProperties,
            final PortfoliosRepository portfoliosRepository
    ) {
        this.servicesProperties = servicesProperties;
        this.portfoliosRepository = portfoliosRepository;
    }

    /**
     * getContractsFilteredByContratosCarterasType
     *
     * @param contracts Contracts List of contracts
     * @param params    Customer query string
     * @return portfolio base contract list
     */
    @Override
    public <T extends PortfolioBaseContract> List<T> getContractsFilteredByContratosCarterasType(
            final List<T> contracts,
            final CustomerProductQueryParams params
    ) {
        Assert.notNull(contracts, "Contracts should not be null");
        Assert.notNull(params, "\"customerProductQueryParams\" parameter is required");

        final var portfolioMap = findPortfolioTypesAsMap(contracts, params, false);

        return contracts.stream()
                .filter(contract -> filterByPortfoliosType(contract.getContratosCarteras(), portfolioMap))
                .map((T contract) -> {
                    findActiveNaSiga(contract, portfolioMap, null).ifPresent(contract::setSiga);
                    return contract;
                })
                .collect(toList());
    }

    /**
     * getContractsFilteredByContratosCarterasType
     *
     * @param contracts                  Contracts List of contracts
     * @param customerProductQueryParams Customer query string
     * @param portfolioTypeFilter    	 portFolioTypeFilter
     * @return portfolio base contract list
     *
     * @deprecated  a better way to include and/or exclude certain portfolio types has been implemented <br/>
     *              use {@link #getContractsFilteredByPortfolioTypes} instead
     *
     */
    @Deprecated
    @Override
    public <T extends PortfolioBaseContract> List<T> getContractsFilteredByContratosCarterasType(
            final List<T> contracts,
            final CustomerProductQueryParams customerProductQueryParams,
            final String portfolioTypeFilter
    ) {
        Assert.notNull(contracts, "Contracts should not be null");
        Assert.notNull(customerProductQueryParams, "\"customerProductQueryParams\" parameter is required");
        Assert.isTrue(PF_FILTERS.contains(portfolioTypeFilter), "Not supported filter: " + portfolioTypeFilter);

        final var typeMap = findPortfolioTypesAsMap(contracts, customerProductQueryParams, false);

        return contracts.stream()
                .filter(contract -> filterByType(contract, typeMap, portfolioTypeFilter))
                .map((T contract) -> {

                    findActiveNaSiga(contract, typeMap, portfolioTypeFilter).ifPresent(contract::setSiga);

                    final var cc = findActivesWithSigaAndType(contract, typeMap).orElse(null);
                    contract.setContratosCarteras(cc);

                    return contract;

                }).collect(toList());
    }

    /**
     * Returns the initial list of contracts filtered by portfolio types.
     * It also sets the list of portfolios of each contract.
     *
     * @param contracts                  Contracts List of contracts
     * @param customerProductQueryParams customer product query params
     * @param portfolioQueryParams    	 portfolio query params
     * @return portfolio base contract list
     *
     */
    @Override
    public <T extends PortfolioBaseContract> List<T> getContractsFilteredByPortfolioTypes(
            final List<T> contracts,
            final CustomerProductQueryParams customerProductQueryParams,
            final PortfolioQueryParams portfolioQueryParams
    ) {
        Assert.notNull(contracts, "Contracts should not be null");
        Assert.notNull(customerProductQueryParams, "\"customerProductQueryParams\" parameter is required");
        Assert.notNull(portfolioQueryParams, "\"portfolioQueryParams\" parameter is required");

        final var typeMap = findPortfolioTypesAsMap(contracts, customerProductQueryParams, true);

        return contracts.stream()
                .filter(contract -> filterByType(contract, typeMap, portfolioQueryParams))
                .map((T contract) -> {

                    // Para replicar el comportamiento del método getContractsFilteredByContratosCarterasType
                    // de 3 parámetros, como el tercero nunca venía como null pues tenía un valor por defecto,
                    // se asigna un valor no nulo.
                    findActiveNaSiga(contract, typeMap, "notNullValue").ifPresent(contract::setSiga);

                    final var cc = findActivesWithSigaAndType(contract, typeMap).orElse(null);
                    contract.setContratosCarteras(cc);

                    return contract;

                }).collect(toList());
    }

    /**
     * findPortfolioTypesAsMap
     *
     * @param contracts to find
     * @param params to filter
     * @param keepEmptyPortfolioTypes  indicates if portfolios without a type should be kept
     * @param <T> contract
     * @return types map
     */
    @Override
    public <T extends PortfolioBaseContract> Map<String, PortfolioType> findPortfolioTypesAsMap(
            final List<T> contracts,
            final CustomerProductQueryParams params,
            final boolean keepEmptyPortfolioTypes
    ) {
        final var portfoliosContracts = contracts.stream()
                .filter(c -> ! CollectionUtils.isEmpty(c.getContratosCarteras()))
                .flatMap(c -> c.getContratosCarteras().stream())
                .filter(PortfolioContract::isActive)
                .map(PortfolioContract::getContratoCartera)
                .filter(StringUtils::hasText)
                .distinct()
                .collect(toList());

        if (portfoliosContracts.isEmpty()) {
            return Collections.emptyMap();
        }

        return getPortfolioType(portfoliosContracts, params, keepEmptyPortfolioTypes).stream()
                .collect(toMap(
                        PortfolioType::getIdPortfolioContract,
                        Function.identity(),
                        (oldVal, newVal) -> newVal
                ));
    }

    /**
     * filterByType
     *
     * @param contract to filter
     * @param portfolioMap type map
     * @param portfolioTypeFilter filter
     * @param <T> contract
     *
     * @return filtered
     */
    private <T extends PortfolioBaseContract> boolean filterByType(
            final T contract,
            final Map<String, PortfolioType> portfolioMap,
            final String portfolioTypeFilter
    ) {
        return switch (portfolioTypeFilter) {
            case ALL_FILTER -> true;
            case MANAGED_FILTER -> filterByType(contract, portfolioMap,
                    PortfolioQueryParams.builder()
                            .related_to_portfolio_types(Set.of(PortfolioFilterType.ALL_MANAGED)).build());
            case DEFAULT_FILTER -> filterByType(contract, portfolioMap,
                    PortfolioQueryParams.builder()
                            .related_to_portfolio_types(
                                    Set.of(PortfolioFilterType.NO_PORTFOLIO, PortfolioFilterType.NOT_MANAGED)).build());
            case UNMANAGED_FILTER -> filterByType(contract, portfolioMap,
                    PortfolioQueryParams.builder()
                            .related_to_portfolio_types(Set.of(PortfolioFilterType.NOT_MANAGED)).build());
            case NONE_FILTER -> filterByType(contract, portfolioMap,
                    PortfolioQueryParams.builder()
                            .related_to_portfolio_types(Set.of(
                                    PortfolioFilterType.NO_PORTFOLIO)).build());
            case ANYPORTFOLIO_FILTER -> filterByType(contract, portfolioMap,
                    PortfolioQueryParams.builder()
                            .related_to_portfolio_types(Set.of(
                                    PortfolioFilterType.ALL_MANAGED,
                                    PortfolioFilterType.NOT_MANAGED)).build());
            default -> throw new IllegalStateException("Not supported");
        };
    }

    /**
     * Returns a boolean that indicates if a given contract should pass the portfolio type filter
     *
     * @param contract to check
     * @param portfolioMap portfolio contract number-portfolioType map
     * @param portfolioQueryParams portfolio query params
     * @param <T> contract
     *
     * @return indicates if contract passes the filter
     */
    public <T extends PortfolioBaseContract> boolean filterByType(
            final T contract,
            final Map<String, es.santander.adn360.products.common.domain.PortfolioType> portfolioMap,
            final PortfolioQueryParams portfolioQueryParams
    ) {

        // Con este nuevo filtro no hay una forma directa de saber si se quieren incluir todos los contratos como con
        // el antiguo (con el valor ALL). Para replicar el mismo comportamiento, si se detecta que los parámetros de
        // carteras se corresponden con el ALL, se continúa devolviendo siempre true.
        if (isAllFilter(portfolioQueryParams)) {
            return true;
        }

        var hasPortfolios = contract.hasContratosCarteras(portfolioMap);
        var activePortfolioTypes = contract.getActivePortfolioTypes(portfolioMap);

        return portfolioTypesAreValid(hasPortfolios, activePortfolioTypes,
                Optional.ofNullable(portfolioQueryParams.getRelated_to_portfolio_types())
                        .orElse(Collections.emptySet()),
                Optional.ofNullable(portfolioQueryParams.getUnrelated_to_portfolio_types())
                        .orElse(Collections.emptySet()));
    }

    /**
     * This method checks if the provided PortfolioQueryParams object represents an "all filter" condition.
     * An "all filter" condition is defined as one where all portfolio types (NO_PORTFOLIO, MANAGED, NOT_ADMINISTERED,
     * ADVISED) are included and no portfolio types are excluded.
     *
     * @param portfolioQueryParams The PortfolioQueryParams object to check.
     * @return Returns true if the provided PortfolioQueryParams object represents an "all filter" condition,
     * false otherwise.
     */
    private boolean isAllFilter(PortfolioQueryParams portfolioQueryParams) {
        return Optional.ofNullable(portfolioQueryParams.getRelated_to_portfolio_types()).orElse(Collections.emptySet())
                .containsAll(Set.of(PortfolioFilterType.NO_PORTFOLIO, PortfolioFilterType.MANAGED,
                        PortfolioFilterType.NOT_ADMINISTERED, PortfolioFilterType.ADVISED, PortfolioFilterType.REST))
                && CollectionUtils.isEmpty(portfolioQueryParams.getUnrelated_to_portfolio_types());
    }

    /**
     * Checks if the portfolio types are valid based on the inclusion and exclusion sets.
     *
     * @param hasPortfolios Boolean indicating if the contract has portfolios.
     * @param portfolioTypes List of portfolio types associated with the contract.
     * @param typesToInclude Set of portfolio types that should be included.
     * @param typesToExclude Set of portfolio types that should be excluded.
     * @return Returns true if the portfolio types are valid, false otherwise.
     */
    private boolean portfolioTypesAreValid(boolean hasPortfolios, List<String> portfolioTypes,
                                          Set<PortfolioFilterType> typesToInclude,
                                          Set<PortfolioFilterType> typesToExclude) {
        return portfolioTypesAreIncluded(hasPortfolios, portfolioTypes, typesToInclude)
                && !portfolioTypesAreExcluded(hasPortfolios, portfolioTypes, typesToExclude);
    }

    /**
     * Checks if the portfolio types are included in the typesToInclude set.
     *
     * @param hasPortfolios Boolean indicating if the contract has portfolios.
     * @param portfolioTypes List of portfolio types associated with the contract.
     * @param typesToInclude Set of portfolio types that should be included.
     * @return Returns true if the portfolio types are included, false otherwise.
     */
    private boolean portfolioTypesAreIncluded(boolean hasPortfolios, List<String> portfolioTypes,
                                              Set<PortfolioFilterType> typesToInclude) {
        return CollectionUtils.isEmpty(typesToInclude) || typesToInclude.stream()
                .anyMatch(typeToCheck -> portfolioTypeMatches(hasPortfolios, portfolioTypes, typeToCheck));
    }

    /**
     * Checks if the portfolio types are excluded in the typesToExclude set.
     *
     * @param hasPortfolios Boolean indicating if the contract has portfolios.
     * @param portfolioTypes List of portfolio types associated with the contract.
     * @param typesToExclude Set of portfolio types that should be excluded.
     * @return Returns true if the portfolio types are excluded, false otherwise.
     */
    private boolean portfolioTypesAreExcluded(boolean hasPortfolios, List<String> portfolioTypes,
                                              Set<PortfolioFilterType> typesToExclude) {
        return typesToExclude.stream()
                .anyMatch(typeToCheck -> portfolioTypeMatches(hasPortfolios, portfolioTypes, typeToCheck));
    }

    /**
     * Checks if the portfolio type matches the typeToCheck based on the portfolio type values from the configuration.
     *
     * @param hasPortfolios Boolean indicating if the contract has portfolios.
     * @param portfolioTypes List of portfolio types associated with the contract.
     * @param typeToCheck The portfolio filter type to check.
     * @return Returns true if the portfolio type matches the typeToCheck, false otherwise.
     */
    private boolean portfolioTypeMatches(boolean hasPortfolios, List<String> portfolioTypes,
                                         PortfolioFilterType typeToCheck) {
        var typeToCheckStr = typeToCheck.getValue();
        var configKey = typeToCheckStr.replace("ALL_", "");
        var valuesToCheck = servicesProperties.getManagedPortfolioService().getPortfolioFilterTypeValues()
                .get(configKey);
        if (PortfolioFilterType.NO_PORTFOLIO != typeToCheck) {
            Assert.notNull(valuesToCheck, String.format("No portfolioTypes config found for key %s", configKey));
        }

        return switch (typeToCheck) {
            case MANAGED, NOT_ADMINISTERED, ADVISED -> portfolioTypes.stream().anyMatch(valuesToCheck::contains);
            case ALL_MANAGED, ALL_NOT_ADMINISTERED, ALL_ADVISED, NOT_MANAGED ->
                    !CollectionUtils.isEmpty(portfolioTypes) &&
                            portfolioTypes.stream().allMatch(valuesToCheck::contains);
            case REST -> portfolioTypes.stream().anyMatch(type -> !valuesToCheck.contains(type));
            case ALL_REST -> !CollectionUtils.isEmpty(portfolioTypes) &&
                    portfolioTypes.stream().allMatch(type -> !valuesToCheck.contains(type));
            case NO_PORTFOLIO -> !hasPortfolios;
            default -> false;
        };
    }

    /**
     * Check if the contract must be filtered checking porfolio type
     *
     * @param contratosCarteras portfolio contracts
     * @param portfolioMap      portfolio map
     * @return true if must be filtered
     */
    private boolean filterByPortfoliosType(
            final List<PortfolioContract> contratosCarteras,
            final Map<String, PortfolioType> portfolioMap
    ) {
        if (CollectionUtils.isEmpty(contratosCarteras)) {
            return true;
        }

        final var portfoliosNotAllowed = servicesProperties.getManagedPortfolioService().getTiposCartera();

        return contratosCarteras.stream()
                .filter(c -> c.isActive(portfolioMap))
                .map(PortfolioContract::getContratoCartera)
                .filter(portfolioMap::containsKey)
                .map(portfolioMap::get)
                .map(PortfolioType::getTypePortfolio)
                .noneMatch(portfoliosNotAllowed::contains);
    }

    /**
     * findActivesWithSigaAndType
     *
     * @param contract to get
     * @param portfolioMap type map
     * @param <T> contract
     * @return portfolios
     */
    private <T extends PortfolioBaseContract> Optional<List<PortfolioContract>> findActivesWithSigaAndType(
            final T contract,
            final Map<String, PortfolioType> portfolioMap
    ) {
        if (contract.nonContratosCarteras(portfolioMap)) {
            return Optional.empty();
        }

        final var response = contract.getActiveContratosCarteras(portfolioMap)
                .map(portfolio -> new FullPortfolio(portfolio, portfolioMap))
                .filter(FullPortfolio::isTypeActive)
                .map(FullPortfolio::getSetContract)
                .collect(toList());

        return Optional.of(response)
                .filter(resp -> ! CollectionUtils.isEmpty(resp));
    }

    /**
     * Set SIGA number to contract.
     * @param contract          Contract
     * @param portfolioMap      map that content as a key id contract portfolio and as a value info about portfolio
     * @param portFolioTypeFilter   parameter to decide if filter or not by portfolio type
     */
    private Optional<String> findActiveNaSiga(
            final PortfolioBaseContract contract,
            final Map<String, PortfolioType> portfolioMap,
            final String portFolioTypeFilter
    ) {
        if (contract.nonContratosCarteras(portfolioMap)) {
            return Optional.empty();
        }

        final var siga = contract.getContratosCarteras().stream()
                .filter(c -> c.isActive(portfolioMap))
                .map(PortfolioContract::getContratoCartera)
                .map(portfolioMap::get)
                .filter(Objects::nonNull)
                .filter(pt -> Objects.nonNull(portFolioTypeFilter) || C_NO_ASESORADA_KEY.equals(pt.getTypePortfolio()))
                .map(PortfolioType::getSiga)
                .filter(StringUtils::hasText)
                .findAny()
                .orElse("");

        return Optional.of(siga);
    }

    /**
     * Portfolio base contract list
     *
     * @param contracts                  Contracts List of contracts
     * @param customerProductQueryParams Customer query string
     * @return portfolio list
     */
    @Override
    public <T extends PortfolioBaseContract> List<T> getContractsFilteredByCarteraType(
            final List<T> contracts,
            final CustomerProductQueryParams customerProductQueryParams
    ) {
        Assert.notNull(contracts, "Contracts should not be null");
        Assert.notNull(customerProductQueryParams, "\"customerProductQueryParams\" parameter is required");

        List<String> portfolios = contracts.stream()
                .map(PortfolioBaseContract::getContratoCartera)
                .filter(Objects::nonNull)
                .collect(toList());

        if (portfolios.isEmpty()) {
            return contracts;
        }

        List<PortfolioType> portfoliosData = getPortfolioType(portfolios, customerProductQueryParams, false);

        return getAllowedContracts(contracts, portfoliosData);
    }

    /**
     * Get portfolio type
     *
     * @param contracts                  list of contracts
     * @param params params
     * @param keepEmptyPortfolioTypes  indicates if portfolios without a type should be kept
     * @return list of portfolios
     */
    private List<PortfolioType> getPortfolioType(
            final List<String> contracts,
            final CustomerProductQueryParams params,
            final boolean keepEmptyPortfolioTypes
    ) {
        // To improve the cache of the callToPortfolios
        Collections.sort(contracts);

        return this.portfoliosRepository.callToPortfolios(contracts, params).stream()
                .filter(portfolio -> this.isActiveValidType(portfolio, keepEmptyPortfolioTypes))
                .collect(toList());
    }

    /**
     * Validate portfolio checking if is not null or void
     *
     * @param portfolio portfolio to be checked
     * @param keepEmptyPortfolioTypes  indicates if portfolios without a type should be kept
     * @return true if is valid
     */
    private boolean isActiveValidType(final PortfolioType portfolio, final boolean keepEmptyPortfolioTypes) {

        return portfolio != null
                && StringUtils.hasText(portfolio.getIdPortfolioContract())
                && (keepEmptyPortfolioTypes || StringUtils.hasText(portfolio.getTypePortfolio()))
                && ! "BJ".equalsIgnoreCase(portfolio.getTypePortfolio());
    }

    /**
     * Get allowed contracts
     *
     * @param contracts      contracts to be checked
     * @param portfoliosData portfolio data
     * @return list of allowed contracts
     */
    private <T extends PortfolioBaseContract> List<T> getAllowedContracts(
            final List<T> contracts,
            final List<PortfolioType> portfoliosData
    ) {

        return contracts.stream()
                .filter(contract -> contract.getContratoCartera() == null
                        || filterByPortfolioType(contract.getContratoCartera(), portfoliosData))
                .map((T contract) -> {
                    if (contract.getContratoCartera() != null) {
                        contract.setSiga(findSiga(contract.getContratoCartera(), portfoliosData));
                    }
                    return contract;
                })
                .collect(toList());
    }

    /**
     * Filter by portfolio type
     *
     * @param portfolioContractId portfolio contract
     * @param portfolios          list of porffolios
     * @return true if must by filtered
     */
    private boolean filterByPortfolioType(
            final String portfolioContractId,
            final List<PortfolioType> portfolios
    ) {
        List<String> portfoliosNotAllowed = servicesProperties.getManagedPortfolioService().getTiposCartera();

        String type = portfolios.stream()
                .filter(p -> portfolioContractId.equals(p.getIdPortfolioContract()))
                .findFirst()
                .map(PortfolioType::getTypePortfolio)
                .orElse("");

        return ! portfoliosNotAllowed.contains(type);
    }

    /**
     * Find SIGA number in list of portfolios
     *
     * @param portfolioContractId portfolio contract
     * @param portfolios          list of portfolios where find
     * @return found SIGA number or ""
     */
    private String findSiga(
            final String portfolioContractId,
            final List<PortfolioType> portfolios
    ) {
        return portfolios.stream()
                .filter(p -> portfolioContractId.equals(p.getIdPortfolioContract()))
                .findFirst()
                .map(PortfolioType::getSiga)
                .orElse("");
    }

}
