package es.santander.adn360.products.common.domain.bean;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serial;
import java.io.Serializable;
import java.math.BigDecimal;

/**
 * BalanceBean
 *
 * nonsense commentary to comply with a nonsense rule nonsense commentary to
 * comply with a nonsense rule nonsense commentary to comply with a nonsense
 * rule nonsense commentary to comply with a nonsense rule
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class BalanceBean implements Serializable {

	/**
	 * Generated serial version UID
	 */
	@Serial
	private static final long serialVersionUID = 1L;

	/**
	 * Balance amount
	 */
	@Schema(description = "Balance amount.", example = "20")
	private BigDecimal amount;

	/**
	 * Balance currency
	 */
	@Schema(description = "Balance currency.", example = "EUR")
	private String currency;

}
