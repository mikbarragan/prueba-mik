package es.santander.adn360.products.common.service;

import es.santander.adn360.products.common.domain.IntervenerInfo;

import java.util.Optional;

/**
 * Intervener Info Service
 */
public interface IntervenerInfoService {

    /**
     * Find nombre by tipo
     *
     * @param tipo to find
     * @return nombre optional
     */
    Optional<IntervenerInfo> findByTipo(String tipo);

    /**
     * findNombreByTipo
     *
     * @param tipo to find
     * @return nombre opt
     */
    Optional<String> findNombreByTipo(String tipo);

    /**
     * cleanCache
     */
    void cleanCache();
}
