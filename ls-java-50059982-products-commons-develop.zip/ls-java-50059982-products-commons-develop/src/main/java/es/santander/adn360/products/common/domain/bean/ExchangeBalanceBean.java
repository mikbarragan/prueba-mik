package es.santander.adn360.products.common.domain.bean;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;

/**
 * ExchangeBalanceBean
 */
@Data
@Builder
public class ExchangeBalanceBean {

	/**
	 * Exchange balance amount
	 */
	@Schema(description = "Exchange balance amount", example = "7796190.0" )
	private BigDecimal amount;

	/**
	 * Exchange
	 */
	@Schema(description = "Exchange")
	private BalanceBean exchange;

}
