package es.santander.adn360.products.common.service;

import es.santander.adn360.core.util.CustomerProductQueryParams;
import es.santander.adn360.core.util.ProductQueryParams;
import es.santander.adn360.products.common.domain.DescriptionFormInterveners;
import es.santander.adn360.products.common.domain.IntervenerInfo;
import es.santander.adn360.products.common.domain.entity.BaseContract;
import es.santander.adn360.products.common.domain.entity.Intervener;

import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * IntervenerService
 */
public interface IntervenerService {
	
    /**
     * Get intervener info associated participant type. Each contract has one to many
     * participants with differents descriptions each one. 
     *  
     * @param participantType participant type (01, 04, 0A,...)
     * @return IntervenerInfo or null if not exists
     */
    IntervenerInfo getIntervenerInformation(String participantType);

    /**
     * Find intervener info associated participant type. Each contract has one to many
     * participants with differents descriptions each one.
     *
     * @param participantType participant type (01, 04, 0A,...)
     * @return IntervenerInfo optional
     */
    default Optional<IntervenerInfo> findInfo(String participantType) {
        return Optional.empty();
    }

    /**
     * Find intervener name associated participant type. Each contract has one to many
     * participants with differents descriptions each one.
     *
     * @param participantType participant type (01, 04, 0A,...)
     * @return Intervener name optional
     */
    default Optional<String> findName(String participantType) {
        return Optional.empty();
    }

    /**
     * Get intervener info associated participant form. Each contract has one to many
     * participants with differents descriptions each one.
     *
     * @param participantForm participant form (01, 04, 0A,...)
     * @return Description form or null if not exists
     */
    DescriptionFormInterveners getDescriptionForm(String participantForm);

    /**
     * Find description-form by associated participant form. Each contract has one to many
     * participants with differents descriptions each one.
     *
     * @param participantForm participant form (01, 04, 0A,...)
     * @return DescriptionFormInterveners optional
     */
    default Optional<DescriptionFormInterveners> findDescriptionForm(String participantForm) {
        return Optional.empty();
    }

    /**
     * Find description by associated participant form. Each contract has one to many
     * participants with differents descriptions each one.
     *
     * @param participantForm participant form (01, 04, 0A,...)
     * @return Description optional
     */
    default Optional<String> findDescription(String participantForm) {
        return Optional.empty();
    }

    /**
     * Get list interveners info within contracts list. Each contract has one to many
     * participants with differents descriptions each one. 
     *  
     * @param contracts Contracts list
     * @return List IntervenerInfo
     */
    List<IntervenerInfo> findIntervenerInfoByContracts(List<? extends BaseContract> contracts);

    /**
     * Get list DescriptionFormInterveners info within contracts list. Each contract has one to many
     * participants with differents descriptions each one.
     *
     * @param contracts Contracts list
     * @return List DescriptionFormInterveners
     */
    List<DescriptionFormInterveners> findDescriptionFormByContracts(List<? extends BaseContract> contracts);

    /**
     * Get list interveners info with in interveners list.
     *  
     * @param interveners Intervener list
     * @return List IntervenerInfo
     */
    List<IntervenerInfo> findIntervenerInfoByInterveners(List<Intervener> interveners);

    /**
     * Get list Description Form Interveners with in interveners list.
     *
     * @param interveners Intervener list
     * @return List DescriptionFormInterveners
     */
    List<DescriptionFormInterveners> findDescriptionFormByInterveners(List<Intervener> interveners);

    /**
     * Method needed to clean currencies cache.
     */
    void cleanCache();

    /**
     * Filling intervener information (participant and descripcionFormaIntervencion fields),
     * and filter interveners return only actives or every (depend on allInteveners value)
     *
     * @param interveners list
     * @param  allInterveners Indicator to obtain all the participants(true) or only the active participants(false)
     * @param filter references to participant type value (OWN,ALL) {@link CustomerProductQueryParams}
     * @param application references to application name param value (ADN360, PSD2, NWE,..) {@link ProductQueryParams}
     * @return intervener list
     */
    List<Intervener> fillAndFilterIntervenerParticipantField(List<Intervener> interveners,
                                                             boolean allInterveners,
                                                             String filter,
                                                             String application);

    /**
     * Set partipant field of Intervener entity. Ej: 1 Titular, 2 Avalista, 1 Apoderado...
     * The ordinal number is calculated according intervener position take into interveners list ordered by ordenInterv field.
     *
     * @param interveners list
     * @param  allInterveners . Indicator to obtain all the participants or only the active participants
     * @return return new modified Intervener list with participant field filled: [number] + [Name]
     * with values appropriated by filters equals "all" and application equals "default"
     */
    List<Intervener> fillAndFilterIntervenerParticipantField(List<Intervener> interveners,
                                                             boolean allInterveners);

    /**
     * Filling intervener information (participant and descripcionFormaIntervencion fields),
     * and filter interveners return only actives or every (depend on allInteveners value)
     * @deprecated
     * This method is no longer acceptable to retrieve information about intervener.
     * <p> Use {@link IntervenerService#fillAndFilterIntervenerParticipantField} instead.
     *
     * @param interveners list
     * @param  allInterveners . Indicator to obtain all the participants or only the active participants
     * @param filter references to participant type value (OWN,ALL) {@link CustomerProductQueryParams}
     * @param application references to application name param value (ADN360, PSD2, NWE,..) {@link ProductQueryParams}
     * @return intervener list
     */
    @Deprecated(since = "4.1.18")
    public List<Intervener> fillAndFilterIntervenerParticipantAndFormFields(List<Intervener> interveners,
                                                                            boolean allInterveners,
                                                                            String filter,
                                                                            String application);

    /**
     * Set partipant field of Intervener entity. Ej: 1 Titular, 2 Titular, 3 Titular...
     * Only active interveners are considered. 
     * The ordinal number is calculated according ordenInterv field of intervener.
     * @deprecated
     *
     * @param interveners list
     * @return return the new modified list with participant field filled with ordinal number + Titular string: 1 Titular.
     */
    @Deprecated(since = "")
    List<Intervener> fillAndSortFilterIntervenerParticipantField(List<Intervener> interveners);

    /**
     * Return all interventions codes and names configured into application.yaml under key:
     * intervenerFilters.*.filters:
     *
     *
     * Ej: Disscounts product has 44 code as TITULAR with filter equals OWN
     * @param filter references to participant type value (OWN,ALL) {@link CustomerProductQueryParams}
     * @param application references to application name param value (ADN360, PSD2, NWE,..) {@link ProductQueryParams}
     * @return a Map whose Key is intervention code and its Value is then convention intervention name
     *
     *
     * Ej: If filter is "OWN" the method return this map {01=Titular,44=Titular}
     */
    Map<String, String> findInterventionCodes(String filter, String application);

    /**
     * Return all interventions codes and names configured into application.yaml under key:
     * intervenerFilters.*.filters:
     *
     * This method use "default" value as application configuration
     *
     * Ej: Disscounts product has 44 code as TITULAR with filter equals OWN
     * @param filter references to participant type value (OWN,ALL) {@link CustomerProductQueryParams}. If filter is
     * null then it will be applied "own" value as configuration.
     * @return a Map whose K is intervention code and V is convention intervention name
     *
     *
     * Ej: If filter is "OWN" the method return this map {01=Titular,44=Titular}
     */
    Map<String, String> findInterventionCodes(String filter);

    /**
     * Return interventions codes for "own" filter and application "default".
     *
     * @return a Map in K is intervention code and V is convention intervention name, for OWN filter
     *
     */
    Map<String, String> findInterventionCodes();

}
