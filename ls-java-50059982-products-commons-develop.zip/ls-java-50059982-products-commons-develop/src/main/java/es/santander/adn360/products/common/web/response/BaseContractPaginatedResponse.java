package es.santander.adn360.products.common.web.response;

import es.santander.adn360.core.model.exception.FunctionalException;
import es.santander.adn360.core.util.ExceptionEnum;
import es.santander.adn360.core.util.PaginatedResponse;
import es.santander.adn360.products.common.domain.entity.BaseContract;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.List;
import java.util.OptionalInt;
import java.util.stream.IntStream;

/**
 * Base contract paginated response
 *
 * @param <T>
 *            abtract param
 */
@Slf4j
public abstract class BaseContractPaginatedResponse<T extends BaseContract> implements PaginatedResponse<T, String> {

	private static final int CONTRACT_LENGTH = 18;
	private static final String DEFAULT_OFFSET = "0";

	/**
	 * Get paginated field
	 *
	 * @return list
	 */
	@Override
	public abstract List<T> getPaginatedField();

	/**
	 * Set paginated field
	 *
	 * @param paginatedField
	 *            field to set
	 */
	@Override
	public abstract void setPaginatedField(List<T> paginatedField);

	/**
	 * Get offset
	 *
	 * @param id
	 *            id
	 * @return long offset
	 */
	@Override
	public Long getOffsetById(String id) {
		if (StringUtils.isEmpty(id) || DEFAULT_OFFSET.equalsIgnoreCase(id)) {
			return 0L;
		}

		OptionalInt value = IntStream.range(0, getPaginatedField().size())
				.filter(i -> id.equalsIgnoreCase(getPaginatedField().get(i).getIdContrato())).findFirst();

		if (!value.isPresent()) {
			throw new FunctionalException(ExceptionEnum.INVALID_INPUT_PARAMETERS,
					"Pagination: Get index by 'Offset' parameter no data found.");
		}

		return (long) value.getAsInt();
	}

	/**
	 * Get id offset
	 *
	 * @param offset
	 *            long offset
	 * @return id
	 */
	@Override
	public String getIdByOffset(Long offset) {
		try {
			return getPaginatedField().get(offset.intValue()).getIdContrato();
		} catch (Exception e) {
			throw new FunctionalException(e, ExceptionEnum.INTERNAL_SERVER_ERROR,
					"Pagination: Get id by 'Offset' index throws error.");
		}
	}

	/**
	 * Check is valid or not the input id offset
	 *
	 * @param id
	 *            offset
	 * @return true or false
	 */
	@Override
	public boolean isValidOffset(String id) {
		try {
			return StringUtils.isEmpty(id) || DEFAULT_OFFSET.equalsIgnoreCase(id) || CONTRACT_LENGTH == id.length();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			return false;
		}
	}
}
