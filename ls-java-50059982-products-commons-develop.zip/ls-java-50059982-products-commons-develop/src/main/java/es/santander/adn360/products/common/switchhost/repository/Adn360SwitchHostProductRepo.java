package es.santander.adn360.products.common.switchhost.repository;

import es.santander.adn360.core.util.CustomerProductQueryParams;
import es.santander.adn360.mongodb.starter.domain.QueryParams;

import java.util.Map;

/**
 * Adn360SwitchHostProductRepo
 */
public interface Adn360SwitchHostProductRepo {
    /**
     * Find information by customer id
     *
     * @param params query params
     * @param customerProductQueryParams customer params
     * @param responsetype abstract extra info
     * @return T abstract info
     */
    <T> T findByCustomerId(
            QueryParams params,
            CustomerProductQueryParams customerProductQueryParams,
            Class<T> responsetype
    );

    /**
     * Find information by customer id
     *
     * @param params    query params
     * @param customerProductQueryParams    customer params
     * @param responsetype abstract extra info
     * @param extraParams extra params
     *
     * @return  abstract info
     */
    <T> T findByCustomerId(
            QueryParams params,
            CustomerProductQueryParams customerProductQueryParams,
            Class<T> responsetype,
            Map<String, String> extraParams
    );

    /**
     * Get aggregations
     *
     * @param params  params
     * @param customerProductQueryParams customerProductQueryParams
     * @param responsetype response
     * @return abstract aggregations
     */
    <K> K getAggregations(
            QueryParams params,
            CustomerProductQueryParams customerProductQueryParams,
            Class<K> responsetype
    );
    /**
     * Get aggregations
     *
     * @param params  params
     * @param customerProductQueryParams customerProductQueryParams
     * @param responsetype abstract
     * @param extraParams extra params
     * @return abstract aggregations
     */
    <K> K getAggregations(
            QueryParams params,
            CustomerProductQueryParams customerProductQueryParams,
            Class<K> responsetype,
            Map<String, String> extraParams
    );
}
