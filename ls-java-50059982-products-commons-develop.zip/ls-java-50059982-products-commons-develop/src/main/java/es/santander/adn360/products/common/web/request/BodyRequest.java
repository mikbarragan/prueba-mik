package es.santander.adn360.products.common.web.request;

import io.swagger.v3.oas.annotations.Parameter;
import lombok.Builder;
import lombok.Data;

import jakarta.validation.constraints.Pattern;
import java.util.List;

/**
 * Request model
 */
@Data
@Builder
public class BodyRequest {
    @Parameter(description = "List of hidden contracts.")
    private List<@Pattern(regexp = "^[0-9]{18}$") String> hideContracts;

}
