package es.santander.adn360.products.common.multichannel.annotation;

import es.santander.adn360.products.common.multichannel.processors.MultiChannelProcessor;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;


/**
 * Anotación que permite recibir una lista de clases que se utilizarán como procesadores para
 * actualizar la información para un canal concreto
 *
 * */
@Retention(RetentionPolicy.RUNTIME)
@Target(value = {ElementType.METHOD})
public @interface MultiChannelPostProcessor {
    /**
     * Valor por defecto
     * @return  procesador
     */
    Class<? extends MultiChannelProcessor>[] value() default {};

}
