package es.santander.adn360.products.common.util;

import es.santander.adn360.products.common.domain.entity.BaseContract;
import es.santander.adn360.products.common.domain.entity.RiskSituation;
import lombok.val;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

/**
 * Aggregation utils
 */
public class AggregationUtils {

    /**
     * Private constructor
     * to prevent instantiate object
     */
    private AggregationUtils() {
        // Add private constructor
    }

    /**
     * Get Max GSI in contracts list.
     *
     * @param contracts contract list
     * @return RiskSituation
     */
    public static RiskSituation getMaxRiskSituation(List<? extends BaseContract> contracts) {
        val contract = Collections
                .max(contracts, Comparator.comparing(c ->
                                Optional.ofNullable(c.getSituacionGSI())
                                        .map(RiskSituation::getId)
                                        .orElse(0),
                        Comparator.nullsLast(Comparator.naturalOrder())));

        return Optional.ofNullable(contract.getSituacionGSI())
                .filter(s -> s.getId() != null)
                .orElse(RiskSituation.builder()
                        .id(0)
                        .situacion("NR")
                        .build());
    }
}
