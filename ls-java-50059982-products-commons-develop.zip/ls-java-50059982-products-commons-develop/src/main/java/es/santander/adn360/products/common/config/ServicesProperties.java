package es.santander.adn360.products.common.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import java.util.List;
import java.util.Map;

/**
 * Services
 * Properties
 */
@Data
@Configuration
@ConfigurationProperties(prefix = "services")
@PropertySource("classpath:/products-common.properties")
@RefreshScope
public class ServicesProperties {

    /**
     * productGroupsService
     */
    private final ProductGroupService productGroupsService = new ProductGroupService();

    /**
     * currenciesService
     */
    private final CurrenciesService currenciesService = new CurrenciesService();

    /**
     * customersService
     */
    private final CustomersService customersService = new CustomersService();

    /**
     * customersPhoneService
     */
    private final CustomersPhoneService customersPhoneService = new CustomersPhoneService();

    /**
     * managedPortfolioService
     */
    private final ManagedPortfolioService managedPortfolioService = new ManagedPortfolioService();

    /**
     * Product Group Service
     */
    @Data
    public static class ProductGroupService {
        private String productGroupsUri;
        private String productGroupUri;
        private String productsUri;
        private String catalogUri;
        private String productUri;
        private String cacheCron;
        private String cacheSpec;
    }

    /**
     * Currencies Service
     */
    @Data
    public static class CurrenciesService {
        private String currenciesUri;
    }

    /**
     * Customers Service
     */
    @Data
    public static class CustomersService {
        private String customersUri;
    }

    /**
     * Customers Phone Service
     */
    @Data
    public static class CustomersPhoneService {
        private String uri;
    }

    /**
     * ManagedPortfolioService
     */
    @Data
    public static class ManagedPortfolioService {
    	private String endpoint;
    	private List<String> tiposCartera;
        private List<String> carterasConGestion;
        private List<String> carterasSinGestion;
        private Map<String, List<String>> portfolioFilterTypeValues;
    }

}
