package es.santander.adn360.products.common.domain;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.time.LocalDate;

/**
 * Person model
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "#{@commonMongoCollectionsProperties.getPerson()}")
public class Person {
	/**
	 * tipo persona
	 */
	@Field("tipoPersona")
	@Schema(description = "Person type")
	private String type;
	/**
	 * codigoPersona
	 */
	@Field("codigoPersona")
	@Schema(description = "Person code")
	private String code;
	/**
	 * nombrePersona
	 */
	@Field("nombrePersona")
	@Schema(description = "Person name")
	private String name;
	/**
	 * codDocumento
	 */
	@Field("codDocumento")
	@Schema(description = "Document code")
	private String idNumber;
	/**
	 * tipoDocumento
	 */
	@Field("tipoDocumento")
	@Schema(description = "Document type")
	private String idType;
	/**
	 * Cuenta banesto - check true or false
	 */
	@Field("cuentaBanesto")
	@Schema(description = "Banesto account", example = "false")
	private Boolean banesto;
	/**
	 * segmento
	 */
	@Field("segmento")
	@Schema(description = "Segment")
	private String segment;
	/**
	 * fechaBaja
	 */
	@Field("fechaBaja")
	@Schema(description = "Due date")
	private LocalDate dueDate;
	/**
	 * empresa
	 */
	@Field("empresa")
	@Schema(description = "Company")
	private String company;

}
