package es.santander.adn360.products.common.service;

import es.santander.adn360.products.common.domain.IntervenerInfo;
import es.santander.adn360.products.common.domain.repository.IntervenerInfoRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import jakarta.annotation.PostConstruct;
import java.util.Optional;

/**
 * Intervener Info Service
 */
@Slf4j
@Service
public class IntervenerInfoServiceImpl implements IntervenerInfoService {

    /** Repo */
    private final IntervenerInfoRepository repository;

    /**
     * Constructor
     *
     * @param repository repo
     */
    public IntervenerInfoServiceImpl(final IntervenerInfoRepository repository) {
        this.repository = repository;
    }

    /**
     * Init Cache
     */
    @PostConstruct
    public void initCache() {
        this.repository.findAllAsMap();
    }

    /**
     * Find nombre by tipo
     *
     * @param tipo to find
     * @return nombre optional
     */
    @Override
    public Optional<IntervenerInfo> findByTipo(final String tipo) {

        if (! StringUtils.hasText(tipo)) {
            return Optional.empty();
        }

        return Optional.ofNullable(this.repository.findAllAsMap().get(tipo));
    }

    /**
     * Find nombre by tipo
     *
     * @param tipo to find
     * @return nombre optional
     */
    @Override
    public Optional<String> findNombreByTipo(final String tipo) {

        return this.findByTipo(tipo)
                .map(IntervenerInfo::getNombreIntervencion);
    }

    /**
     * Clean cache
     */
    @CacheEvict(
            cacheNames = { "tipoNombreIntervenersMap" },
            allEntries = true
    )
    @Override
    public void cleanCache() {
        log.info("Cleaned IntervenerInfoService chache");
    }
}
