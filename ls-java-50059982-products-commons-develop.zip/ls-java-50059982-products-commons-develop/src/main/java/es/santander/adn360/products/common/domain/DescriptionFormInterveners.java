package es.santander.adn360.products.common.domain;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.Document;

import java.io.Serial;
import java.io.Serializable;
import java.util.Objects;

/**
 * Descriptions for
 * participants forms
 *
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "#{@commonMongoCollectionsProperties.getDescripcionesFormaIntervencion()}")
public class DescriptionFormInterveners implements Serializable {

	/**
	 * Generated serial version UID
	 */
	@Serial
	private static final long serialVersionUID = 1L;

	/**
	 * Participant form
	 */
	@Schema(description = "Participant form", example = "01")
	private String formaIntervencion;
	/**
	 * Participant name
	 */
	@Schema(description = "Description for participant form")
	private String descripcion;

	/**
	 * Equal method
	 * @param o object to compare
	 * @return if is equal or no
	 */
	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		DescriptionFormInterveners that = (DescriptionFormInterveners) o;
		return Objects.equals(formaIntervencion, that.formaIntervencion);
	}

	/**
	 * Hash code
	 * @return int hash
	 */
	@Override
	public int hashCode() {
		return Objects.hash(formaIntervencion);
	}
}
