package es.santander.adn360.products.common.domain.entity;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Adress Customer model
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class CustomerAddress {
    /**
     * tipo de via
     */
     @Schema(description = "Customer address type")
    private String addressType;
    /**
     * nombre de la via
     */
     @Schema(description = "Address name")
    private String addressName;
    /**
     * numero de la via
     */
     @Schema(description = "Address number")
    private String number;
    /**
     * ciudad de la direccion del cliente
     */
     @Schema(description = "Address city")
    private String city;


}
