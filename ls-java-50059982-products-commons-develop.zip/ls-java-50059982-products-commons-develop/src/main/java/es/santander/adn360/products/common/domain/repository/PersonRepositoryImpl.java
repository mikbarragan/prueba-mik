package es.santander.adn360.products.common.domain.repository;

import es.santander.adn360.mongodb.starter.autoconfigure.MongoQueryRepositoryAutoConfiguration;
import es.santander.adn360.mongodb.starter.domain.MongoQueryRepositoryImpl;
import es.santander.adn360.products.common.domain.Person;
import es.santander.adn360.products.common.domain.entity.Intervener;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.repository.support.MongoRepositoryFactory;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

import static java.util.stream.Collectors.toMap;

/**
 * PersonRepository implementation.
 *
 * nonsense commentary to comply with a nonsense rule
 * nonsense commentary to comply with a nonsense rule
 * nonsense commentary to comply with a nonsense rule
 * nonsense commentary to comply with a nonsense rule
 *
 */
@ConditionalOnClass(MongoQueryRepositoryAutoConfiguration.class)
@Repository
public class PersonRepositoryImpl extends MongoQueryRepositoryImpl<Person, String> implements PersonRepository {

    /**
     * Constructor
     * @param mongoRepositoryFactory mongoRepositoryFactory
     * @param mongoOperations mongoOperations
     */
    public PersonRepositoryImpl(
            final MongoRepositoryFactory mongoRepositoryFactory,
            final MongoOperations mongoOperations
    ) {
        super(mongoRepositoryFactory.getEntityInformation(Person.class), mongoOperations);
    }

    /**
     * Find one person by type and code
     * @param type Type
     * @param code Code
     * @return found person
     */
    @Override
    public Person findOneByTypeAndCode(
            final String type,
            final String code
    ) {
        final var criteria = Criteria.where("type").is(type).and("code").is(code);

        return this.findAll(null, criteria)
                .getContent().stream()
                .findFirst()
                .orElse(null);
    }

    /**
     * Find person by type, code and company
     * @param type Type
     * @param code Code
     * @param company Company
     * @return found person
     */
    @Override
    public Person findOneByTypeAndCodeAndCompany(
            final String type,
            final String code,
            final String company
    ) {
        return this.findAll(null, this.matchData(type, code, company)).getContent().stream()
                .findFirst()
                .orElse(null);
    }

    /**
     * Find by intervener list
     * @param interveners Intervener list.
     * @return list of persons
     */
    @Override
    public List<Person> findByIntervenerList(final List<Intervener> interveners) {

        if (CollectionUtils.isEmpty(interveners)) {
            return Collections.emptyList();
        }

        final var filters = interveners.stream()
                .map(Intervener::getIdCliente)
                .filter(StringUtils::hasText)
                .distinct()
                .map(idClient -> Criteria
                        .where("type").is(idClient.substring(0, 1))
                        .and("code").is(idClient.substring(1)))
                .toArray(Criteria[]::new);

        return this.findAll(null, new Criteria().orOperator(filters)).getContent();
    }

    /**
     * findAsMapByInterveners
     * @param interveners to find
     * @return map
     */
    @Override
    public Map<String, Person> findAsMapByInterveners(final List<Intervener> interveners) {

        if (CollectionUtils.isEmpty(interveners)) {
            return Collections.emptyMap();
        }

        final var filters = interveners.stream()
                .map(Intervener::getIdCliente)
                .filter(StringUtils::hasText)
                .distinct()
                .map(idClient -> Criteria
                        .where("type").is(idClient.substring(0, 1))
                        .and("code").is(idClient.substring(1)))
                .toArray(Criteria[]::new);

        return this.findAll(null, new Criteria().orOperator(filters)).stream()
                .collect(toMap(
                        person -> person.getType() + person.getCode(),
                        Function.identity(),
                        (existing, replacement) -> existing
                ));
    }

    /**
     * Funtion that match the person Query
     *
     * @param type . PersonType
     * @param  code . Person code
     *
     * @return  criteria.
     *
     * */
    private Criteria matchData(
            final String type,
            final String code,
            final String company
    ) {
       return Criteria.where("type").is(type)
                        .and("code").is(code)
                        .and("company").is(company);
    }
}
