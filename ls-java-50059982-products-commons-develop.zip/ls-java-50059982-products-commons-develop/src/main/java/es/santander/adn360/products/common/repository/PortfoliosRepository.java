package es.santander.adn360.products.common.repository;

import es.santander.adn360.core.util.CustomerProductQueryParams;
import es.santander.adn360.products.common.domain.PortfolioType;

import java.util.List;

/**
 * PortfoliosRepository
 */
public interface PortfoliosRepository {

    /**
     * Funcion que llama al micro de carteras con ids contratos que devuelve los ids junto con sus typos
     * sigas respectivos
     *
     * @param contracts Contracts List of contracts
     * @param customerProductQueryParams Customer query string
     * @return List contracts filtered by managed portfolio type configured
     */
    List<PortfolioType> callToPortfolios(List<String> contracts, CustomerProductQueryParams customerProductQueryParams);

    /**
     * Method needed to clean currencies cache.
     */
    void cleanCache();
}
