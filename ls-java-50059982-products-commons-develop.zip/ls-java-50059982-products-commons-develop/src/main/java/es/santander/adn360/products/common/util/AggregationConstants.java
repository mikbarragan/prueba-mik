package es.santander.adn360.products.common.util;

/**
 * Aggregation constants
 */
public final class AggregationConstants {

    /**
     * DRAWN_FIELD
     */
    public static final String DRAWN_FIELD = "drawnBalance";
    /**
     * DRAWN_TITLE
     */
    public static final String DRAWN_TITLE = "Saldo Dispuesto";
    /**
     * LIMIT_FIELD
     */
    public static final String LIMIT_FIELD = "limit";
    /**
     * LIMIT_TITLE
     */
    public static final String LIMIT_TITLE = "Límite";
    /**
     * AVAILABLE_FIELD
     */
    public static final String AVAILABLE_FIELD = "availableBalance";
    /**
     * AVAILABLE_TITLE
     */
    public static final String AVAILABLE_TITLE = "Disponible";
    /**
     * GSI_FIELD
     */
    public static final String GSI_FIELD = "GSI";
    /**
     * GSI_TITLE
     */
    public static final String GSI_TITLE = "GSI";
    /**
     * BALANCE_FIELD
     */
    public static final String BALANCE_FIELD = "balance";
    /**
     * BALANCE_TITLE
     */
    public static final String BALANCE_TITLE = "Saldo";
    /**
     * REMUNERATION_FIELD
     */
    public static final String REMUNERATION_FIELD = "remuneration";
    /**
     * REMUNERATION_TITLE
     */
    public static final String REMUNERATION_TITLE = "Remuneración";
    /**
     * SITUATION_NO_RISK
     */
    public static final String SITUATION_NO_RISK = "NR";

    private AggregationConstants() {
    }
}
