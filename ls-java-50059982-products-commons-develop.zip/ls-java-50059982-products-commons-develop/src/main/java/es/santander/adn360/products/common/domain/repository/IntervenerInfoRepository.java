package es.santander.adn360.products.common.domain.repository;

import es.santander.adn360.products.common.domain.IntervenerInfo;
import es.santander.adn360.products.common.domain.entity.Intervener;

import java.util.List;
import java.util.Map;

/**
 * IntervenerInfoRepository interface
 */
public interface IntervenerInfoRepository {

	/**
	 * Find all inverneners
	 *
	 * @return list of intervener
	 */
	List<IntervenerInfo> findAll();
	
	/**
	 * Get intervener info (tipoIntervencion, nombreIntervencion) for interveners
	 * @param interveners Interveners list
	 * @return IntervenerInfo list
	 */
	List<IntervenerInfo> findByIntervenerList(List<Intervener> interveners);
	
	/**
	 * Get intervener info (tipoIntervencion, nombreIntervencion) associated intervener type
	 * 
	 * @param intervenerType intervener type
	 * @return IntervenerInfo information about type and description 
	 */
	IntervenerInfo findByIntervenerType(String intervenerType);

	/**
	 * Find all tipo-nombre map
	 *
	 * @return tipo-nombre map
	 */
	Map<String, IntervenerInfo> findAllAsMap();


}
