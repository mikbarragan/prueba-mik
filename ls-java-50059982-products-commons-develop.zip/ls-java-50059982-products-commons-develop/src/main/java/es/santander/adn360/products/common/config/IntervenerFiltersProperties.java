package es.santander.adn360.products.common.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * class dedicated to obtaining intervener filters configuration properties
 *
 * @author Santander Tecnologia
 */
@Data
@Configuration
@ConfigurationProperties(prefix = "intervener-filter")
@PropertySource("classpath:/products-common.properties")
@RefreshScope
public class IntervenerFiltersProperties {

    /**
     * Listado de código para propietarios y t0dos
     * - Listado por defecto sin canal ni aplicación.
     */
    private List<String> own;

    /**
     * All intervineer filter types
     */
    private List<String> all;

    /**
     * Channel map
     */
    private Map<String, Channel> channel;

    /**
     * Intervener configuration available per channel.
     *
     */
    @Data
    public static class Channel {
        private final List<ApplicationCfg> application = new ArrayList<>();
    }

    /**
     * Intervener configuration available per application.
     *
     */
    @Data
    public static class ApplicationCfg {
        private String name;
        private Map<String, List<String>> filters;
    }

}
