package es.santander.adn360.products.common.domain.bean;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Data;

/**
 * Risk bean model
 */
@Data
@Builder
public class RiskBean {

	/**
	 * Situation id
	 */
	@Schema(description = "Situation id", example = "20")
	private Integer situationId;

	/**
	 * Situation description
	 */
	@Schema(description = "Situation description", example = "DS")
	private String situation;

}
