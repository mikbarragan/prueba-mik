## Release 8.0.0
* [ESPC360-11897](https://sanes.atlassian.net/browse/ESPC360-11897)__
  * [Migrar Darwin 4.x] ls-java-50059982-products-commons
## Release 7.2.9 (3.179.0)
* [ESPC360-9117](https://sanes.atlassian.net/browse/ESPC360-9117)
  * [Global PG] - Incluir los productos carterizados sin tipología dentro del filtro resto de tipologías
## Release 7.2.8 (3.178.0)
* [ESPC360-8570](https://sanes.atlassian.net/browse/ESPC360-8570)
  * [Global PG] - Incluir el resto de tipologías en el filtro de contratos carterizados
## Release 7.2.5
* [CACHE] Se incluye Serializable a clase IntervenerInfo.
## Release 7.2.4
* [ESPC360-6348](https://sanes.atlassian.net/browse/ESPC360-6348)
  * Se incluye el campo indicadorProducto en el modelo ContractInfo
## Release 7.2.3
  * [CACHE] - Se añade configuración de caches datagrid en application.yml.
## Release 7.2.2
* [ESPC360-7580](https://sanes.atlassian.net/browse/ESPC360-7580)
  * Se hace público el método de filtrado de carteras por tipo
## Release 7.2.1
* [ESPC360-5203](https://sanes.atlassian.net/browse/ESPC360-5203)
  * [CACHE] - Optimizar caché librería product-commons

## Release 7.1.0
* __[ESPC360-7600](https://sanes.atlassian.net/browse/ESPC360-7600)
  * Se habilita un nuevo filtro que mejora al actual del tipo de carteras

## Release 7.0.1
* Hotfix: parallelStream is changes with stream
## Release 7.0.0
* [ESPC360-4277](https://sanes.atlassian.net/browse/ESPC360-4277)
  * Implementación reactiva parcial

## Release 6.0.4
* Hotfix: parallelStream is changed with stream
## Release 6.0.3
* Hotfix: use core version with RestTemplate original Darwin client restablished

## Release 3.165.0
* [PORTALADN-38898](https://sanes.atlassian.net/browse/PORTALADN-38898)
  * Integrar migraciones Darwin 3.2 (1/2)

## Release 3.159.0
* [ESPC360-1115](https://sanes.atlassian.net/browse/ESPC360-1115)
  * Renombrado micro Customers

## Release 3.148.0
* [PORTALADN-35475](https://sanes.atlassian.net/browse/PORTALADN-35475)
  * Posición Inversión Valores (listado): Devolver la descripción de la cartera a la que pertenece
## Release 3.146.0
* [PORTALADN-34901](https://sanes.atlassian.net/browse/PORTALADN-34901)
  * Marca contratos PMP

## Release 4.1.27
* [#29987] Nexus (2022) Cuentas: Listado de cuentas relacionadas por producto
## Release 4.1.26
* [#29797] Disponibilizar fecha de alta en intervinientes
## Release 4.1.23
* [#28326] Optimizar resolución nombres de intervinientes
## Release 4.1.21
* Se permite devolver un titular de contrato con orden de intervencion cualquiera
## Release 4.1.19
* Se depreca el metodo fillAndFilterIntervenerParticipantAndFormFields para usar fillAndFilterIntervenerParticipantFields
con la misma funcionalidad heredada.
## Release 4.1.18
* Ahora se filtran las carteras por fecha de relación y tipo de contrato.
## Release 4.1.17
* [#29325] Se actualiza a adn360-core:3.0.16
## Release 4.1.14
* [#29198] Ahora cachea las consultas a las descripciones de forma de intervención.
## Release 4.1.13
* [#29007] Error filtro tipo cartera: Ahora no se mostraran las carteras BJ
## Release 4.1.12
* [#28811] Bug fix para corregir el comportamiento del filtro/servicio de carteras, cuando se usa su valor ALL.
## Release 4.1.11
* Se modifica el servicio findInterventionCodes para que en caso de buscar por un filtro que no se encuentre en la
configuración del producto, devuelva un mapa por defecto {"-1":"nothing"} evitando devolver una functional exception. El
error se quedara registrado en los logs.
## Release 4.1.11
* [#27730] Unicorn Fondos: Se amplia el filtro de contratos por cartera: ANYPORTFOLIO|MANAGED|UNMANAGED|NONE|ALL|DEFAULT
## Release 4.1.8
* Fix sobre el seteo del atributo siga a nivel de contrato, en concreto cuando se usa la nueva funcionalidad
de filtrar por tipo de cartera.
## Release 4.1.7
* Se incrementa la capacidad de la caché de products-groups ya que se ha identificado que no es suficiente y está provocando excesivas llamadas al micro adn360-product-groups.
## Release 4.1.5
* Se detecta que no siempre se puede modificar la cabecera con un filtro y se cambia a ControllerAdvice
## Release 4.1.4
* Se mejora el filtro de limite tecnico para que muestre información cuando mostramos menos información debido a que salta
un circuit breaker.
## Release 4.1.2
* [#255446] El filtro de carteras recibe parametro para poder filtrar no solo por las gestionadas si no poder obtener el resto
## Release 4.1.1
* Utilidad limite tecnico en numero de contratos mostrados
## Release 4.1.0
* Modificacion en getProductCriteria para que acepte una lista de customerId
## Release 4.0.11
* Utilidad para contratos ocultos
## Release 4.0.10
* Se recupera el generico para PorfolioService
## Release 4.0.9
* [#23142] Se añade metodo para rellenar la descripción de la forma de intervención en 
los participantes y se deja la funcion original como en versiones anteriores a 4.0.6
Control forma de intervencion nula.
## Release 4.0.6
* [#23142] Se añade la descripción de la forma de intervención a los participantes.
  
## Release 4.0.6
* [fix-22868] Se cambia el comportamiento de PortfoliosRepository.callToPortfolios en vez de GET ahora es POST y 
su URI tambien cambia /managed_portfolios/v1/types?...(se añade versionado de api)
## Release 4.x
* Migración a Darwin y Java 11

## Release 3.4.11
* [#23142] Se añade la descripción de la forma de intervención a los participantes.

## Release 3.4.10
* [fix-22868] Se cambia el comportamiento de PortfoliosRepository.callToPortfolios en vez de GET ahora es POST y su URI tambien cambia 
  /managed_portfolios/v1/types?...
## Release 3.4.8
* [fix-23430] Se cambia el comportamiento de IntervenerService.findIntervenerInfoByContracts para que no devuelva 
intervenciones duplicadas ni cachee ya que llama a un método ya cacheado.
  
## Release 3.4.7
* [fix-23160] Se añade la cantidad de un cambio cuando no viene el cambio, 
  para que al menos siempre se tenga la cantidad

## Release 3.4.6
* [fix] Vuelta a uso de genericos

## Release 3.4.0
* [#19100] Include "usuariosEmpresas" attribute to BaseContract model

## Release 3.3.11
* [#16339] Removed address and phones customers caches
 
## Release 3.3.10
* [#16339] Added new feature to customer service to retrieve shipping address associated to customer address code. 
~~~ 
../customers/F026239524?address_code=1
~~~ 

## Release 3.3.9
* [#20324] Se evoluciona la solución de búsqueda de códigos de intervinientes para que se pueda tener una por defecto.

## Release 3.3.8
* [#17218] Se añade la configuración global y por defecto de la situación de los contratos, lectura de 
los application.yml de cada uno de los micros que hagan uso de ello.

## Release 3.3.7
* [#16997] Added new service to call product groups by related product and subproduct
