# ADN 360: Funciones comunes entre Productos
[![Quality Gate Status](https://sonar.alm.europe.cloudcenter.corp/sonar/api/project_badges/measure?project=SANES%3Asanes-adn360%3ASUA%3Aadn360-products-common&metric=alert_status)](https://sonar.alm.europe.cloudcenter.corp/sonar/dashboard?id=SANES%3Asanes-adn360%3ASUA%3Aadn360-products-common)
[![Coverage](https://sonar.alm.europe.cloudcenter.corp/sonar/api/project_badges/measure?project=SANES%3Asanes-adn360%3ASUA%3Aadn360-products-common&metric=coverage)](https://sonar.alm.europe.cloudcenter.corp/sonar/dashboard?id=SANES%3Asanes-adn360%3ASUA%3Aadn360-products-common)

Library with common functionality for product microservices.

* Hierarchies services.
* Currency services.
* Common Product models.
* Common Product constants.
# Releases 
## release 5.1.0
* Migrated to darwin 3.x
## release 2.5
* Se añade el campo "estado" en el BaseContract, por tanto los micros deben incorporar ese nuevo campo en sus constructores
* Se crea una nueva configuración para el filtro de intervinientes. Hay que actualizar la configuración de cada micro y modificar las capas de repo y servicio que hacen uso del servicio de intervinientes. (ver micros adaptados)

## Getting Started
### Prerequisites

To config a development environment, we must follow these [steps](https://confluence.ci.gsnet.corp/display/ADN360PORTAL/%5BMS-BACK%5D+Entorno+de+desarrollo)

```
[MS-BACK] Entorno de desarrollo
```

### Installing

To use the library, just add the dependency in the file pom

```
    <dependencies>
        <dependency>
            <groupId>es.santander</groupId>
            <artifactId>adn360-products-common</artifactId>
            <version>${adn360-products-common.version}</version>
        </dependency>
        ...
    </dependencies>
```

Configuration properties that can be overriden in microservices that use this library

```
    #Services properties
    services.productGroupsService.productGroupsUri=http://adn360-product-groups:8080/product_groups
    services.productGroupsService.productGroupUri=http://adn360-product-groups:8080/product_groups/%s
    services.productGroupsService.productsUri=http://adn360-product-groups:8080/product_groups/%s/products
    services.currenciesService.currenciesUri=http://adn360-exchange:8080/currencies
    services.currenciesService.cacheCron=0 30 15 * * ?
    
    #Hystrix commands properties
    hystrix.command.currenciesService.circuitBreaker.sleepWindowInMilliseconds=5000
    
    #Cache config
    spring.cache.cache-names=currencies
    spring.cache.caffeine.spec=maximumSize=500
```

## Built With

* [Nexus Repository Manager](https://nexus.alm.gsnetcloud.corp/) - Maven Dependency Management

## Versioning

For the versions available, see the [tags on this repository](https://gitlab.alm.gsnetcloud.corp/adn360posgob/adn360-products-common/tags). 

## Authors

* **Damian Junquera** - [@XI319166](https://gitlab.alm.gsnetcloud.corp/XI319166)
* **David Palomar** - [@XI330240](https://gitlab.alm.gsnetcloud.corp/XI330240)
* **Diego Casanova** - [@XI330112](https://gitlab.alm.gsnetcloud.corp/XI330112)
* **Javier Moreno** - [@XI321781](https://gitlab.alm.gsnetcloud.corp/XI321781)
* **Luis Ruzafa** - [@XI312225](https://gitlab.alm.gsnetcloud.corp/XI312225)
* **Misael Suriel** - [@XI330281](https://gitlab.alm.gsnetcloud.corp/XI330281)

See also the list of [contributors](https://gitlab.alm.gsnetcloud.corp/adn360posgob/adn360-products-common/graphs/development) who participated in this project.

